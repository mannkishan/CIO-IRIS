package page;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.SuperHelper;

import utility.CoreSuperHelper;

/*
'Revision History
'#############################################################################
'@rev.On	@rev.No		@rev.By				  @rev.Comments
'										
'#############################################################################
*/

/**
 * <Add description here>
 * 
 * @author <Author name>
 * @since <Creation date>
 *
 */


public class ZonePage extends SuperHelper {

	private static ZonePage thisIsTestObj;

	// So that there only one object accesses this class at any moment
	public synchronized static ZonePage get() {
		thisIsTestObj = PageFactory.initElements(driver, ZonePage.class);
		return thisIsTestObj;
	}

	@FindBy(how=How.XPATH,using="//table[@id = 'menuTable']/tbody/tr[3]/td/a")
	public WebElement centralZoneLink;
	
	}
