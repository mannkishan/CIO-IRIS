package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.SuperHelper;

/*
'Revision History
'#############################################################################
'@rev.On	@rev.No		@rev.By				  @rev.Comments
'										
'#############################################################################
*/

/**
 * Page: LoginPage<p>
 * Page Object Model Sample<p>
 * Please refer this page while creating other page object models
 * 
 * @author TP&E 
 * @since 14-July-2017
 *
 */
public class LoginPage extends SuperHelper {

	private static LoginPage thisIsTestObj;

	// So that there only one object accesses this class at any moment
	public synchronized static LoginPage get() {
		thisIsTestObj = PageFactory.initElements(driver, LoginPage.class);
		return thisIsTestObj;
	}

	// Recommended model for all objects
	@FindBy(how = How.NAME, using = "j_username")
	@CacheLookup
	public WebElement userNameField;
	
	@FindBy(how = How.NAME, using = "j_password")
	@CacheLookup
	public WebElement password;
	
	// in case you want to use XPATH
	@FindBy(how = How.XPATH, using = "//Button[@type='submit']")
	@CacheLookup
	public WebElement submit;


	/**
	 * Logs into the application
	 * @param userProfile
	 * @author TP&E
	 */
	public void loginApplication(String userProfile) {

		//getLoginInfo function provides the user id and password from the user profile
		String[] userInfo = getLoginInfo(userProfile);

		setUserName(userInfo[0]);

		setPassword(userInfo[1]);

		clickSubmit();
	}

	/**
	 * Sets user name
	 * @param strUserID User ID
	 * @author TP&E
	 */
	public void setUserName(String strUserID) {
		seSetUserId(userNameField, strUserID, "User Name");
	}

	
	/**
	 * Sets password
	 * @param strPasword encrypted password
	 * @author TP&E
	 */
	public void setPassword(String strPasword) {
		seSetPassword(password, strPasword, "Enter Password");
	}

	
	/**
	 * Clicks on Submit button
	 * @author TP&E
	 */
	public void clickSubmit() {
		seClick(submit, "Click Submit button");
	}

}
