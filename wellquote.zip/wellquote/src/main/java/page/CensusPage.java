package page;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import com.anthem.selenium.SuperHelper;
import com.anthem.selenium.constants.ApplicationConstants;
import com.anthem.selenium.utility.ExtentReportsUtility;
import utility.WellQuoteUtility;

/*
'Revision History
'#############################################################################
'@rev.On	@rev.No		@rev.By				  @rev.Comments
'										
'#############################################################################
*/

/**
 * <Add description here>
 * 
 * @author <Author name>
 * @since <Creation date>
 *
 */

public class CensusPage extends SuperHelper {

	private static CensusPage thisIsTestObj;

	// So that there only one object accesses this class at any moment
	public synchronized static CensusPage get() {
		thisIsTestObj = PageFactory.initElements(driver, CensusPage.class);
		return thisIsTestObj;
	}
	
	@FindBy(how = How.XPATH, using = "//table[@id='GroupView.tableTable']/tbody/tr[2]/td")
	@CacheLookup
	public static  WebElement header;
	
	@FindBy(how = How.XPATH, using = "//table[@id='CensusView']/tbody/tr[1]/td/table/tbody/tr/td[6]/select/option[1]")
	@CacheLookup
	public static  WebElement drpdownCensus;
	
	@FindBy(how = How.XPATH, using = "//table[@id='CensusView.censusPanel']/tbody/tr[3]/td/div/select/option[2]")
	@CacheLookup
	public static  WebElement drpdownCensusType;
	
	@FindBy(how = How.ID, using = "gwt-uid-33")
	@CacheLookup
	public  WebElement chkboxCopy;
	
	@FindBy(how = How.XPATH, using = "//table[@id='CensusView.copyFieldsTable']/tbody/tr[6]/td/button[@id='CensusView.copySelectAllButton']")
	@CacheLookup
	public  WebElement selectAll;
	
	@FindBy(how = How.XPATH, using = "//table/tbody/tr[7]/td/div/table/tbody/tr[3]/td[4]/input[@type='text']")
	@CacheLookup
	public  WebElement txtboxAge;
	
	@FindBy(how = How.XPATH, using = "//table/tbody/tr[7]/td/div/table/tbody/tr[3]/td[7]/input[@type='text']")
	@CacheLookup
	public  WebElement txtboxSex;
	
	@FindBy(how = How.XPATH, using = "//table/tbody/tr[7]/td/div/table/tbody/tr[3]/td[27]/input[@type='text']")
	@CacheLookup
	public  WebElement txtboxX;
	
	@FindBy(how = How.XPATH, using = "//table[@id='CommonView.rowButtonPanel']/tbody/tr/td[1]/button[@id='CensusView.addRowButton']")
	@CacheLookup
	public  WebElement btnInsertRow;
	
	@FindBy(how = How.XPATH, using = "//table[@id='CensusView']/tbody/tr[7]/td/div/table/tbody/tr[5]/td[3]/input[@type='text']")
	@CacheLookup
	public  WebElement table;
	
	@FindBy(how = How.XPATH, using = "//table[@id='CensusView.tableTable']/tbody/tr[1]/td[3]/table/tbody/tr[2]/td[2]")
	@CacheLookup
	public  WebElement totalEmpl;
	
	@FindBy(how = How.XPATH, using = "//table[@id='CensusView.tableTable']/tbody/tr[1]/td[3]/table/tbody/tr[1]/td[2]")
	@CacheLookup
	public static WebElement eligibleEmpl;
	
	@FindBy(how = How.XPATH, using = "//table[@id='CensusView.tableTable']/tbody/tr[1]/td[3]/table/tbody/tr[3]/td[2]")
	@CacheLookup
	public static  WebElement ratingTyp;
	
	@FindBy(how = How.XPATH, using = "//table[@id='GroupView.headerPanel']/tbody/tr/td[1]/div]")
	@CacheLookup
	public  WebElement pid;
	
	@FindBy(how = How.XPATH, using = "//table[@id='GroupView.headerPanel']/tbody/tr/td[3]/div]")
	@CacheLookup
	public static  WebElement renewal;
	
	@FindBy(how = How.XPATH, using = "//table[@id='GroupView.headerPanel']/tbody/tr/td[5]/div]")
	@CacheLookup
	public  WebElement effdate;
	
	@FindBy(how = How.XPATH, using = "//table[@id='GroupView.headerPanel']/tbody/tr/td[7]/div]")
	@CacheLookup
	public  WebElement census;
	
	@FindBy(how = How.XPATH, using = "//table[@id='GroupView.headerPanel']/tbody/tr/td[9]/div]")
	@CacheLookup
	public  WebElement ee;
	
	@FindBy(how = How.ID, using = "GroupView.pidLabel")
	@CacheLookup
	public WebElement PID;
	
	@FindBy(how = How.ID, using = "GroupView.newRenewalLabel")
	@CacheLookup
	public WebElement NewRenewal;
	
	@FindBy(how = How.ID, using = "GroupView.effectiveDateLabel")
	@CacheLookup
	public WebElement effectDate;
	
	@FindBy(how = How.ID, using = "GroupView.eligEmpLabel")
	@CacheLookup
	public WebElement eligEmpLabel;
	
	@FindBy(how = How.ID, using = "GroupView.groupNameLabel")
	@CacheLookup
	public WebElement GroupName;
	
	@FindBy(how = How.XPATH, using = "//div[@id='CensusView.censusType']/select/option[2]")
	@CacheLookup
	public WebElement censusType;
	
	@FindBy(how = How.ID, using = "CensusView.eligEmpLabel")
	@CacheLookup
	public  WebElement eligEmp;
	
	@FindBy(how = How.ID, using = "CensusView.ratingTypeLabel")
	@CacheLookup
	public WebElement Ratingtype;
	
	@FindBy(how = How.XPATH, using = "//span[@id='CensusView.ageEntryCheckBox']/input")
	@CacheLookup
	public WebElement ageCheckBox;
	
	@FindBy(how = How.XPATH, using = "//table/tbody/tr[7]/td/div/table/tbody/tr[3]/td[16]/input[@type='text']")
	public  WebElement txtHealth;
	
	@FindBy(how = How.XPATH, using = "//table/tbody/tr[7]/td/div/table/tbody/tr[3]/td[17]/input[@type='text']")
	public  WebElement txtDental;
	
	@FindBy(how = How.XPATH, using = "//table/tbody/tr[7]/td/div/table/tbody/tr[3]/td[18]/input[@type='text']")
	public  WebElement txtVision;
	
	@FindBy(how = How.ID, using = "gwt-uid-31")
	@CacheLookup
	public WebElement dobCheckBox;
	
	@FindBy(how = How.XPATH, using = "//table/tbody/tr[7]/td/div/table/tbody/tr[3]/td[15]/input[@type='text']")
	public  WebElement txtStatus;
	
	@FindBy(how = How.XPATH, using = "//table/tbody/tr[7]/td/div/table/tbody/tr[3]/td[19]/input[@type='text']")
	@CacheLookup
	public  WebElement txtLife;
	
	@FindBy(how = How.XPATH, using = "//table/tbody/tr[7]/td/div/table/tbody/tr[3]/td[20]/input[@type='text']")
	@CacheLookup
	public  WebElement txtClass;
	
	@FindBy(how = How.XPATH, using = "//table/tbody/tr[7]/td/div/table/tbody/tr[3]/td[26]/input[@type='text']")
	@CacheLookup
	public  WebElement txtZip;
	
	@FindBy(how = How.XPATH, using = "//table/tbody/tr[7]/td/div/table/tbody/tr[3]/td[27]/input[@type='text']")
	@CacheLookup
	public  WebElement txtX;
	
	@FindBy(how = How.ID, using = "CensusView.nextButton")
	@CacheLookup
	public WebElement censusviewNextbtn;
	
	@FindBy(how = How.ID, using = "LoadsView.nextButton")
	@CacheLookup
	public WebElement groupLoadNextbtn;
	
	@FindBy(how = How.XPATH, using = "//td[contains(text(),'Total Employees')]")
	@CacheLookup
	public WebElement totalEmployeeLable;
	
	@FindBy(how = How.ID, using = "YesNoDialog.yesButton")
	@CacheLookup
	public WebElement yesDiologCensus;
	
	@FindBy(how = How.ID, using = "CensusView.totalEmpLabel")
	@CacheLookup
	public WebElement totalEmp;
	

	/**
	 * @param verifyHeader
	 */
	public static  void verifyHeader()
	 {
		try{
			Thread.sleep(5000);
			String strCensusHeader = seGetText(header).toString().trim();
			System.out.println("strCensusHeader:"  +strCensusHeader);
			
			String strexpvalue="PID:\nTQ1713408\nNew/Renewal:\nNew\nEffective Date:\n01/01/2017\nCensus:\n0\nEE:\n55";
			
			if(!header.isDisplayed())
			{		
				ExtentReportsUtility.log(ApplicationConstants.FAIL , "Header  values are not present",
						"Verified Header is not present",true);

			}
			else{
				ExtentReportsUtility.log(ApplicationConstants.PASS , "Header values are present",
						"Verified Header is present",true);
			}  

		}catch(Exception e){
			e.printStackTrace();
		}
	}


	/**
	 * @author AF14733 The Method is used to verifyDropDownvalue
	 * @param strexpDropDownvalue which is fetched from the data sheet
	 * @throws Exception
	 */
	public static void verifyDropDownvalue(String strexpDropDownvalue) {
		try {
			String stractDropDownvalue = seGetElementValue(drpdownCensus).toString();
			System.out.println("stractDropDownvalue " + stractDropDownvalue);
			Thread.sleep(5000);
			if ((stractDropDownvalue.equalsIgnoreCase(strexpDropDownvalue))) {
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"DropDownvalue " + strexpDropDownvalue + " should be  present",
						"Verified DropDownvalue " + stractDropDownvalue + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"DropDownvalue " + strexpDropDownvalue + " not present",
						"Verified DropDownvalue " + stractDropDownvalue + " is NOT present", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @author AF14733 The Method is used to verifyDropDownvalue
	 * @param strexpDropDownvalue which is fetched from the data sheet
	 * @throws Exception
	 */
	public static void verifyDropDownvalueCensusType(String strexpDropDownvalueCensusType) {
		try {
			String stractCensusTypee = seGetElementValue(drpdownCensusType).toString();
			System.out.println("stractDropDownvalue " + stractCensusTypee);
			Thread.sleep(5000);
			if ((stractCensusTypee.equalsIgnoreCase(strexpDropDownvalueCensusType))) {
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"DropDownvalue " + strexpDropDownvalueCensusType + " should be  present",
						"Verified DropDownvalue " + stractCensusTypee + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"DropDownvalue " + strexpDropDownvalueCensusType + " not present",
						"Verified DropDownvalue " + stractCensusTypee + " is NOT present", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @author AF14733 The Method is used to verifyDropDownvalue
	 * @param strexpDropDownvalue which is fetched from the data sheet
	 * @throws Exception
	 */
	public static void verifyCheckBoxes() {
		try {
		boolean age= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Age']/preceding-sibling::input[@type='checkbox']")).isSelected();
		if(!age)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Age Checkbox  not selected","Verified Age Checkbox  NOT selected", true);
		}
		else 
		{
		ExtentReportsUtility.log(ApplicationConstants.PASS,
				"Age Checkbox should be present and  selected ","Verified Age CheckBox is  present  and is selected", true);
		}
		boolean Multiplier= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Multiplier']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!Multiplier)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Multiplier Checkbox  not selected","Verified Multiplier Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Multiplier Checkbox should be present and  selected ","Verified Multiplier CheckBox is  present  and is selected", true);
			}
		boolean SpDOB= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Sp DOB']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!SpDOB)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Sp DOB Checkbox  not selected","Verified Sp DOB Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Sp DOB Checkbox should be present and  selected ","Verified Sp DOB CheckBox is  present  and is selected", true);
			}
		boolean DOB= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='DOB']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!DOB)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"DOB Checkbox  not selected","Verified DOB Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"DOB Checkbox should be present and  selected ","Verified DOB CheckBox is  present  and is selected", true);
			}
		boolean SubName= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Sub Name']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!SubName)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Sub Name Checkbox  not selected","Verified Sub Name Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Sub Name Checkbox should be present and  selected ","Verified Sub Name CheckBox is  present  and is selected", true);
			}
		boolean Sex= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Sex']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!Sex)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Sex Checkbox  not selected","Verified Sex Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Sex Checkbox should be present and  selected ","Verified Sex CheckBox is  present  and is selected", true);
			}
		
		boolean SpAge= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Sp Age']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!SpAge)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Sp Age Checkbox  not selected","Verified Sp Age Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Sp Age Checkbox should be present and  selected ","Verified Sp Age CheckBox is  present  and is selected", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		boolean SpSex= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Sp Sex']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!SpSex)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Sp Sex Checkbox  not selected","Verified Sp Sex Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Sp Sex Checkbox should be present and  selected ","Verified Sp Sex CheckBox is  present  and is selected", true);
			}
		boolean ChildCount= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Child Count']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!ChildCount)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Child Count Checkbox  not selected","Verified Child Count Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Child Count Checkbox should be present and  selected ","Verified Child Count CheckBox is  present  and is selected", true);
			}
		boolean Medicare= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Medicare']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!Medicare)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Medicare Checkbox  not selected","Verified Medicare Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Medicare Checkbox should be present and  selected ","Verified Medicare CheckBox is  present  and is selected", true);
			}
		boolean Disabled= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Disabled']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!Disabled)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Disabled Checkbox  not selected","Verified Disabled Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Disabled Checkbox should be present and  selected ","Verified Disabled CheckBox is  present  and is selected", true);
			}
		boolean LifeOnly= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Life Only']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!LifeOnly)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Life Only Checkbox  not selected","Verified Life Only Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Life Only Checkbox should be present and  selected ","Verified Life Only CheckBox is  present  and is selected", true);
			}
		boolean Health= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Health']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!Health)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Health, Checkbox  not selected","Verified Health Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Health Checkbox should be present and  selected ","Verified Health CheckBox is  present  and is selected", true);
			}
		boolean SubStatus= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Sub Status']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!SubStatus)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"SubStatus Checkbox  not selected","Verified SubStatus Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"SubStatus Checkbox should be present and  selected ","Verified SubStatus CheckBox is  present  and is selected", true);
			}
		boolean Vision= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Vision']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!Vision)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Vision Checkbox  not selected","Verified Vision Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Vision Checkbox should be present and  selected ","Verified Vision CheckBox is  present  and is selected", true);
			}
		boolean Dental= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Dental']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!Dental)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Dental Checkbox  not selected","Verified Dental Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Dental Checkbox should be present and  selected ","Verified Dental CheckBox is  present  and is selected", true);
			}
		boolean LifeCoverage= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Life Coverage']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!LifeCoverage)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Life Coverage Checkbox  not selected","Verified Life Coverage Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Life Coverage Checkbox should be present and  selected ","Verified Life Coverage CheckBox is  present  and is selected", true);
			}
		boolean LifeClass= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Life Class']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!LifeClass)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Life Class Checkbox  not selected","Verified Life Class Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Life Class Checkbox should be present and  selected ","Verified Life Class CheckBox is  present  and is selected", true);
			}
		boolean Earnings= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Earnings']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!Earnings)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Earnings Checkbox  not selected","Verified Earnings Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Earnings Checkbox should be present and  selected ","Verified Earnings CheckBox is  present  and is selected", true);
			}
		boolean Paid= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Paid']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!Paid)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Paid Checkbox  not selected","Verified Paid Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Paid Checkbox should be present and  selected ","Verified Paid CheckBox is  present  and is selected", true);
			}
		boolean OptLAmt= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='OptLAmt']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!OptLAmt)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"OptLAmt Checkbox  not selected","Verified OptLAmt Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"OptLAmt Checkbox should be present and  selected ","Verified OptLAmt CheckBox is  present  and is selected", true);
			}
		boolean OptLX= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='OptLX']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!OptLX)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"OptLX Checkbox  not selected","Verified OptLX Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"OptLX Checkbox should be present and  selected ","Verified OptLX CheckBox is  present  and is selected", true);
			}
		boolean State= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='State']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!State)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"State Checkbox  not selected","Verified State Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"State Checkbox should be present and  selected ","Verified State CheckBox is  present  and is selected", true);
			}
		boolean ZipCode= driver.findElement(By.xpath("//table[@id='CensusView.copyFieldsTable']/tbody//label[text()='Zip Code']/preceding-sibling::input[@type='checkbox']")).isDisplayed();
		if(!ZipCode)
		{
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"Zip Code Checkbox  not selected","Verified Zip Code Checkbox  NOT selected", true);
		}
		else 
				{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Zip Code Checkbox should be present and  selected ","Verified Zip Code CheckBox is  present  and is selected", true);
			}
	}
	
	/**
	 * @author AF14733 The Method is used to  verify EligibleEmp displayed in census page and Group info page are same
	 * @throws Exception
	 */
	public static void verifyEligibleEmp() {
		try {
			String stractEligibleEmp = seGetElementValue(eligibleEmpl).toString();
			System.out.println("stractEligibleEmp " + stractEligibleEmp);
			Thread.sleep(5000);
			
			String strEmployees = driver.findElement(By.xpath("//table[@id='GroupInfoView.tableTable']/tbody/tr[11]/td[6]/div/input[@type='text']")).getAttribute("Value");
			System.out.println("strEmployees " + strEmployees);
			
			if ((stractEligibleEmp.equalsIgnoreCase(strEmployees))) {
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"EligibleEmp " + strEmployees + " should be  present",
						"Verified EligibleEmp " + stractEligibleEmp + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"EligibleEmp " + strEmployees + " not present",
						"Verified EligibleEmp " + stractEligibleEmp + " is NOT present", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @author AF14733 The Method is used to  verify ratingType displayed in census page and Group info page are same 
	 * @throws Exception
	 */
	public static void verifyratingType() {
		try {
			String stractRatingType = seGetElementValue(ratingTyp).toString();
			System.out.println("stractRatingType " + stractRatingType);
			Thread.sleep(5000);
			String strratingType =driver.findElement(By.xpath("//table/tbody/tr[2]/td/table/tbody/tr[13]/td[4]/div[@id='GroupInfoView.ratingTypeListBox']/select/option[1]")).getAttribute("Value");
			System.out.println("strratingType " + strratingType);
			
			if ((stractRatingType.equalsIgnoreCase(strratingType))) {
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Rating Type " + strratingType + " should be  present",
						"Verified Rating Type " + stractRatingType + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Rating Type " + strratingType + " not present",
						"Verified Rating Type " + stractRatingType + " is NOT present", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void seEnterValues_CensusPage() {
	
		String strAge= getCellValue("Age");
		String strSex= getCellValue("Sex");
		String strX= getCellValue("X");
	
		try {
			
			verifyHeader();
			seWaitForPageLoad();
			verifyDropDownvalue("Census");
			verifyDropDownvalueCensusType("Four Tier");
			WellQuoteUtility.seClickCheckBox(CensusPage.get().chkboxCopy, "Copy CheckBox");
			seClick(CensusPage.get().selectAll, "Click SelectAll chkbox ");
			Thread.sleep(3000);
			verifyCheckBoxes();
			seWaitForPageLoad();
			verifyratingType();
			seWaitForPageLoad();
			verifyEligibleEmp();
			seWaitForPageLoad();
			seSetText(CensusPage.get().txtboxAge,strAge,"Set Age in Eligible Age Field ");
			Thread.sleep(5000);
			seSetText(CensusPage.get().txtboxSex,strSex,"Set Sex in Eligible Sex Field ");
			Thread.sleep(5000);
			seSetText(CensusPage.get().txtboxX,strX,"Set X in Eligible Multiplier Field ");
			Thread.sleep(5000);
			seClick(CensusPage.get().btnInsertRow, "Click InsertRow Button");
			Thread.sleep(3000);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @author  AF54545
	 * The Method is used to validate Census Page Header
	 */
	public void validateCensusPageHeader() {
		try {
			String pid = seGetElementValue(CensusPage.get().PID).toString();
			setCellValue("Pid", pid);
			String newRenewal = seGetElementValue(CensusPage.get().NewRenewal).toString();
			setCellValue("New_Renewal", newRenewal);
			String EffectDate = seGetElementValue(CensusPage.get().effectDate).toString();
			setCellValue("Effective date", EffectDate);
			String EligEmpLabel = seGetElementValue(CensusPage.get().eligEmpLabel).toString();
			setCellValue("EE", EligEmpLabel);
			String Groupname = seGetElementValue(CensusPage.get().GroupName).toString();
			setCellValue("GroupName", Groupname);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @author AF54545 The Method is used to verify Census Type dropdown
	 * @param strCensustype which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyCenusType(String strCensustype) {
		try {
			String strDropDownvalue = seGetElementValue(censusType).toString();
			System.out.println("stractDropDownvalue " + strDropDownvalue);
			Thread.sleep(5000);
			if ((strDropDownvalue.equalsIgnoreCase(strCensustype))) {
				RESULT_STATUS = true;
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"DropDownvalue " + strCensustype + " should be  present",
						"Verified DropDownvalue " + strCensustype + " is present", true);

			} else {
				RESULT_STATUS = false;
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"DropDownvalue " + strCensustype + " not present",
						"Verified DropDownvalue " + strCensustype + " is NOT present", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @author AF54545 The Method is used to verify Census Type dropdown
	 * @param strCensustype which is fetched from the data sheet
	 * @throws Exception
	 */
	public  void verifyEligEmp(String strEligEmployees) {
		try {
			
			
			String EligibleEmployee = seGetElementValue(CensusPage.get().eligEmp).toString();
			if(strEligEmployees.equalsIgnoreCase(EligibleEmployee)){
				RESULT_STATUS = true;
				ExtentReportsUtility.log(ApplicationConstants.PASS,
				"The Eligible Employees values "+EligibleEmployee+" should be the same as in Group info page "+strEligEmployees+"",
				"Verified Eligible Employees values is same as in Group info page" ,true);
		}else
		{
			RESULT_STATUS = false;
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"The Eligible Employees values not same as in Group info page",
					"Eligible Employees values is not same as in Group info page" ,true);
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void verifyratingType(String strRatingType) {
		try {
			
			String RatingType = seGetElementValue(CensusPage.get().Ratingtype).toString();
			if(strRatingType.equalsIgnoreCase(RatingType)){
				RESULT_STATUS = true;
				ExtentReportsUtility.log(ApplicationConstants.PASS,
				"The Rating Type values "+RatingType+" should be the same as in Group info page "+strRatingType+"",
				"Verified  Rating Type values is same as in Group info page" ,true);
		}else
		{
			RESULT_STATUS = false;
			ExtentReportsUtility.log(ApplicationConstants.FAIL,
					"The Rating Type values not same as in Group info page",
					"Rating Type values is not same as in Group info page" ,true);
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @author AF54545 The Method is used to verify default mandatory fields in the census grid
	 * @param strCensustype which is fetched from the data sheet
	 * @throws Exception
	 */
	public  void verifyDefaultValinCensusGrid() {
		try {
		
			String TxtStatus = CensusPage.get().txtStatus.getAttribute("value");
			String TxtLife = CensusPage.get().txtLife.getAttribute("value");
			String TxtClass = CensusPage.get().txtClass.getAttribute("value");
			String TxtZip = CensusPage.get().txtZip.getAttribute("value");
			if(!TxtStatus.isEmpty()){
				RESULT_STATUS = true;
				ExtentReportsUtility.log(ApplicationConstants.PASS,
				"Mandatory fields Status should be displayed with default values " + TxtStatus+ "",
				"Verified Mandatory fields Status displayed with default values " + TxtStatus+ "", true);
			} else {
				RESULT_STATUS = false;
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Mandatory fields Status not displayed with default values ",
						"Mandatory fields Status is not displayed with default values ", true);
			}
			if(!TxtLife.isEmpty()){
				RESULT_STATUS = true;
				ExtentReportsUtility.log(ApplicationConstants.PASS,
				"Mandatory fields Life should be displayed with default values " + TxtLife+ "",
				"Verified Mandatory fields Life displayed with default values " + TxtLife+ "", true);
			} else {
				RESULT_STATUS = false;
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Mandatory fields Life not displayed with default values ",
						"Mandatory fields Life is not displayed with default values ", true);
			}
			if(!TxtClass.isEmpty()){
				RESULT_STATUS = true;
				ExtentReportsUtility.log(ApplicationConstants.PASS,
				"Mandatory fields Class should be displayed with default values " + TxtClass+ "",
				"Verified Mandatory fields Class displayed with default values " + TxtClass+ "", true);
			} else {
				RESULT_STATUS = false;
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Mandatory fields Class not displayed with default values ",
						"Mandatory fields Class is not displayed with default values ", true);
			}
			if(!TxtZip.isEmpty()){
				RESULT_STATUS = true;
				ExtentReportsUtility.log(ApplicationConstants.PASS,
				"Mandatory fields Zip should be displayed with default values " + TxtZip+ "",
				"Verified Mandatory fields Zip displayed with default values " + TxtZip+ "", true);
			} else {
				RESULT_STATUS = false;
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Mandatory fields Zip not displayed with default values ",
						"Mandatory fields Zip is not displayed with default values ", true);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

