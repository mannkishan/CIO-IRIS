package page;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.SuperHelper;

import utility.CoreSuperHelper;

/*
'Revision History
'#############################################################################
'@rev.On	@rev.No		@rev.By				  @rev.Comments
'										
'#############################################################################
*/

/**
 * <Add description here>
 * 
 * @author @author AF60410 Sandeep Reddy R
 * @since Nov 20, 2017
 *
 */


public class GroupPage extends SuperHelper {

	private static GroupPage thisIsTestObj;

	// So that there only one object accesses this class at any moment
	public synchronized static GroupPage get() {
		thisIsTestObj = PageFactory.initElements(driver, GroupPage.class);
		return thisIsTestObj;
	}
	
	@FindBy(how = How.ID, using = "QuickLaunchView.newButton")
	@CacheLookup
	public WebElement newGroupLink;
	
//	@FindBy(how=How.XPATH,using="//table[@id='QuickLaunchView.tableTable']/tbody/tr[2]/td[2]/div/img") //table[@id='QuickLaunchView.tableTable']/tbody/tr[2]/td[2]/div/img
//	public WebElement newGroupLink; 
	
	//html/body/table/tbody/tr[2]/td/div/table[1]/tbody/tr[3]/td/table/tbody/tr[1]/td/table/tbody/tr[2]/td[2]
	////[@id='QuickLaunchView.newButton']/img
	
	@FindBy(how=How.ID,using="QuickLaunchView.openButton")
	public WebElement openGroupLink;
	
	@FindBy(how=How.ID,using="QuickLaunchView.recentGroupButton")
	public WebElement recentGroupLink;
	
	@FindBy(how=How.ID,using="MainView.utilitesMenuItem")
	public WebElement utilitiesMenu;
	
	@FindBy(how=How.ID,using="MainView.benefitSummariesMenuItem")
	public WebElement benefitSummaries;
	
	
	
	/**
	 * Clicks on New Group Button
	 * @author Surya
	 */
	public void clickNewGroup() {
		seClick(newGroupLink, "New Group");
		seWaitForPageLoad();
		
	}
	
	/**
	 * Open Benefit summaries page
	 * @author Surya
	 */
	public void openBenefitSummaries() {
		seWaitForElementLoad(utilitiesMenu);
		seClick(utilitiesMenu, "Utilities");
		seWaitForPageLoad();
		seClick(benefitSummaries, "Benefit Summaries");
		seWaitForPageLoad();
	}
}
