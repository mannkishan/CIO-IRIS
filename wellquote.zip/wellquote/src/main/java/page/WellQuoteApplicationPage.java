package page;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import com.anthem.selenium.SuperHelper;

import com.anthem.selenium.constants.ApplicationConstants;
import com.anthem.selenium.utility.ExtentReportsUtility;

import utility.CoreSuperHelper;

/*
'Revision History
'#############################################################################
'@rev.On	@rev.No		@rev.By				  @rev.Comments
'										
'#############################################################################
*/

/**
 * <Add description here>
 * 
 * @author <Author name>
 * @since <Creation date>
 *
 */
public class WellQuoteApplicationPage extends CoreSuperHelper {

	private static WellQuoteApplicationPage thisIsTestObj;

	// So that there only one object accesses this class at any moment
	public synchronized static WellQuoteApplicationPage get() {
		thisIsTestObj = PageFactory.initElements(driver, WellQuoteApplicationPage.class);
		return thisIsTestObj;
	}

	//Add objects here...
	@FindBy(how = How.PARTIAL_LINK_TEXT, using = "Georgia")
	@CacheLookup
	public WebElement linkGeorgia;
	
	@FindBy(how = How.ID, using = "QuickLaunchView.newButton")
	@CacheLookup
	public WebElement buttonNewGroup;
	
	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.newRenewal']/div[contains(text(),'New')]")
	@CacheLookup
	public WebElement defaultNew;
	
	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.nameLabel']/input")
	@CacheLookup
	public WebElement name;
	
	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.addressLabel']/input")
	@CacheLookup
	public WebElement address;
	
	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.cityLabel']/input")
	@CacheLookup
	public WebElement city;
	
	
	/**
	 * Clicks on Georgia link
	 * @author Surya
	 */
	public void clickGeorgiaLink() {
		seClick(linkGeorgia, "Georgia link");
		seWaitForPageLoad();
	}
	
	/**
	 * Clicks on New Group Button
	 * @author Surya
	 */
	public void clickNewGroup() {
		seClick(buttonNewGroup, "New Group");
		seWaitForPageLoad();
		
	}
	
	/**
	 * Validates default New besides Name text box
	 * @author Surya
	 */
	public void validateDefaultNew() {
		try{
				if (seCheckElementPresence(By.xpath("//div[@id='GroupInfoView.newRenewal']/div[contains(text(),'New')]")))
				{
					ExtentReportsUtility.log(ApplicationConstants.PASS , "Default value 'New' should be present besides Name textbox",
							"Verified default 'New' is present besides Name textbox" ,true);

				}
				else{
					ExtentReportsUtility.log(ApplicationConstants.FAIL ,"Default value 'New' NOT present besides Name textbox",
							"Default value 'New' is NOT present besides Name textbox",true);
				}  

			}catch(Exception e){
				e.printStackTrace();
			}
		}
	
	
	/**
	 * Enters values in New Group form
	 * @author Surya
	 */
	public void seEnterValuesNewGroupForm() {
		String strName = getCellValue("Name");
		String strAddress = getCellValue("Address");
		String strCity = getCellValue("City");
	
		seSetText(false, name, strName, "Enter Name");
		seSetText(false, address, strAddress, "Enter Address");
		seSetText(true, city, strCity, "Enter City");
		
	}
	
}
