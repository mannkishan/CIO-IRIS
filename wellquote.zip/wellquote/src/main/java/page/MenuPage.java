/**
 * 
 */
package page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.SuperHelper;

import utility.CoreSuperHelper;

/*
'Revision History
'#############################################################################
'@rev.On	@rev.No		@rev.By				  @rev.Comments
'										
'#############################################################################
*/

/**
 * Page: MenuPage
 * <p>
 * Page Object Model Sample
 * <p>
 * Please refer this page while creating other page object models
 * 
 * @author AF60410
 * @since 20-Nov-2017
 *
 */

public class MenuPage extends CoreSuperHelper {

	private static MenuPage thisIsTestObj;

	// So that there only one object accesses this class at any moment
	public synchronized static MenuPage get() {
		thisIsTestObj = PageFactory.initElements(driver, MenuPage.class);
		return thisIsTestObj;
	}

	// Recommended model for all objects
	@FindBy(how = How.XPATH, using = "//Table[@id='menuTable']/tbody/tr[1]/td/a")
	@CacheLookup
	public WebElement lifeAndDisability;

	@FindBy(how = How.XPATH, using = "//Table[@id='menuTable']/tbody/tr[2]/td/a")
	@CacheLookup
	public WebElement georgia;

	@FindBy(how = How.XPATH, using = "//Table[@id='menuTable']/tbody/tr[3]/td/a")
	@CacheLookup
	public WebElement centralZone;

	@FindBy(how = How.XPATH, using = "//Table[@id='menuTable']/tbody/tr[4]/td/a")
	@CacheLookup
	public WebElement virginia;
	
	@FindBy(how = How.ID, using = "BusyDialogView.tableTable")
	@CacheLookup
	public WebElement sendingRequest;
	
	
	/**
	 * Navigates to the Application Menu
	 * 
	 * @param userProfile
	 * @author AF60410
	 */

	public WebElement clickLifeAndDisability() {
		seClick(lifeAndDisability, "LifeAndDisability Link");
		return lifeAndDisability;
	}

	public WebElement clickGeorgia() {
		seClick(georgia, "Georgia Link");
		return georgia;
	}

	public WebElement clickCentralZone() {
		seClick(centralZone, "CentralZone Link");
		return centralZone;
	}

	public WebElement clickVirginia() {
		seClick(virginia, "Virginia Link");
		return virginia;
	}

}
