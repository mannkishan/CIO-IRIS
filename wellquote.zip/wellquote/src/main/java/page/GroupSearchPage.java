/**
 * 
 */
package page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.SuperHelper;

import utility.CoreSuperHelper;

/*
'Revision History
'#############################################################################
'@rev.On	@rev.No		@rev.By				  @rev.Comments
'										
'#############################################################################
*/

/**
 * Page: SamplePage
 * <p>
 * Page Object Model Sample
 * <p>
 * Please refer this page while creating other page object models
 * 
 * @author af60410
 * @since 20-Nov-2017
 *
 */

public class GroupSearchPage extends CoreSuperHelper {

	private static GroupSearchPage thisIsTestObj;

	// So that there only one object accesses this class at any moment
	public synchronized static GroupSearchPage get() {
		thisIsTestObj = PageFactory.initElements(driver, GroupSearchPage.class);
		return thisIsTestObj;
	}

	// Recommended model for all objects
	@FindBy(how = How.ID, using = "gwt-uid-29")
	@CacheLookup
	public WebElement allGroupsCheckBox;

	@FindBy(how = How.ID, using = "GroupSearchView.searchPIDTextBox")
	@CacheLookup
	public WebElement groupPID;

	@FindBy(how = How.ID, using = "GroupSearchView.searchButton")
	@CacheLookup
	public WebElement searchButton;

	@FindBy(how = How.ID, using = "GroupSearchView.resultTextLabel")
	@CacheLookup
	public WebElement groupPIDText;

	@FindBy(how = How.ID, using = "GroupSearchView.name1Label")
	@CacheLookup
	public WebElement groupName;

	@FindBy(how = How.XPATH, using = "//tbody/tr[2]/td[text()='TQ1692335']")
	@CacheLookup
	public WebElement selectGroupPID1;

	@FindBy(how = How.XPATH, using = "//tbody/tr[2]/td[text()='TQ1692342']")
	@CacheLookup
	public WebElement selectGroupPID2;

	/**
	 * Navigates to the Central Zone Screen
	 * 
	 * @param userProfile
	 * @author af60410
	 */

	/*
	 * public WebElement selectAllGroupsCheckBox() { seClick(allGroupsCheckBox,
	 * "All Groups Check Box"); return allGroupsCheckBox; }
	 */

}
