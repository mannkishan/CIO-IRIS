package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import com.anthem.selenium.constants.ApplicationConstants;
import com.anthem.selenium.utility.ExtentReportsUtility;

import utility.CoreSuperHelper;
import utility.WellQuoteUtility;

/*
'Revision History
'#############################################################################
'@rev.On	@rev.No		@rev.By				  @rev.Comments
'										
'#############################################################################
*/

/**
 * <Add description here>
 * 
 * @author AF60410 Sandeep Reddy R
 * @since Nov 20, 2017
 *
 */

public class GroupInfoPage extends CoreSuperHelper {

	private static GroupInfoPage thisIsTestObj;

	// So that there only one object accesses this class at any moment
	public synchronized static GroupInfoPage get() {
		thisIsTestObj = PageFactory.initElements(getWebDriver(), GroupInfoPage.class);
		return thisIsTestObj;
	}

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.tableTable']/tbody/tr[2]/td[2]/div/input[@type='text']")
	public WebElement name;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView']/tbody/tr[2]/td/table/tbody/tr[4]/td[2]/div/input[@type='text']")
	public WebElement address;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.tableTable']/tbody/tr[6]/td[2]/div/input[@type='text']")
	public WebElement city;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.tableTable']/tbody/tr[9]/td[2]/div/input[@type='text']")
	public WebElement effDate;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.tableTable']/tbody/tr[9]/td[4]/div/input[@type='text']")
	public WebElement zipCode;

	@FindBy(how = How.XPATH, using = "//table[@id='ExceptionDialog.tableTable']/tbody/tr[1]/td[2]")
	public WebElement errorMess;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.tableTable']/tbody/tr[7]/td[2]")
	public WebElement errorMessValidation;

	@FindBy(how = How.XPATH, using = "//table[@id='ExceptionDialog.tableTable']/tbody/tr[2]/td/button")
	public WebElement clickOk;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.tableTable']/tbody/tr[9]/td[5]")
	public WebElement clickLabel;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.tableTable']/tbody/tr[2]/td[3]/div/select/option[1]")
	public WebElement clickDropDown;

	@FindBy(how = How.ID, using = "MainView.groupMenuItem")
	public WebElement groupMainMenu;

	@FindBy(how = How.ID, using = "MainView.groupListMenuItem")
	public WebElement groupListMainMenu;

	@FindBy(how = How.ID, using = "MainView.groupMenu.openMenuItem")
	public WebElement openSubMenu;

	@FindBy(how = How.ID, using = "MainView.groupListMenuItem.Tim tom Holdings")
	public WebElement groupListSubMenu;

	@FindBy(how = How.ID, using = "MainView.groupListMenuItem.TC_Reg_BMS_GrpList_VA")
	public WebElement groupListSubMenuVA;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.tableTable']//tbody/tr[9]/td[6]/div[@class='gwt-Label']")
	public WebElement labelState;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.tableTable']/tbody/tr[11]/td[4]/div/select[@class='gwt-ListBox']")
	public WebElement drpdownBill;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.tableTable']/tbody/tr[11]/td[4]/div/select[@class='gwt-ListBox']/option[1]")
	public WebElement drpdownBill_Standard;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.tableTable']/tbody/tr[11]/td[6]/div/input[@type='text']")
	public WebElement eligibleEmpl;

	@FindBy(how = How.XPATH, using = "//table/tbody/tr[2]/td/table/tbody/tr[13]/td[4]/div[@id='GroupInfoView.ratingTypeListBox']/select")
	public WebElement ratingType;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.tableTable']/tbody/tr[13]/td[2]/div[@id='GroupInfoView.marketCodeListBox']/select[@class='gwt-ListBox']")
	public WebElement marketCode;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.table2Table']/tbody/tr[5]/td[4]/div/input[@type='text']")
	public WebElement sicCode_id;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.table2Table']/tbody/tr[7]/td[5]/div/input[@type='text']")
	public WebElement salesRepCode_id;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.table2Table']/tbody/tr[9]/td[5]/div/input[@type='text']")
	public WebElement brokerCode;

	@FindBy(how = How.ID, using = "GroupInfoView.nextButton")
	public WebElement btnNext;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.tableTable']/tbody/tr[18]/td/table/tbody/tr[2]/td[2]/div/input")
	public WebElement association;

	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.tableTable']/tbody/tr[18]/td/table/tbody/tr[3]/td[2]/div/select/option[1]")
	public WebElement sub_Association;

	@FindBy(how = How.ID, using = "ExceptionDialog.ok")
	public WebElement buttonOk;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.printDateLabel']/div")
	public WebElement PrintDateVA;
	
	@FindBy(how = How.XPATH, using = "//table[@id='GroupInfoView.tableTable']/tbody/tr[11]/td[4]/div/select[@class='gwt-ListBox']")
	public WebElement dropdown_Bill;
	
	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.cityLabel']/input")
	@CacheLookup
	public WebElement city_GrpInfo;
	
	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.salesRepIdLabel']/input")
	@CacheLookup
	public WebElement salesRepid;
	
	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.brokerIdLabel']/input")
	@CacheLookup
	public WebElement brokerID;
	
	@FindBy(how = How.ID, using = "GroupInfoView.commentsTextArea")
	public WebElement comments;
	
	

	/////////////////////////////////// For
	/////////////////////////////////// Georgia/////////////////////////////////////////////
	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.newRenewal']/div[contains(text(),'New')]")
	public WebElement defaultNew;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.nameLabel']/input")
	public WebElement nameGeorgia;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.addressLabel']/input")
	public WebElement addressGeorgia;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.cityLabel']/input")
	public WebElement cityGeorgia;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.effectiveDateLabel']/input")
	public WebElement effDateGeorgia;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.zipCodeLabel']/input")
	public WebElement zipCodeGeorgia;

	@FindBy(how = How.XPATH, using = "//table[@class='ErrorText']/tbody/tr/td/div[@class='gwt-Label']")
	public WebElement errorMessage;

	@FindBy(how = How.XPATH, using = "//table[@class='ErrorText']/tbody/tr[2]/td/div[@class='gwt-Label']")
	public WebElement errorMessageLine2;

	@FindBy(how = How.ID, using = "GroupInfoView.nextButton")
	public WebElement nextButton;

	@FindBy(how = How.XPATH, using = "//*[@id='GAGroupInfoView']/tbody/tr/td/table/tbody/tr[6]/td[3]")
	public WebElement errorMessageGA;

	@FindBy(how = How.XPATH, using = "//table[@class='ErrorText']/tbody/tr[1]/td/div")
	public WebElement errorMessageCZ;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.billAsLabel']/select/option[@value='4']")
	public WebElement billAsDefaultGA;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.contributionEmployeeListBox']/select/option[7]")
	public WebElement employeeDefaultGA;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.contributionDependentListBox']/select/option[1]")
	public WebElement dependentDefaultGA;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.currentCarrierSuggestBox']/input")
	public WebElement currentCarrierGA;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.officeListBox']/select")
	public WebElement officeGA;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.associationSuggestBox']/input")
	public WebElement associationDefaultGA;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.subAssociationListBox']/select/option")
	public WebElement subAssociationDefaultGA;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.sicIdLabel']/input[@type='text']")
	public WebElement sicCodeIdGA;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.sicHeadersListBox']/select/option[70]")
	public WebElement sicHeaderGA;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.sicCodesListBox']/select")
	public WebElement sicCodeGA;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.salesRepIdLabel']/input")
	public WebElement salesRepIdGA;

	@FindBy(how = How.XPATH, using = "(//table[@class='ErrorText']/tbody/tr/td/div)[1]")
	public WebElement nameErrorMessageGA;

	@FindBy(how = How.XPATH, using = "//table[@id='GAGroupInfoView']/tbody/tr/td/table/tbody/tr[3]/td[2]/div/input")
	@CacheLookup
	public WebElement namefieldGeorgia;
	
	@FindBy(how = How.XPATH, using = "//table[@id='GAGroupInfoView']/tbody/tr/td/table/tbody/tr[27]/td")
	public WebElement quotesGeneratedLabel;


	/////////////////////////////////// For Central Zone
	/////////////////////////////////// /////////////////////////////////////////////

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.newRenewalListBox']/select[@class='gwt-ListBox']/option[1]")
	@CacheLookup
	public WebElement defaultdropdownNew;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.printDateLabel']/input")
	@CacheLookup
	public WebElement PrintDate;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.currentCarrierSuggestBox']/input")
	@CacheLookup
	public WebElement currentcarrier;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.officeListBox']/select")
	@CacheLookup
	public WebElement Office;

	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Group Name is a required field')]")
	@CacheLookup
	public WebElement ErrorMsgName;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.brokerSuggestBox']/input")
	@CacheLookup
	public WebElement Broker;

	/////////////////////////////////// For
	/////////////////////////////////// Virginia/////////////////////////////////////////////

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.ratingTypeListBox']/div[contains(text(),'Subscriber Rated')]")
	public WebElement ratingTypeVA;

	@FindBy(how = How.XPATH, using = "//div[@id='GroupInfoView.accountCodeLabel']/input")
	public WebElement accountCodeVA;

	/**
	 * @author Surya 
	 * @method Validates default New text besides Name text box
	 * @param
	 * @throws Exception
	 */
	public void validateDefaultNew() {
		try {
			if (seCheckElementPresence(By.xpath("//div[@id='GroupInfoView.newRenewal']/div[contains(text(),'New')]"))) {
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Default value 'New' should be present besides Name textbox",
						"Verified default 'New' is present besides Name textbox", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Default value 'New' NOT present besides Name textbox",
						"Default value 'New' is NOT present besides Name textbox", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author Surya 
	 * @method Validates default New text besides Name text box for
	 *         Virginia
	 * @param
	 * @throws Exception
	 */
	public void validateDefaultNewVA() {
		try {
			if (seCheckElementPresence(
					By.xpath("//div[@id='GroupInfoView.newRenewalListBox']/div[contains(text(),'New')]"))) {
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Default value 'New' should be present besides Name textbox",
						"Verified default 'New' is present besides Name textbox", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Default value 'New' NOT present besides Name textbox",
						"Default value 'New' is NOT present besides Name textbox", true);
				throw new Exception("Fail");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author Surya 
	 * @method Enters values in new group form
	 * @param
	 * @throws Exception
	 */
	public void seEnterValuesNewGroupForm() {
		try {

			String strName = getCellValue("Name");
			String strAddress = getCellValue("Address");
			String strCity = getCellValue("City");
			String strEffectivedate = getCellValue("EffectiveDate");

			seSetText(true, nameGeorgia, strName, "Enter Name");
			seSetText(true, addressGeorgia, strAddress, "Enter Address");
			seSetText(true, cityGeorgia, strCity, "Enter City");
			seSetText(true, effDateGeorgia, strEffectivedate, "Set Effective Date ");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author Surya 
	 * @method This Method is used to validate multiple error messages for
	 *         Zipcode field at Georgia region
	 * @param
	 * @throws Exception
	 */
	public void seValidateInvalidZipcodeErrors() {

		try {

			String strZipcode1 = getCellValue("Zipcode1");
			String strZipcode2 = getCellValue("Zipcode2");
			String strZipcode3 = getCellValue("Zipcode3");
			String strZipcode_Error1 = getCellValue("Error1");
			String strZipcode_Error2 = getCellValue("Error2");
			String strZipcode_Error3 = getCellValue("Error3");

			seSetText(true, zipCodeGeorgia, strZipcode1, "Set Invalid Zipcode 1 in Zipcode Field ");
			seWaitForPageLoad();
			Thread.sleep(3000);
			// Error Message Validation
			verifyZipCodeErrorMessageGeorgia(strZipcode_Error1);
			seWaitForPageLoad();

			seSetText(true, zipCodeGeorgia, strZipcode2, "Set Invalid Zipcode 2 in Zipcode Field ");
			seWaitForPageLoad();
			Thread.sleep(3000);
			// Error Message Validation
			verifyZipCodeErrorMessageGeorgia(strZipcode_Error2);
			seWaitForPageLoad();

			seSetText(true, zipCodeGeorgia, strZipcode3, "Set Invalid Zipcode 3 in Zipcode Field ");
			Thread.sleep(2000);
			zipCodeGeorgia.sendKeys("1");
			seWaitForPageLoad();
			Thread.sleep(3000);
			// Verify Error Message Validation
			verifyZipCodeErrorMessageGeorgia(strZipcode_Error3);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author Surya 
	 * @method This Method is used to validate multiple error messages for
	 *         Zipcode field at Virginia region
	 * @param
	 * @throws Exception
	 */
	public void seValidateInvalidZipcodeErrorsVA() {

		try {

			String strZipcode1 = getCellValue("Zipcode1");
			String strZipcode2 = getCellValue("Zipcode2");
			String strZipcode3 = getCellValue("Zipcode3");
			String strZipcode_Error1 = getCellValue("Error1");
			String strZipcode_Error2 = getCellValue("Error2");
			String strZipcode_Error3 = getCellValue("Error3");

			seSetText(true, zipCodeGeorgia, strZipcode1, "Set Invalid Zipcode 1 in Zipcode Field ");
			seWaitForPageLoad();
			Thread.sleep(5000);
			// Error Message Validation
			verifyErrorPopupVA(strZipcode_Error1);
			GroupInfoPage.get().buttonOk.click();
			seClick(GroupInfoPage.get().buttonOk, "Click OK Button");
			Thread.sleep(5000);

			seSetText(true, zipCodeGeorgia, strZipcode2, "Set Invalid Zipcode 2 in Zipcode Field ");
			seWaitForPageLoad();
			Thread.sleep(3000);
			// Error Message Validation
			verifyZipCodeErrorMessageGeorgia(strZipcode_Error2);
			seWaitForPageLoad();

			seSetText(true, zipCodeGeorgia, strZipcode3, "Set Invalid Zipcode 3 in Zipcode Field ");
			Thread.sleep(5000);
			GroupInfoPage.get().buttonOk.click();
			seClick(GroupInfoPage.get().buttonOk, "Click OK Button");
			Thread.sleep(2000);
			zipCodeGeorgia.sendKeys("1");

			// Verify Error Message Validation
			verifyZipCodeErrorMessageGeorgia(strZipcode_Error3);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void setDrpdownBill(WebElement drpdownBill) {
		this.drpdownBill = drpdownBill;
	}

	/**
	 * @author Surya 
	 * @method This Method is used to validate correct error message is
	 *         displayed for Georgia region
	 * @param strExpValue
	 * @throws Exception
	 */
	public void verifyZipCodeErrorMessageGeorgia(String strExpValue) {
		try {
			String strActErrorMess = seGetElementValue(errorMessage).toString();
			System.out.println("actErrorMessage: " + strActErrorMess + "expErrorMessage: " + strExpValue);
			Thread.sleep(5000);
			if ((strActErrorMess.trim()).contains(strExpValue.trim())) {
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Error Message '" + strExpValue + "' should be present",
						"Verified Error Message '" + strActErrorMess + "' is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Error Message '" + strExpValue + "' should be present", "Error Message '" + strExpValue
								+ "' is NOT present. Error message present is : '" + strActErrorMess,
						true);
				throw new Exception("Fail");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author Kavitha 
	 * @method This Method is used to validate State IsDisplayed
	 * @param
	 * @throws Exception
	 */
	public void validateStateIsDisplayed() {
		try {

			String strActState = seGetElementValue(labelState).toString();
			System.out.println("strActState: " + strActState);
			Thread.sleep(5000);
			if ((!(strActState == null))) {
				ExtentReportsUtility.log(ApplicationConstants.PASS, "State  value is populated " + strActState + "",
						"Verified State " + strActState + "' is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL, "State value is NOT populated " + strActState + "",
						"Verified State value " + strActState + "' is NOT present", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author Kavitha 
	 * @method This Method is used to validate State IsDisplayed
	 * @param
	 * @throws Exception
	 */
	public void validateStandardIsDisplayed(String strexpDropdownValue) {
		try {
			String strActDropdownValue = seGetElementValue(drpdownBill_Standard).toString();
			System.out.println("strActDropdownValue: " + strActDropdownValue);
			Thread.sleep(5000);
			if (strActDropdownValue.equalsIgnoreCase(strexpDropdownValue)) {
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"DropDownvalue " + strexpDropdownValue + " should be  present",
						"Verified DropDownvalue " + strActDropdownValue + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"DropDownvalue " + strexpDropdownValue + " should be  present",
						"Verified DropDownvalue " + strActDropdownValue + " is NOT present", true);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author AF14733 
	 * @method This Method is used to search verifyZipCode
	 * @param strexpvalue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyZipCode(String strexpvalue) {
		try {
			String acterrormess = seGetElementValue(GroupInfoPage.get().errorMess).toString();
			System.out.println("Errormess1 " + acterrormess);
			Thread.sleep(5000);
			if ((acterrormess.contains(strexpvalue))) {
				ExtentReportsUtility.log(ApplicationConstants.PASS, "Error Message is present",
						"Verified Error Message is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL, "Error Message is not present",
						"Verified Error Message is NOT present", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author Surya
	 * @param strExpValue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyErrorPopupVA(String strExpValue) {
		try {
			String actErrorMess = seGetElementValue(GroupInfoPage.get().errorMess).toString();
			System.out.println("Errormess1 " + actErrorMess);
			Thread.sleep(5000);
			if ((actErrorMess.contains(strExpValue))) {
				ExtentReportsUtility.log(ApplicationConstants.PASS, "Error Message is present : " + strExpValue,
						"Verified Error Message is present : " + actErrorMess, true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL, "Error Message is present : " + strExpValue,
						"Required Error Message is NOT present.Error Present is : " + actErrorMess, true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author AF14733 
	 * @method This Method is used to search verifyZipCodeErrorMessage
	 * @param strexpvalue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyZipCodeErrorMessage(String strexpvalue) {
		try {
			String stracterrormess = seGetElementValue(GroupInfoPage.get().errorMessValidation).toString();
			System.out.println("stracterrormess2 " + stracterrormess);
			Thread.sleep(5000);
			if ((stracterrormess.contains(strexpvalue))) {

				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Error Message " + strexpvalue + " should be present",
						"Verified Error Message " + stracterrormess + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL, "Error Message " + strexpvalue + " not present",
						"Verified Error Message " + stracterrormess + " is NOT present", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author AF14733 
	 * @method This Method is used to verifyDropDownvalue Census
	 * @param strexpDropDownvalue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyDropDownvalue(String strexpDropDownvalue) {
		try {
			String stractDropDownvalue = seGetElementValue(GroupInfoPage.get().clickDropDown).toString();
			System.out.println("stractDropDownvalue " + stractDropDownvalue);
			Thread.sleep(5000);
			if ((stractDropDownvalue.equalsIgnoreCase(strexpDropDownvalue))) {
				RESULT_STATUS = true;
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"DropDownvalue " + strexpDropDownvalue + " should be  present",
						"Verified DropDownvalue " + stractDropDownvalue + " is present", true);

			} else {
				RESULT_STATUS = false;
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"DropDownvalue " + strexpDropDownvalue + " not present",
						"Verified DropDownvalue " + stractDropDownvalue + " is NOT present", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author AF54545 
	 * @method This Method is used to verifyDropDownvalue of NEW
	 * @param strDropDownvalue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyDropDownvalueNew(String strDropDownvalue) {
		try {
			String stractDropDownvalue = seGetElementValue(GroupInfoPage.get().defaultdropdownNew).toString();
			Thread.sleep(5000);
			if ((stractDropDownvalue.equalsIgnoreCase(strDropDownvalue))) {
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"DropDownvalue " + strDropDownvalue + " should be  present",
						"Verified DropDownvalue " + stractDropDownvalue + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"DropDownvalue " + strDropDownvalue + " not present",
						"Verified DropDownvalue " + stractDropDownvalue + " is NOT present", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author AF54545 
	 * @method This Method is used to Print date set to default
	 * @param strPrintDate
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyPrintDate(String strPrintDate) {
		try {
			String strActPrintdate = seGetElementTextBoxValue(GroupInfoPage.get().PrintDate).toString();
			System.out.println("Print Date: " + strActPrintdate);
			Thread.sleep(5000);
			if ((strActPrintdate.equalsIgnoreCase(strPrintDate))) {
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Print date" + strPrintDate + " should be auto populated",
						"Verified Print Date " + strActPrintdate + " auto populated", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Print Date " + strPrintDate + " not auto populated",
						"Verified Print Date " + strActPrintdate + " is NOT auto populated", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author Surya 
	 * @method This Method is used to verify Print date set to default
	 * @param strPrintDate
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyPrintDateVA(String strPrintDate) {
		try {
			String strActPrintdate = seGetElementTextBoxValue(GroupInfoPage.get().PrintDateVA).toString();
			System.out.println("Print Date: " + strActPrintdate);
			Thread.sleep(5000);
			if ((strActPrintdate.equalsIgnoreCase(strPrintDate))) {
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Print date" + strPrintDate + " should be auto populated",
						"Verified Print Date " + strActPrintdate + " auto populated", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Print Date " + strPrintDate + " not auto populated",
						"Verified Print Date " + strActPrintdate + " is NOT auto populated", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author AF54545 
	 * @method The Method is used to validate Name field required for CZ
	 */
	public void validateNamefieldRequired() {
		try {
			String strerrorMsg = seGetElementValue(ErrorMsgName).toString();
			if (name.getText().isEmpty()) {
				ExtentReportsUtility.log(ApplicationConstants.PASS, strerrorMsg + " for CZ",
						"Verified" + strerrorMsg + "for CZ", true);
			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL, "Group Name is present in required field for CZ",
						"Group Name is present in required field for CZ", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author AF60410 
	 * @method This Method is used to verifyZipCodeErrorMessage
	 * @param strexpvalue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyZipCodeClearMessage(String strExpvalue) {
		try {
			String stracterrormess = seGetElementValue(GroupInfoPage.get().errorMessageCZ).toString();
			System.out.println("stracterrormessage " + stracterrormess);
			Thread.sleep(5000);
			if ((strExpvalue.contains(stracterrormess))) {

				ExtentReportsUtility.log(ApplicationConstants.PASS, "Error Message " + strExpvalue + " present",
						"Verified Error Message is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL, "Error Message " + strExpvalue + " not present",
						"Verified Error Message " + stracterrormess + " is NOT present", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author AF60410 
	 * @method This Method is used to verifyZipCodeErrorMessage for
	 *         Georgia
	 * @param strexpvalue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyZipCodeErrorMessageGA(String strExpvalue) {
		try {
			String stracterrormess = seGetElementValue(GroupInfoPage.get().errorMessageGA).toString();
			System.out.println("stracterrormessage " + stracterrormess);
			Thread.sleep(5000);
			if ((stracterrormess.contains(strExpvalue))) {

				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Error Message " + strExpvalue + " should be present",
						"Verified Error Message " + stracterrormess + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL, "Error Message " + strExpvalue + " not present",
						"Verified Error Message " + stracterrormess + " is NOT present", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author af14733 : kavitha 
	 * @method To enter Values in the Group info page for New
	 *         Group-Central Zone
	 */
	public void seEnterValuesNewGroup() {

		try {

			String strName = getCellValue("Name");
			String strCity = getCellValue("City");
			String strZipcode = getCellValue("Zipcode");
			String strEffectivedate = getCellValue("Effectivedate");
			String strAddress = getCellValue("Address");
			String strEmployees = getCellValue("EligibleEmployees");
			String strmarketCode = getCellValue("marketCode");
			String strbillAs = getCellValue("BillAs");
			String strratingType = getCellValue("ratingType");
			String strcurrentCarrier = getCellValue("currentCarrier");
			String strOffice = getCellValue("Office");
			String strID = getCellValue("ID");
			String strsalesRepCode_id = getCellValue("SalesRepCode");
			String strbrokerCode = getCellValue("BrokerCode");

			GroupInfoPage.get().verifyDropDownvalue("New");
			seWaitForPageLoad();
			seSetText(GroupInfoPage.get().address, strAddress, "Set Address in Address Field ");
			seWaitForPageLoad();
			seSetText(GroupInfoPage.get().city, strCity, "Set City in City Field ");
			seWaitForPageLoad();
			seSetText(GroupInfoPage.get().name, strName, "Set Name in Name Field ");
			seWaitForPageLoad();
			seSetText(GroupInfoPage.get().effDate, strEffectivedate, "Set Effectivedate ");
			seWaitForPageLoad();
			seSetText(GroupInfoPage.get().zipCode, strZipcode, "Set Zipcode in Zipcode Field ");
			seWaitForPageLoad();
			seClick(GroupInfoPage.get().clickLabel, "Click Label");
			seWaitForPageLoad();
			// verifyDropDownvalue
			GroupInfoPage.get().validateStateIsDisplayed();
			seWaitForPageLoad();
			WellQuoteUtility.seVerifyDropdownisEnabled(GroupInfoPage.get().drpdownBill);
			seWaitForPageLoad();
			// Verify Label
			// WellQuoteUtility.seVerifylabelIsDisplayed(GroupInfoPage.get().labelState);
			GroupInfoPage.get().validateStandardIsDisplayed(strbillAs);
			seWaitForPageLoad();
			seSetText(GroupInfoPage.get().eligibleEmpl, strEmployees, "Set Employees in Eligible Employees Field ");
			seWaitForPageLoad();
			seSelectText(GroupInfoPage.get().marketCode, strmarketCode, "Select Market Code ");
			seWaitForPageLoad();
			seSelectText(GroupInfoPage.get().ratingType, strratingType, "Select Rating Type ");
			Thread.sleep(5000);
			// seSetText(GroupInfoPage.get().currentCarrier,strcurrentCarrier,"Set
			// " +strcurrentCarrier+ " in currentCarrierField ");
			GroupInfoPage.get().selectOffice();
			seSetText(GroupInfoPage.get().sicCode_id, strID, "Set ID in Eligible SIC ID Field ");
			Thread.sleep(3000);
			seSetText(GroupInfoPage.get().salesRepCode_id, strsalesRepCode_id,
					"Set salesRepCode_id in salesRepCode_id Field ");
			Thread.sleep(3000);
			// Click Next
			seClick(GroupInfoPage.get().btnNext, "Click Next Button");
			Thread.sleep(3000);
			seSetText(GroupInfoPage.get().brokerCode, strbrokerCode, "Set ID in brokerCode Field ");
			Thread.sleep(3000);
			seClick(GroupInfoPage.get().clickLabel, "Click Label");
			Thread.sleep(2000);
			seClick(GroupInfoPage.get().btnNext, "Click Next Button");
			GroupInfoPage.get().validateAssociation();
			GroupInfoPage.get().validateSub_Assoc();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @method - This is used to validate Assoc Default value - "None"
	 * 
	 * @author kavitha
	 */
	public void validateAssociation() {
		String stractassocvalue = "";

		try {
			stractassocvalue = driver
					.findElement(By
							.xpath("//table[@id='GroupInfoView.tableTable']/tbody/tr[18]/td/table/tbody/tr[2]/td[2]/div/input"))
					.getAttribute("value");
			System.out.println("stractassocvalue" + stractassocvalue);
			if (stractassocvalue.contains("None"))

			{
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Default value 'None' should be present in the Association  Fields",
						"Verified default value " + stractassocvalue + "is present in the Association  Fields", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Default value 'None' NOT present in the Association Fields",
						"Default value " + stractassocvalue + " is NOT present in the Association  Fields", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author kavitha
	 * @method - This is used to validate Sub_Assoc value
	 * 
	 */
	public void validateSub_Assoc() {
		String stractsub_assocvalue = "";
		try {
			stractsub_assocvalue = driver
					.findElement(By
							.xpath("//table[@id='GroupInfoView.tableTable']/tbody/tr[18]/td/table/tbody/tr[3]/td[2]/div/select/option[1]"))
					.getAttribute("value");
			System.out.println("stractsub_assocvalue : " + stractsub_assocvalue);
			if (stractsub_assocvalue.contains("None")) {
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Default value 'None' should be present in the  Sub_Association Fields",
						"Verified default  " + stractsub_assocvalue + " is present in the  Sub_Association Fields",
						true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Default value 'None' NOT present in the Sub_Association Fields",
						"Default value  " + stractsub_assocvalue + " is NOT present in the  Sub_Association Fields",
						true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author AF14733
	 * @method - This is used to select the Office value
	 * 
	 */
	public void selectOffice() {
		try {
			Select dropdown = new Select(driver.findElement(By.xpath(
					"html/body/table/tbody/tr[2]/td/div/table[1]/tbody/tr[3]/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/div/div/table/tbody/tr[2]/td/table/tbody/tr[17]/td[2]/div/select")));
			int size = dropdown.getOptions().size();
			System.out.println("size:" + size);
			dropdown.selectByIndex(53);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @author AF60410 Sandeep Reddy R
	 * @method This Method is used to verifyBillAsdefaultValue for
	 *         Georgia
	 * @param strexpvalue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyBillAsdefaultValueGA(String strExpvalue) {
		try {
			String stractBillAs = seGetElementValue(GroupInfoPage.get().billAsDefaultGA).toString();
			System.out.println("BillAs: " + stractBillAs);
			if ((stractBillAs.contains(strExpvalue))) {

				ExtentReportsUtility.log(ApplicationConstants.PASS, "Bill As " + strExpvalue + " should be present",
						"Verified Bill As " + stractBillAs + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL, "Bill As " + strExpvalue + " not present",
						"Verified Bill As " + stractBillAs + " is NOT present", true);
				RESULT_STATUS = false;
			}

		} catch (Exception excException) {
			processExceptions("Exception occured ", excException);
			throw excException;
		}
	}

	/**
	 * @author AF60410 Sandeep Reddy R
	 * @method This Method is used to verifyEmployeedefaultValue for
	 *         Georgia
	 * @param strexpvalue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyEmployeedefaultValueGA(String strExpvalue) {
		try {
			String stractEmployeeDefaultValue = seGetElementValue(GroupInfoPage.get().employeeDefaultGA).toString();
			System.out.println("Employee Default Value: " + stractEmployeeDefaultValue);
			if ((stractEmployeeDefaultValue.equalsIgnoreCase(strExpvalue))) {

				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Employee default value " + strExpvalue + " should be present",
						"Verified Employee default value " + stractEmployeeDefaultValue + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Employee default value " + strExpvalue + " not present",
						"Verified Employee default value " + stractEmployeeDefaultValue + " is NOT present", true);
				RESULT_STATUS = false;
			}

		} catch (Exception excException) {
			processExceptions("Exception occured ", excException);
			throw excException;
		}
	}

	/**
	 * @author AF60410 Sandeep Reddy R
	 * @method This Method is used to verifyDependentdefaultValue for
	 *         Georgia
	 * @param strexpvalue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyDependentdefaultValueGA(String strExpvalue) {
		try {
			String stractDependentDefaultValue = seGetElementValue(GroupInfoPage.get().dependentDefaultGA).toString();
			System.out.println("Dependent Default Value: " + stractDependentDefaultValue);
			if ((stractDependentDefaultValue.equalsIgnoreCase(strExpvalue))) {

				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Dependent default value " + strExpvalue + " should be present",
						"Verified Dependent default value " + stractDependentDefaultValue + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Dependent default value " + strExpvalue + " not present",
						"Verified Dependent default value " + stractDependentDefaultValue + " is NOT present", true);
				RESULT_STATUS = false;
			}

		} catch (Exception excException) {
			processExceptions("Exception occured ", excException);
			throw excException;
		}
	}

	/**
	 * @author AF60410 Sandeep Reddy R
	 * @method This Method is used to verifyAssociationdefaultValue for
	 *         Georgia
	 * @param strexpvalue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyAssociationdefaultValueGA(String strExpvalue) {
		try {
			String stractAssociationDefaultValue = seGetElementValue(GroupInfoPage.get().associationDefaultGA)
					.toString();
			System.out.println("Association Default Value: " + stractAssociationDefaultValue);
			if ((stractAssociationDefaultValue.equalsIgnoreCase(strExpvalue))) {

				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Association Default Value " + strExpvalue + " should be present",
						"Verified Association Default Value " + stractAssociationDefaultValue + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Association Default Value " + strExpvalue + " not present",
						"Verified Association Default Value " + stractAssociationDefaultValue + " is NOT present",
						true);
				RESULT_STATUS = false;
			}

		} catch (Exception excException) {
			processExceptions("Exception occured ", excException);
			throw excException;
		}
	}

	/**
	 * @author AF60410 Sandeep Reddy R
	 * @method This Method is used to verifySubAssociationdefaultValue
	 *         for Georgia
	 * @param strexpvalue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifySubAssociationdefaultValueGA(String strExpvalue) {
		try {
			String stractSubAssociationDefaultValue = seGetElementValue(GroupInfoPage.get().subAssociationDefaultGA)
					.toString();
			System.out.println("SubAssociation Default Value: " + stractSubAssociationDefaultValue);
			if ((stractSubAssociationDefaultValue.equalsIgnoreCase(strExpvalue))) {

				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Sub Association Default Value " + strExpvalue + " should be present",
						"Verified Sub Association Default Value " + stractSubAssociationDefaultValue + " is present",
						true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"Sub Association Default Value " + strExpvalue + " not present",
						"Sub Association Default Value " + stractSubAssociationDefaultValue + " is NOT present", true);
				RESULT_STATUS = false;
			}

		} catch (Exception excException) {
			processExceptions("Exception occured ", excException);
			throw excException;
		}
	}

	/**
	 * @author AF60410 Sandeep Reddy R
	 * @method This Method is used to verifySICHeaderdefaultValue for
	 *         Georgia
	 * @param strexpvalue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifySICHeaderdefaultValueGA(String strExpvalue) {
		try {
			String stractSICHeaderDefaultValue = seGetElementValue(GroupInfoPage.get().sicHeaderGA).toString();
			System.out.println("SICHeader Default Value: " + stractSICHeaderDefaultValue);
			if ((stractSICHeaderDefaultValue.equalsIgnoreCase(strExpvalue))) {

				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"SIC Header Value " + strExpvalue + " should be present",
						"Verified SIC Header Value " + stractSICHeaderDefaultValue + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL, "SIC Header Value " + strExpvalue + " not present",
						"Verified SIC Header Value " + stractSICHeaderDefaultValue + " is NOT present", true);
				RESULT_STATUS = false;
			}

		} catch (Exception excException) {
			processExceptions("Exception occured ", excException);
			throw excException;
		}
	}

	/**
	 * @author AF60410 Sandeep Reddy R
	 * @method This Method is used to verifySICCodedefaultValue for
	 *         Georgia
	 * @param strexpvalue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifySICCodedefaultValueGA(String strExpvalue) {
		try {
			String stractSICCodeDefaultValue = seGetElementValue(GroupInfoPage.get().sicCodeGA).toString();
			System.out.println("SICCode Default Value: " + stractSICCodeDefaultValue);
			if ((stractSICCodeDefaultValue.equalsIgnoreCase(strExpvalue))) {

				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"SIC Code value " + strExpvalue + " should be present",
						"Verified SIC Code value " + stractSICCodeDefaultValue + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL, "SIC Code value " + strExpvalue + " not present",
						"Verified SIC Code value " + stractSICCodeDefaultValue + " is NOT present", true);
				RESULT_STATUS = false;
			}

		} catch (Exception excException) {
			processExceptions("Exception occured ", excException);
			throw excException;
		}
	}

	/**
	 * @author AF60410 Sandeep Reddy R
	 * @method This Method is used to verifyNameErrorMessage for Georgia
	 * @param strexpvalue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyNameErrorMessageGA(String strExpvalue) {
		try {
			String stracterrormess = seGetElementValue(GroupInfoPage.get().ErrorMsgName).toString();
			System.out.println("Error message: " + stracterrormess);
			if ((stracterrormess.equalsIgnoreCase(strExpvalue))) {

				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"Error Message " + strExpvalue + " should be present",
						"Verified Error Message " + stracterrormess + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL, "Error Message " + strExpvalue + " not present",
						"Verified Error Message " + stracterrormess + " is NOT present", true);
				RESULT_STATUS = false;
			}

		} catch (Exception excException) {
			processExceptions("Exception occured ", excException);
			throw excException;
		}
	}

	/**
	 * @author AF60410 Sandeep Reddy R
	 * @method This Method is used to verifyRatingTypedefault for
	 *         Virginia
	 * @param strexpvalue
	 *            which is fetched from the data sheet
	 * @throws Exception
	 */
	public void verifyRatingTypedefaultVA(String strExpvalue) {
		try {
			String stractRatingType = seGetElementValue(GroupInfoPage.get().ratingTypeVA).toString();
			System.out.println("Rating Type: " + stractRatingType);
			if ((stractRatingType.equalsIgnoreCase(strExpvalue))) {

				ExtentReportsUtility.log(ApplicationConstants.PASS, "Rating Type " + strExpvalue + " should be present",
						"Verified Rating Type " + stractRatingType + " is present", true);

			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL, "Rating Type " + strExpvalue + " not present",
						"Verified Rating Type " + stractRatingType + " is NOT present", true);
				RESULT_STATUS = false;
			}

		} catch (Exception excException) {
			processExceptions("Exception occured ", excException);
			throw excException;
		}
	}

}
