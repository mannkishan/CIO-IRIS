/**
 * 
 */
package page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.SuperHelper;

import utility.CoreSuperHelper;

/*
'Revision History
'#############################################################################
'@rev.On	@rev.No		@rev.By				  @rev.Comments
'										
'#############################################################################
*/

/**
 * Page: SamplePage
 * <p>
 * Page Object Model Sample
 * <p>
 * Please refer this page while creating other page object models
 * 
 * @author @author AF60410 Sandeep Reddy R
 * @since Nov 20, 2017
 *
 */

public class CentralZonePage extends CoreSuperHelper {

	private static CentralZonePage thisIsTestObj;

	// So that there only one object accesses this class at any moment
	public synchronized static CentralZonePage get() {
		thisIsTestObj = PageFactory.initElements(driver, CentralZonePage.class);
		return thisIsTestObj;
	}

	// Recommended model for all objects
	@FindBy(how = How.ID, using = "QuickLaunchView.newButton")
	@CacheLookup
	public WebElement newGroup;
	
	@FindBy(how = How.ID, using = "QuickLaunchView.openButton")
	@CacheLookup
	public WebElement openGroup;

	@FindBy(how = How.ID, using = "QuickLaunchView.recentGroupButton")
	@CacheLookup
	public WebElement recentGroup;

	/**
	 * Navigates to the Central Zone Screen
	 * 
	 * @param userProfile
	 * @author Sandeep Reddy R
	 */

	public WebElement clicknewGroup() {
		seClick(newGroup, "New Group Link");
		return newGroup;
	}

	public WebElement clickopenGroup() {
		seClick(openGroup, "Open Group Link");
		return openGroup;
	}
	
	public WebElement clickrecentGroup() {
		seClick(recentGroup, "Recent Group Link");
		return recentGroup;
	}

}
