/**
 * 
 */
package page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.SuperHelper;

import utility.CoreSuperHelper;

/*
'Revision History
'#############################################################################
'@rev.On	@rev.No		@rev.By				  @rev.Comments
'										
'#############################################################################
*/

/**
 * Page: Benefit Summaries Page
 * <p>
 * Benefit Summaries Page
 * <p>
 * 
 * 
 * @author Surya Pratap Singh
 * @since 24-Nov-2017
 *
 */

public class BenefitSummariesPage extends CoreSuperHelper {

	private static BenefitSummariesPage thisIsTestObj;

	// So that there only one object accesses this class at any moment
	public synchronized static BenefitSummariesPage get() {
		thisIsTestObj = PageFactory.initElements(driver, BenefitSummariesPage.class);
		return thisIsTestObj;
	}

	@FindBy(how = How.XPATH, using = "//div[@id='BenefitSummaryView.nameLabel']/input")
	@CacheLookup
	public WebElement printName;

	@FindBy(how = How.XPATH, using = "//div[@id='BenefitSummaryView.effectiveDateLabel']/input")
	@CacheLookup
	public WebElement effectiveDate;

	@FindBy(how = How.XPATH, using = "//div[@id='BenefitSummaryView.rateAsLabel']/input")
	@CacheLookup
	public WebElement groupSize;

	@FindBy(how = How.XPATH, using = "//div[@id='BenefitSummaryView.zipCodeLabel']/input")
	@CacheLookup
	public WebElement zipCode;

	@FindBy(how = How.XPATH, using = "//span[@id='BenefitSummaryView.showDateCheckBox']/input")
	@CacheLookup
	public WebElement showEffDateCheckbox;

	@FindBy(how = How.XPATH, using = "//span[@id='BenefitSummaryView.showSizeCheckBox']/input")
	@CacheLookup
	public WebElement showGroupSizeCheckbox;

	@FindBy(how = How.XPATH, using = "//div[@id='BenefitSummaryView.newRenewalListBox']/select")
	public WebElement status;

	@FindBy(how = How.ID, using = "BenefitSummaryView.loadButton")
	public WebElement loadButton;

	@FindBy(how = How.ID, using = "BenefitSummaryView.exitButton")
	public WebElement closeBenefitSummariesButton;

	@FindBy(how = How.XPATH, using = "//div[@id='BenefitSummaryView.editionListBox']/select")
	public WebElement editionDropdown;

	@FindBy(how = How.ID, using = "BenefitSummaryView.pdfButon")
	public WebElement createPDFButton;
	
	@FindBy(how = How.ID, using = "BlueMCBPView.okButton")
	@CacheLookup
	public WebElement okBtn_Benefit;
	
	@FindBy(how = How.ID, using = "BlueMCBPView.clearButton")
	@CacheLookup
	public WebElement clearBtn_Benefit;
	
	@FindBy(how = How.XPATH, using = "//div[@id='BlueMCBPView.editionListBox']/select")
	@CacheLookup
	public WebElement edition;
	
	@FindBy(how = How.XPATH, using = "//div[@id='BlueMCBPView_optionListBox']/select")
	@CacheLookup
	public WebElement option;
	
	@FindBy(how = How.ID, using = "AvailableBenefitsView.11.benefitHealthLabel")
	@CacheLookup
	public WebElement blueMCBPLink;
	
	

	/**
	 * Enters initial values in Benefit Summaries page
	 * 
	 * @param
	 * @author Surya
	 */

	public void seEnterValuesBenefitSummaries() {

		try {

			String strPrintName = getCellValue("Name");
			String strEffectivedate = getCellValue("EffectiveDate");
			String strGroupSize = getCellValue("GroupSize");
			String strZipCode = getCellValue("Zipcode");
			String strStatus = getCellValue("BenefitStatus");

			seSetText(true, printName, strPrintName, "Enter Print Name");
			seSetText(true, effectiveDate, strEffectivedate, "Set Effective Date");
			seSetText(true, groupSize, strGroupSize, "Enter Group Size");
			seSetText(true, zipCode, strZipCode, "Enter ZipCode ");

			seClickCheckBox(showEffDateCheckbox, "Show Effective date");
			seClickCheckBox(showGroupSizeCheckbox, "Show Group Size");

			seSelectText(true, status, strStatus, "Select Status");

			seClick(true, loadButton, "Laod Button");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Enters Edition & clicks on create PDF button
	 * 
	 * @param
	 * @author Surya
	 */

	public void seEnterEditionCreatePDF() {

		try {

			String strEdition = getCellValue("Edition");

			seSelectText(true, editionDropdown, strEdition, "Select Edition");
			seClick(true, createPDFButton, "Create PDF");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Close Benefit Summaries Page
	 * 
	 * @param
	 * @author Surya
	 */

	public void seCloseBenefitSummary() {

		try {

			seClick(true, closeBenefitSummariesButton, "Close");
			seWaitForPageLoad();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
