/**
 * 
 */
package testScripts;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.CentralZonePage;
import page.GroupInfoPage;
import page.GroupSearchPage;
import page.LoginPage;
import page.MenuPage;
import utility.CoreSuperHelper;

/**
 * manualTestCase :TC_Reg_BMS_GrpList_002.001
 * </p>
 * 
 * @author: AF60410
 * @since: Nov 22, 2017
 * @Revision<>
 *
 */

public class TC_Reg_BMS_GrpList_002_TS extends CoreSuperHelper {

	static String strBaseUrl = EnvHelper.getValue("url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {

		try {

			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {

				try {
					logExtentReport("TC_Reg_BMS_GrpList_002_TS");
					if (getCellValue("Run_Flag").equalsIgnoreCase("Yes")) {

						// Open Browser
						seOpenBrowser(BrowserConstants.InternetExplorer, strBaseUrl);
						LoginPage.get().loginApplication(strUserProfile);
						seWaitForPageLoad();
						seClick(true, MenuPage.get().virginia, "Virginia Link");
						seWaitForPageLoad();
						seClick(true, CentralZonePage.get().openGroup, "Open Group Link");
						seWaitForPageLoad();
						seSetText(GroupSearchPage.get().groupPID, getCellValue("Group_PID1"), "Group PID");
						seClick(true, GroupSearchPage.get().searchButton, "Search Button");
						seWaitForPageLoad();
						seClick(true, GroupSearchPage.get().selectGroupPID1, "Select the Group PID");
						seWaitForPageLoad();
						Thread.sleep(10000);
						seClick(GroupInfoPage.get().groupMainMenu, "Group Menu Item");
						seClick(true, GroupInfoPage.get().openSubMenu, "Open Sub Menu");
						seWaitForPageLoad();
						seSetText(GroupSearchPage.get().groupPID, getCellValue("Group_PID2"), "Group PID");
						seClick(true, GroupSearchPage.get().searchButton, "Search Button");
						seWaitForPageLoad();
						seClick(true, GroupSearchPage.get().selectGroupPID2, "Select the Group PID");
						seWaitForPageLoad();
						Thread.sleep(10000);
						seClick(GroupInfoPage.get().groupListMainMenu, "Group List Menu Item");
						seClick(true, GroupInfoPage.get().groupListSubMenuVA, "Group List Sub Menu");

						// Test Scripts End Here
						setResult("STATUS", RESULT_STATUS);
						// seCloseBrowser();
					}
				} catch (Exception e) {

					e.printStackTrace();
				} finally {
					endTestScript();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			seCloseBrowser();
		}
	}
}
