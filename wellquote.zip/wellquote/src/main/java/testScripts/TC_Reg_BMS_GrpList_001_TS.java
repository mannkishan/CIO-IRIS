/**
 * 
 */
package testScripts;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.anthem.selenium.SuperHelper;
import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;

import page.CentralZonePage;
import page.GroupInfoPage;
import page.GroupSearchPage;
import page.LoginPage;
import page.MenuPage;
import utility.CoreSuperHelper;

/**
 * manualTestCase :TC_Reg_BMS_GrpList_001.001
 * </p>
 * 
 * @author: AF60410
 * @since: Nov 20, 2017
 * @Revision<>
 *
 */

public class TC_Reg_BMS_GrpList_001_TS extends CoreSuperHelper {

	static String strBaseUrl = EnvHelper.getValue("url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {

			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {

				try {
					logExtentReport("TC_Reg_BMS_GrpList_001_TS");
					if (getCellValue("Run_Flag").equalsIgnoreCase("Yes")) {

						// Open Browser
						seOpenBrowser(BrowserConstants.InternetExplorer, strBaseUrl);
						LoginPage.get().loginApplication(strUserProfile);
						seWaitForPageLoad();
						// seWaitForElementLoad(MenuPage.get().centralZone);
						// seWaitForWebElement(60,
						// ExpectedConditions.visibilityOf(MenuPage.get().clickLifeAndDisability()));
						MenuPage.get().clickCentralZone();
						// seClick(MenuPage.get().clickCentralZone(),
						// "CentralZone");
						seWaitForPageLoad();
						// seWaitForWebElement(30,
						// ExpectedConditions.elementToBeClickable(CentralZonePage.get().clickopenGroup()));
						CentralZonePage.get().clickopenGroup();
						seWaitForPageLoad();
						seClick(GroupSearchPage.get().allGroupsCheckBox, "All Groups CheckBox");
						seSetText(GroupSearchPage.get().groupPID, getCellValue("Group_PID1"), "Group PID");
						seClick(GroupSearchPage.get().searchButton, "Search Button");
						seWaitForPageLoad();
						// verifyGroup PID value
						verifyGroupPID(getCellValue("Group_PID1"));
						seClick(GroupSearchPage.get().groupName, "Group Name");
						seWaitForPageLoad();
						Thread.sleep(10000);
						seClick(GroupInfoPage.get().groupMainMenu, "Group Menu Item");
						seClick(GroupInfoPage.get().openSubMenu, "Open Sub Menu");
						// seSelectText(GroupInfoPage.get().openSubMenu, "Open",
						// "Open Sub Menu");
						seWaitForPageLoad();
						seClick(GroupSearchPage.get().allGroupsCheckBox, "All Groups CheckBox");
						seSetText(GroupSearchPage.get().groupPID, getCellValue("Group_PID2"), "Group PID");
						seClick(GroupSearchPage.get().searchButton, "Search Button");
						seWaitForPageLoad();
						verifyGroupPID(getCellValue("Group_PID2"));
						seClick(GroupSearchPage.get().groupName, "Group Name");
						seWaitForPageLoad();
						Thread.sleep(10000);
						seClick(GroupInfoPage.get().groupListMainMenu, "Group List Menu Item");
						seClick(GroupInfoPage.get().groupListSubMenu, "Group List Sub Menu");
						// Test Scripts End Here
						setResult("STATUS", RESULT_STATUS);
						// seCloseBrowser();
					}
				} catch (Exception e) {

					e.printStackTrace();
				} finally {
					endTestScript();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			seCloseBrowser();
		}
	}
}