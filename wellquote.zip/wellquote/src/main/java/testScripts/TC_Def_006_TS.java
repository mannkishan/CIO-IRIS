package testScripts;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.GroupInfoPage;
import page.GroupPage;
import page.LoginPage;
import page.MenuPage;
import page.WellQuoteApplicationPage;
import utility.CoreSuperHelper;
import utility.WellQuoteUtility;

/*

*/

/**
 * Manual test case: TC_Def_006.001 
 *To verify the Zip Code field (Required/Optional) validation for VA region New Business group.
 * <p>
 * 
 * @author Surya Pratap Singh
 * @since 11/28/2017
 * @Revision<>
 *
 */

public class TC_Def_006_TS extends CoreSuperHelper {

	static String strBaseUrl = EnvHelper.getValue("url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	

	public static void main(String[] args) {

		try {

			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {

				try {
					logExtentReport("TC_Def_006_TS");
					if (getCellValue("Run_Flag").equalsIgnoreCase("Yes")) {
						String strEffectivedate = getCellValue("EffectiveDate");
						String strExpValue1 = getCellValue("Error1");
						String strExpValue2 = getCellValue("Error2");
						
						seOpenBrowser(BrowserConstants.InternetExplorer, strBaseUrl);
						
						// Test Scripts Start Here
						LoginPage.get().loginApplication(strUserProfile);

						MenuPage.get().clickVirginia();
//						WellQuoteUtility.seWaitTillElementDisappears(MenuPage.get().sendingRequest);
						Thread.sleep(10000);
						GroupPage.get().clickNewGroup();

						// Enter initial values
						GroupInfoPage.get().validateDefaultNewVA();
						GroupInfoPage.get().seEnterValuesNewGroupForm();

						// Validation
						GroupInfoPage.get().verifyPrintDateVA(strEffectivedate);
						seClick(true, GroupInfoPage.get().btnNext, "Next Button", "Clicked Next Button");
						GroupInfoPage.get().verifyZipCodeErrorMessageGeorgia(strExpValue1);
						seCompareText(true, GroupInfoPage.get().errorMessageLine2, strExpValue2, "Validate Error Line 2 : "+strExpValue2);
						

						// Test Scripts End Here
						setResult("STATUS", RESULT_STATUS);
						seCloseBrowser();

					}
				} catch (Exception e) {

					e.printStackTrace();
				} finally {
					endTestScript();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
	}
}
