package testScripts;
import java.io.FileInputStream;

import org.apache.poi.xwpf.usermodel.XWPFDocument;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.GroupInfoPage;
import page.GroupPage;
import page.LoginPage;
import page.ZonePage;
import utility.CoreSuperHelper;
import utility.PDFValidator;

/*

*/

/**
 * Manual test case: Validate_ZipCode_TS
 * <p>
 * 
 * @author <Write name of Author>
   @since 17/11/17
   @Revision<>
 *
 */
public class Validate_ZipCode_TS  extends CoreSuperHelper {
	
	static String strBaseUrl = EnvHelper.getValue("url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
static String sWordDocumentPath = "C:\\Users\\AF14733\\Desktop\\Sample PDF_Converted.docx";


/**
 * @param args
 */
public static  void main(String[] args) {
	
try{
		
     initiateTestScript();
		
     for(iROW=1;iROW<=getRowCount();iROW++) {
		
     try {
			logExtentReport("Demo Script");
			if (getCellValue("Run_Flag").equalsIgnoreCase("Yes")) {
				
					String strname = getCellValue("Name");
					String strCity = getCellValue("City");
					String strZipcode = getCellValue("Zipcode");
					String strEffectivedate = getCellValue("Effectivedate");
					String strAddress = getCellValue("Address");
					String strexpvalue =getCellValue("expvalue");
					String strexpErrorMessage =getCellValue("expvalue2");
					String strZipcode_Invalid = getCellValue("Zipcode1");	
					//Open Browser
					seOpenBrowser(BrowserConstants.InternetExplorer, strBaseUrl);
					LoginPage.get().loginApplication(strUserProfile);
					seWaitForPageLoad();
					seClick(ZonePage.get().centralZoneLink, "Click on CentralZoneLink in the Zone Page");
					seWaitForPageLoad();
					seClick(GroupPage.get().newGroupLink, "Click on NewGroup Link in the Group Page");
					seWaitForPageLoad();
					//verifyDropDownvalue
					GroupInfoPage.get().verifyDropDownvalue("New");
					seWaitForPageLoad();				
					seSetText(GroupInfoPage.get().address, strAddress ,"Set Address in Address Field ");
					seWaitForPageLoad();
					seSetText(GroupInfoPage.get().city, strCity ,"Set City in City Field ");
					seWaitForPageLoad();
					seSetText(GroupInfoPage.get().name, strname ,"Set Name in Name Field ");
					seWaitForPageLoad();
					seSetText(GroupInfoPage.get().effDate,strEffectivedate,"Set Effectivedate ");
					seWaitForPageLoad();
					seSetText(GroupInfoPage.get().zipCode,strZipcode,"Set Zipcode in Zipcode Field ");
					seWaitForPageLoad();
					seClick(GroupInfoPage.get().clickLabel, "Click Label");
					seWaitForPageLoad();
					//Verify Error Message Validation
					GroupInfoPage.get().verifyZipCode(strexpvalue);
					seWaitForPageLoad();
					seClick(GroupInfoPage.get().clickOk, "Click OK Button");
					seWaitForPageLoad();
					seSetText(GroupInfoPage.get().zipCode,strZipcode_Invalid,"Set Zipcode in City Field ");
				//	seSetText(GroupInfoPage.get().zipCode,"099990","Set Zipcode in City Field ");
					seWaitForPageLoad();
					seClick(GroupInfoPage.get().clickLabel, "Click Label");
					seWaitForPageLoad();
					GroupInfoPage.get().verifyZipCodeErrorMessage(strexpErrorMessage);
					
					/*new ParagraphsAndTables().PrintParagraphsAndTables(sWordDocumentPath);
					 
					 new ParagraphsAndTables().PrintParagraphs1to600(sWordDocumentPath);*/
					
				//	 new PDFValidator().verify(sWordDocumentPath);
						
					setResult("STATUS", RESULT_STATUS);
				//	seCloseBrowser();
			}
         } catch (Exception e) {
				
            e.printStackTrace();
            }
           finally {
               endTestScript();
                }
		}
}
catch(Exception e){
 e.printStackTrace();
}
finally{
	seCloseBrowser();
}
}
}
