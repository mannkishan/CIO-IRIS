package testScripts;

import org.openqa.selenium.By;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.GroupInfoPage;
import page.GroupPage;
import page.LoginPage;
import page.MenuPage;
import page.WellQuoteApplicationPage;
import utility.CoreSuperHelper;

/*

*/

/**
 * Manual test case: TC_Def_005.001 
 * To verify the Zip Code field (Input Data) validation for VA region New Business group.
 * <p>
 * 
 * @author Surya Pratap Singh
 * @since 11/28/2017
 * @Revision<>
 *
 */

public class TC_Def_005_TS extends CoreSuperHelper {

	static String strBaseUrl = EnvHelper.getValue("url");
	static String strUserProfile = EnvHelper.getValue("user.profile");


	public static void main(String[] args) {

		try {

			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {

				try {
					logExtentReport("TC_Def_005_TS");
					if (getCellValue("Run_Flag").equalsIgnoreCase("Yes")) {
						String strEffectivedate = getCellValue("EffectiveDate");
						
						
						seOpenBrowser(BrowserConstants.InternetExplorer, strBaseUrl);
						
						// Test Scripts Start Here
						LoginPage.get().loginApplication(strUserProfile);

						MenuPage.get().clickVirginia();
						Thread.sleep(25000);
						GroupPage.get().clickNewGroup();

						// Enter initial values
						GroupInfoPage.get().validateDefaultNewVA();
						GroupInfoPage.get().seEnterValuesNewGroupForm();

						// Validation
						GroupInfoPage.get().verifyPrintDateVA(strEffectivedate);
						GroupInfoPage.get().seValidateInvalidZipcodeErrorsVA();

						// Test Scripts End Here
						setResult("STATUS", RESULT_STATUS);
						seCloseBrowser();

					}
				} catch (Exception e) {

					e.printStackTrace();
				} finally {
					endTestScript();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
