/**
 * 
 */
package testScripts;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.GroupInfoPage;
import page.GroupPage;
import page.LoginPage;
import page.MenuPage;
import page.ZonePage;
import utility.CoreSuperHelper;
import utility.WellQuoteUtility;

/**
 * <p>
 * manualTestCase :TC_Def_004.001
 * </p>
 * *
 * <p>
 * comments:To verify the Zip Code field (Required/Optional) validation for GA region New Business group.
 * </p>
 * * *
 * 
 * @author: AF60410 Sandeep Reddy R
 * @since: Nov 27, 2017
 */

public class TC_Def_004_TS extends CoreSuperHelper {

	static String strBaseUrl = EnvHelper.getValue("url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {

			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {

				try {
					logExtentReport("TC_Def_004_TS");
					if (getCellValue("Run_Flag").equalsIgnoreCase("Yes")) {
						
						String strExpvalue = getCellValue("Expected_Error");
						// Open Browser
						seOpenBrowser(BrowserConstants.InternetExplorer, strBaseUrl);
						LoginPage.get().loginApplication(strUserProfile);
						seWaitForPageLoad();
						MenuPage.get().clickGeorgia();
						seWaitForPageLoad();
						Thread.sleep(10000);
						GroupPage.get().clickNewGroup();
						seWaitForPageLoad();
						// Enter initial values
						GroupInfoPage.get().validateDefaultNew();
						seWaitForPageLoad();
						GroupInfoPage.get().seEnterValuesNewGroupForm();
						seWaitForPageLoad();
						seClick(true, GroupInfoPage.get().nextButton, "Click Next Button");
						seWaitForPageLoad();
						GroupInfoPage.get().verifyZipCodeErrorMessageGA(strExpvalue);
						seWaitForPageLoad();
						setResult("STATUS", RESULT_STATUS);
						// seCloseBrowser();
					}
				} catch (Exception e) {

					e.printStackTrace();
				} finally {
					endTestScript();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			seCloseBrowser();

		}
	}
}
