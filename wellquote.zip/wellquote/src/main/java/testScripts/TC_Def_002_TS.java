/**
 * 
 */
package testScripts;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.GroupInfoPage;
import page.GroupPage;
import page.LoginPage;
import page.ZonePage;
import utility.CoreSuperHelper;
import utility.PDFValidator;
import utility.WellQuoteUtility;

/**
 * <p>
 * manualTestCase :TC_Def_002.001
 * </p>
 * *
 * <p>
 * comments:To verify the Zip Code field (Required/Optional) validation for CZ region New Business group.
 * </p>
 * * *
 * 
 * @author: AF60410 Sandeep Reddy R
 * @since: Nov 27, 2017
 */

public class TC_Def_002_TS extends CoreSuperHelper {
	static String strBaseUrl = EnvHelper.getValue("url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {

			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {

				try {
					logExtentReport("TC_Def_002_TS");
					if (getCellValue("Run_Flag").equalsIgnoreCase("Yes")) {

						String strName = getCellValue("Name");
						String strCity = getCellValue("City");
						String strZipcode = getCellValue("Zipcode");
						String strEffectivedate = getCellValue("Effectivedate");
						String strAddress = getCellValue("Address");
						String strExpvalue = getCellValue("Expected_Error");
						// Open Browser
						seOpenBrowser(BrowserConstants.InternetExplorer, strBaseUrl);
						LoginPage.get().loginApplication(strUserProfile);
						seWaitForPageLoad();
						seClick(ZonePage.get().centralZoneLink, "Click on Central Zone Link");
						//seWaitForPageLoad();
						Thread.sleep(10000);
						seClick(GroupPage.get().newGroupLink, "Click on New Group icon");
						seWaitForPageLoad();
						// verifyDropDownvalue
						GroupInfoPage.get().verifyDropDownvalue(getCellValue("Dropdown_Value"));
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().name, strName, "Enter Name");
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().address, strAddress, "Enter Address");
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().city, strCity, "Enter City");
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().effDate, strEffectivedate, "Set Effectivedate");
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().zipCode, strZipcode, "Set Zipcode");
						seWaitForPageLoad();
						WellQuoteUtility.seVerifyDropdownisEnabled(GroupInfoPage.get().drpdownBill);
						seWaitForPageLoad();
						Thread.sleep(10000);
						seSetText(GroupInfoPage.get().zipCode, "", "Clear the Zipcode Field");
						seWaitForPageLoad();
						seClick(true, GroupInfoPage.get().name, "Click Label");
						seWaitForPageLoad();
						GroupInfoPage.get().verifyZipCodeClearMessage(strExpvalue);
						seWaitForPageLoad();
						setResult("STATUS", RESULT_STATUS);
					}
				} catch (Exception e) {

					e.printStackTrace();
				} finally {
					endTestScript();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			seCloseBrowser();
		}
	}
}
