package testScripts;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.GroupInfoPage;
import page.GroupPage;
import page.LoginPage;
import page.MenuPage;
import page.WellQuoteApplicationPage;
import utility.CoreSuperHelper;

/*

*/

/**
 * Manual test case: TC_Def_003.001 
 * To verify the Zip Code field(Input Data)
 * validation for GA region New Business group.
 * <p>
 * 
 * @author Surya Pratap Singh
 * @since 11/21/2017
 * @Revision<>
 *
 */

public class TC_Def_003_TS extends CoreSuperHelper {

	static String strBaseUrl = EnvHelper.getValue("url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {

		try {

			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {

				try {
					logExtentReport("TC_Def_003_TS");
					if (getCellValue("Run_Flag").equalsIgnoreCase("Yes")) {

						seOpenBrowser(BrowserConstants.InternetExplorer, strBaseUrl);
						
						// Test Scripts Start Here
						LoginPage.get().loginApplication(strUserProfile);

						MenuPage.get().clickGeorgia();
						GroupPage.get().clickNewGroup();

						// Enter initial values
						GroupInfoPage.get().validateDefaultNew();
						GroupInfoPage.get().seEnterValuesNewGroupForm();

						// Validation
						GroupInfoPage.get().seValidateInvalidZipcodeErrors();

						// Test Scripts End Here
						setResult("STATUS", RESULT_STATUS);
						seCloseBrowser();

					}
				} catch (Exception e) {

					e.printStackTrace();
				} finally {
					endTestScript();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
	}
}
