/**
 * 
 */
package testScripts;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.GroupInfoPage;
import page.GroupPage;
import page.LoginPage;
import page.MenuPage;
import utility.CoreSuperHelper;

/**
 * <p>
 *   manualTestCase :TC_Def_008.001                                    
 * </p> * 
 *  <p>
 *    comments:  Verify that "Name" field in "Group Info" page is required for VA region New Business.                                  
 * </p> * * 
 * @author: AF60410 Sandeep Reddy R
 * @since: Nov 30, 2017
 */

public class TC_Def_008_TS extends CoreSuperHelper {
	
	static String strBaseUrl = EnvHelper.getValue("url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {

			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {

				try {
					logExtentReport("TC_Def_008_TS");
					if (getCellValue("Run_Flag").equalsIgnoreCase("Yes")) {
						
						// Open Browser
						seOpenBrowser(BrowserConstants.InternetExplorer, strBaseUrl);
						LoginPage.get().loginApplication(strUserProfile);
						seWaitForPageLoad();
						MenuPage.get().clickVirginia();
						//seWaitForPageLoad();
						Thread.sleep(20000);
						GroupPage.get().clickNewGroup();
						seWaitForPageLoad();
						// Enter initial values
						GroupInfoPage.get().validateDefaultNewVA();
						seWaitForPageLoad();
						GroupInfoPage.get().seEnterValuesNewGroupForm();
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().zipCodeGeorgia, getCellValue("ZipCode"), "Enter Zip Code");
						seWaitForPageLoad();
						GroupInfoPage.get().verifyRatingTypedefaultVA(getCellValue("RatingType"));
						//seWaitForPageLoad();
						Thread.sleep(10000);
						seSetText(GroupInfoPage.get().accountCodeVA, getCellValue("AccountCode"), "Enter the Account Code");
						//seWaitForPageLoad();
						Thread.sleep(10000);
						seHighlightElement(GroupInfoPage.get().currentCarrierGA);
						seSetText(GroupInfoPage.get().currentCarrierGA, getCellValue("CurrentCarrier"), "Enter Current Carrier");
						seWaitForPageLoad();
						seSelectText(GroupInfoPage.get().Office, getCellValue("Office"), "Select Office");
						//seWaitForPageLoad();
						Thread.sleep(10000);
						seHighlightElement(GroupInfoPage.get().associationDefaultGA);
						GroupInfoPage.get().verifyAssociationdefaultValueGA(getCellValue("Association"));
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().sicCodeIdGA, getCellValue("SIC_ID"), "Enter SIC Code ID");
						//seWaitForPageLoad();
						Thread.sleep(5000);
						GroupInfoPage.get().verifySICHeaderdefaultValueGA(getCellValue("SIC_Header"));
						seWaitForPageLoad();
						GroupInfoPage.get().verifySICCodedefaultValueGA(getCellValue("SIC_Code"));
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().nameGeorgia, "", "Clear the Name Field");
						seWaitForPageLoad();
						seClick(true, GroupInfoPage.get().nextButton, "Click Next Button");
						seWaitForPageLoad();
						GroupInfoPage.get().verifyNameErrorMessageGA(getCellValue("Expected_Error"));
						seWaitForPageLoad();				
						setResult("STATUS", RESULT_STATUS);
					}
				} catch (Exception e) {

					e.printStackTrace();
				} finally {
					endTestScript();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			seCloseBrowser();

		}
	}

}
