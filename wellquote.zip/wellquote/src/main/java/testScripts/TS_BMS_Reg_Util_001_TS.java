package testScripts;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.BenefitSummariesPage;
import page.CentralZonePage;
import page.GroupPage;
import page.LoginPage;
import page.MenuPage;
import utility.CoreSuperHelper;

/*

*/

/**
 * Manual test case: TS_BMS_Reg_Util_001
 * <p>
 * 
 * @author Surya
 * @since 11/23/2017
 * @Revision<>
 *
 */

public class TS_BMS_Reg_Util_001_TS extends CoreSuperHelper {

	static String strBaseUrl = EnvHelper.getValue("url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {

		try {

			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {

				try {
					logExtentReport("TS_BMS_Reg_Util_001_TS");
					if (getCellValue("Run_Flag").equalsIgnoreCase("Yes")) {

						seOpenBrowser(BrowserConstants.InternetExplorer, strBaseUrl);
						// Test Scripts Start Here
						LoginPage.get().loginApplication(strUserProfile);

						MenuPage.get().clickCentralZone();
						GroupPage.get().openBenefitSummaries();

						BenefitSummariesPage.get().seEnterValuesBenefitSummaries();
						BenefitSummariesPage.get().seEnterEditionCreatePDF();
						seWaitForPageLoad();

						// Test Scripts End Here
						setResult("STATUS", RESULT_STATUS);
						seCloseBrowser();
					}
				} catch (Exception e) {

					e.printStackTrace();
				} finally {
					endTestScript();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
	}
}
