package testScripts;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.GroupInfoPage;
import page.GroupPage;
import page.LoginPage;
//import page.MenuPage;
import page.ZonePage;
//import page.planConfigurator.CreatePlanLegacyHeaderPage;
import utility.CoreSuperHelper;
/**
 * Manual test case: TC_Def_007.001 
 * Verify that "Name" field in "Group Info" page is required.
 * validation for for CZ region,New Business.
 * <p>
 * @author AF54545
 * @since 11/28/2017
 * @Revision<>
 *
 */
public class TC_Def_007_TS extends CoreSuperHelper {

	static String strBaseUrl = EnvHelper.getValue("url");
	static String strUserProfile = EnvHelper.getValue("user.profile");	

	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {

				try {
					logExtentReport("TC_Def_007_TS");
					if (getCellValue("Run_Flag").equalsIgnoreCase("Yes")) {

						String strname = getCellValue("Name");
						String strDropdown = getCellValue("Dropdown");
						String strAddress = getCellValue("Address");
						String strCity = getCellValue("City");
						String strZipcode = getCellValue("Zipcode");
						String strEffectivedate = getCellValue("Effectivedate");
						String strBillAs =getCellValue("BillAs");
						String strMarketCode =getCellValue("MarketCode");
						String strEligibleEmployees = getCellValue("EligibleEmployees");
						String strCurrentCarrier = getCellValue("CurrentCarrier");
						String strOffice = getCellValue("Office");
						String strSICCodeID = getCellValue("SICCodeID");
						String strBroker = getCellValue("Broker");
						//Open Browser
						seOpenBrowser(BrowserConstants.InternetExplorer, strBaseUrl);
						LoginPage.get().loginApplication(strUserProfile);
						Thread.sleep(5000);
						seClick(ZonePage.get().centralZoneLink, "Click on CentralZoneLink in the Zone Page");
						//seWaitForPageLoad();
						Thread.sleep(12000);
						seClick(GroupPage.get().newGroupLink, "Click on NewGroup Link in the Group Page");
						//seWaitForPageLoad();
						Thread.sleep(8000);
						seSetText(GroupInfoPage.get().name, strname ,"Set Name in Name Field ");
						seWaitForPageLoad();
						GroupInfoPage.get().verifyDropDownvalueNew(strDropdown);
						seWaitForPageLoad();				
						seSetText(GroupInfoPage.get().address, strAddress ,"Set Address in Address Field ");
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().city, strCity ,"Set City in City Field ");
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().effDate,strEffectivedate,"Set Effective date ");
						seWaitForPageLoad();
						GroupInfoPage.get().verifyPrintDate(strEffectivedate);
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().zipCode,strZipcode,"Set Zipcode in Zipcode Field ");
						seWaitForPageLoad();
						GroupInfoPage.get().validateStandardIsDisplayed(strBillAs);
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().eligibleEmpl, strEligibleEmployees ,"Set Eligible Employees in Eligibl Employees Field ");
						seWaitForPageLoad();
						seSelectText(GroupInfoPage.get().marketCode, strMarketCode, "Set Market Code in Market Code Field");
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().currentcarrier, strCurrentCarrier, "Set Current Carrier in Current Carrier Field");
						Thread.sleep(500);
						seSelectText(GroupInfoPage.get().Office, strOffice, "Set Office in Office Field");
						seWaitForPageLoad();
						GroupInfoPage.get().validateAssociation();
						GroupInfoPage.get().validateSub_Assoc();
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().sicCode_id, strSICCodeID, "Set SIC Code ID in SIC Code ID Field");
						seWaitForPageLoad();
						Thread.sleep(2000);
						seSetText(GroupInfoPage.get().Broker, strBroker, "Set Broker in Broker Field");
						seWaitForPageLoad();
						seClick(GroupInfoPage.get().btnNext, "Click on Next Button");
						seWaitForPageLoad();
						GroupInfoPage.get().validateNamefieldRequired();
						seWaitForPageLoad();
						
						setResult("STATUS", RESULT_STATUS);
						seCloseBrowser();
					}
				} catch (Exception e) {

					e.printStackTrace();
				} finally {
					endTestScript();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
	}
}
