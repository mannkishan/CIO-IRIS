/**
 * 
 */
package testScripts;

import org.apache.xmlbeans.impl.xb.xsdschema.impl.GroupImpl;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.GroupInfoPage;
import page.GroupPage;
import page.LoginPage;
import page.MenuPage;
import utility.CoreSuperHelper;

/**
 * <p>
 * manualTestCase :TC_Def_017.001
 * </p>
 * *
 * <p>
 * comments: Verify that "Print Date" field in "Group Info" page is populated by default with same value as "Effective Date" for VA region
 * </p>
 * * *
 * 
 * @author: AF60410 Sandeep Reddy R
 * @since: Dec 1, 2017
 */

public class TC_Def_017_TS extends CoreSuperHelper {

	static String strBaseUrl = EnvHelper.getValue("url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		try {

			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {

				try {
					logExtentReport("TC_Def_017_TS");
					if (getCellValue("Run_Flag").equalsIgnoreCase("Yes")) {

						// Open Browser
						seOpenBrowser(BrowserConstants.InternetExplorer, strBaseUrl);
						LoginPage.get().loginApplication(strUserProfile);
						seWaitForPageLoad();
						MenuPage.get().clickVirginia();
						// seWaitForPageLoad();
						Thread.sleep(20000);
						GroupPage.get().clickNewGroup();
						seWaitForPageLoad();
						GroupInfoPage.get().validateDefaultNewVA();
						seWaitForPageLoad();
						GroupInfoPage.get().seEnterValuesNewGroupForm();
						seWaitForPageLoad();
						setResult("STATUS", RESULT_STATUS);
					}
				} catch (Exception e) {

					e.printStackTrace();
				} finally {
					endTestScript();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			seCloseBrowser();
		}
	}

}
