package testScripts;
import java.io.FileInputStream;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.CensusPage;
import page.GroupInfoPage;
import page.GroupPage;
import page.LoginPage;
import page.ZonePage;
import utility.CoreSuperHelper;
import utility.PDFValidator;
import utility.WellQuoteUtility;

/*

*/

/**
 * Manual test case: TC_BMS_Reg_Census_003
 * <p>
 * 
 * @author AF14733
   @since 23/11/17
   @Revision<>
 *
 */
public class TC_BMS_Reg_Census_003  extends CoreSuperHelper {
	
static String strBaseUrl = EnvHelper.getValue("url");
static String strUserProfile = EnvHelper.getValue("user.profile");	

/**
 * @param args
 */
public static  void main(String[] args) {
	
try{
		
     initiateTestScript();
		
     for(iROW=1;iROW<=getRowCount();iROW++) {
		
     try {
			logExtentReport("TC_BMS_Reg_Census_003");
			if (getCellValue("Run_Flag").equalsIgnoreCase("Yes")) {
				 
					//Open Browser
					seOpenBrowser(BrowserConstants.InternetExplorer, strBaseUrl);
					LoginPage.get().loginApplication(strUserProfile);
					seWaitForPageLoad();
				//	Thread.sleep(20000);
					seClick(ZonePage.get().centralZoneLink, "Click on CentralZoneLink in the Zone Page");
				//	seWaitForPageLoad();
					Thread.sleep(10000);
					seClick(GroupPage.get().newGroupLink, "Click on NewGroup Link in the Group Page");
					seWaitForPageLoad();
					// Enter Values in Group info page
					GroupInfoPage.get().seEnterValuesNewGroup();
					Thread.sleep(5000);
					CensusPage.get().seEnterValues_CensusPage();
					//Total Number Of Employees
					WellQuoteUtility.clickAtCell(CensusPage.get().table,"Get Cell Value of Row Count");
					setResult("STATUS", RESULT_STATUS);
				//	seCloseBrowser();
			}
         } catch (Exception e) {
				
            e.printStackTrace();
            }
           finally {
               endTestScript();
                }
		}
}
catch(Exception e){
 e.printStackTrace();
}
finally{
	//seCloseBrowser();
}
}
}
