package testScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import page.BenefitSummariesPage;
import page.CensusPage;
import page.GroupInfoPage;
import page.GroupPage;
import page.LoginPage;
//import page.MenuPage;
import page.ZonePage;
import utility.CoreSuperHelper;

/**
 * Manual test case: TC_Def_007.001 
 * Verify that "Name" field in "Group Info" page is required.
 * validation for for CZ region,New Business.
 * <p>
 * @author AF54545
 * @since 11/30/2017
 * @Revision<>
 *
 */
public class TC_Reg_BMS_New_032 extends CoreSuperHelper {

	static String strBaseUrl = EnvHelper.getValue("url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {

		try {
			MANUAL_TC_EXECUTION_EFFORT="00:15:00";
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {

				try {
					
					String strname = getCellValue("Name");
					String strDropdown = getCellValue("Dropdown");
					String strAddress = getCellValue("Address");
					String strCity = getCellValue("City");
					String strZipcode = getCellValue("Zipcode");
					String strEffectivedate = getCellValue("Effectivedate");
					String strBillAs =getCellValue("BillAs");
					String strMarketCode =getCellValue("MarketCode");
					String strEligibleEmployees = getCellValue("EligibleEmployees");
					String strCurrentCarrier = getCellValue("CurrentCarrier");
					String strOffice = getCellValue("Office");
					String strSICCodeID = getCellValue("SICCodeID");
					String strSalesRepID = getCellValue("SalesRepID");
					String strBrokerID = getCellValue("BrokerID");
					//String strBroker = getCellValue("Broker");
					String strcensusdropdown = getCellValue("Censusdropdown");
					String strcensustypedropdown = getCellValue("Censustypedropdown");
					String strEmployees = getCellValue("EligibleEmployees");
					String strRatingType = getCellValue("ratingType");
					//String strDOB = getCellValue("DOB");
					String strAge = getCellValue("AGE");
					String strSex = getCellValue("Sex");
					String strX = getCellValue("X");
					String strEdition = getCellValue("Edition");
					String stroption = getCellValue("Option_Bundles");
					String strHealth = getCellValue("Health");
					String strDental = getCellValue("Dental");
					String strVision = getCellValue("Vision");
					logExtentReport("TC_Reg_BMS_New_032");
					if (getCellValue("Run_Flag").equalsIgnoreCase("Yes")) {

						//Open Browser
						seOpenBrowser(BrowserConstants.InternetExplorer, strBaseUrl);
						LoginPage.get().loginApplication(strUserProfile);
						//seWaitForPageLoad();
						Thread.sleep(10000);
						seClick(ZonePage.get().centralZoneLink, "Click on CentralZoneLink in the Zone Page");
					//	seWaitForPageLoad();
						Thread.sleep(10000);
						seClick(GroupPage.get().newGroupLink, "Click on NewGroup Link in the Group Page");
						//seWaitForPageLoad();
						Thread.sleep(8000);
						// Enter Values in Group info pagek
						seSetText(GroupInfoPage.get().name, strname ,"Set Name in Name Field ");
						seWaitForPageLoad();
						GroupInfoPage.get().verifyDropDownvalueNew(strDropdown);
						seWaitForPageLoad();				
						seSetText(GroupInfoPage.get().address, strAddress ,"Set Address in Address Field ");
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().city_GrpInfo, strCity ,"Set City in City Field ");
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().effDate,strEffectivedate,"Set Effective date ");
						seWaitForPageLoad();
						GroupInfoPage.get().verifyPrintDate(strEffectivedate);
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().zipCode,strZipcode,"Set Zipcode in Zipcode Field ");
						seWaitForPageLoad();
						seSelectText(GroupInfoPage.get().dropdown_Bill, strBillAs, "Set Bill as in dropdown Field");
						seWaitForPageLoad();
						seSetText(GroupInfoPage.get().eligibleEmpl, strEligibleEmployees ,"Set Eligible Employees in Eligibl Employees Field ");
						seWaitForPageLoad();
						seSelectText(GroupInfoPage.get().marketCode, strMarketCode, "Set Market Code in Market Code Field");
						seWaitForPageLoad();
						Thread.sleep(2000);
						driver.findElement(By.xpath("//table[@id='GroupInfoView.tableTable']/tbody/tr[15]/td[2]/div/input[@type='text']")).sendKeys(strCurrentCarrier);
						Robot r = new Robot();
						Thread.sleep(2000);
						r.keyPress(KeyEvent.VK_ENTER);
						r.keyRelease(KeyEvent.VK_ENTER); 
						Thread.sleep(2000);
						seSelectText(GroupInfoPage.get().Office, strOffice, "Set Office in Office Field");
						//seWaitForPageLoad();
						Thread.sleep(2000);
						GroupInfoPage.get().validateAssociation();
						Thread.sleep(2000);
						GroupInfoPage.get().validateSub_Assoc();
						seWaitForPageLoad();
						Thread.sleep(2000);
						seSetText(GroupInfoPage.get().sicCode_id, strSICCodeID, "Set SIC Code ID in SIC Code ID Field");
						seWaitForPageLoad();
						Thread.sleep(4000);
						seSetText(GroupInfoPage.get().salesRepid, strSalesRepID, "Set Sales Rep ID in Sales Rep ID Field");
						seWaitForPageLoad();
						Thread.sleep(6000);
						seSetText(GroupInfoPage.get().brokerID, strBrokerID, "Set Broker ID in Broker ID Field");
						seWaitForPageLoad();
						Thread.sleep(4000);
						seClick(GroupInfoPage.get().comments, "Click on Comments Box");
						Thread.sleep(2000);
						seClick(GroupInfoPage.get().btnNext, "Click on Next Button");
						Thread.sleep(12000);
						//validate Census Page Header
						CensusPage.get().validateCensusPageHeader();
						Thread.sleep(5000);
						GroupInfoPage.get().verifyDropDownvalue(strcensusdropdown);
						Thread.sleep(4000);
						CensusPage.get().verifyCenusType(strcensustypedropdown);
						seWaitForPageLoad();
						CensusPage.get().verifyEligEmp(strEmployees);
						seWaitForPageLoad();
						CensusPage.get().verifyratingType(strRatingType);
						seWaitForPageLoad();
						if(CensusPage.get().ageCheckBox.isSelected())
						{
							RESULT_STATUS = true;
							log(PASS, "Age checkbox should be checked in Allow Entry of section in the census screen",
									"Age checkbox checked in Allow Entry of section in the census screen", true);
						}else
						{
							RESULT_STATUS = false;
							log(FAIL, "Age checkbox Not checked in Allow Entry of section in the census screen",
									"Age checkbox is not checked in Allow Entry of section in the census screen", true);
						}
						seClickCheckBox(CensusPage.get().dobCheckBox, "Select Date of birth check box");
						seSetText(CensusPage.get().txtboxAge,strAge,"Set Age in dob Field ");
						Thread.sleep(2000);
						seSetText(CensusPage.get().txtboxSex,strSex,"Set Sex in Sex Field ");
						Thread.sleep(2000);
						seSetText(CensusPage.get().txtHealth,strHealth,"Set Health in Health Field ");
						Thread.sleep(2000);
						seSetText(CensusPage.get().txtDental,strDental,"Set Dental in Dental Field ");
						Thread.sleep(2000);
						seSetText(CensusPage.get().txtVision,strVision,"Set Vision in Vision Field ");
						Thread.sleep(2000);
						CensusPage.get().verifyDefaultValinCensusGrid();
						seSetText(CensusPage.get().txtX,strX,"Set X value in X Field ");
						Thread.sleep(2000);
						seClick(CensusPage.get().totalEmployeeLable, "Select total employee lable");
						Thread.sleep(2000);
						String totalEmp = seGetElementValue(CensusPage.get().totalEmp).toString();
						if(totalEmp.equals(strX)){
							RESULT_STATUS = true;
							log(PASS, "Total Employees "+totalEmp+ "should be auto populated in the Census screen");
						}else
						{
							RESULT_STATUS = false;
							log(FAIL, "Total Employees not populated in the Census screen");
						}
						Thread.sleep(2000);
						seClick(CensusPage.get().censusviewNextbtn, "Click on Next Button from Census view");
						Thread.sleep(10000);
						seClick(CensusPage.get().yesDiologCensus, "Click on Yes  from Census view");
						Thread.sleep(12000);
						seClick(CensusPage.get().groupLoadNextbtn, "Click on Next Button from Group Load");
						Thread.sleep(10000);
						seClick(CensusPage.get().yesDiologCensus, "Click on Yes  from Census view");
						Thread.sleep(10000);
						seClick(BenefitSummariesPage.get().blueMCBPLink, "Click on BlueMCBP Link from Benefit screen");
						Thread.sleep(4000);
						seSelectText(BenefitSummariesPage.get().edition, strEdition, "Select edition form benefit");
						Thread.sleep(4000);
						seSelectText(BenefitSummariesPage.get().option, stroption, "Select option form benefit");
						Thread.sleep(4000);
						seClick(BenefitSummariesPage.get().okBtn_Benefit, "Click on Ok Button from Benefit");
						Thread.sleep(5000);
						//seClick(BenefitSummariesPage.get().clearBtn_Benefit, "Click on Clear Button from Benefit");
						//Thread.sleep(2000);
						if(BenefitSummariesPage.get().blueMCBPLink.isEnabled())
						{
							RESULT_STATUS = true;
							log(PASS,  "Blue MCBP - Not Selected' link is not available under Health product selection section",
									"Verified the 'Blue MCBP - Not Selected' link is not available under Health product selection section",true);
						}else
						{
							RESULT_STATUS = false;
							log(FAIL,  "Blue MCBP - Not Selected' link available under Health product selection section",
									"Blue MCBP - Not Selected' link is available under Health product selection section",true);
						}
						
					}
					
						setResult("STATUS", RESULT_STATUS);
						seCloseBrowser();
					
				} catch (Exception e) {

					e.printStackTrace();
				} finally {
					endTestScript();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
	}
}
