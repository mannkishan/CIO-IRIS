/**
 * 
 */
package utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Calendar;
import java.util.Locale;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;

import com.anthem.selenium.utility.ExcelUtility;
import com.anthem.selenium.utility.ReadWordDocxUtils;

import utility.CoreSuperHelper;

public class PDFValidator extends ReadWordDocxUtils {

	public XWPFDocument docx;

	public void verify(String sWordDocumentPath) {

		try {	
			
			docx = new XWPFDocument(new FileInputStream("C:\\Users\\AF14733\\Desktop\\Sample PDF_Converted.docx"));
			
			//**************************PDF page 1***********************************************//
			
			// Table 1 Validadtion
			XWPFTable table1 = getTableContainingText(docx,"Calendar Year Deductible (individual/family)");
            CoreSuperHelper.aTafContainString(table1.getRow(0).getCell(1).getText(), "Network", "Network");
            CoreSuperHelper.aTafContainString(table1.getRow(1).getCell(0).getText(), "Calendar Year Deductible (individual/family)", "Calendar Year Deductible (individual/family)");
            
			
		//	for Wellcore Sample PDF Table 2 Column Validation :
			XWPFTable tableIfSummary = getTableContainingText(docx,"Out-of-Pocket Limit (Single/Family) (1)");
			CoreSuperHelper.aTafContainString(tableIfSummary.getRow(0).getCell(0).getText(), "Covered Benefits", "Covered Benefits");
            CoreSuperHelper.aTafContainString(tableIfSummary.getRow(0).getCell(1).getText(), "Network", "Network");
        //    for Wellcore Sample PDF Cell Validation :
            CoreSuperHelper.aTafContainString(tableIfSummary.getRow(1).getCell(0).getText(), "Out-of-Pocket Limit (Single/Family) (1)", "Out-of-Pocket Limit (Single/Family) (1)");
            CoreSuperHelper.aTafContainString(tableIfSummary.getRow(1).getCell(1).getText(), "$7,350/$14,700", "$7,350/$14,700");
			
            
            String strFirsPara = getParagraphContainingText(docx, "Durable Medical Equipment, cost share varies by service Outpatient Therapies");
            
            String parag2 = getParagraphContainingText(docx, "Physical/Manipulation Therapy excluding Chiropractic Services: 20 visit limit");
         // String strFirsPara = getParagraphContainingText(docx, "Other Network Services:");
			CoreSuperHelper.aTafContainString(strFirsPara, "Durable Medical Equipment, cost share varies by service Outpatient Therapies", "Durable Medical Equipment, cost share varies by service Outpatient Therapies"); // 1
			CoreSuperHelper.aTafContainString(parag2, "Physical/Manipulation Therapy excluding Chiropractic Services: 20 visit limit",  "Validate Physical/Manipulation Therapy"); // 2
		//	CoreSuperHelper.aTafContainString(strFirsPara, "Allergy injections", "Allergy injections"); // 3

			
			String strValidateParag = getParagraphContainingText(docx, "Per the Affordable Care Act (or health care reform law), Summary of Benefits and Coverage (SBCs) can be accessed through our Internet Posting Site at sbc.anthem.com/ dps/.");
            String strvalidate= "Per the Affordable Care Act (or health care reform law), Summary of Benefits and Coverage (SBCs) can be accessed through our Internet Posting Site at sbc.anthem.com/ dps/.";
			CoreSuperHelper.aTafContainString(strValidateParag, strvalidate, "Validate WQ output"); // 1

			
			
			
            //	docx = new XWPFDocument(new FileInputStream(sWordDocumentPath));
			
			/*docx = new XWPFDocument(new FileInputStream("C:\\Users\\AF14733\\Desktop\\CA_I_F_CDHP_NA_GANJA_NA_0917_SBC_2017_Converted.docx"));
			
			String strFirsPara = getParagraphContainingText(docx, "Summary of Benefits and Coverage:");
			int intCurrentYear = Calendar.getInstance().get(Calendar.YEAR); // fetch the current year
			intCurrentYear = intCurrentYear + 1; // incrememnt it by 1 so that we get the next year
			String strCurrentYear = String.valueOf(intCurrentYear);
			CoreSuperHelper.aTafContainString(strFirsPara, "Coverage Period: 01/01/" + strCurrentYear + "� 12/31/" + strCurrentYear, "Coverage Period"); // 1
			CoreSuperHelper.aTafContainString(strFirsPara, "Plan Type: " + CoreSuperHelper.getCellValue("Plan_Type"), "Plan Type"); // 2
			CoreSuperHelper.aTafContainString(strFirsPara, "Coverage for: " + CoreSuperHelper.getCellValue("Coverage Type"), "Coverage Type"); // 3

			
			String table = "The Summary of Benefits and Coverage (SBC) document will help you choose a health plan. The SBC shows you how you and the  plan would share the cost for covered health care services. "
					+ "NOTE: Information about the cost of this plan (called the premium) will be provided separately. This is only a summary. "
					+ "For more information about your coverage, or to get a copy of the complete terms "
					+ "of coverage, https://eoc.anthem.com/eocdps/ca/fi. For general definitions of "
					+ "common terms, such as allowed amount, balance billing, coinsurance,  copayment, deductible, provider, or other underlined terms see "
					+ "	the Glossary. You can view the Glossary at www.healthcare.gov/sbc-glossary/ or call (855) 333-5730 to request a copy.";
			
			//**************************PDF page 1***********************************************/
		/*	String strFirsPara = getParagraphContainingText(docx, "Summary of Benefits and Coverage:");
			int intCurrentYear = Calendar.getInstance().get(Calendar.YEAR); // fetch the current year
			intCurrentYear = intCurrentYear + 1; // incrememnt it by 1 so that we get the next year
			String strCurrentYear = String.valueOf(intCurrentYear);
			CoreSuperHelper.aTafContainString(strFirsPara, "Coverage Period: 01/01/" + strCurrentYear + "� 12/31/" + strCurrentYear, "Coverage Period"); // 1
			CoreSuperHelper.aTafContainString(strFirsPara, "Plan Type: " + CoreSuperHelper.getCellValue("Plan_Type"), "Plan Type"); // 2
			CoreSuperHelper.aTafContainString(strFirsPara, "Coverage for: " + CoreSuperHelper.getCellValue("Coverage Type"), "Coverage Type"); // 3

		//	for Wellcore PDF :
			XWPFTable tableIfSummary = getTableContainingText(docx, table);
			CoreSuperHelper.aTafContainString(tableIfSummary.getRow(1).getCell(0).getText(), "What is the overall deductible?", "What is the overall deductible?");
            CoreSuperHelper.aTafContainString(tableIfSummary.getRow(1).getCell(0).getText(), "Important Questions", "Important Questions");
        //    CoreSuperHelper.aTafContainString(tableIfSummary.getRow(0).getCell(1).getText(), "Important Questions", "Important Questions");	
			
			
			
			XWPFTable tableIfYouNeedMentalHealth = getTableContainingText(docx, "If you need mental health, behavioral health, or substance abuse services");
			CoreSuperHelper.aTafContainString(tableIfYouNeedMentalHealth.getRow(0).getCell(0).getText(), "Common Medical Event", "Common Medical Event");
            CoreSuperHelper.aTafContainString(tableIfYouNeedMentalHealth.getRow(0).getCell(1).getText(), "Services You May Need", "Services You May Need");
            CoreSuperHelper.aTafContainString(tableIfYouNeedMentalHealth.getRow(0).getCell(2).getText(), "What You Will Pay", "What You Will Pay");
			
			*/
			
        
           		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	
	public void verify1(String sWordDocumentPath) {

		try {			
			
			docx = new XWPFDocument(new FileInputStream(sWordDocumentPath));
			
			
			//**************************PDF page 1***********************************************//
			String strFirsPara = getParagraphContainingText(docx, "Summary of Benefits and Coverage:");
			int intCurrentYear = Calendar.getInstance().get(Calendar.YEAR); // fetch the current year
			intCurrentYear = intCurrentYear + 1; // incrememnt it by 1 so that we get the next year
			String strCurrentYear = String.valueOf(intCurrentYear);
			CoreSuperHelper.aTafContainString(strFirsPara, "Coverage Period: 01/01/" + strCurrentYear + "� 12/31/" + strCurrentYear, "Coverage Period"); // 1
			CoreSuperHelper.aTafContainString(strFirsPara, "Plan Type: " + CoreSuperHelper.getCellValue("Plan_Type"), "Plan Type"); // 2
			CoreSuperHelper.aTafContainString(strFirsPara, "Coverage for: " + CoreSuperHelper.getCellValue("Coverage Type"), "Coverage Type"); // 3

			XWPFTable tableSummaryOfBenefitsAndCoverage = getTableContainingText(docx, "The Summary of Benefits and Coverage");
			CoreSuperHelper.aTafContainString(tableSummaryOfBenefitsAndCoverage.getRow(0).getCell(0).getText(), CoreSuperHelper.getCellValue("EOC Microsite"), "EOC Microsite"); // 4
			CoreSuperHelper.aTafContainString(tableSummaryOfBenefitsAndCoverage.getRow(0).getCell(0).getText(), "www.healthcare.gov/sbc-glossary/", "SBC Glossary"); // 5
			CoreSuperHelper.aTafContainString(tableSummaryOfBenefitsAndCoverage.getRow(0).getCell(0).getText(), CoreSuperHelper.getCellValue("CSR Phone"), "CSR Phone"); // 5

				CoreSuperHelper.aTafContainString(tableSummaryOfBenefitsAndCoverage.getRow(3).getCell(0).getText(), "What is the overall deductible?", "Important question: What is the overall deductible?"); // 6
			NumberFormat nmbrfrmtUSDollar = NumberFormat.getCurrencyInstance(Locale.US);
			String strAnswer = nmbrfrmtUSDollar.format(Integer.parseInt(CoreSuperHelper.getCellValue("Deductible Amount")));
			CoreSuperHelper.aTafContainStringIgnoreCase(tableSummaryOfBenefitsAndCoverage.getRow(3).getCell(1).getText(),
					strAnswer.substring(0, strAnswer.length() - 3) + "/" + CoreSuperHelper.getCellValue("Deductible Type") + " for " + CoreSuperHelper.getCellValue("Deductible Network Name") + " Providers.",
					"Answer: What is the overall deductible?"); // 6

			CoreSuperHelper.aTafContainString(tableSummaryOfBenefitsAndCoverage.getRow(4).getCell(0).getText(), "Are there services covered before you meet your deductible?",
					"Important question: Are there services covered before you meet your deductible?"); // 7
			CoreSuperHelper.aTafContainString(tableSummaryOfBenefitsAndCoverage.getRow(4).getCell(1).getText(), "No.", "Answer: Are there services covered before you meet your deductible?"); // 7

			CoreSuperHelper.aTafContainString(tableSummaryOfBenefitsAndCoverage.getRow(5).getCell(0).getText(), "Are there other  deductibles for specific services?", "Important question: Are there other  deductibles for specific services?"); // 8
			CoreSuperHelper.aTafContainString(tableSummaryOfBenefitsAndCoverage.getRow(5).getCell(1).getText(), "No.", "Answer: Are there other  deductibles for specific services?"); // 8
			CoreSuperHelper.aTafContainString(tableSummaryOfBenefitsAndCoverage.getRow(6).getCell(0).getText(), "What is the out-of-  pocket limit for this plan?", "Important question: What is the out-of-  pocket limit for this plan?"); // 9
			strAnswer = nmbrfrmtUSDollar.format(Integer.parseInt(CoreSuperHelper.getCellValue("Out of Pocket Amount")));
			CoreSuperHelper.aTafContainStringIgnoreCase(tableSummaryOfBenefitsAndCoverage.getRow(6).getCell(1).getText(),
					strAnswer.substring(0, strAnswer.length() - 3) + "/" + CoreSuperHelper.getCellValue("Out of Pocket Type") + " for " + CoreSuperHelper.getCellValue("Out of Pocket Network Name") + " Providers.",
					"Answer: What is the out-of-  pocket limit for this plan?"); // 9
			
			 // CoreSuperHelper.aTafContainString(tableSummaryOfBenefitsAndCoverage.getRow(9).getCell(1).getText(), "data", "data"); //10 
		
			CoreSuperHelper.aTafContainString(tableSummaryOfBenefitsAndCoverage.getRow(8).getCell(0).getText(), "Will you pay less if you use a network  provider?", "Important question: Will you pay less if you use a network  provider?"); // 11
			CoreSuperHelper.aTafContainString(tableSummaryOfBenefitsAndCoverage.getRow(8).getCell(1).getText(), "Not Applicable.", "Answer: Will you pay less if you use a network  provider?"); // 11
			CoreSuperHelper.aTafContainString(tableSummaryOfBenefitsAndCoverage.getRow(9).getCell(0).getText(), "Do you need a referral to see a specialist?", "Important question: Do you need a referral to see a specialist?"); // 12
			CoreSuperHelper.aTafContainString(tableSummaryOfBenefitsAndCoverage.getRow(9).getCell(1).getText(), "No.", "Answer: Do you need a referral to see a specialist?"); // 12
			
			
			//***************************************************PDF page 2***********************************************//		
			
			
			
			
			XWPFTable tableCommonMedicalEvent = getTableContainingText(docx, "Common Medical Event");
            XWPFTable tableIfyouhaveatest = getTableContainingText(docx, "If you have a test");
            
            if(tableCommonMedicalEvent.getRow(2).getCell(1).getText().concat(" ").concat(tableIfyouhaveatest.getRow(2).getCell(1).getText()).equalsIgnoreCase("Primary care visit to treat an injury or illness"))
            {
            //Primary care visit to treat an injury or illness
            CoreSuperHelper.aTafContainString(tableCommonMedicalEvent.getRow(2).getCell(2).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableCommonMedicalEvent.getRow(2).getCell(3).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableCommonMedicalEvent.getRow(2).getCell(4).getText().concat(tableIfyouhaveatest.getRow(2).getCell(4).getText()),"10 day limit every 3 months for In-Network Providers for Inpatient Rehabilitation."
                         + " Freeform. 1 surgery every 5 years under the HMO benefit","Limitations, Exceptions, & Other Important Information"); // 
           //Specialist visit
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(3).getCell(2).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(3).getCell(3).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(3).getCell(4).getText(), "10 day limit every 3 months for In- Network Providers for Inpatient "
                         + "Rehabilitation. Freeform. 1 surgery every 5 years under the HMO benefit" ,"Limitations, Exceptions, & Other Important Information"); 
          
            //Preventive care/screening/ immunization
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(4).getCell(2).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(4).getCell(3).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(4).getCell(4).getText(), "10 day limit every 3 months for In-  Network Providers for Inpatient Rehabilitation. Freeform. 1 surgery every 5 "
                     + "years under the HMO benefit You may have to pay for services that aren't preventive. Ask your provider if the services needed are preventive."
                     + "Then check what your plan will pay for." ,"Limitations, Exceptions, & Other Important Information"); 
          
            //Diagnostic test (x-ray, blood work)
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(5).getCell(2).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(5).getCell(3).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(5).getCell(4).getText(), "Lab � Office10 day limit every 3 months for In-  Network Providers for Inpatient Rehabilitation. Freeform. 1 surgery"
                     + " every 5 years under the HMO benefit X-Ray � Office10 day limit every 3 months for In-  Network Providers for Inpatient Rehabilitation. Freeform. "
                     + "1 surgery every 5 years under the HMO benefit" ,"Limitations, Exceptions, & Other Important Information"); 
            
          //Imaging (CT/PET scans, MRIs)
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(6).getCell(2).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(6).getCell(3).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(6).getCell(4).getText(), "10 day limit every 3 months for In- Network Providers for Inpatient Rehabilitation. Freeform. 1 surgery every"
                     + " 5 years under the HMO benefit" ,"Limitations, Exceptions, & Other Important Information"); 
             
            //Tier 1 - Typically Generic
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(7).getCell(2).getText(),"Not covered", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(7).getCell(3).getText(), "Not covered", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(7).getCell(4).getText(), "Most home delivery is 90-day supply.*See Prescription Drug section of the  plan "
                     + "or policy document (e.g. evidence of coverage or certificate)." ,"Limitations, Exceptions, & Other Important Information"); 
             
          //  Tier 2 - Typically Preferred / Brand
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(8).getCell(2).getText(),"Not covered", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(8).getCell(3).getText(), "Not covered", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(7).getCell(4).getText(), "Most home delivery is 90-day supply.*See Prescription Drug section of the  plan "
                     + "or policy document (e.g. evidence of coverage or certificate)." ,"Limitations, Exceptions, & Other Important Information"); 
             
            //Tier 3 - Typically Non-Preferred/ Specialty Drugs

            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(9).getCell(2).getText(),"Not covered", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(9).getCell(3).getText(), "Not covered", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(7).getCell(4).getText(), "Most home delivery is 90-day supply.*See Prescription Drug section of the  plan "
                     + "or policy document (e.g. evidence of coverage or certificate)." ,"Limitations, Exceptions, & Other Important Information"); 
            }
            
            
            
          //***************************************************PDF page 3***********************************************//
            
            
            
            
            XWPFTable tableIfYouHaveOutPatientSurgery = getTableContainingText(docx, "If you have outpatient surgery");
            
            // Column Header Validation
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(0).getCell(0).getText(), "Common Medical Event", "Common Medical Event");
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(0).getCell(1).getText(), "Services You May Need", "Services You May Need");
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(0).getCell(2).getText(), "What You Will Pay", "What You Will Pay");
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(0).getCell(3).getText(), "Limitations, Exceptions, & Other Important Information", "Limitations, Exceptions, & Other Important Information");
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(1).getCell(2).getText(), "In-Network Provider", "In-Network Provider");
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(1).getCell(3).getText(), "Out-Network Provider", "Out-Network Provider");

            // Tier 4 - Typically Specialty (brand and generic)
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(7).getCell(0).getText().concat(tableIfYouHaveOutPatientSurgery.getRow(2).getCell(0).getText()),"If you need drugs to treat your illness or conditionMore informationabout prescription drug coverage is available at  http://www.restat.c  om"+ExcelUtility.getCellValue("Formulary Drug List"), "Services You May Need"); // 
            
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(2).getCell(1).getText(),"Tier 4 - Typically Specialty (brand and generic)", "Services You May Need"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(2).getCell(2).getText(),"Not covered", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(2).getCell(3).getText(), "Not covered", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfyouhaveatest.getRow(7).getCell(4).getText(), "Most home delivery is 90-day supply.*See Prescription Drug section of the  plan "
                     + "or policy document (e.g. evidence of coverage or certificate)." ,"Limitations, Exceptions, & Other Important Information"); 
           
            //Facility fee (e.g., ambulatory surgery center)
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(3).getCell(1).getText(), "Facility fee (e.g., ambulatory surgery center)", "Services You May Need"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(3).getCell(2).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(3).getCell(3).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(3).getCell(4).getText(), "10 day limit every 3 months for In-  Network Providers for Inpatient Rehabilitation. Freeform. 1 surgery every 5 years under the HMO benefit" ,"Limitations, Exceptions, & Other Important Information"); 
            
            //Physician/surgeon fees
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(4).getCell(1).getText(), "Physician/surgeon fees", "Services You May Need");  
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(4).getCell(2).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(4).getCell(3).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(4).getCell(4).getText(), "10 day limit every 3 months for In-  Network Providers for "
                     + "Inpatient Rehabilitation. Freeform. 1 surgery every 5 years under the HMO benefit$"+ExcelUtility.getCellValue("Cost Share Amount")+" coinsurance for Physician. "
                     + "$"+ExcelUtility.getCellValue("Cost Share Amount")+"  coinsurance for Anesthesia." ,"Limitations, Exceptions, & Other Important Information"); 
            
            //Emergency room care
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(5).getCell(1).getText(), "Emergency room care", "Services You May Need");  
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(5).getCell(2).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(5).getCell(3).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(5).getCell(4).getText(), "10 day limit every 3 months for In-  Network Providers for Inpatient Rehabilitation. Freeform. 1 surgery every "
                     + "5 years under the HMO benefit$"+ExcelUtility.getCellValue("Cost Share Amount")+" coinsurance for Emergency Room Physician Fee." ,"Limitations, Exceptions, & Other Important Information"); 
            
			
            //Emergency medical transportation
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(6).getCell(1).getText(), "Emergency medical  transportation", "Services You May Need");  
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(6).getCell(2).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(6).getCell(3).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(6).getCell(4).getText(), "10 day limit every 3 months for In-  Network Providers for Inpatient Rehabilitation. Freeform. 1 surgery every 5 years under the HMO benefit"
                     ,"Limitations, Exceptions, & Other Important Information"); 
            	
            
            //Urgent care
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(7).getCell(1).getText(), "Urgent care", "Services You May Need");  
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(7).getCell(2).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(7).getCell(3).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(7).getCell(4).getText(), "10 day limit every 3 months for In- Network Providers for Inpatient Rehabilitation. Freeform. 1 surgery every 5 years under the HMO benefit"
                     ,"Limitations, Exceptions, & Other Important Information"); 
            
            //Facility fee (e.g., hospital room)
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(8).getCell(1).getText(), "Facility fee (e.g., hospital room)", "Services You May Need");  
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(8).getCell(2).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(8).getCell(3).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(8).getCell(4).getText(), "10 day limit every 3 months for In- Network Providers for Inpatient Rehabilitation. Freeform. 1 surgery every 5 years under the HMO benefit"
                     ,"Limitations, Exceptions, & Other Important Information"); 
            
            
            //Physician/surgeon fees
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(9).getCell(1).getText(), "Physician/surgeon fees", "Services You May Need");  
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(9).getCell(2).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "In-Network Provider (You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(9).getCell(3).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+ " coinsurance", "Out-Network Provider(You will pay the least)"); // 
            CoreSuperHelper.aTafContainString(tableIfYouHaveOutPatientSurgery.getRow(9).getCell(4).getText().concat(tableIfYouHaveOutPatientSurgery.getRow(2).getCell(4).getText()), "10 day limit every 3 months for In-  Network Providers for Inpatient Rehabilitation. Freeform. 1 surgery"
                     ,"Limitations, Exceptions, & Other Important Information"); 
            
            
            
            
            //***************************************************PDF page 4***********************************************//
            
          
			XWPFTable tableMentalHealth = getTableContainingText(docx, "If you need mental health, behavioral health, or substance abuse services");
			//Column Header Validation
			CoreSuperHelper.aTafContainString(tableMentalHealth.getRow(0).getCell(0).getText(), "Common Medical Event", "Common Medical Event");
			CoreSuperHelper.aTafContainString(tableMentalHealth.getRow(0).getCell(1).getText(), "Services You May Need", "Services You May Need");
			CoreSuperHelper.aTafContainString(tableMentalHealth.getRow(0).getCell(2).getText(), "What You Will Pay", "What You Will Pay");
			CoreSuperHelper.aTafContainString(tableMentalHealth.getRow(0).getCell(3).getText(), "Limitations, Exceptions, & Other Important Information", "Limitations, Exceptions, & Other Important Information");
			CoreSuperHelper.aTafContainString(tableMentalHealth.getRow(1).getCell(2).getText(), "In-Network Provider (You will pay the least)", "In-Network Provider");
			CoreSuperHelper.aTafContainString(tableMentalHealth.getRow(1).getCell(3).getText(), "Out-Network Provider (You will pay the most)", "Out-Network Provider");
			
			//'If you need mental health, behavioral health, or substance abuse services' - section validation. Except 'Limitations, Exceptions, & Other Important Information column' values
			CoreSuperHelper.aTafContainString(tableMentalHealth.getRow(3).getCell(0).getText(), "If you need mental health, behavioral health, or substance abuse services", "If you need mental health, behavioral health, or substance abuse services");
			CoreSuperHelper.aTafContainString(tableMentalHealth.getRow(3).getCell(1).getText(), "Outpatient services", "Outpatient services");
			CoreSuperHelper.aTafContainString(tableMentalHealth.getRow(3).getCell(2).getText(), "Office Visit$"+ExcelUtility.getCellValue("Cost Share Amount")+" coinsurance Other Outpatient$"+ExcelUtility.getCellValue("Cost Share Amount")+" coinsurance", "In-Network Provider");
			CoreSuperHelper.aTafContainString(tableMentalHealth.getRow(3).getCell(3).getText(), "Office Visit$"+ExcelUtility.getCellValue("Cost Share Amount")+" coinsurance Other Outpatient$"+ExcelUtility.getCellValue("Cost Share Amount")+" coinsurance", "Out-Network Provider");
			CoreSuperHelper.aTafContainString(tableMentalHealth.getRow(4).getCell(1).getText(), "Inpatient services", "Inpatient services");
			CoreSuperHelper.aTafContainString(tableMentalHealth.getRow(4).getCell(2).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+" coinsurance", "In-Network Provider");
			CoreSuperHelper.aTafContainString(tableMentalHealth.getRow(4).getCell(3).getText(), "$"+ExcelUtility.getCellValue("Cost Share Amount")+" coinsurance", "Out-Network Provider");

            //limitation tab
			CoreSuperHelper.aTafContainString(tableMentalHealth.getRow(4).getCell(4).getText(), "10 day limit every 3 months for In-  Network Providers for Inpatient Rehabilitation. Freeform. 1 surgery every 5 years under the HMO benefit$"+ExcelUtility.getCellValue("Cost Share Amount")+" coinsurance for Inpatient Physician Fee.", "Limitation Tab");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
