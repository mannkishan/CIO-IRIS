package utility;
import java.io.File;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.anthem.selenium.SuperHelper;
import com.anthem.selenium.constants.ApplicationConstants;
import com.anthem.selenium.logging.AnthemLogger;
import com.anthem.selenium.utility.ExtentReportsUtility;

import page.CensusPage;
import page.GroupInfoPage;
import page.GroupSearchPage;

public class WellQuoteUtility extends SuperHelper {

	protected static AnthemLogger logger;

	
	public static void seVerifyDropdownisEnabled(WebElement element) {

		try {
			if(element.isEnabled())
			{
			log(PASS, " To Verify Dropdown value is Present ","Verified Dropdown value is present", true);	
			}
			else
				log(FAIL, "Dropdown value not Selected" ,"Verified Dropdown value is Not present", true);	
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public static void seVerifylabelIsDisplayed(WebElement element) {

		try {
			if(element.isDisplayed())
			{
			log(PASS, "Label value is Displayed ","Verified Label value is present", true);	
			}
			else
				log(FAIL, "Label value is NOT Displayed " ,"Verified Label value is Not present", true);	
		} catch (Exception e) {
			e.printStackTrace();
	}
	
}
	/**
	 * <p>Method to select CheckBox</p>
	 * @param checkBox- WebElement of CheckBox	 
	 * 		eg- seClickRadio(checkBox);
	 * @author Usha
	 * @since Sep 25, 2017
	 */

	private static void processExceptions(String strStep, Exception excException) {
		RESULT_STATUS = false;
		logger.error(strStep);
		excException.printStackTrace();
		log(ERROR, strStep, "Exception: " + excException.getLocalizedMessage(), true);

	}
	
	/**
	 * <p>Method to select CheckBox</p>
	 * @param checkBox- WebElement of CheckBox	 
	 * 		eg- seClickRadio(checkBox);
	 * @author AF14733 kavitha
	 *
	 */
	public static void seClickCheckBox(WebElement checkBox, String strCheckBoxName) {

		try {
			if(checkBox!=null)
			{
				checkBox.click();
				ExtentReportsUtility.log(ApplicationConstants.PASS,
						"CheckBox button "+strCheckBoxName+ " is clicked",
						"Verified CheckBox button " +strCheckBoxName+ "clicked", true);

			}
			else
				ExtentReportsUtility.log(ApplicationConstants.FAIL,
						"CheckBox button "+strCheckBoxName+ " is NOT clicked",
						"Verified CheckBox button " +strCheckBoxName+ "not found", true);	
		} catch (Exception excException) {
			processExceptions("Exception occured while clicking on CheckBox", excException);
			throw excException;
		}

	}

	/**
	 * @author AF14733
	 * @method This method is used to get the Cell value of the last row 
	 * @param testObject: variable holding the locator value of the table object that needs to be validated
	 * @param stepName
	 */

	public static void clickAtCell(WebElement testObject,String stepName)
	{
		try
		{
			String columnValue ="";
			String stremplNumber = seGetText(CensusPage.get().totalEmpl).toString();
			System.out.println("Total Number Of Employees :" +stremplNumber);
			int intfindvalue = Integer.parseInt(stremplNumber);
			System.out.println("No Of rows Of Employees : " +intfindvalue);
			WebElement table = testObject;
			if(table != null)
			{

				int rowIndex = 0; 	
				List<WebElement> rows = driver.findElements(By.xpath("//table[@class='CensusGrid']/tbody/tr[*]"));
				int introwsize = rows.size();
				System.out.println("No Of rows in table : " +introwsize);

				for(int i=1; i<= rows.size(); i++)
				{
					columnValue = driver.findElement(By.xpath("//table[@class='CensusGrid']/tbody/tr[@id='row" + String.valueOf(i) + "']/td[3]/input")).getAttribute("value");;
					if (columnValue.equals(""))
					{

						rowIndex = i-1;
						break;
					}
				}
				if(intfindvalue==rowIndex)
				{
					log(PASS,"Total Number of employees Count matches:" +intfindvalue,
							"Verified Total Number of employees Count matches :" + intfindvalue);
				}
				else
				{
					log(FAIL,"Not able to identify the table with given properties","Not able to identify the table with given properties");
				}	

			}}
					
		catch(Exception e)
		{
			log(ERROR,"Exception caught in the get cell value","Exception caught in the get cell value is: "+e.getLocalizedMessage());
		}		

	}
	
	/**
	 * @author AF14733
	 * @method This method is used to get the Cell value of the last row 
	 * @param testObject: variable holding the locator value of the table object that needs to be validated
	 * @param stepName
	 */

	public static void verifyCheckboxeschecked(WebElement testObject,String stepName)
	{
		try
		{
			String columnValue ="";
			String stremplNumber = seGetText(CensusPage.get().totalEmpl).toString();
			System.out.println("Total Number Of Employees :" +stremplNumber);
			int intfindvalue = Integer.parseInt(stremplNumber);
			System.out.println("No Of rows Of Employees : " +intfindvalue);
			WebElement table = testObject;
			if(table != null)
			{

				int rowIndex = 0; 	
				List<WebElement> rows = driver.findElements(By.xpath("//table[@id='CensusView.copyPanel']/tbody/tr/td/table/tbody/tr[*]"));
				int introwsize = rows.size();
				System.out.println("No Of rows in table : " +introwsize);
				
				/*List<WebElement> columns = driver.findElements(By.xpath("//table[@id='CensusView.copyPanel']/tbody/tr/td/table/colgroup"));
				int intrcolsize = rows.size();
				System.out.println("No Of rows in table : " +introwsize);
*/
				for(int i=1; i<= rows.size(); i++)
				{
					
					List chkboxes = driver.findElements(By.xpath("//table[@class='CensusGrid']/tbody/tr[@id='row" + String.valueOf(i) + "']/td[3]/input"));
					if (columnValue.equals(""))
					{

						rowIndex = i-1;
						break;
					}
				}
				if(intfindvalue==rowIndex)
				{
					log(PASS,"Total Number of employees Count matches:" +intfindvalue,
							"Verified Total Number of employees Count matches :" + intfindvalue);
				}
				else
				{
					log(FAIL,"Not able to identify the table with given properties","Not able to identify the table with given properties");
				}	

			}}
					
		catch(Exception e)
		{
			log(ERROR,"Exception caught in the get cell value","Exception caught in the get cell value is: "+e.getLocalizedMessage());
		}		

	}
	
	/**
	 * @author  Surya
	 * @method This method waits till a particular element disappears
	 * @param 
	 * @throws Exception  
	 */
	public static void seWaitTillElementDisappears(WebElement elementToDisappear,String StepName) {
		try {

			for(;;){
				seWaitForElementLoad(elementToDisappear);
				
				if(!(elementToDisappear.isDisplayed())){
					break;
				}
				log(PASS,"Expected element:" +elementToDisappear,
						"Verified element :" +elementToDisappear );
			}
			log(FAIL,"Expected element:" +elementToDisappear,
					"Verified element :" +elementToDisappear );
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
