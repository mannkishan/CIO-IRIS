package utility;

import java.io.FileInputStream;
import java.util.List;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import com.anthem.selenium.utility.ReadWordDocxUtils;

/*
'Revision History
'#############################################################################
'@rev.On	@rev.No		@rev.By				  @rev.Comments
'10-October-2017	1			AF30637 Rajat Mishra	Reviewed. Uni tested for EPDG										
'#############################################################################
*/
/**
 * Class to handle and print all the text of a document(format-docx) in console.
 * Works only on docx format
 * As we know a document can contain paragraphs and table. This class will print all paragraphs and tables respectively.
 * 
 * 
 * Usage-
 * 
 *	ParagraphsAndTables strDocumentText = new ParagraphsAndTables();
 * 	strDocumentText.PrintParagraphsAndTables(String sWordDocumentPath);
 * 
 * @param sWordDocumentPath
 *         sWordDocumentPath-Word Document Path
 * 
 * 
 *  Output Format-
 *  **************************** Paragraphs start here ************************
 *  ------------------------------- Paragraph 1 -------------------------------
 *  text present in paragraph 1
 *  ------------------------------- Paragraph 2 -------------------------------
 *  text present in paragraph 2
 *  
 *  so on...
 *  **************************** Paragraphs end here **************************
 *  
 *  
 *  
 *  ############################ Tables start here ############################
 *  ------------------------------- Table 1 -----------------------------------
 *  cell 0, 0:  Text in cell[0][0] of Table1
 *  cell 0, 1:  Text in cell[0][1] of Table1
 *  ------------------------------- Table 2 -----------------------------------
 *  cell 0, 0:  Text in cell[0][0] of Table2
 *  
 *  so on...
 *  ############################ Tables start here ############################
 *  
 *  
 *  @author AF37512 Santosh Bukkashetti
 *  @since 10-Oct-2017
 */

public class ParagraphsAndTables extends ReadWordDocxUtils {

	public XWPFDocument docx;

	public void PrintParagraphsAndTables(String sWordDocumentPath) {
		try {
			docx = new XWPFDocument(new FileInputStream(sWordDocumentPath));

			System.out.println("**************************** Paragraphs start here ************************");
			List<String> lstParagraphs = getAllParagraphsText(docx);			
			int intParagraphCounter = 1;
			for (String strParagrap : lstParagraphs) {
				System.out.println("------------------------------- Paragraph " + intParagraphCounter + " -------------------------------");
				System.out.println(strParagrap);
				intParagraphCounter = intParagraphCounter + 1;
			}
			System.out.println("**************************** Paragraphs end here **************************");
			
			System.out.println("");
			System.out.println("");			
			
			List<XWPFTable> lstTables = getAllTables(docx);
			System.out.println("############################ Tables start here ############################");
			intParagraphCounter = 1;
			int intRow;
			int intCol;
			for (XWPFTable tblTable : lstTables) {
			System.out.println("------------------------------- Table " + intParagraphCounter + " -----------------------------------");
			intRow = 0;				
			for (XWPFTableRow row : tblTable.getRows()) {
			intCol = 0;
			for (XWPFTableCell cell : row.getTableCells())
				{
					System.out.println("cell " + intRow + ", " + intCol + ": " + cell.getText());
					intCol = intCol + 1;						
				}
					intRow = intRow + 1;
				}
				
			intParagraphCounter = intParagraphCounter + 1;
			}
			System.out.println("############################ Tables ends here ############################");
			
		} catch (Exception e) {
			e.printStackTrace();						
		}

	}
	
}
