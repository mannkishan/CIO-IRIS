package com.anthem;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.SuperHelper;

public class HomePage extends SuperHelper {

	private static LoginPage thisIsTestObj;
	public  synchronized static LoginPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), LoginPage.class);
		return thisIsTestObj;
		}
	@FindBy(how=How.XPATH,using="//li[@class='rootMenu dropdown pull-right']/a[@class='dropdown-toggle']")
	public static WebElement loggedinuser;
	
	@FindBy(how=How.XPATH,using="//a[@class='group-title'][contains(text(),'Plans')]")
	public static WebElement Plantitle;
	
	@FindBy(how = How.XPATH, using = "//div[@id='header-wrapper']/ul/li[3]/a")
	public WebElement create;
	
	@FindBy(how = How.ID, using = "action_logout")
	public static WebElement logout;
	
	@FindBy(how = How.XPATH, using = "//div[@id='header-wrapper']//li[@class='rootMenu dropdown pull-right open']//li[1]/a[1]")
	public static WebElement user;
}
