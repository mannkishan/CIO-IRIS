package com.anthem;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;



public class LoginPage extends CoreSuperHelper {
	private static LoginPage thisIsTestObj;
	public  synchronized static LoginPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), LoginPage.class);
		return thisIsTestObj;
		}
	@FindBy(how=How.NAME,using="USER")
	public WebElement userNameField;
	
	@FindBy(how=How.NAME,using="PASSWORD")
	public WebElement passwordField;
	
	@FindBy(how=How.XPATH,using="//input[@type='submit']")
	@CacheLookup
	public WebElement submitButton;

	public void loginApplication(String userProfile){
		String[] userInfo = getLoginInfo(userProfile);
		setUserName(userInfo[0],"UserName");
		setPassword(userInfo[1]);
		clickSubmit();
		}
	
	public void setUserName(String userId,String UserID){
		seSetUserId(userNameField, userId,"UserName");
	}
	
	public void setPassword(String pwd){
		seSetPassword(passwordField, pwd,"Password");
	}
	
	public void clickSubmit(){
		seClick(submitButton, "Submit");
	}


}
