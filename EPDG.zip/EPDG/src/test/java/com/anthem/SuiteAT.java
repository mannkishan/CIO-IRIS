package com.anthem;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.anthem.RunCukes;

@RunWith(Suite.class)
@SuiteClasses({RunCukes.class})
public class SuiteAT {
  // Default constructor
}
