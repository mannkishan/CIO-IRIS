/**
 * 
 */
package com.anthem;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.junit.Cucumber;

/**
 * 
 */
/*  plugin = {"pretty",
"json:target/at/cucumber.result.json"}*/

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "target/at/cucumber.feature",
    snippets = SnippetType.CAMELCASE,
    glue = "com.anthem.stepdefinitions",
    plugin = {"pretty",
              "json:target/at/cucumber.result.json"},
//    tags = {"@RegressionTest,@SmokeTest"},
   // tags = {"~@SmokeTest"},
    //tags = {"@RegressionTest"},
    //tags = {"@MyTest"},
    monochrome = true,
    strict = true
    )
public class RunCukes {

}
