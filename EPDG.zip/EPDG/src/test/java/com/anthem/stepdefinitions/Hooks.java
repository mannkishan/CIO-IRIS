package com.anthem.stepdefinitions;

import org.junit.Assert;

import com.anthem.selenium.utility.BrowserUtility;
import com.anthem.selenium.utility.EnvHelper;

import cucumber.api.java.After;
import cucumber.api.java.Before;
//import page.LoginPage;
import utility.CoreSuperHelper;

public class Hooks extends CoreSuperHelper {
	
	//public static WebDriver driver;
	
	//@Before
	/*public void beforeScenario() throws InterruptedException
	{
		if(Boolean.parseBoolean(EnvHelper.getValue("runHook"))){
			String baseURL = EnvHelper.getValue("siebelUrl");
			seOpenBrowser(EnvHelper.getValue("browserType"), baseURL);
			seWaitForPageLoad();
			LoginPage.get().loginApplication(EnvHelper.getValue("Siebel.profile"));
			Thread.sleep(10000);
		}

	}
	
//	@After
	public void afterScenario() throws InterruptedException
	{
		if(Boolean.parseBoolean(EnvHelper.getValue("runHook"))){
			seClick(LoginPage.get().logOut, "Log Out");
			seWaitForPageLoad();
			Assert.assertTrue(isElementPresent(LoginPage.get().userName));
			if(EnvHelper.getValue("browserType").equalsIgnoreCase("IE")){
				BrowserUtility.clearBrowserCache("IE");
			}
			seCloseBrowser();
		}
	}*/

}
