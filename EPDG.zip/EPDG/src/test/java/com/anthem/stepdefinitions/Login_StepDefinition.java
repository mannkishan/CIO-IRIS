package com.anthem.stepdefinitions;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.SuperHelper;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import com.anthem.LoginPage;

import org.junit.Assert;

import com.anthem.HomePage;

public class Login_StepDefinition extends SuperHelper {

	@Given("^User is on Login Page$")
	public void userIsOnLoginPage() throws Throwable {
		String baseURL = EnvHelper.getValue("baseurl");
		System.out.println(baseURL);
		// Write code here that turns the phrase above into concrete actions
		seOpenBrowser("Chrome", baseURL);
		seWaitForPageLoad();
		Assert.assertTrue((LoginPage.get().userNameField.isDisplayed()));
	}

	@When("^User enters credentials to Login$")
	public void userEntersCredentialsToLogin() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String[] userInfo = getLoginInfo(EnvHelper.getValue("user.profile1"));
		seSetUserId(LoginPage.get().userNameField, userInfo[0], "User Name");
		seSetPassword(LoginPage.get().passwordField, userInfo[1], "Password");
	}

	@When("^User clicks on Login Button$")
	public void userClicksOnLoginButton() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		seClick(LoginPage.get().submitButton, "Submit button");
	}

	@Then("^User should be able to view the Home Screen$")
	public void userShouldBeAbleToViewTheHomeScreen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		seWaitForPageLoad();
		Thread.sleep(10000);
		String b  = "WSBPER13";
		seClick(HomePage.loggedinuser, "User");
        String a = 	seGetText(HomePage.user);
        System.out.println(a);
        if(a.equalsIgnoreCase(b))
        {
        	System.err.println("loggedin");
        }
		Thread.sleep(10000);
		
	}	
}
