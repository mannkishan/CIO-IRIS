/**
 * 
 */
package utility;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NotFoundException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.anthem.selenium.SuperHelper;
import com.anthem.selenium.constants.ApplicationConstants;
import com.anthem.selenium.logging.AnthemLogger;
import com.anthem.selenium.utility.ExtentReportsUtility;
import com.wellpoint.cssd.spider.DownloadFinalizeXML;

import page.planConfigurator.PlanSetupPage;

/**
 * @author shiva.katula
 * 
 * ##### Do not delete this file. ######
 * 
 * This class is specifically only for any Project specific Helper Methods for SuperHelper Extension
 *
 * Any method defined in this class will be automatically available in the project like Super Helper methods.
 * Any methods defined here will need to be called without the Class Name to maintain consistency in calling
 * If Project defines a helper method here and if that method is harvested back into Selenium Framework
 * by Architects, then the local method in this class can be deleted with out changing any of the test scripts.
 * 
 * To maintain naming convention across all the projects do not name the method with the Project Name.
 * Also take the suggestion/Approval for the method name to avoid discrepancy with the Framework methods.
 *  
 */
public class CoreSuperHelper extends SuperHelper {
	
	protected static AnthemLogger logger = AnthemLogger.getLogger(CoreSuperHelper.class.getName());;
		
			
	// This is the example method to be followed while coding CoreSuperHelper methods.
	/**
	 * <p>
	 * Click web element
	 * </p>
	 * @param screenShot
	 * 		Enter True or false to capture snap shot before clicking web element
	 * @param testObject
	 *            required test object need to test
	 * @param buttonName 
	 *            name Enter buttonName name to click.
	 * @param step
	 *            Enter steps to perform
	 */
	
	public static void seClick1(boolean screenShot, WebElement testObject, String buttonName, String step) {
		int successFlag = ApplicationConstants.FAIL;

		if (step == null) {
			step = "Click " + buttonName;
		}

		if (testObject.isDisplayed()) {
			testObject.click();
			successFlag = ApplicationConstants.PASS;
			ExtentReportsUtility.log(successFlag, step, "Core Super Helper Expected button \"" + buttonName + "\" clicked successfully");

		} else {
			
			ExtentReportsUtility.log(successFlag, step, "Core Super Helper Unable to click the button \"" + buttonName + "\" successfully"
					+ seCaptureScreenshot(driver, buttonName));
		}

		if (screenShot) {
			ExtentReportsUtility.log(successFlag, step, seCaptureScreenshot(driver, buttonName));
		}
	}

	

	/**
	 * Function is to verify whether an element is enabled
	 * 
	 * @author Gautam Kumar (AF15254)
	 * 
	 * @param testObject
	 *            object which need to be verified
	 * @return boolean is element enabled or not
	 */

	public static boolean seIsElementEnabled(WebElement testObject, String strElementName) {
		
		boolean seIsElementEnabled = false;
		
		try {

			if (testObject.isEnabled()) {
				log(PASS, "Verify " + strElementName + " is enabled", strElementName + " is enabled", true);
				seIsElementEnabled = true;
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify " + strElementName + " is enabled", strElementName + " is not enabled", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			RESULT_STATUS = false;
			log(FAIL, "Verify " + strElementName + " is enabled", "Exception while verifyng " + strElementName + " is enabled", true);
		}
		
		return seIsElementEnabled;
	}

	/**
	 * Function is to verify whether an element is disabled
	 * 
	 * @author Gautam Kumar (AF15254)
	 * 
	 * @param testObject
	 *            object which need to be verified
	 * @return boolean is element disabled or not
	 */
	public static boolean seIsElementDisabled(WebElement testObject, String strElementName) {
		boolean blnIsElementDisplayed = false;
		
		try {

			if (!testObject.isEnabled()) {
				log(PASS, "Verify " + strElementName + " is disabled", strElementName + " is disabled", true);
				blnIsElementDisplayed = true;
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify " + strElementName + " is disabled", strElementName + " is not disabled", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			RESULT_STATUS = false;
			log(FAIL, "Verify " + strElementName + " is disabled", "Exception while verifyng " + strElementName + " is disabled", true);
		}
		
		return blnIsElementDisplayed;
	}

	/**
	 * Function is to verify whether the element is displayed or not
	 * 
	 * @author Gautam Kumar (AF15254)
	 * 
	 * @param testObject
	 *            object which need to be verified
	 *  @return boolean is element displayed or not
	 */
	public static boolean seIsElementDisplayed(WebElement testObject, String strElementName) {
		boolean blnIsElementDisplayed = false;
		
		try {
			if (testObject.isDisplayed()) {
				log(PASS, "Verify " + strElementName + " is displayed", strElementName + " is displayed", true);
				blnIsElementDisplayed = true;
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify " + strElementName + " is displayed", strElementName + " is NOT displayed", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			RESULT_STATUS = false;
			log(FAIL, "Verify " + strElementName + " is displayed", "Exception while verifyng " + strElementName + " is displayed", true);
		}
		
		return blnIsElementDisplayed;
	}

	/**
	 * Function is to verify whether the element is NOT displayed
	 * 
	 * @author Algie Watts (AD20221)
	 * 
	 * @param testObject
	 *            object which need to be verified
	 *  @return boolean is element displayed or not
	 */
	public static boolean seIsElementNotDisplayed(WebElement testObject, String strElementName) {
		boolean blnIsElementDisplayed = false;
		
		try {
			
			if (!testObject.isDisplayed()) {
				log(PASS, "Verify " + strElementName + " is NOT displayed", strElementName + " is NOT displayed", true);
				blnIsElementDisplayed = true;
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify " + strElementName + " is displayed", strElementName + " is displayed", true);
			}
		} catch (NoSuchElementException e) {
			RESULT_STATUS = true;
			log(PASS, "Verify " + strElementName + " is NOT displayed", "Exception while verifyng " + strElementName + " is NOT displayed", true);
		}
		
		return blnIsElementDisplayed;
	}
	

	/**
	 * Function is to verify whether the element is selected
	 * 
	 * @author Gautam Kumar (AF15254)
	 * 
	 * @param testObject
	 *            object which need to be verified
	 *  @return boolean is element selected or not
	 */
	
	public static boolean seIsElementSelected(WebElement testObject, String strElementName) {
    	boolean blnIsElementSelectedSuccess = false;
		try {
			if (testObject.isSelected()) {
				log(PASS, "Verify " + strElementName + " is Selected", strElementName + " is Selected", true);
				 blnIsElementSelectedSuccess=true;
				
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify " + strElementName + " is Selected", strElementName + " is not Selected", true);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			RESULT_STATUS = false;
			log(FAIL, "Verify " + strElementName + " is not selected ", "Exception while verifyng " + strElementName + " is not selected", true);
			
		}
	return	blnIsElementSelectedSuccess;
		}   
	/**
	 * Function is to verify whether the element is not selected
	 * 
	 * @author Gautam Kumar (AF15254)
	 * 
	 * @param testObject
	 *            object which need to be verified
	 *  @return boolean is element not selected
	 */
    public static boolean seIsElementNotSelected(WebElement testObject, String strElementName) {
    	boolean blnIsElementNotSelectedSuccess = false;
		try {
			if (!testObject.isSelected()) {
				log(PASS, "Verify " + strElementName + " is not Selected", strElementName + " is not Selected", true);
				blnIsElementNotSelectedSuccess = true;
				
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify " + strElementName + " is  not Selected", strElementName + " is Selected", true);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			RESULT_STATUS = false;
			log(FAIL, "Verify " + strElementName + " is selected ", "Exception while verifyng " + strElementName + " is selected", true);
			
		}
		return blnIsElementNotSelectedSuccess;
	}
    

	/**
	 * Author: AF17189 Ramandeep Kaur The below method is to upload the file
	 * 
	 * @param fileToUpload
	 */
	public static boolean seUploadFile(String filePathToUpload) {
		boolean result = false;
		try {
		
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(filePathToUpload), null);
			Robot r = new Robot();
			Thread.sleep(1000);
			r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_V);
			Thread.sleep(1000);
			r.keyRelease(KeyEvent.VK_CONTROL);
			r.keyRelease(KeyEvent.VK_V);
			Thread.sleep(1000);
			r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(1000);
			
			log(PASS, "Verify Documnet uploaded", "Document is successfully uploaded");
		} catch (NotFoundException e) {
			e.printStackTrace();
			log(FAIL, "Verify Documnet uploaded", "Exception caught while uploading file");
		} catch (Exception e) {
			e.printStackTrace();
			log(FAIL, "Verify Documnet uploaded", "Exception caught while uploading file");
		}
		return result;
	}
	
	
	
	
	
	
	public static void seWaitForClickableWebElement(WebElement element, long sleep )
	{
//		seWaitForWebElement(sleep, ExpectedConditions.elementToBeClickable(element));
		waitForPageLoad();
		WebDriverWait wait = new WebDriverWait(getWebDriver(), sleep);
		wait.pollingEvery(100, TimeUnit.MILLISECONDS);
		wait.ignoring(StaleElementReferenceException.class, NoSuchElementException.class);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		
		
	}
	public static void updatePlanInformation(String planID)
	{
		WebElement planDetail = getWebDriver().findElement(By.xpath("//ul[starts-with(@class,'messagesList')]/li[1]/a"));
		System.out.println(planDetail.getText());
	}
	
	
	/**
	 * @author AF15123
	 * @param ID - Pass the Plan or Contract ID.
	 * @param region - Pass Application environment name
	 * @param downloadPath - Declare the path for downloding xml file.
	 */
	public static void DownloadXML(String ID, String region, String downloadPath)
	{
		try
		{
			
			DownloadFinalizeXML.downloadXML(region, downloadPath, ID);
			int loopCounter = 0;
			
			File currentFolder = new File(downloadPath +region+"_"+ID+".xml");
			while(!currentFolder.exists())
			{
				Thread.sleep(1);
				loopCounter++;
				if(loopCounter==60)
				{
					break;
				}
			}
			if(currentFolder.exists())
			{
				RESULT_STATUS = true;
				log(PASS, "Validate XML file is downloadable", "Downloaded the XML from the region:"+region+" for "+ID);
			}
			else
			{
				RESULT_STATUS = false;
				log(FAIL, "Validate XML file is downloadable", "XML file is not exists");
			}
		}
		catch(Exception e){

			e.printStackTrace();
		}
	}
	
	public static void waitForPageLoad()
	{
		try
		{
			waitForPageLoad(60);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void waitForPageLoad(int intTimeOut)
	{
		try
		{
			getWebDriver().manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(getWebDriver(), intTimeOut);
			wait.pollingEvery(500, TimeUnit.MILLISECONDS);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("div[class=\"spinner ui-widget-overlay ajax-loader-modal\"]")));
			getWebDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void waitForPageLoad(int implicitWait, int intTimeOut)
	{
		try
		{
			getWebDriver().manage().timeouts().implicitlyWait(implicitWait, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(getWebDriver(), intTimeOut);
			wait.pollingEvery(500, TimeUnit.MILLISECONDS);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("div[class=\"spinner ui-widget-overlay ajax-loader-modal\"]")));
			getWebDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
	/**
	 * This method should be used for PC2.0 application where the step needs to wait for 
	 * the spinner icon to be invisible after selecting the text from drop down
	 * @param selectObject Web element for the drop down element
	 * @param optionText text that needs to be selected from the drop down
	 * @param stepName used for report 
	 * @param maxWaitTime Maximum amount of time script needs to wait for the spinner icon to be invisible
	 */
	public static void seSelectText(WebElement selectObject, String optionText, String elementName, int maxWaitTime)
	{
		try
		{
			waitForPageLoad(1,maxWaitTime);
			Select dropDown = new Select(selectObject);			
			dropDown.selectByVisibleText(optionText);
			waitForPageLoad(1,maxWaitTime);
			String selectedText = dropDown.getFirstSelectedOption().getText();
			
			if(selectedText.equalsIgnoreCase(optionText))
			{
				log(PASS, "Select "+optionText+" from drop down "+ elementName, "Expected "+optionText+" selected from the drop down "+elementName, false);
			}
			else
			{
				log(FAIL, "Select "+optionText+" from drop down "+ elementName, "Expected "+optionText+" not selected from the drop down "+elementName+" Actual selected text "+selectedText, false);
			}
			waitForPageLoad(1,maxWaitTime);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void seWaitForPageLoad(int timeOut)
	{
		ExpectedCondition<Boolean> expectation = new  ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                return ((JavascriptExecutor) getWebDriver()).executeScript("return document.readyState").toString().equals("complete");
            }
        };

        WebDriverWait wait = new WebDriverWait(getWebDriver(), timeOut);
        wait.until(expectation);
    
	}
	
	
	public static void seSelectValue(WebElement dropDown, WebElement textField, String valueToBeSelected)
	{
		
	}
	
	
	/**
	 * This method will switch the frame specified by the locator
	 * @param locator
	 */
	public static void seSwitchFrame(By locator)
	{
		WebDriverWait wait = new WebDriverWait(getWebDriver(), 60);
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(locator));
		
	}
	
	
	/**
	 * This method will return the location of the reports folder 
	 * @return: Reports folder location will be returned
	 */
	public static String getReportPathFolder()
	{
		String reportsFolder = "";
		try
		{
			File f = new File(ExtentReportsUtility.reportsPathFolder);
			reportsFolder = f.getCanonicalPath()+File.separator;
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return reportsFolder;
	}
	
	
	
	/**
	 * @author AF12450
	 * Method to read the column value from the excel file from the specified location with the reference provided by KeyColumn
	 * KeyValue  pair
	 * @param filePath: Location of the excel file
	 * @param sheetName: Sheet name from which the data should be read
	 * @param keyColumn: Column header which helps in fetching the row number
	 * @param keyValue: Column value which helps in fetching the row number when paired with KeyColumn
	 * @param columnHeader: Column header from which the data should be fetched
	 * @return : String value which holds the cell data
	 */
	public static String readFromExcel(String filePath, String sheetName, String keyColumn, String keyValue, String columnHeader)
	{
		try
		{
			return ExcelUtility.get().readFromExcel(filePath, sheetName, keyColumn, keyValue, columnHeader);
		}
		catch (Exception e) {
			processExceptions("Read from excel", e.getLocalizedMessage());
		}
		return "";
	}
	
	/**
	 * @author AF12450
	 * Method to write the data to excel file from the specified location with the reference provided by KeyColumn
	 * KeyValue  pair
	 * @param filePath: Location of the excel file
	 * @param sheetName: Sheet name from which the data should be read
	 * @param keyColumn: Column header which helps in fetching the row number
	 * @param keyValue: Column value which helps in fetching the row number when paired with KeyColumn
	 * @param columnHeader: Column header to which the data should be written
	 * @param columnValue : value that needs to be written
	 */
	public static void writeToExcel(String filePath, String sheetName, String keyColumn, String keyValue, String columnHeader,String columnValue)
	{
		try
		{
			ExcelUtility.get().writeToExcel(filePath, sheetName, keyColumn, keyValue, columnHeader, columnValue);
		}
		catch (Exception e) {
			processExceptions("Write to excel", e.getLocalizedMessage());
		}
	}
	
	
	public static void processExceptions(String stepName, String localizedMessage)
	{
			RESULT_STATUS = false;
			logger.debug("Exception Occured: "+localizedMessage);
			log(ERROR, stepName, "Exception occured: "+localizedMessage);
	}
	
	
	/**
	 * This method will be useful in Plan COnfigurator Application to select the
	 * values from the drop down
	 * 
	 * @param containerSpan
	 *            :
	 * @param elementName
	 * @param strValue
	 * @param intMaxWaitTime
	 */
	public static void sePCSelectText(WebElement containerSpan, String elementName, String strValue,
			int intMaxWaitTime) {
		String stepName = "Select " + strValue + " from " + elementName;
		try {
			seClick(containerSpan, elementName);
			waitForPageLoad(2, intMaxWaitTime);
			seSetText(PlanSetupPage.get().dropDownInput, strValue, "Set text for " + elementName);
			waitForPageLoad(2, intMaxWaitTime);
			seClick(PlanSetupPage.get().dropDownSelect, "Select " + strValue + " from " + elementName);
			waitForPageLoad(2, intMaxWaitTime);
		} catch (Exception e) {
			e.printStackTrace();
			processExceptions(stepName, e.getLocalizedMessage());
		}
	}

	public static boolean seVerifyFieldValue(WebElement testObject, String expectedValue, String fieldName,
			boolean comparePartialValue) {
		String textType = "";
		String attributeValue = "";
		String targetValue = "";
		boolean success = false;

		try {
			targetValue = testObject.getTagName();
			if (targetValue.contains("input")) {
				textType = "TextBox";
			} else if (targetValue.contains("label")) {
				textType = "Text";
			} else if (targetValue.contains("select")) {
				textType = "DropDown/ListBox";
			}
		} catch (Exception arg11) {
			;
		}

		try {
			byte arg9 = -1;
			switch (textType.hashCode()) {
			case -1791084433:
				if (textType.equals("DropDown/ListBox")) {
					arg9 = 1;
				}
				break;
			case 246787390:
				if (textType.equals("TextBox")) {
					arg9 = 0;
				}
			}

			switch (arg9) {
			case 0:
				attributeValue = seGetElementTextBoxValue(testObject);
				break;
			case 1:
				attributeValue = seGetDropDownValue(testObject);
				break;
			default:
				attributeValue = seGetElementValue(testObject);
			}

			if (comparePartialValue) {
				success = attributeValue.trim().contains(expectedValue.trim());
			} else {
				success = attributeValue.trim().equals(expectedValue.trim());
			}

			if (success) {
				ExtentReportsUtility.log(1, "VerifyFieldValue : " + fieldName,
						textType + " value \"" + attributeValue + "\" for the field \"" + fieldName
								+ "\" matches the expected  value \"" + expectedValue.trim() + "\""
								+ seCaptureScreenshot(driver, fieldName));
			} else {
				success = false;
				ExtentReportsUtility.log(0, "VerifyFieldValue : " + fieldName,
						textType + " value \"" + attributeValue + "\" for the field \"" + fieldName
								+ "\" do not match the expected  value \"" + expectedValue.trim() + "\""
								+ seCaptureScreenshot(driver, fieldName));
			}
		} catch (Exception arg10) {
			System.out.println("No data found.");
			arg10.printStackTrace();
			ExtentReportsUtility.log(0, "VerifyFieldValue : " + fieldName,
					"Web element NOT found" + seCaptureScreenshot(driver, fieldName));
		}

		return success;
	}
	
	

}


