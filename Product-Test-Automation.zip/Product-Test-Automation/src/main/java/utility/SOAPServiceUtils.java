package utility;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class SOAPServiceUtils extends CoreSuperHelper{
	/**
	 * <p>
	 *getSOAPResponsefromRequestFile
	 *		This method takes XML File as Request Input file and returns the response as String
	 *	 * </p>
	 * @param XMLFilePath
	 * 		FullPath of the request XML
	 * 		File should be a xml file and Path should end with .xml
	 * @param ElementValue
	 *            Test data and xpath combination in hmap 
	 *            XPath acts as the Key
	 * @param strEndPointURL 
	 *          EndPointUrl for the service
	 */

	public static String  getSOAPResponsefromRequestFile(String XMLFilePath,HashMap <String, String>ElementValue,String strEndPointURL) throws Exception
	{

		SOAPMessage request = createAndUpdateSOAPRequestFromFile(XMLFilePath,ElementValue);
		String request1 = convertSOAPMessageToString(request);
		System.out.println(request1);
		URL url = new URL(strEndPointURL);
		doTrustToCertificates();
		InputStreamReader isr = getHTTPResonspe(url, request1);
		String soapresponse = convertInputStreamReadertoString(isr);
		return soapresponse;
	}
	/**
	 * <p>
	 *getSOAPResponsefromRequestString
	 *		This method takes XML String as Request and returns the response in String
	 *		
	 *	 * </p>
	 * @param Req XML
	 * 		Soap Request XML as String
	 * @param ElementValue
	 *            Test data and Xpath combination in hmap 
	 *            XPath acts as the Key
	 * @param strEndPointURL 
	 *          EndPointUrl for the service
	 */

	public static String getSOAPResponsefromRequestString(String ReqXML,HashMap <String, String>ElementValue,String strEndPointURL) throws Exception
	{

		SOAPMessage request = createAndUpdateSOAPRequestFromString(ReqXML,ElementValue);
		String request1 = convertSOAPMessageToString(request);
		System.out.println(request1);
		URL url = new URL(strEndPointURL);
		doTrustToCertificates();
		InputStreamReader isr = getHTTPResonspe(url, request1);
		String soapresponse = convertInputStreamReadertoString(isr);
		return soapresponse;
	}

	/**
	 * <p>
	 *get_Save_SOAPResponsefromRequestString
	 *		
	 *			This method takes XML String as Request and returns the response as String 
	 *			and Saves the response at the specified location
	 *	 * </p>
	 * @param Req XML
	 * 		Soap Request XML as String
	 * @param ElementValue
	 *            Test data and Xpath combination in hmap 
	 *            XPath acts as the Key
	 * @param strEndPointURL 
	 *          EndPointUrl for the service
	 * @param RespFilepath
	 * 			Full Path of the text file where Response needs to be stored
	 * 			FilePath should end with .txt  
	 */

	public static String get_Save_SOAPResponsefromRequestString(String ReqXML,HashMap <String, String>ElementValue,String strEndPointURL,String RespFilepath) throws Exception
	{

		String response = getSOAPResponsefromRequestString(ReqXML,ElementValue,strEndPointURL);
		System.out.println("Response");
		System.out.println(response);

		String strStepName = "Writing to text file"; 
		boolean WriteToTextFile = saveResponseInTextFile(response,RespFilepath);
		if (!WriteToTextFile)
		{
			log(FAIL, strStepName, "Unable to update Response in a text file. Validate the path provided");
			log(FAIL, strStepName, "Unable to update Response in a text file. Check extension of text file is included");
		}
		else 
		{
			log(PASS, strStepName, "Able to update Response in a text file");	
		}

		return response;
	}
	
	/**
	 * <p>
	 *get_Save_SOAPResponsefromRequestString
	 *		
	 *			This method takes XML String as Request and returns the response as String 
	 *			and Saves the response at the specified location
	 *	 * </p>
	 * @param Req XML
	 * 		Soap Request XML as String
	 * @param ElementValue
	 *            Test data and Xpath combination in hmap 
	 *            XPath acts as the Key
	 * @param strEndPointURL 
	 *          EndPointUrl for the service
	 * @param RespFilepath
	 * 			Full Path of the text file where Response needs to be stored
	 * 			FilePath should end with .txt  
	 */

	public static String get_Save_SOAPResponsefromRequestString(String ReqXML,String strEndPointURL,String RespFilepath) throws Exception
	{

		HashMap<String, String> elementValue = new HashMap<>();
		String response = get_Save_SOAPResponsefromRequestFile(ReqXML, elementValue, strEndPointURL, RespFilepath);
		return response;
	}
	
	/**
	 * <p>
	 *get_Save_SOAPResponsefromRequestFile
	 *		This method takes XML File as Request and returns the response as String 
	 *			and Saves the response at the specified location
	 *</p>
	 * @param Req XML
	 * 		Soap Request XML as String
	 * @param ElementValue
	 *            Test data and Xpath combination in hmap 
	 *            XPath acts as the Key
	 * @param strEndPointURL 
	 *          EndPointUrl for the service
	 * @param RespFilepath
	 * 			Full Path of the text file where Response needs to be stored
	 * 			FilePath should end with .txt  
	 */

	public static String get_Save_SOAPResponsefromRequestFile(String ReqXMLPath,HashMap <String, String>ElementValue,String strEndPointURL,String RespFilepath) throws Exception
	{

		String response = getSOAPResponsefromRequestFile(ReqXMLPath,ElementValue,strEndPointURL);
		System.out.println("Response");
		System.out.println(response);
		String strStepName = "Writing to text file";
		boolean WriteToTextFile = saveResponseInTextFile(response,RespFilepath);
		if (!WriteToTextFile)
		{
			log(FAIL, strStepName, "Unable to update Response in a text file. Validate the path provided");
			log(FAIL, strStepName, "Unable to update Response in a text file. Check extension of text file is included");
		}
		else 
		{
			log(PASS, strStepName, "Unable to update Response in a text file. Please check the path provided");	
		}

		return response;

	}
	/**
	 * <p>
	 *createAndUpdateSOAPRequestFromFile
	 *		This method takes XML File as Request Input file and returns the response as Soap Message
	 *</p>
	 *  * @param XMLFilePath
	 * 		FullPath of the request XML
	 * 		File should be a xml file and Path should end with .xml
	 * @param ElementValue
	 *            Test data and Xpath combination in hmap 
	 */

	@SuppressWarnings("rawtypes")
	public static SOAPMessage createAndUpdateSOAPRequestFromFile(String XMLFilePath,HashMap <String, String>ElementValue ) throws Exception {

		XPathFactory xPathFactory = XPathFactory.newInstance();
		XPath xPath = xPathFactory.newXPath();
		FileInputStream fis = new FileInputStream(new File(XMLFilePath));
		MessageFactory factory = MessageFactory.newInstance();
		SOAPMessage message = factory.createMessage(new MimeHeaders(), fis);
		SOAPBody soapBody = message.getSOAPBody();
		Set set = ElementValue.entrySet();
		Iterator iterator = set.iterator();
		while(iterator.hasNext()) {

			Map.Entry Xpath = (Map.Entry)iterator.next();
			System.out.print("key is: "+ Xpath.getKey()+ " & location is: ");
			System.out.println(Xpath.getValue());
			NodeList elements = (NodeList)xPath.compile(Xpath.getKey().toString()).evaluate(soapBody, XPathConstants.NODESET);
			elements.item(0).setTextContent(Xpath.getValue().toString());
		}
		return message;
	} 
	/**
	 * <p>
	 *createAndUpdateSOAPRequestFromString
	 *		This method takes XML string as Request Input and returns the response as Soap Message
	 *</p>
	 *  * @param XML_Creation
	 * 		Soap Request XML as the String
	 * 		File should be a xml file and Path should end with .xml
	 * @param ElementValue
	 *            Test data and Xpath combination in hmap 
	 */

	@SuppressWarnings("rawtypes")
	public static SOAPMessage createAndUpdateSOAPRequestFromString(String XML_Creation, HashMap <String, String>ElementValue ) throws Exception {

		XPathFactory xPathFactory = XPathFactory.newInstance();
		XPath xPath = xPathFactory.newXPath();
		SOAPMessage message = createSOAPMessagefromString(XML_Creation);
		SOAPPart msgPart = message.getSOAPPart();
		SOAPEnvelope envelope = msgPart.getEnvelope();
		SOAPBody soapBody = envelope.getBody();
		Set set = ElementValue.entrySet();

		Iterator iterator = set.iterator();		       
		while(iterator.hasNext()) {
			Map.Entry Xpath = (Map.Entry)iterator.next();
			System.out.print("key is: "+ Xpath.getKey()+ " & location is: ");
			System.out.println(Xpath.getValue());
			NodeList elements = (NodeList)xPath.compile(Xpath.getKey().toString()).evaluate(soapBody, XPathConstants.NODESET);
			elements.item(0).setTextContent(Xpath.getValue().toString());
		}
		return message;

	}
	/**
	 * <p>
	 *convertSOAPMessageToString
	 *		This method takes converts SOAPMessage to String
	 *</p>
	 *  * @param Message
	 * 		Soap Message to String		
	 */

	public static String convertSOAPMessageToString(SOAPMessage Message ) throws Exception {

		SOAPMessage message = Message;
		String SoapMessage;	 	
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		message.writeTo(baos); 
		SoapMessage = baos.toString();
		System.out.println(SoapMessage);
		return SoapMessage;
	}

	/**
	 * <p>
	 *convertInputStreamReadertoString
	 *		This method takes converts InputStreamReader to String
	 *</p>
	 *  * @param Message
	 * 		Soap Message to String		
	 */
	public static String convertInputStreamReadertoString(InputStreamReader soapResponse) throws Exception, SOAPException {


		InputStreamReader isr = soapResponse;
		BufferedReader br = null;
		StringBuilder sb = new StringBuilder();
		String line;
		String Soapmessage = null;
		try{
			br = new BufferedReader(isr);
			while ((line = br.readLine()) != null) {
				sb.append(line);

			}

		}
		catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		Soapmessage = sb.toString();
		Soapmessage = Soapmessage.replaceAll("&lt;", "<");
		Soapmessage = Soapmessage.replaceAll("&gt;", ">");
		Soapmessage = Soapmessage.replaceAll("&quot;", "\"");
		return Soapmessage;
	}

	/**
	 * <p>
	 *createSOAPMessagefromString
	 *		This method takes StringXML as Input and convert it to SOAP Message
	 *</p>
	 *  * @param  XML_Creation
	 * 		Soap Message to String		
	 */

	public static SOAPMessage createSOAPMessagefromString(String XML_Creation) throws IOException, SOAPException
	{
		MessageFactory factory = MessageFactory.newInstance(SOAPConstants.SOAP_1_1_PROTOCOL);
		MimeHeaders headers = new MimeHeaders();
		SOAPMessage message = null;	
		headers.addHeader("Content-Type", "text/xml");
		ByteArrayInputStream var = new ByteArrayInputStream(XML_Creation.getBytes(Charset.forName("UTF-8")));			 
		message = factory.createMessage(headers, var);		    
		// message.writeTo(System.out);
		return message;

	}
	/**
	 * <p>
	 *saveResponseInTextFile
	 *		This methods Save the Response string to the specified location
	 *</p>
	 * @param  soapmessage
	 * 		String which needs to be written to the File
	 * @param  RespFilepath
	 * 		Full Text File path which needs to be saved	
	 */
	public static boolean saveResponseInTextFile(String soapmessage,String RespFilepath)
	{
		boolean result = false;
		soapmessage = soapmessage.replaceAll("&lt;", "<");
		soapmessage = soapmessage.replaceAll("&gt;", ">");
		soapmessage = soapmessage.replaceAll("&quot;", "\"");
		soapmessage = soapmessage.replaceAll(">", ">\n");
		System.out.println("Modified soapmessage in string");
		System.out.println(soapmessage);
		String text = soapmessage;
		String filename = RespFilepath;
		System.out.println(filename +"FILENAME");
		File file = new File(filename);

		try {
			if (!file.exists()) {
				file.createNewFile();
			}
			String bytes = text;
			byte[] buffer = bytes.getBytes();
			FileOutputStream outputStream =
					new FileOutputStream(filename);
			outputStream.write(buffer);
			System.out.println("Wrote " + buffer.length + 
					" bytes");
			outputStream.close();  
			System.out.println("Done");
			result = true;
		}   

		catch (IOException e) {

			e.printStackTrace();
			result = false;
		}

		return result;
	}


	/**
	 * <p>
	 *getHTTPResonspe
	 *		This method sends the String XML as request 
	 *		and gets the Response in InputstreamReader format
	 *</p>
	 * @param  url
	 * 		EndPoint url
	 * @param  XMLInput
	 * 		Request Soap Message or XML as String
	 */




	public static InputStreamReader getHTTPResonspe(URL url, String XMLInput) throws Exception {
		URLConnection connection = url.openConnection();
		HttpURLConnection httpConn = (HttpURLConnection) connection;
		ByteArrayOutputStream bout = new ByteArrayOutputStream();
		String strInput = XMLInput;

		byte[] buffer = new byte[strInput.length()];
		buffer = strInput.getBytes();


		bout.write(buffer);
		byte[] b = bout.toByteArray();

		String SOAPAction = "";
		// Set the appropriate HTTP parameters.
		doTrustToCertificates();
		httpConn.setRequestProperty("Content-Length", String.valueOf(b.length));
		httpConn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
		httpConn.setRequestProperty("SOAPAction", SOAPAction);
		httpConn.setRequestMethod("POST");
		httpConn.setDoOutput(true);
		httpConn.setDoInput(true);
		doTrustToCertificates();
		OutputStream out = httpConn.getOutputStream();
		// Write the content of the request to the outputstream of the HTTP
		// Connection.
		out.write(b);
		out.close();
		// Ready with sending the request.

		System.out.println(httpConn.getResponseCode());
		// Read the response.
		InputStreamReader isr = null;
		if (httpConn.getResponseCode() == 200) {
			doTrustToCertificates();
			isr = new InputStreamReader(httpConn.getInputStream());
		} else {
			isr = new InputStreamReader(httpConn.getErrorStream());
		}
		return isr;
	}
	@SuppressWarnings("restriction")
	static public void doTrustToCertificates() throws Exception {
		Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
		TrustManager[] trustAllCerts = new TrustManager[]{
				new X509TrustManager() {
					public X509Certificate[] getAcceptedIssuers() {
						return null;
					}

					public void checkServerTrusted(X509Certificate[] certs, String authType) throws CertificateException {
						return;
					}

					public void checkClientTrusted(X509Certificate[] certs, String authType) throws CertificateException {
						return;
					}
				}
		};

		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, new SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		HostnameVerifier hv = new HostnameVerifier() {
			public boolean verify(String urlHostName, SSLSession session) {
				if (!urlHostName.equalsIgnoreCase(session.getPeerHost())) {
					System.out.println("Warning: URL host '" + urlHostName + "' is different to SSLSession host '" + session.getPeerHost() + "'.");
				}
				return true;
			}
		};
		HttpsURLConnection.setDefaultHostnameVerifier(hv);
	} 

	/**
	 * <p>
	 *convertResponseStringtoDocument
	 *		This method converts the String XML  to Document  
	 *		to enable XPath actions
	 *</p>
	 * @param  XML
	 * 		XML as String
	 */

	public static Document convertResponseStringtoDocument(String XML)
	{
		String xml = XML;
		Document xmlDocument = null;
		try{
			DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder =  builderFactory.newDocumentBuilder();

			xmlDocument = builder.parse(new ByteArrayInputStream(xml.getBytes()));


		}
		catch (FileNotFoundException e) {
			e.printStackTrace();}
		catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}

		return xmlDocument;
	}

	/**
	 * <p>
	 *getNodelistfromXpath
	 *		This method checks the Response string and
	 *		returns all the nodes as NodeList matching xpath expression
	 *</p>
	 * @param  XML
	 * 		XML as String
	 * @param Xpathexpression
	 * 		Xpathexpression as String
	 */

	public static NodeList getNodelistfromXpath(String XML,String Xpathexpression)
	{

		XPath xPath =  XPathFactory.newInstance().newXPath();
		Document XmlString = convertResponseStringtoDocument(XML);
		String expression = Xpathexpression;
		NodeList nodelist = null;
		try {
			nodelist = (NodeList) xPath.compile(expression).evaluate(XmlString, XPathConstants.NODESET);
		} catch (XPathExpressionException e) {

			e.printStackTrace();
		}


		return nodelist;
	}
	/**
	 * <p>
	 *getNodelistfromXpath
	 *		This method returns the attribute value of the node
	 *</p>
	 * @param  XML
	 * 		XML as String
	 * @param Xpathexpression
	 * 		Xpathexpression as String
	 * @param Attribute
	 * 		value of node Attribute ( ex:- Text, value)
	 */

	public static String getNodeAttributeValue(String XML,String Xpathexpression,String Attribute)
	{
		NodeList Nodelist1 = getNodelistfromXpath(XML,Xpathexpression);
		String Value = null;
		for (int i = 0; i < Nodelist1.getLength(); i++) {
			Element element1 = (Element) Nodelist1.item(i);
			Value = element1.getAttribute(Attribute);
		}
		return Value;

	}
}