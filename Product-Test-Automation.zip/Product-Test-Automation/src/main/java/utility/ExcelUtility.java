package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.naming.spi.DirStateFactory.Result;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.SuperHelper;
import com.anthem.selenium.constants.ApplicationConstants;
import com.anthem.selenium.logging.AnthemLogger;
import com.anthem.selenium.utility.ExtentReportsUtility;

public class ExcelUtility extends SuperHelper{

	static AnthemLogger logger = AnthemLogger.getLogger(ExcelUtility.class.getName());
	Workbook workbook;
	Sheet sheet;
	private static ExcelUtility excel ;

	public static ExcelUtility get()
	{
		if(excel== null)
		{
			excel = new ExcelUtility();
		}
		return excel;
	}

	/**
	 * Method to open the excel file present in the specified path
	 * @param filePath: Location of the excel file
	 * @param sheetName: Sheet name in the excel file that needs to be referred for data
	 * @throws IOException: if the file or sheet is not present, IO exception will be thrown.
	 */
	public void openExcel(String filePath, String sheetName) throws IOException
	{
		FileInputStream inputStream = new FileInputStream(new File(filePath));
		workbook = getWorkbook(inputStream, filePath);
		sheet = workbook.getSheet(sheetName);
	}

	
	public Workbook openExcel(String filePath) throws IOException
	{
		FileInputStream inputStream = new FileInputStream(new File(filePath));
		Workbook workbook =  getWorkbook(inputStream, filePath);
		return workbook;
	}


	/**
	 * Method to close the excel file
	 * @throws IOException
	 */
	public void closeExcel() throws IOException
	{
		if(workbook != null)
		{
			workbook.close();
		}

	}



	/**
	 * Method to fetch the cell value identified by the rowNum and columnHeader
	 * @param rowNum: Row number from which the data should be fetched
	 * @param columnHeader: Column header which needs to be refernced to fetch the cell value
	 * @return
	 */
	public String getCellValue(int rowNum, String columnHeader)
	{
		Row row = sheet.getRow(rowNum);
		int headerIndex = getColumnHeaderNum(columnHeader);
		Cell cell = row.getCell(headerIndex);
		String cellValue = cell.getStringCellValue();
		return cellValue;
	}

	/**
	 * Method to fetch the cell value identified by the rowNum and columnHeader
	 * @param rowNum: Row number from which the data should be fetched
	 * @param columnHeader: Column header which needs to be refernced to fetch the cell value
	 * @return
	 */
	public String getCellValueForchangeReport(int rowNum, String columnHeader)
	{
		Row row = sheet.getRow(rowNum);
		int headerIndex = getColumnHeaderNumforchangeReport(columnHeader);
		Cell cell = row.getCell(headerIndex);
		String cellValue = cell.getStringCellValue();
		return cellValue;
	}
	/**
	 * Method to fetch the column header number
	 * @param colHeader: Column header for which the number has to be fetched
	 * @return : number of the column
	 * @throws IllegalArgumentException
	 */
	public int getColumnHeaderNum(String colHeader) throws IllegalArgumentException
	{

		Row row = sheet.getRow(0);
		Iterator<Cell> cellIterator = row.cellIterator();
		while (cellIterator.hasNext()) {
			Cell nextCell = cellIterator.next();
			String cellValue = nextCell.getStringCellValue();
			if(cellValue != null)
			{
				if(cellValue.equalsIgnoreCase(colHeader))
				{
					return nextCell.getColumnIndex();
				}
			}
		}
		return -1;
	}

	/**
	 * AF54545
	 * Method to fetch the column header number
	 * @param colHeader: Column header for which the number has to be fetched
	 * @return : number of the column
	 * @throws IllegalArgumentException
	 */
	public int getColumnHeaderNumforchangeReport(String colHeader) throws IllegalArgumentException
	{

		Row row = sheet.getRow(1);
		Iterator<Cell> cellIterator = row.cellIterator();
		while (cellIterator.hasNext()) {
			Cell nextCell = cellIterator.next();
			String cellValue = nextCell.getStringCellValue();
			if(cellValue != null)
			{
				if(cellValue.equalsIgnoreCase(colHeader))
				{
					return nextCell.getColumnIndex();
				}
			}
		}
		return -1;
	}
	
	public int getRowNumberForChangeReport(String keyColumn, String keyValue) throws IllegalArgumentException
	{
		int columnNumber = getColumnHeaderNumforchangeReport(keyColumn);
		Iterator<Row> iterator = sheet.iterator();
		while (iterator.hasNext()) {
			Row nextRow = iterator.next();
			Cell nextCell = nextRow.getCell(columnNumber);
			int cellType = nextCell.getCellType();
			String cellValue = "";
			if(cellType == Cell.CELL_TYPE_NUMERIC)
			{
				cellValue = String.valueOf(nextCell.getNumericCellValue());
			}
			else if (cellType == Cell.CELL_TYPE_STRING)
			{
				cellValue =  nextCell.getStringCellValue();
			}

			if(cellValue != null)
			{
				if(cellValue.equalsIgnoreCase(keyValue))
				{
					return nextRow.getRowNum();
				}
			}
		}

		return -1;

	}
	/**
	 * Method to fetch the row number with reference to KeyColumn and KeyValue
	 * @param keyColumn: Column header name
	 * @param keyValue: Value of the column that can be used to fetch the row number
	 * @return : Row number identified with the KeyColumn and KeyValue pair 
	 * @throws IllegalArgumentException
	 */
	public int getRowNumber(String keyColumn, String keyValue) throws IllegalArgumentException
	{
		int columnNumber = getColumnHeaderNum(keyColumn);
		Iterator<Row> iterator = sheet.iterator();
		while (iterator.hasNext()) {
			Row nextRow = iterator.next();
			Cell nextCell = nextRow.getCell(columnNumber);
			int cellType = nextCell.getCellType();
			String cellValue = "";
			if(cellType == Cell.CELL_TYPE_NUMERIC)
			{
				cellValue = String.valueOf(nextCell.getNumericCellValue());
			}
			else if (cellType == Cell.CELL_TYPE_STRING)
			{
				cellValue =  nextCell.getStringCellValue();
			}

			if(cellValue != null)
			{
				if(cellValue.equalsIgnoreCase(keyValue))
				{
					return nextRow.getRowNum();
				}
			}
		}

		return -1;

	}

	public  boolean setCellValue(int rowNum, String columnHeader, String cellValue)
	{
		Row row = sheet.getRow(rowNum);
		int headerIndex = getColumnHeaderNum(columnHeader);
		Cell cell = row.createCell(headerIndex);
		cell.setCellValue(cellValue);
		return true;
	}

	public static void processExceptions(String stepName, String localizedMessage)
	{
		RESULT_STATUS = false;
		logger.debug("Exception Occured: "+localizedMessage);
		log(ERROR, stepName, "Exception occured: "+localizedMessage);
	}

	/**
	 * @author AF12450
	 * Method to read the column value from the excel file from the specified location with the reference provided by KeyColumn
	 * KeyValue  pair
	 * @param filePath: Location of the excel file
	 * @param sheetName: Sheet name from which the data should be read
	 * @param keyColumn: Column header which helps in fetching the row number
	 * @param keyValue: Column value which helps in fetching the row number when paired with KeyColumn
	 * @param columnHeader: Column header from which the data should be fetched
	 * @return : String value which holds the cell data
	 * @throws IOException 
	 */
	public String readFromExcel(String filePath, String sheetName, String keyColumn, String keyValue, String columnHeader) throws IOException 
	{
		String returnValue = "";
		try
		{
			openExcel(filePath, sheetName);
			int rownum = getRowNumber(keyColumn, keyValue);
			returnValue = getCellValue(rownum,columnHeader);
			log(PASS, "Read from Excel", "Successfully fetched the value: "+returnValue);
			return returnValue;
		}
		catch (Exception e) {
			e.printStackTrace();
			processExceptions("Read from excel", e.getLocalizedMessage());
		}
		finally {
			closeExcel();
		}
		return returnValue;
	}

	/**
	 * @author AF12450
	 * Method to write the data to excel file from the specified location with the reference provided by KeyColumn
	 * KeyValue  pair
	 * @param filePath: Location of the excel file
	 * @param sheetName: Sheet name from which the data should be read
	 * @param keyColumn: Column header which helps in fetching the row number
	 * @param keyValue: Column value which helps in fetching the row number when paired with KeyColumn
	 * @param columnHeader: Column header to which the data should be written
	 * @param columnValue : value that needs to be written
	 */
	public void writeToExcel(String filePath, String sheetName, String keyColumn, String keyValue, String columnHeader,String columnValue) throws IOException
	{
		try
		{
			openExcel(filePath, sheetName);
			int rownum = getRowNumber(keyColumn, keyValue);
			RESULT_STATUS = setCellValue(rownum, columnHeader, columnValue);
			FileOutputStream output = new FileOutputStream(new File(filePath));
			workbook.write(output);
			output.close();
			log(RESULT_STATUS?PASS:FAIL, "Write data to Excel");
		}
		catch (Exception e) {
			e.printStackTrace();
			processExceptions("Write to excel", e.getLocalizedMessage());
		}
		finally {
			closeExcel();
		}
	}

	/**
	 * Method to fetch the workbook object specified by the input stream
	 * @param inputStream: File input stream of the excel
	 * @param excelFilePath: Location of the excel file
	 * @return: workbook object of the excel file will be returned
	 * @throws IOException
	 */
	static Workbook getWorkbook(FileInputStream inputStream, String excelFilePath)
			throws IOException {
		Workbook workbook = null;

		if (excelFilePath.endsWith("xlsx")) {
			workbook = new XSSFWorkbook(inputStream);
		} else if (excelFilePath.endsWith("xls")) {
			workbook = new HSSFWorkbook(inputStream);
		} else {
			throw new IllegalArgumentException("The specified file is not Excel file");
		}
		return workbook;
	}

	/**
	 * Method to fetch the column header number
	 * @param colHeader: Column header for which the number has to be fetched
	 * @return : number of the column
	 * @throws IllegalArgumentException
	 */
	static int getColumnHeaderNum(Sheet sheet, String sheetName, String columnHeader) throws IllegalArgumentException
	{
		int index= -1;                     
		Row row = sheet.getRow(1);
		Iterator<Cell> cellIterator = row.cellIterator();
		while (cellIterator.hasNext()) {
			Cell nextCell = cellIterator.next();
			String cellValue = nextCell.getStringCellValue();
			if(cellValue != null)
			{
				if(cellValue.equalsIgnoreCase(columnHeader))
					index= nextCell.getColumnIndex();
			}
		}
		return index;
	}


	public  void  validateUMRuleImpact(String planID,String reportPath,String currentUMRule, String priorUMRule) throws Exception
	{
		try
		{
			String benefitName = "Plan Setup/Plan Administration/PlanAdmin";
			String costShareName = "UM Rule Penalty Plan Design";
			openExcel(reportPath, "Plans Not for Republish");
			int  intRowNum = getRowNumber("Version ID", planID);
			if(!(intRowNum > 0))
			{
				//     		 validations in Plan Republish Impact
				sheet = workbook.getSheet("Plan Republish Impact");
				intRowNum = getRowNumber("Benefit Name", benefitName, "Prior Version ID", planID);
				if(intRowNum >0)
				{
					String actualCurrentUMRule = sheet.getRow(intRowNum).getCell(34).getStringCellValue().trim();
					String actualPriorUMRule = sheet.getRow(intRowNum).getCell(37).getStringCellValue().trim();
					String changeAction = sheet.getRow(intRowNum).getCell(40).getStringCellValue().trim();
					String domainOverride = sheet.getRow(intRowNum).getCell(41).getStringCellValue().trim();
					String actualCostShareName = sheet.getRow(intRowNum).getCell(27).getStringCellValue().trim();

					compareStrings(costShareName, actualCostShareName, "Validate Cost share in the Impact Analysis for the plan ID: "+planID);
					compareStrings(currentUMRule, actualCurrentUMRule, "Validate Current UM rule in the Impact Analysis Report for the plan ID: "+planID);
					compareStrings(priorUMRule, actualPriorUMRule, "Validate Prior UM Rule in the Impact Analysis for the plan ID: "+planID);
					compareStrings("Was updated", changeAction, "Validate Change Action in the Impact Analysis for the plan ID: "+planID);
					compareStrings("No", domainOverride, "Validate Domain Override in the Impact Analysis for the plan ID: "+planID);
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate change details in Plan Republish Impact","Not able to find the ID: "+planID+" in Plan Republish Impact");
				}

				//  			validations in Plans for Republish sheet
				sheet = workbook.getSheet("Plans for Republish");
				intRowNum = getRowNumber("Version ID", planID);
				if(intRowNum>0)
				{
					RESULT_STATUS=true;
					log(PASS, "Validate Plan is present in Plans for Republish","Plan ID: "+planID+" is present in the Plans for Republish sheet");
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate Plan is present in Plans for Republish","Plan ID: "+planID+" not is present in the Plans for Republish sheet");
				}
			}
			else
			{
				RESULT_STATUS=false;
				String strFailureReason = getCellValue(intRowNum, "Reason");
				log(FAIL, "Validate details of Bulk republis for plan ID: "+planID,
						"Plan ID: "+planID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
			}

		}
		catch (Exception e) {
			throw e;
		}
		finally {
			closeExcel();
		}

	}

	public int getRowNumber(String keyColumn1, String keyValue1, String keyColumn2, String keyValue2 ) throws IllegalArgumentException
	{
		int columnNumber1 = getImpactReportColumnHeaderNum(keyColumn1);
		int columnNumber2 = getImpactReportColumnHeaderNum(keyColumn2);
		Iterator<Row> iterator = sheet.iterator();
		while (iterator.hasNext()) {
			Row nextRow = iterator.next();
			Cell nextCell = nextRow.getCell(columnNumber1);
			String cellValue = nextCell.getStringCellValue();
			if(cellValue != null)
			{
				if(cellValue.contains(keyValue1))
				{
					Cell secondCell = nextRow.getCell(columnNumber2);
					String secondCellValue = secondCell.getStringCellValue().trim();
					if(secondCellValue.equalsIgnoreCase(keyValue2))
					{
						return nextRow.getRowNum();
					}
				}
			}
		}

		return -1;
	}

	/**
	 * Method to fetch the column header number
	 * @param colHeader: Column header for which the number has to be fetched
	 * @return : number of the column
	 * @throws IllegalArgumentException
	 */
	public int getImpactReportColumnHeaderNum(String colHeader) throws IllegalArgumentException
	{

		Row row = sheet.getRow(1);
		Iterator<Cell> cellIterator = row.cellIterator();
		while (cellIterator.hasNext()) {
			Cell nextCell = cellIterator.next();
			String cellValue = nextCell.getStringCellValue();
			if(cellValue != null)
			{
				if(cellValue.equalsIgnoreCase(colHeader))
				{
					return nextCell.getColumnIndex();
				}
			}
		}
		throw new IllegalArgumentException("Not able to find the given column header: "+colHeader+" in the Excel");
	}

	public void compareStrings(String expectedValue, String actualValue, String stepName)
	{

		if(expectedValue.equalsIgnoreCase(actualValue))
		{
			RESULT_STATUS = true;
			log(PASS, stepName,"Actual value: \""+actualValue+"\" is equal to Expected Value \""+expectedValue+"\"");
		}
		else
		{
			RESULT_STATUS = false;
			log(FAIL, stepName,"Actual value: \""+actualValue+"\" is not equal to Expected Value \""+expectedValue+"\"");
		}
	}


	public void validateSituationChange(String strPlanID,String strReportPath,String strSituation, boolean booadd ) throws Exception
	{
		try
		{
			String benefitName = "/Physician_MedSvcs/ExamVst";
			openExcel(strReportPath, "Plans Not for Republish");
			int  intRowNum = getRowNumber("Version ID", strPlanID);
			if(!(intRowNum > 0))
			{
				// 		 validations in Plan Republish Impact
				sheet = workbook.getSheet("Plan Republish Impact");
				intRowNum = getRowNumber("Benefit Name", benefitName, "Prior Version ID", strPlanID);
				if(intRowNum >0)
				{
					String changeAction = sheet.getRow(intRowNum).getCell(40).getStringCellValue().trim();
					String domainOverride = sheet.getRow(intRowNum).getCell(41).getStringCellValue().trim();
					String strNewSituationType = sheet.getRow(intRowNum).getCell(23).getStringCellValue().trim(); 

					if(booadd)
					{
						compareStrings("Is New", changeAction, "Validate \"Is New\" is displayed Change Action in the Impact Analysis for the plan ID: "+strPlanID);
					}
					else
					{
						compareStrings("Was Removed", changeAction, "Validate \"Is New\" is displayed Change Action in the Impact Analysis for the plan ID: "+strPlanID);
					}
					compareStrings("No", domainOverride, "Validate Domain Override in the Impact Analysis for the plan ID: "+strPlanID);
					compareStrings(strSituation, strNewSituationType, "Validate New Situation in the Impact Analysis for the plan ID: "+strPlanID);
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate change details in Plan Republish Impact","Not able to find the ID: "+strPlanID+" in Plan Republish Impact");
				}

				//			validations in Plans for Republish sheet
				sheet = workbook.getSheet("Plans for Republish");
				intRowNum = getRowNumber("Version ID", strPlanID);
				if(intRowNum>0)
				{
					RESULT_STATUS=true;
					log(PASS, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" is present in the Plans for Republish sheet");
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" not is present in the Plans for Republish sheet");
				}
			}
			else
			{
				RESULT_STATUS=false;
				String strFailureReason = getCellValue(intRowNum, "Reason");
				log(FAIL, "Validate details of Bulk republis for plan ID: "+strPlanID,
						"Plan ID: "+strPlanID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
			}

		}
		catch (Exception e) {
			throw e;
		}
		finally {
			closeExcel();
		}
	}

	public void validateBenefitChange(String strPlanID,String strReportPath,String benefitName, boolean booadd) throws Exception
	{
		try
		{
			waitForDownload(strReportPath);
			openExcel(strReportPath, "Plans Not for Republish");
			int  intRowNum = getRowNumber("Version ID", strPlanID);
			if(!(intRowNum > 0))
			{
				// 		 validations in Plan Republish Impact
				sheet = workbook.getSheet("Plan Republish Impact");
				intRowNum = getRowNumber("Benefit Name", benefitName, "Prior Version ID", strPlanID);
				if(intRowNum >0)
				{			
					String changeAction = sheet.getRow(intRowNum).getCell(40).getStringCellValue().trim();
					String domainOverride = sheet.getRow(intRowNum).getCell(41).getStringCellValue().trim();
					if(booadd)
					{
						compareStrings("Is New", changeAction, "Validate \"Is New\" is displayed Change Action in the Impact Analysis for the plan ID: "+strPlanID);
					}
					else
					{
						compareStrings("Was removed", changeAction, "Validate \"Was Removed\" is displayed Change Action in the Impact Analysis for the plan ID: "+strPlanID);
					}
					compareStrings("No", domainOverride, "Validate Domain Override in the Impact Analysis for the plan ID: "+strPlanID);
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate change details in Plan Republish Impact","Not able to find the ID: "+strPlanID+" in Plan Republish Impact");
				}

				//			validations in Plans for Republish sheet
				sheet = workbook.getSheet("Plans for Republish");
				intRowNum = getRowNumber("Version ID", strPlanID);
				if(intRowNum>0)
				{
					RESULT_STATUS=true;
					log(PASS, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" is present in the Plans for Republish sheet");
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" not is present in the Plans for Republish sheet");
				}

			}
			else
			{
				RESULT_STATUS=false;
				String strFailureReason = getCellValue(intRowNum, "Reason");
				log(FAIL, "Validate details of Bulk republis for plan ID: "+strPlanID,
						"Plan ID: "+strPlanID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
			}

		}
		catch (Exception e) {
			throw e;
		}
		finally {
			closeExcel();
		}
	}

	public void validatePlanOptionImpactReport(String strPlanID,String strReportPath,String benefitName, boolean booadd) throws Exception
	{
		try
		{
			waitForDownload(strReportPath);
			openExcel(strReportPath, "Plans Not for Republish");
			int  intRowNum = getRowNumber("Version ID", strPlanID);
			if(!(intRowNum > 0))
			{
				// 		 validations in Plan Republish Impact
				sheet = workbook.getSheet("Plan Republish Impact");
				intRowNum = getRowNumber("Benefit Name", benefitName, "Prior Version ID", strPlanID);
				if(intRowNum >0)
				{			
					String changeAction = sheet.getRow(intRowNum).getCell(40).getStringCellValue().trim();
					String domainOverride = sheet.getRow(intRowNum).getCell(41).getStringCellValue().trim();
					if(booadd)
					{
						compareStrings("Is New", changeAction, "Validate \"Is New\" is displayed Change Action in the Impact Analysis for the plan ID: "+strPlanID);
					}
					else
					{
						compareStrings("Was removed", changeAction, "Validate \"Was Removed\" is displayed Change Action in the Impact Analysis for the plan ID: "+strPlanID);
					}
					compareStrings("No", domainOverride, "Validate Domain Override in the Impact Analysis for the plan ID: "+strPlanID);
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate change details in Plan Republish Impact","Not able to find the ID: "+strPlanID+" in Plan Republish Impact");
				}

				//			validations in Plans for Republish sheet
				sheet = workbook.getSheet("Plans for Republish");
				intRowNum = getRowNumber("Version ID", strPlanID);
				if(intRowNum>0)
				{
					RESULT_STATUS=true;
					log(PASS, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" is present in the Plans for Republish sheet");
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" not is present in the Plans for Republish sheet");
				}

				log(RESULT_STATUS?PASS:FAIL, "Validate Plan Option change in Impact Report for Plan ID"+strPlanID);
			}
			else
			{
				RESULT_STATUS=false;
				String strFailureReason = getCellValue(intRowNum, "Reason");
				log(FAIL, "Validate details of Bulk republis for plan ID: "+strPlanID,
						"Plan ID: "+strPlanID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
			}

		}
		catch (Exception e) {
			throw e;
		}
		finally {
			closeExcel();
		}
	}

	public String validateUpdateBenefitChange(String strPlanID,String strReportPath,String benefitName, boolean booadd) throws Exception
	{
		String strNewVersionID = "";
		try
		{
			waitForDownload(strReportPath);
			openExcel(strReportPath, "Plans Not Republished");
			int  intRowNum = getRowNumber("Old Version ID", strPlanID);
			if(!(intRowNum > 0))
			{
				//          validations in Plan Republish Impact
				sheet = workbook.getSheet("Plan Republish Impact");
				intRowNum = getRowNumber("Benefit Name", benefitName, "Prior Version ID", strPlanID);
				if(intRowNum >0)
				{                    
					String changeAction = sheet.getRow(intRowNum).getCell(40).getStringCellValue().trim();
					String domainOverride = sheet.getRow(intRowNum).getCell(41).getStringCellValue().trim();
					if(booadd)
					{
						compareStrings("Is New", changeAction, "Validate \"Is New\" is displayed Change Action in the Update Report for the plan ID: "+strPlanID);
					}
					else
					{
						compareStrings("Was removed", changeAction, "Validate \"Was Removed\" is displayed Change Action in the Update Report for the plan ID: "+strPlanID);
					}
					compareStrings("No", domainOverride, "Validate Domain Override in the Update Report for the plan ID: "+strPlanID);
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate change details in Plan Republish Impact","Not able to find the ID: "+strPlanID+" in Plan Republish Impact");
				}

				//                validations in Plans for Republish sheet
				sheet = workbook.getSheet("Republished Plans");
				intRowNum = getRowNumber("Old Version ID", strPlanID);
				if(intRowNum>0)
				{
					strNewVersionID = getCellValue(intRowNum, "New Version ID");
					RESULT_STATUS=true;
					log(PASS, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" is present in the Plans for Republish sheet");
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" not is present in the Plans for Republish sheet");
				}
				log(RESULT_STATUS?PASS:FAIL, "Validate Benefit change in Impact Report for Plan ID"+strPlanID);
			}
			else
			{
				RESULT_STATUS=false;
				String strFailureReason = getCellValue(intRowNum, "Failure Reason");
				log(FAIL, "Validate details of Bulk republis for plan ID: "+strPlanID,
						"Plan ID: "+strPlanID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
			}

		}
		catch (Exception e) {
			throw e;
		}
		finally {
			closeExcel();
		}
		return strNewVersionID;
	}

	public String validatePlanOptionUpateReport(String strPlanID,String strReportPath,String benefitName, boolean booadd) throws Exception
	{
		String strNewVersionID = "";
		try
		{

			waitForDownload(strReportPath);
			openExcel(strReportPath, "Plans Not Republished");
			int  intRowNum = getRowNumber("Old Version ID", strPlanID);
			if(!(intRowNum > 0))
			{
				//          validations in Plan Republish Impact
				sheet = workbook.getSheet("Plan Republish Impact");
				intRowNum = getRowNumber("Benefit Name", benefitName, "Prior Version ID", strPlanID);
				if(intRowNum >0)
				{                    
					String changeAction = sheet.getRow(intRowNum).getCell(40).getStringCellValue().trim();
					String domainOverride = sheet.getRow(intRowNum).getCell(41).getStringCellValue().trim();
					if(booadd)
					{
						compareStrings("Is New", changeAction, "Validate \"Is New\" is displayed Change Action in the Update Report for the plan ID: "+strPlanID);
					}
					else
					{
						compareStrings("Was removed", changeAction, "Validate \"Was Removed\" is displayed Change Action in the Update Report for the plan ID: "+strPlanID);
					}
					compareStrings("No", domainOverride, "Validate Domain Override in the Update Report for the plan ID: "+strPlanID);
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate change details in Plan Republish Impact","Not able to find the ID: "+strPlanID+" in Plan Republish Impact");
				}

				//                validations in Plans for Republish sheet
				sheet = workbook.getSheet("Republished Plans");
				intRowNum = getRowNumber("Old Version ID", strPlanID);
				if(intRowNum>0)
				{
					strNewVersionID = getCellValue(intRowNum, "New Version ID");
					RESULT_STATUS=true;
					log(PASS, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" is present in the Plans for Republish sheet");
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" not is present in the Plans for Republish sheet");
				}

				log(RESULT_STATUS?PASS:FAIL, "Validate Plan Option change in Impact Report for Plan ID"+strPlanID);

			}
			else
			{
				RESULT_STATUS=false;
				String strFailureReason = getCellValue(intRowNum, "Failure Reason");
				log(FAIL, "Validate details of Bulk republis for plan ID: "+strPlanID,
						"Plan ID: "+strPlanID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
			}

		}
		catch (Exception e) {
			throw e;
		}
		finally {
			closeExcel();
		}
		return strNewVersionID;
	}
	
	public void validateLegacyUpdateReport(String strPlanID,String strReportPath) throws Exception
	{
		try
		{
			waitForDownload(strReportPath);
			openExcel(strReportPath, "Plans Not Republished");
			int  intRowNum = getRowNumber("Old Version ID", strPlanID);
			if(!(intRowNum > 0))
			{
				
				RESULT_STATUS=false;
				log(PASS, "Validate details of Bulk republis for plan ID: "+strPlanID,
						"Plan ID: "+strPlanID+" is present in the Plans for Republish sheet  \n");
			}
			else
			{
				RESULT_STATUS=false;
				String strFailureReason = getCellValue(intRowNum, "Reason");
				log(FAIL, "Validate details of Bulk republis for plan ID: "+strPlanID,
						"Plan ID: "+strPlanID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
			}

		}
		catch (Exception e) {
			throw e;
		}
		finally {
			closeExcel();
		}
	}
	
	public String validateUpateReportForAddOrRemove(String strPlanID,String strReportPath,String benefitName, String strStepName, boolean booadd) throws Exception
	{
		String strNewVersionID = "";
		try
		{
			waitForDownload(strReportPath);
			openExcel(strReportPath, "Plans Not Republished");
			int  intRowNum = getRowNumber("Old Version ID", strPlanID);
			if(!(intRowNum > 0))
			{
				//          validations in Plan Republish Impact
				sheet = workbook.getSheet("Plan Republish Impact");
				intRowNum = getRowNumber("Benefit Name", benefitName, "Prior Version ID", strPlanID);
				if(intRowNum >0)
				{                    
					String changeAction = sheet.getRow(intRowNum).getCell(40).getStringCellValue().trim();
					String domainOverride = sheet.getRow(intRowNum).getCell(41).getStringCellValue().trim();
					if(booadd)
					{
						compareStrings("Is New", changeAction, "Validate \"Is New\" is displayed Change Action in the Update Report for the plan ID: "+strPlanID);
					}
					else
					{
						compareStrings("Was removed", changeAction, "Validate \"Was Removed\" is displayed Change Action in the Update Report for the plan ID: "+strPlanID);
					}
					compareStrings("No", domainOverride, "Validate Domain Override in the Update Report for the plan ID: "+strPlanID);
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, strStepName,"Not able to find the ID: "+strPlanID+" in Plan Republish Impact");
				}

				//validations in Plans for Republish sheet
				sheet = workbook.getSheet("Republished Plans");
				intRowNum = getRowNumber("Old Version ID", strPlanID);
				if(intRowNum>0)
				{
					strNewVersionID = getCellValue(intRowNum, "New Version ID");
					RESULT_STATUS=true;
					log(PASS, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" is present in the Plans for Republish sheet");
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" not is present in the Plans for Republish sheet");
				}

				log(RESULT_STATUS?PASS:FAIL, strStepName+" "+strPlanID);

			}
			else
			{
				RESULT_STATUS=false;
				String strFailureReason = getCellValue(intRowNum, "Failure Reason");
				log(FAIL, strStepName + " "+strPlanID,
						"Plan ID: "+strPlanID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
			}

		}
		catch (Exception e) {
			log(FAIL, strStepName + " "+strPlanID,
					"Exception occured in validation of update report : "+e.getLocalizedMessage());
		}
		finally {
			closeExcel();
		}
		return strNewVersionID;
	}


	public void validateUMRuleChangeUpdateReport(String strPlanID,String strReportPath,String strCurrentUMRule, String strPriorUMRule) throws Exception
	{
		try
		{
			waitForDownload(strReportPath);
			String benefitName = "Plan Setup/Plan Administration/PlanAdmin";
			String costShareName = "UM Rule Penalty Plan Design";
			openExcel(strReportPath, "Plans Not Republished");
			int  intRowNum = getRowNumber("Old Version ID", strPlanID);
			if(!(intRowNum > 0))
			{
				//          validations in Plan Republish Impact
				sheet = workbook.getSheet("Plan Republish Impact");
				intRowNum = getRowNumber("Benefit Name", benefitName, "Prior Version ID", strPlanID);
				if(intRowNum >0)
				{  
					String actualCurrentUMRule = sheet.getRow(intRowNum).getCell(34).getStringCellValue().trim();
					String actualPriorUMRule = sheet.getRow(intRowNum).getCell(37).getStringCellValue().trim();
					String actualCostShareName = sheet.getRow(intRowNum).getCell(27).getStringCellValue().trim();
					String changeAction = sheet.getRow(intRowNum).getCell(40).getStringCellValue().trim();
					String domainOverride = sheet.getRow(intRowNum).getCell(41).getStringCellValue().trim();
					compareStrings("Was updated", changeAction, "Validate \"Was Removed\" is displayed Change Action in the Update Report for the plan ID: "+strPlanID);
					compareStrings("No", domainOverride, "Validate Domain Override in the Update Report for the plan ID: "+strPlanID);
					compareStrings(costShareName, actualCostShareName, "Validate Cost share in the Impact Analysis for the plan ID: "+strPlanID);
					compareStrings(strCurrentUMRule, actualCurrentUMRule, "Validate Current UM rule in the Impact Analysis Report for the plan ID: "+strPlanID);
					compareStrings(strPriorUMRule, actualPriorUMRule, "Validate Prior UM Rule in the Impact Analysis for the plan ID: "+strPlanID);
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate change details in Plan Republish Impact","Not able to find the ID: "+strPlanID+" in Plan Republish Impact");
				}

				//                validations in Plans for Republish sheet
				sheet = workbook.getSheet("Republished Plans");
				intRowNum = getRowNumber("Old Version ID", strPlanID);
				if(intRowNum>0)
				{
					RESULT_STATUS=true;
					log(PASS, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" is present in the Plans for Republish sheet");
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" not is present in the Plans for Republish sheet");
				}
			}
			else
			{
				RESULT_STATUS=false;
				String strFailureReason = getCellValue(intRowNum, "Failure Reason");
				log(FAIL, "Validate details of Bulk republis for plan ID: "+strPlanID,
						"Plan ID: "+strPlanID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
			}

		}
		catch (Exception e) {
			throw e;
		}
		finally {
			closeExcel();
		}
	}

	public void validateUpdateSituationTypeChange(String strPlanID,String strReportPath,String strServiceCode, boolean booadd) throws Exception
	{
		try
		{
			String benefitName = "/Physician_MedSvcs/ExamVst";
			openExcel(strReportPath, "Plans Not Republished");
			int  intRowNum = getRowNumber("Old Version ID", strPlanID);
			if(!(intRowNum > 0))
			{
				//          validations in Plan Republish Impact
				sheet = workbook.getSheet("Plan Republish Impact");
				intRowNum = getRowNumber("Benefit Name", benefitName, "Prior Version ID", strPlanID);
				if(intRowNum >0)
				{                    
					String changeAction = sheet.getRow(intRowNum).getCell(40).getStringCellValue().trim();
					String domainOverride = sheet.getRow(intRowNum).getCell(41).getStringCellValue().trim();
					String strNewSituationType = sheet.getRow(intRowNum).getCell(23).getStringCellValue().trim(); 
					if(booadd)
					{
						compareStrings("Is New", changeAction, "Validate \"Is New\" is displayed Change Action in the Update Report for the plan ID: "+strPlanID);
					}
					else
					{
						compareStrings("Was removed", changeAction, "Validate \"Was Removed\" is displayed Change Action in the Update Report for the plan ID: "+strPlanID);
					}
					compareStrings("No", domainOverride, "Validate Domain Override in the Update Report for the plan ID: "+strPlanID);
					compareStrings(strServiceCode, strNewSituationType, "Validate New Situation in the Update report for the plan ID: "+strPlanID);
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate change details in Plan Republish Impact","Not able to find the ID: "+strPlanID+" in Plan Republish Impact");
				}

				//                validations in Plans for Republish sheet
				sheet = workbook.getSheet("Republished Plans");
				intRowNum = getRowNumber("Old Version ID", strPlanID);
				if(intRowNum>0)
				{
					RESULT_STATUS=true;
					log(PASS, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" is present in the Plans for Republish sheet");
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" not is present in the Plans for Republish sheet");
				}
			}
			else
			{
				RESULT_STATUS=false;
				String strFailureReason = getCellValue(intRowNum, "Failure Reason");
				log(FAIL, "Validate details of Bulk republish for plan ID: "+strPlanID,
						"Plan ID: "+strPlanID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
			}

		}
		catch (Exception e) {
			throw e;
		}
		finally {
			closeExcel();
		}
	}


	public void waitForDownload(String strFilePath) throws Exception
	{
		File downloadedFile = new File(strFilePath);
		int loopCounter = 120;
		while(!downloadedFile.exists())
		{
			loopCounter--;
			Thread.sleep(1000);
			if(loopCounter==0)
			{
				break;
			}
		}
	}

	public void validateImpactBenefitOptionChange(String strPlanID,String strReportPath,String benefitName, boolean booadd) throws Exception
	{
		try
		{
			//String benefitName = "/Acupuncture";
			openExcel(strReportPath, "Plans Not for Republish");
			int  intRowNum = getRowNumber("Version ID", strPlanID);
			if(!(intRowNum > 0))
			{
				//validations in Plan Republish Impact
				sheet = workbook.getSheet("Plan Republish Impact");
				intRowNum = getRowNumber("Benefit Name", benefitName, "Prior Version ID", strPlanID);
				if(intRowNum >0)
				{
					String changeAction = sheet.getRow(intRowNum).getCell(40).getStringCellValue().trim();
					String domainOverride = sheet.getRow(intRowNum).getCell(41).getStringCellValue().trim();

					if(booadd)
					{
						compareStrings("Is New", changeAction, "Validate \"Is New\" is displayed Change Action in the Impact Analysis for the plan ID: "+strPlanID);
					}
					else
					{
						compareStrings("Was Removed", changeAction, "Validate \"Was Removed\" is displayed Change Action in the Impact Analysis for the plan ID: "+strPlanID);
					}
					compareStrings("No", domainOverride, "Validate Domain Override in the Impact Analysis for the plan ID: "+strPlanID);
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate change details in Plan Republish Impact","Not able to find the ID: "+strPlanID+" in Plan Republish Impact");
				}

				//validations in Plans for Republish sheet
				sheet = workbook.getSheet("Plans for Republish");
				intRowNum = getRowNumber("Version ID", strPlanID);
				if(intRowNum>0)
				{
					RESULT_STATUS=true;
					log(PASS, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" is present in the Plans for Republish sheet");
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" not is present in the Plans for Republish sheet");
				}
			}
			else
			{
				RESULT_STATUS=false;
				String strFailureReason = getCellValue(intRowNum, "Reason");
				log(FAIL, "Validate details of Bulk republis for plan ID: "+strPlanID,
						"Plan ID: "+strPlanID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
			}

		}
		catch (Exception e) {
			throw e;
		}
		finally {
			closeExcel();
		}
	}

	public String validateUpdateBenefitOptionChange(String strPlanID,String strReportPath,String benefitName, boolean booadd) throws Exception
	{
		String strNewVersionID = "";
		try
		{
			openExcel(strReportPath, "Plans Not Republished");
			int  intRowNum = getRowNumber("Old Version ID", strPlanID);
			if(!(intRowNum > 0))
			{
				//	          validations in Plan Republish Impact
				sheet = workbook.getSheet("Plan Republish Impact");
				intRowNum = getRowNumber("Benefit Name", benefitName, "Prior Version ID", strPlanID);
				if(intRowNum >0)
				{                    
					String changeAction = sheet.getRow(intRowNum).getCell(40).getStringCellValue().trim();
					String domainOverride = sheet.getRow(intRowNum).getCell(41).getStringCellValue().trim();
					if(booadd)
					{
						compareStrings("Is New", changeAction, "Validate \"Is New\" is displayed Change Action in the Update Report for the plan ID: "+strPlanID);
					}
					else
					{
						compareStrings("Was removed", changeAction, "Validate \"Was Removed\" is displayed Change Action in the Update Report for the plan ID: "+strPlanID);
					}
					compareStrings("No", domainOverride, "Validate Domain Override in the Update Report for the plan ID: "+strPlanID);
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate change details in Plan Republish Impact","Not able to find the ID: "+strPlanID+" in Plan Republish Impact");
				}

				//	                validations in Plans for Republish sheet
				sheet = workbook.getSheet("Republished Plans");
				intRowNum = getRowNumber("Old Version ID", strPlanID);
				if(intRowNum>0)
				{
					strNewVersionID = getCellValue(intRowNum, "New Version ID");
					RESULT_STATUS=true;
					log(PASS, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" is present in the Plans for Republish sheet");
				}
				else
				{
					RESULT_STATUS=false;
					log(FAIL, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" not is present in the Plans for Republish sheet");
				}
			}
			else
			{
				RESULT_STATUS=false;
				String strFailureReason = getCellValue(intRowNum, "Failure Reason");
				log(FAIL, "Validate details of Bulk republish for plan ID: "+strPlanID,
						"Plan ID: "+strPlanID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
			}

		}
		catch (Exception e) {
			throw e;
		}
		finally {
			closeExcel();
		}
		return strNewVersionID;
	}

	 public String validatePlanOptionUpdateinIMpactReport(String strPlanID,String strReportPath, String strPlanOptionOldValue,String strPlanOptionNewValue) throws Exception
	  {
		  String strNewVersionID = "";
		  try
		  {
			  openExcel(strReportPath, "Plans Not for Republish");
			  int  intRowNum = getRowNumber("Version ID", strPlanID);
			  if(intRowNum < 0)
			  {
//				  validations in Plan Republish Impact
				  sheet = workbook.getSheet("Plan Republish Impact");
				  intRowNum = getRowNumber("Benefit Name", "Plan Options/Inpatient Facility/CoveredINNOON", "Prior Version ID", strPlanID);
				  if(intRowNum >0)
				  {                    
					  String changeAction = sheet.getRow(intRowNum).getCell(40).getStringCellValue().trim();
					  String currentValue = sheet.getRow(intRowNum).getCell(34).getStringCellValue().trim();
					  String actualPriorPlanOption = sheet.getRow(intRowNum).getCell(37).getStringCellValue().trim();
					  
					  compareStrings("Was updated", changeAction, "Validate \"Was updated\" is displaying inn Change Action in the Impact Report for the plan ID: "+strPlanID);
					  compareStrings(strPlanOptionNewValue, currentValue, "Validate currentValue in the Impact Report for the plan ID: "+strPlanID);
					  compareStrings(strPlanOptionOldValue, actualPriorPlanOption, "Validate old plan option value in the Impact Report for the plan ID: "+strPlanID);
				  }
				  else
				  {
					  log(FAIL, "Validate Edit Plan Option details in Impact Report","Not able to find the expected change in the Plan Rebulish Impact sheet");
				  }
			  }
			  else
			  {
				  RESULT_STATUS=false;
				  String strFailureReason = getCellValue(intRowNum, "Reason");
				  log(FAIL, "Validate details of Bulk republish for plan ID: "+strPlanID,
						  "Plan ID: "+strPlanID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
			  }

		  }
		  catch (Exception e) {
			  e.printStackTrace();
			  log(FAIL, "Validate details of Bulk republish for plan ID: "+strPlanID,
					  "Exception occured"+e.getLocalizedMessage());
		  }
		  finally {
			  closeExcel();
		  }
		  return strNewVersionID;
	  }
	 
	 
	
	 
	 
	 public void validatePlanOptionUpdateInUpdateReport(String strPlanID,String strReportPath, String strPlanOptionOldValue,String strPlanOptionNewValue) throws Exception
	  {
		 try
			{
				waitForDownload(strReportPath);
				String benefitName = "Plan Options/Inpatient Facility/CoveredINNOON";
				String costShareName = "Does PREF apply";
				openExcel(strReportPath, "Plans Not Republished");
				int  intRowNum = getRowNumber("Old Version ID", strPlanID);
				if(!(intRowNum > 0))
				{
					//          validations in Plan Republish Impact
					sheet = workbook.getSheet("Plan Republish Impact");
					intRowNum = getRowNumber("Benefit Name", benefitName, "Prior Version ID", strPlanID);
					if(intRowNum >0)
					{  
						String actualCurrentUMRule = sheet.getRow(intRowNum).getCell(34).getStringCellValue().trim();
						String actualPriorUMRule = sheet.getRow(intRowNum).getCell(37).getStringCellValue().trim();
						String actualCostShareName = sheet.getRow(intRowNum).getCell(27).getStringCellValue().trim();
						String changeAction = sheet.getRow(intRowNum).getCell(40).getStringCellValue().trim();
						String domainOverride = sheet.getRow(intRowNum).getCell(41).getStringCellValue().trim();
						compareStrings("Was updated", changeAction, "Validate \"Was Removed\" is displayed Change Action in the Update Report for the plan ID: "+strPlanID);
						compareStrings("No", domainOverride, "Validate Domain Override in the Update Report for the plan ID: "+strPlanID);
						compareStrings(costShareName, actualCostShareName, "Validate Cost share in the Update Report for the plan ID: "+strPlanID);
						compareStrings(strPlanOptionNewValue, actualCurrentUMRule, "Validate Current Apply Deductible value in the Update Report for the plan ID: "+strPlanID);
						compareStrings(strPlanOptionOldValue, actualPriorUMRule, "Validate Prior Apply Deductible value in the Update Report for the plan ID: "+strPlanID);
					}
					else
					{
						RESULT_STATUS=false;
						log(FAIL, "Validate change details in Plan Republish Impact sheet of Update Report","Not able to find change for the ID: "+strPlanID+" in Plan Republish Impact sheet");
					}

					//                validations in Plans for Republish sheet
					sheet = workbook.getSheet("Republished Plans");
					intRowNum = getRowNumber("Old Version ID", strPlanID);
					if(intRowNum>0)
					{
						RESULT_STATUS=true;
						log(PASS, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" is present in the Plans for Republish sheet");
					}
					else
					{
						RESULT_STATUS=false;
						log(FAIL, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" not is present in the Plans for Republish sheet");
					}
				}
				else
				{
					RESULT_STATUS=false;
					String strFailureReason = getCellValue(intRowNum, "Failure Reason");
					log(FAIL, "Validate details of Bulk republis for plan ID: "+strPlanID,
							"Plan ID: "+strPlanID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
				}

			}
			catch (Exception e) {
				throw e;
			}
			finally {
				closeExcel();
			}
	  }
	 
	 
	 
	 
	 public String validateBenefitOptionUpdateinImpactReport(String strPlanID,String strReportPath, String strOldValue,String strNewValue) throws Exception
	  {
		  String strNewVersionID = "";
		  try
		  {
			  openExcel(strReportPath, "Plans Not for Republish");
			  int  intRowNum = getRowNumber("Version ID", strPlanID);
			  String strBenefitName = "Benefit Options/Allergy Serum/CoveredINNOON";
			  String costShareName = "Does PREF apply";
			  if(intRowNum < 0)
			  {
//				  validations in Plan Republish Impact
				  sheet = workbook.getSheet("Plan Republish Impact");
				  intRowNum = getRowNumber("Cost Share Name", costShareName, "Prior Version ID", strPlanID);
				  if(intRowNum >0)
				  {                    
					  String changeAction = sheet.getRow(intRowNum).getCell(40).getStringCellValue().trim();
					  String currentValue = sheet.getRow(intRowNum).getCell(34).getStringCellValue().trim();
					  String actualPriorPlanOption = sheet.getRow(intRowNum).getCell(37).getStringCellValue().trim();
					  String benefitNameImapct = sheet.getRow(intRowNum).getCell(21).getStringCellValue().trim();
					  compareStrings("Was updated", changeAction, "Validate \"Was updated\" is displaying in Change Action in the Impact Report for the plan ID: "+strPlanID);
					  compareStrings(strNewValue, currentValue, "Validate new Benefit option value  for Allergy Serum Does Preference Apply in the Impact Report for the plan ID: "+strPlanID);
					  compareStrings(strOldValue, actualPriorPlanOption, "Validate old Benefit option value  for Allergy Serum Does Preference Apply in the Impact Report for the plan ID: "+strPlanID);
					  compareStrings(benefitNameImapct, strBenefitName, "Validate Benefit Name in the Impact Report for the plan ID: "+strPlanID);
					  
				  }
				  else
				  {
					  log(FAIL, "Validate Edit Benefit Option details in Impact Report","Not able to find the expected change in the Plan Rebulish Impact sheet");
				  }
			  }
			  else
			  {
				  RESULT_STATUS=false;
				  String strFailureReason = getCellValue(intRowNum, "Reason");
				  log(FAIL, "Validate details of Bulk republish for plan ID: "+strPlanID,
						  "Plan ID: "+strPlanID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
			  }

		  }
		  catch (Exception e) {
			  e.printStackTrace();
			  log(FAIL, "Validate details of Bulk republish for plan ID: "+strPlanID,
					  "Exception occured"+e.getLocalizedMessage());
		  }
		  finally {
			  closeExcel();
		  }
		  return strNewVersionID;
	  }
	 
	 
	 public void validateBenefitOptionUpdateInUpdateReport(String strPlanID,String strReportPath, String strBenefitOptionOldValue,String strBenefitOptionNewValue) throws Exception
	  {
		 try
			{
				waitForDownload(strReportPath);
				  String strBenefitName = "Benefit Options/Allergy Serum/CoveredINNOON";
				  String costShareName = "Does PREF apply";
				openExcel(strReportPath, "Plans Not Republished");
				int  intRowNum = getRowNumber("Old Version ID", strPlanID);
				if(!(intRowNum > 0))
				{
					//          validations in Plan Republish Impact
					sheet = workbook.getSheet("Plan Republish Impact");
					intRowNum = getRowNumber("Cost Share Name", costShareName, "Prior Version ID", strPlanID);
					if(intRowNum >0)
					{  
						String actualCurrentUMRule = sheet.getRow(intRowNum).getCell(34).getStringCellValue().trim();
						String actualPriorUMRule = sheet.getRow(intRowNum).getCell(37).getStringCellValue().trim();
						String actualBenefitName = sheet.getRow(intRowNum).getCell(21).getStringCellValue().trim();
						String changeAction = sheet.getRow(intRowNum).getCell(40).getStringCellValue().trim();
						String domainOverride = sheet.getRow(intRowNum).getCell(41).getStringCellValue().trim();
						compareStrings("Was updated", changeAction, "Validate \"Was Removed\" is displayed Change Action in the Update Report for the plan ID: "+strPlanID);
						compareStrings("No", domainOverride, "Validate Domain Override in the Update Report for the plan ID: "+strPlanID);
						compareStrings(strBenefitName, actualBenefitName, "Validate Cost share in the Update Report for the plan ID: "+strPlanID);
						compareStrings(strBenefitOptionNewValue, actualCurrentUMRule, "Validate Current Does Pref apply value in the Update Report for the plan ID: "+strPlanID);
						compareStrings(strBenefitOptionOldValue, actualPriorUMRule, "Validate Prior Does Pref apply in the Update Report for the plan ID: "+strPlanID);
					}
					else
					{
						RESULT_STATUS=false;
						log(FAIL, "Validate change details in Plan Republish Impact sheet of Update Report","Not able to find change for the ID: "+strPlanID+" in Plan Republish Impact sheet");
					}

					//                validations in Plans for Republish sheet
					sheet = workbook.getSheet("Republished Plans");
					intRowNum = getRowNumber("Old Version ID", strPlanID);
					if(intRowNum>0)
					{
						RESULT_STATUS=true;
						log(PASS, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" is present in the Plans for Republish sheet");
					}
					else
					{
						RESULT_STATUS=false;
						log(FAIL, "Validate Plan is present in Plans for Republish","Plan ID: "+strPlanID+" not is present in the Plans for Republish sheet");
					}
				}
				else
				{
					RESULT_STATUS=false;
					String strFailureReason = getCellValue(intRowNum, "Failure Reason");
					log(FAIL, "Validate details of Bulk republis for plan ID: "+strPlanID,
							"Plan ID: "+strPlanID+" is present in the Plans for not Republish sheet with failure reason \n"+strFailureReason);
				}

			}
			catch (Exception e) {
				throw e;
			}
			finally {
				closeExcel();
			}
	  }
	 
	  
	  public String getNewPlanID(String strUpdateReportPath, String strPriorVersionID) throws Exception
	  {
		  String strNewVersionID = "";
		  try
		  {
			  openExcel(strUpdateReportPath, "Republished Plans");
				int intRowNum = getRowNumber("Old Version ID", strPriorVersionID);
				if(intRowNum>0)
				{
					strNewVersionID = getCellValue(intRowNum, "New Version ID");
				}
				else
				{
					log(FAIL, "Get New Plan Version ID from the update report path","Plan is not present in the Republished for Plans");
				}
		  }
		  catch (Exception e) {
			 e.printStackTrace();
			 log(FAIL, "Get New Plan Version ID from the update report path","Exception occured "+e.getLocalizedMessage());
		}
		  finally {
			  closeExcel();
		}
		  return strNewVersionID;
	  }
	  /**
		 * @author AF14733
		 * This method validates the excel sheet downloaded and fetches the column value
		 * @param filePath:Path where the update report is present
		 * @param SheetName:Name of the update report sheet
		 * @param HeaderName: Name of the column need to be validated
		 * @return
		 * @throws IOException
		 */
		public static  String validateexcelData(String filePath,String SheetName,String HeaderName) throws IOException{ 
			int col=0;
			String dataFound="";
			String tempData="";
			boolean found=false;
			FileInputStream  FILE=null;
			XSSFWorkbook WB=null;
			XSSFSheet  SHEET = null;
			try{
				FILE = new FileInputStream(new File(filePath));
				WB = new XSSFWorkbook(FILE);
				SHEET = WB.getSheet(SheetName);
				int cc=SHEET.getRow(0).getLastCellNum();
				for (int i = 0; i < cc; i++) {
					String data=SHEET.getRow(0).getCell(i).toString().trim();
					if(data.equals(HeaderName)){
						col=i;
						found=true;
						break;
					}
				}
				WB.close();
			} catch(Exception e){
				e.printStackTrace();
			}
			if(found){
				try{
					dataFound=SHEET.getRow(1).getCell(col).toString().trim();

				}catch(Exception e){
					dataFound="";
				}
			}
			if(!dataFound.equals("")){
				tempData= dataFound;
			}else{
				tempData="";
			}
			return tempData;
		}	
		/**
		 * @author AF14733
		 * This method validates the header data of the excel sheet fetched
		 * @param filePath:Path into which the excel sheet is downloaded
		 * @param SheetName: Name of the sheet in validation need to be done
		 * @param ExpectedData: Data expected in the sheet downloaded.
		 */
		public static void validateHeaderDataFromExcel(String filePath,String SheetName,String ExpectedData){
			try{

				ArrayList<String> failedHeader = new ArrayList<>();
				boolean found= false;
				FileInputStream      FILE = new FileInputStream(new File(filePath));

				XSSFWorkbook WB = new XSSFWorkbook(FILE);
				XSSFSheet  SHEET = WB.getSheet(SheetName);
				int cc=SHEET.getRow(0).getLastCellNum();
				String[] expectedValue = ExpectedData.split(",");
				for(int i = 0; i< expectedValue.length; i++)
				{
					String actual  = "";
					for (int index = 0; index < cc; index++) {
						actual=SHEET.getRow(0).getCell(index).toString().trim();
						if(actual.equals(expectedValue[i])){
							found= true;
							break;
						}
					}
					if(!found)
					{
						failedHeader.add(expectedValue[i]);
					}
					else
					{
						found = false;
					}
				}
				if(! (failedHeader.size()>0))
				{				 						
					log(PASS, "Validate Excel header", "Expected values "+ExpectedData+ " are present in the table", true);
				}
				else
				{
					String failedValues = "";
					for(int i =0; i< failedHeader.size(); i++ )
					{
						failedValues= failedHeader.get(i)+","+failedValues;
					}
					log(FAIL, "Verify the values in the Excel sheet", "Expected values "+failedValues+ " are not present in the table", false);
				}

				WB.close();
			} catch(Exception e){
				e.printStackTrace();

			}
		}
		
		/**
		 * The below method is to validate Update Report for Bulk Finalize
		 * @param strPlanID
		 * @param strReportPath
		 * @throws Exception
		 */
		public void validateUpateReportForBulkFinalize(String strPlanID,String strReportPath) throws Exception
		{
			//String strPlanProxyID = "";
			try
			{
				//waitForDownload(strReportPath);
				openExcel(strReportPath, "Plans Not Finalized");
				int  intRowNum = getRowNumber("Version ID", strPlanID);
				if(!(intRowNum > 0))
				{				
					//validations in Plans for Republish sheet
					sheet = workbook.getSheet("Finalized Plans");
					intRowNum = getRowNumber("Version ID", strPlanID);
					if(intRowNum>0)
					{
						//strPlanProxyID = getCellValue(intRowNum, "Proxy Plan ID");
						RESULT_STATUS=true;
						log(PASS, "Validate Plan is present in Finalized Plans","Plan ID: "+strPlanID+" is present in the Plans for Republish sheet");
					}
					else
					{
						RESULT_STATUS=false;
						log(FAIL, "Validate Plan is present in Finalized Plans","Plan ID: "+strPlanID+" not is present in the Plans for Republish sheet");
					}

					//log(RESULT_STATUS?PASS:FAIL, "Validate Bulk Finalize for "+" "+strPlanID);

				}
				else
				{
					RESULT_STATUS=false;
					String strFailureReason = getCellValue(intRowNum, "Failure Reason");
					log(FAIL, "Validate Bulk Finalize for " + " "+strPlanID,
							"Plan ID: "+strPlanID+" is present in the Plans for not Finalize sheet with failure reason \n"+strFailureReason);
				}

			}
			catch (Exception e) {
				log(FAIL, "Validate Bulk Finalize for " + " "+strPlanID,
						"Exception occured in validation of update report : "+e.getLocalizedMessage());
			}
			finally {
				closeExcel();
			}
		}
		
		/**
		 * @author AF54545
		 * This method validates the excel sheet downloaded and fetches the column value
		 * @param filePath:Path where the downloaded report is present
		 * @param SheetName:Name of the downloaded report sheet
		 * @param HeaderName: Name of the column need to be validated
		 * @throws IOException
		 */
		
	   //  validations in Plan Comparison Report
		public void validateExcelData(String filePath,String SheetName,String KeyHeaderName,String KeyModifiedHeaderName,String KeyHeaderValue,String KeyModifiedHeaderValue) throws IOException{ 
			int intRowNum =0,intColNum=0;
			FileInputStream  FILE=null;
			XSSFWorkbook WB=null;
			XSSFSheet  SHEET = null;
			try{
				FILE = new FileInputStream(new File(filePath));
				WB = new XSSFWorkbook(FILE);
				SHEET = WB.getSheet(SheetName);
				workbook=ExcelUtility.get().openExcel(filePath);
                sheet = workbook.getSheet(SheetName);
                intColNum = ExcelUtility.get().getColumnHeaderNumforchangeReport(KeyHeaderName);
                intRowNum = ExcelUtility.get().getRowNumberForChangeReport(KeyModifiedHeaderName, KeyModifiedHeaderValue);
				String data=SHEET.getRow(intRowNum).getCell(intColNum).toString().trim();
				if(data.equalsIgnoreCase(KeyHeaderValue)){
					RESULT_STATUS = true;
					log(PASS, "Verify Change is made to the Current Plan",
								"Verified change is made to the Current Plan", true);
					}else{
						RESULT_STATUS = false;
						log(FAIL, "Change not made to the Current Plan",
							"Change is not made to the Current Plan", true);
					}

				WB.close();
			} catch(Exception e){
				e.printStackTrace();
			}
		}
		

		public static void validateBenefitName(String strReportPath,String benefitValue,String strCostShareName)
		    {
		           try{
		                  ExcelUtility.get().openExcel(strReportPath,"PlanComparisonReport");
		                  int  intRowNum = ExcelUtility.get().getRowNumber("Benefit Name", benefitValue, "Cost Share Name", strCostShareName);
		                  if((intRowNum > 0))
		                  {
		                	  log(PASS, "Validate change details in change report","Able to find Changes in change report");                        
		                  }
		                  else
		                  {
		                        RESULT_STATUS=false;
		                        log(FAIL, "Validate change details in change report","Not able to find Benefit Name: "+benefitValue+" in change report");
		                  }
		           }
		           catch(Exception e)
		           {
		                  log(FAIL, "Validate change details in change report","Not able to download the change report");
		           }
		    }
			public static void validateChangeAction(String strReportPath,String benefitValue,String changeValue)
		    {
		           try{
		        	   ExcelUtility.get().openExcel(strReportPath,"PlanComparisonReport");
		                  int  intRowNum = ExcelUtility.get().getRowNumber("Change Action", changeValue, "Benefit Name", benefitValue);
		                  if((intRowNum > 0))
		                  {
		                	  RESULT_STATUS=true;
		                	  log(PASS, "Validate change Change Action details in change report","Able to find Change Action in change report as "+changeValue);  
		                  }
		                  else
		                  {
		                        RESULT_STATUS=false;
		                        log(FAIL, "Validate change details in change report","Not able to find the Cost Share "+benefitValue+" in change report");
		                  }
		           }
		           catch(Exception e)
		           {
		                  log(FAIL, "Validate change details in change report","Not able to download the change report");
		           }
		    }

			public static void validateCurrentValue(String strReportPath,String limitValue,String strCostShareName)
		    {
		           try{
		                  ExcelUtility.get().openExcel(strReportPath,"PlanComparisonReport");
		                  int  intRowNum = ExcelUtility.get().getRowNumber("Value", limitValue, "Cost Share Name", strCostShareName);
		                  if((intRowNum > 0))
		                  {
		                	  log(PASS, "Validate change details in change report","Able to find Changes in change report");                        
		                  }
		                  else
		                  {
		                        RESULT_STATUS=false;
		                        log(FAIL, "Validate change details in change report","Not able to find Prior Value for the Cost share Name "+strCostShareName+" in change report");
		                  }
		           }
		           catch(Exception e)
		           {
		                  log(FAIL, "Validate change details in change report","Not able to download the change report");
		           }
		    }
			
			
			public static void validatePreAuth(String strReportPath,String CSmodified,String CostShareValue,String PreAuth,String tempvalue)
		    {
		           try{
		        	    ExcelUtility.get().openExcel(strReportPath,"PlanComparisonReport");
		                  int  intRowNum = ExcelUtility.get().getRowNumber("Cost Share Name", CostShareValue, "CS Modified", CSmodified);
		                  if(intRowNum > 0)
		                  {
		                	  String strExcelValue = ExcelUtility.get().getCellValueForchangeReport(intRowNum,PreAuth);
		                	  if(strExcelValue.equalsIgnoreCase(tempvalue))
		                	  {
		                		  RESULT_STATUS=true;
		                		  log(PASS, "Validate details in change report","Change is made to the Current Plan",true);
		                	  }else
		                	  {  
			                	  RESULT_STATUS=false;
			                	  log(PASS, "Validate details in change report","Change is not made to the Current Plan",true); 
		                	  }
		                  }
		                  else
		                  {
		                        RESULT_STATUS=false;
		                        log(FAIL, "Validate  details in change report","Not able to find the "+CostShareValue+" in change report");
		                  }
		           }
		           catch(Exception e)
		           {
		                 log(FAIL, "Validate change details in change report","Not able to download the change report");
		        	 
		           }
		    }
			
			/**
			 * @author AF54545
			 * This method validates the excel sheet downloaded and fetches the column value
			 * @param filePath:Path where the downloaded report is present
			 * @param SheetName:Name of the downloaded report sheet
			 * @param HeaderName: Name of the column need to be validated
			 * @throws IOException
			 */
			
		   //  validations in Plan Comparison Report
			public void validateExcelDataForChangeReport(String filePath,String SheetName,String KeyHeaderName,String KeyHeaderValue,String KeyModifiedHeaderValue) throws IOException{ 
				int intRowNum =0,intColNum=0;
				FileInputStream  FILE=null;
				XSSFWorkbook WB=null;
				XSSFSheet  SHEET = null;
				try{
					FILE = new FileInputStream(new File(filePath));
					WB = new XSSFWorkbook(FILE);
					SHEET = WB.getSheet(SheetName);
					workbook=ExcelUtility.get().openExcel(filePath);
	                sheet = workbook.getSheet(SheetName);
	                intColNum = ExcelUtility.get().getColumnHeaderNumforchangeReport(KeyModifiedHeaderValue);
	                intRowNum = ExcelUtility.get().getRowNumberForChangeReport(KeyHeaderName, KeyHeaderValue);
					String data=SHEET.getRow(intRowNum).getCell(intColNum).toString().trim();
					if(data.equalsIgnoreCase("Yes")){
						RESULT_STATUS = true;
						log(PASS, "Verify Change is made to the Current Plan",
									"Verified change is made to the Current Plan", true);
						}else{
							RESULT_STATUS = false;
							log(FAIL, "Change not made to the Current Plan",
								"Change is not made to the Current Plan", true);
						}

					WB.close();
				} catch(Exception e){
					e.printStackTrace();
				}
			}

}
