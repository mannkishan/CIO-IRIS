package utility;

import java.io.FileInputStream;
import java.io.File;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class BIParser extends ExcelUtility{

	private static BIParser thisTestObj;	
	public synchronized static BIParser get() {
		if(thisTestObj==null)
		{
			thisTestObj = new BIParser();
		}
		
		return thisTestObj;
	}
	
	

	}
	
	
	
	
