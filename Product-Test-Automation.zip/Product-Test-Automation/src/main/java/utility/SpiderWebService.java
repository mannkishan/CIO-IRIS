package utility;

import java.io.File;
import java.util.List;

import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

public class SpiderWebService extends CoreSuperHelper{

	private static SpiderWebService thisTestObj;	
	public synchronized static SpiderWebService get() {
		thisTestObj = new SpiderWebService();
		return thisTestObj;
	}

	public String getContractSummaryXML(String streffectiveDate, String strLOB, String strContractCode)
	{
		String xmlInput = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.service.groupconfigurator.core.health.fja.com\">"
				+ "<soapenv:Header/>\n"
				+ "<soapenv:Body>\n"
				+ "<ws:getContractSummary>\n"
				+ "<correlationId>?</correlationId>\n"
				+ "<userId>?</userId>\n"
				+ "<vendorId>?</vendorId>\n"
				+ "<appName>?</appName>\n"
				+ "<appVersion>?</appVersion>\n"
				+ "<timeStamp>?</timeStamp>\n"
				+ "<visibilityAttr>?</visibilityAttr>\n"
				+ "<functionalDomain>ALL</functionalDomain>\n"
				+ "<contractCode>"+strContractCode+"</contractCode>\n"
				+ "<effectiveDate>"+streffectiveDate+"</effectiveDate>\n"
				+ "<asOfDate></asOfDate>\n"
				+ "<lob>"+strLOB+"</lob>\n"
				+ "<returnKeyWords>true</returnKeyWords>\n"
				+ "</ws:getContractSummary>\n"
				+ "</soapenv:Body>\n"
				+ "</soapenv:Envelope>";

		return xmlInput;
	}

	//getBenefitAccumDetails
	public String getResponseWithParentAndChildBenefits(String streffectiveDate, String strLOB, String strContractCode,String returnChild)
	{
		String xmlInput ="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.service.groupconfigurator.core.health.fja.com\">"
				+"<soapenv:Header/>\n"
				+"<soapenv:Body>\n"
				+"<ws:getContractDetail>\n"
				+"<correlationId>?</correlationId>\n"
				+"<userId>?</userId>\n"
				+"<vendorId>?</vendorId>\n"
				+"<appName>?</appName>\n"
				+"<appVersion>?</appVersion>\n"
				+"<timeStamp>?</timeStamp>\n"
				+"<visibilityAttr>?</visibilityAttr>\n"
				+"<functionalDomain>SBC</functionalDomain>\n"
				+"<contractCode>"+strContractCode+"</contractCode>\n"
				+"<effectiveDate>"+streffectiveDate+"</effectiveDate>\n"
				+"<asOfDate/>\n"
				+"<returnKeyWords>true</returnKeyWords>\n"
				+"<Filter>\n"
				+"<!--Optional:-->\n"
				+"<lob>"+strLOB+"</lob>\n"
				+"<!--Optional:-->\n"    	            
				+"<returnBenefits>true</returnBenefits>\n"
				+"<!--Zero or more repetitions:-->\n"
				+"<BenefitLevelNames returnChildLevels=\""+returnChild+"\">\n"
				+"<!--Zero or more repetitions:-->\n"
				+"<benefitLevel>Physician_MedSvcs</benefitLevel>\n"
				+"<benefitLevel>ExamVst</benefitLevel>\n"
				+"</BenefitLevelNames>\n"
				+"</Filter>\n"
				+"</ws:getContractDetail>\n"
				+"</soapenv:Body>\n"
				+"</soapenv:Envelope>";

		return xmlInput;
	}	
	public String getResponseWithNoChildBenefits(String streffectiveDate, String strLOB, String strContractCode,String returnChild)
	{
		String xmlInput ="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.service.groupconfigurator.core.health.fja.com\">"
				+"<soapenv:Header/>\n"
				+"<soapenv:Body>\n"
				+"<ws:getContractDetail>\n"
				+"<correlationId>?</correlationId>\n"
				+"<userId>?</userId>\n"
				+"<vendorId>?</vendorId>\n"
				+"<appName>?</appName>\n"
				+"<appVersion>?</appVersion>\n"
				+"<timeStamp>?</timeStamp>\n"
				+"<visibilityAttr>?</visibilityAttr>\n"
				+"<functionalDomain>SBC</functionalDomain>\n"
				+"<contractCode>"+strContractCode+"</contractCode>\n"
				+"<effectiveDate>"+streffectiveDate+"</effectiveDate>\n"
				+"<asOfDate/>\n"
				+"<returnKeyWords>true</returnKeyWords>\n"
				+"<Filter>\n"
				+"<!--Optional:-->\n"
				+"<lob>"+strLOB+"</lob>\n"
				+"<!--Optional:-->\n"		            
				+"<returnBenefits>true</returnBenefits>\n"
				+"<!--Zero or more repetitions:-->\n"
				+"<BenefitLevelNames returnChildLevels=\""+returnChild+"\">\n"
				+"<!--Zero or more repetitions:-->\n"
				+"<benefitLevel>Physician_MedSvcs</benefitLevel>\n"
				+"</BenefitLevelNames>\n" 
				+"</Filter>\n"
				+"</ws:getContractDetail>\n"
				+"</soapenv:Body>\n"
				+"</soapenv:Envelope>";
		return xmlInput;
	}
	
	public String getResponseWithBenefitDetailsForExamVistAndRehabTherapy(String streffectiveDate, String strLOB, String strContractCode,String examVisitReturnChild,String rehabReturnChild)
	{
		String xmlInput="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.service.groupconfigurator.core.health.fja.com\">"
		        +"<soapenv:Header/>\n"
				+"<soapenv:Body>\n"
				+"<ws:getContractDetail>\n"
				+"<correlationId>?</correlationId>\n"
				+"<userId>?</userId>\n"
				+"<vendorId>?</vendorId>\n"
				+"<appName>?</appName>\n"
				+"<appVersion>?</appVersion>\n"
				+"<timeStamp>?</timeStamp>\n"
				+"<visibilityAttr>?</visibilityAttr>\n"
				+"<functionalDomain>SBC</functionalDomain>\n"
				+"<contractCode>"+strContractCode+"</contractCode>\n"
				+"<effectiveDate>"+streffectiveDate+"</effectiveDate>\n"
				+"<asOfDate/>\n"
				+"<returnKeyWords>true</returnKeyWords>\n"
				+"<Filter>\n"
				+"<!--Optional:-->\n"
				+"<lob>"+strLOB+"</lob>\n"
				+"<!--Optional:-->\n"
				+"<returnBenefits>true</returnBenefits>\n"
				+"<!--Zero or more repetitions:-->\n"
				+"<BenefitLevelNames returnChildLevels=\""+examVisitReturnChild+"\">\n"
				+"<!--Zero or more repetitions:-->\n"
				+"<benefitLevel>Physician_MedSvcs</benefitLevel>\n"
				+"</BenefitLevelNames>\n"   
				+"<BenefitLevelNames returnChildLevels=\""+rehabReturnChild+"\">\n"
				+"<!--Zero or more repetitions:-->\n"
				+"<benefitLevel>RehabTherapies</benefitLevel>\n"
				+"</BenefitLevelNames>\n"
				+"</Filter>\n"
				+"</ws:getContractDetail>\n"
				+"</soapenv:Body>\n"
				+"</soapenv:Envelope>";		
		
		  return xmlInput;
	}
	
	public String getBenefitAccumDetailsForExamVistInjAndRehab(String streffectiveDate, String strLOB, String strContractCode,String examVisitInjReturnChild,String rehabReturnChild)
	{
		String xmlInput="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.service.groupconfigurator.core.health.fja.com\">"
				+"<soapenv:Header/>\n"
				+"<soapenv:Body>\n"
				+"<ws:getContractDetail>\n"
				+"<correlationId>?</correlationId>\n"
				+"<userId>?</userId>\n"
				+"<vendorId>?</vendorId>\n"
				+"<appName>?</appName>\n"
				+"<appVersion>?</appVersion>\n"
				+"<timeStamp>?</timeStamp>\n"
				+"<visibilityAttr>?</visibilityAttr>\n"
				+"<functionalDomain>SBC</functionalDomain>\n"
				+"<contractCode>"+strContractCode+"</contractCode>\n"
				+"<effectiveDate>"+streffectiveDate+"</effectiveDate>\n"
				+"<asOfDate>"+streffectiveDate+"</asOfDate>\n"
				+"<returnKeyWords>true</returnKeyWords>\n"
				+"<Filter>\n"
				+"<!--Optional:-->\n"
				+"<lob>"+strLOB+"</lob>\n"
				+"<!--Optional:-->\n"		            
				+"<returnBenefits>true</returnBenefits>\n"
				+"<!--Zero or more repetitions:-->\n"
				+"<BenefitLevelNames returnChildLevels=\""+examVisitInjReturnChild+"\">\n"
				+"<!--Zero or more repetitions:-->\n"
				+"<benefitLevel>Physician_MedSvcs</benefitLevel>\n"
				+"<benefitLevel>ExamVst</benefitLevel>\n"
				+"<benefitLevel>Injection</benefitLevel>\n"
				+"</BenefitLevelNames>\n"
				+"<!--Zero or more repetitions:-->\n"
				+"<BenefitLevelNames returnChildLevels=\""+rehabReturnChild+"\">\n"
				+"<!--Zero or more repetitions:-->\n"
				+"<benefitLevel>RehabTherapies</benefitLevel>\n"
				+"</BenefitLevelNames>\n"
				+"</Filter>\n"
				+"</ws:getContractDetail>\n"
				+"</soapenv:Body>\n"
				+"</soapenv:Envelope>";	
			   
		   return xmlInput;
	}
	
	public String getResponseWithParentChildBenefits(String streffectiveDate, String strLOB, String strContractCode,String returnChild)
	{
		String xmlInput="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.service.groupconfigurator.core.health.fja.com\">"
                +"<soapenv:Header/>\n"
				+"<soapenv:Body>\n"
				+"<ws:getContractDetail>\n"
				+"<correlationId>?</correlationId>\n"
				+"<userId>?</userId>\n"
				+"<vendorId>?</vendorId>\n"
				+"<appName>?</appName>\n"
				+"<appVersion>?</appVersion>\n"
				+"<timeStamp>?</timeStamp>\n"
				+"<visibilityAttr>?</visibilityAttr>\n"
				+"<functionalDomain>SBC</functionalDomain>\n"
				+"<contractCode>"+strContractCode+"</contractCode>\n"
				+"<effectiveDate>"+streffectiveDate+"</effectiveDate>\n"
				+"<asOfDate>"+streffectiveDate+"</asOfDate>]\n"
				+"<returnKeyWords>true</returnKeyWords>\n"
				+"<Filter>\n"
				+"<!--Optional:-->\n"
				+"<lob>"+strLOB+"</lob>\n"
				+"<!--Optional:-->\n"	
				+"<returnBenefits>true</returnBenefits>\n"
				+"<!--Zero or more repetitions:-->\n"
				+"<BenefitLevelNames returnChildLevels=\""+returnChild+"\">\n"
				+"<!--Zero or more repetitions:-->\n"
				+"<benefitLevel>Physician_MedSvcs</benefitLevel>\n"
				+"</BenefitLevelNames>\n" 
				+"</Filter>\n"
				+"</ws:getContractDetail>\n"
				+"</soapenv:Body>\n"
				+"</soapenv:Envelope>";
				
				  return xmlInput;
	}
	
	public String getResponseWithBenefitOptions(String streffectiveDate, String strLOB, String strContractCode,String returnPlanOptions,String returnBenefitOptions,String returnBenefits)
	{
		String xmlInput="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.service.groupconfigurator.core.health.fja.com\">"
				  +"<soapenv:Header/>\n"
				  +"<soapenv:Body>\n"
                  +"<ws:getContractDetail>\n"
                  +"<correlationId>?</correlationId>\n"
                  +"<userId>?</userId>\n"
                  +"<vendorId>?</vendorId>\n"
                  +"<appName>?</appName>\n"
                  +"<appVersion>?</appVersion>\n"
                  +"<timeStamp>?</timeStamp>\n"
                  +"<visibilityAttr>?</visibilityAttr>\n"
                  +"<functionalDomain>SBC</functionalDomain>\n"
                  +"<contractCode>"+strContractCode+"</contractCode>\n"
                  +"<effectiveDate>"+streffectiveDate+"</effectiveDate>\n"
                  +"<asOfDate>"+streffectiveDate+"</asOfDate>\n"
                  +"<returnKeyWords>true</returnKeyWords>\n"
                  +"<Filter>\n"
                  +"<!--Optional:-->\n"
                  +"<lob>"+strLOB+"</lob>\n"
                  +"<!--Optional:-->\n"            
                  +"<returnPlanOptions>"+returnPlanOptions+"</returnPlanOptions>\n" 
                  +"<returnBenefitOptions>"+returnBenefitOptions+"</returnBenefitOptions>\n" 
                  +"<returnBenefits>"+returnBenefits+"</returnBenefits>\n"
                  +"</Filter>\n"
                  +"</ws:getContractDetail>\n"
                  +"</soapenv:Body>\n"
                  +"</soapenv:Envelope>";

		 return xmlInput;
	}
	
	
   public String webServcRequestGetMedicalLOBPlanDetails(String streffectiveDate,String strContractCode, String strLOB,String returnPlanOptions,String returnBenefitOptions,String returnBenefits)
   {
	   String xmlInput="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.service.groupconfigurator.core.health.fja.com\">"
						   +"<soapenv:Header/>"
						   +"<soapenv:Body>"
						   +"<ws:getContractDetail>"
						   +"<correlationId>?</correlationId>"
						   +"<userId>?</userId>"
						   +"<vendorId>?</vendorId>"
						   +"<appName>?</appName>"
						   +"<appVersion>?</appVersion>"
						   +"<timeStamp>?</timeStamp>"
						   +"<visibilityAttr>?</visibilityAttr>"
						   +"<functionalDomain>SBC</functionalDomain>"
						   +"<contractCode>1FZ9</contractCode>"
						   +"<effectiveDate>"+streffectiveDate+"</effectiveDate>"
						   +" <asOfDate>"+streffectiveDate+"</asOfDate>"
						   +"<returnKeyWords>true</returnKeyWords>"
						   +" <Filter>"
						   +"<!--Optional:-->"
						   +"<lob>"+strLOB+"</lob>"
						   +" <!--Optional:-->"
						   +"<returnPlanOptions>"+returnPlanOptions+"</returnPlanOptions> "
						   +"<returnBenefitOptions>"+returnBenefitOptions+"</returnBenefitOptions> "
						   +" <returnBenefits>"+returnBenefits+"</returnBenefits>"
						   +" </Filter>"
						   +" </ws:getContractDetail>"
						   +"</soapenv:Body>"
						   +"</soapenv:Envelope>";  
	   
	return xmlInput;
	   
   }
   
   public boolean verifyMedicalLOBFilter(String strXMLFile) throws DocumentException{

	   boolean booMedicalPlanLOBFound = false;
	   boolean booMedicalPlanDetailsFound = false;
	   try
	   {		  
		   File file = new File(strXMLFile);
		   SAXReader reader = new SAXReader();
		   org.dom4j.Document document = reader.read(file);
		   List<Node> nodes = document.selectNodes("//plans/planStub");
		   System.out.println(nodes.size());
		   for (Node node : nodes) {
			   Element lob = (Element) (node.selectSingleNode("lob"));
			   if(lob!= null)
			   {
				   String lobValue = lob.attributeValue("name");
				   if(lobValue.equalsIgnoreCase("Medical"))
				   {
					   booMedicalPlanLOBFound = true;
					   //strMedicalPlanID = ((Element) (node)).attributeValue("planId");
					   Element plan = (Element) (node.selectSingleNode("plan"));
					   if(plan!=null)
					   {
						   booMedicalPlanDetailsFound = true;
					   }
				   }
				   else if ((lobValue.equalsIgnoreCase("Dental"))||(lobValue.equalsIgnoreCase("Vision"))||(lobValue.equalsIgnoreCase("Pharmacy")))
				   {								
					   Element plan = (Element) (node.selectSingleNode("plan"));
					   if(plan!=null)
					   {
						   log(FAIL, "Validate Plan details for other than Medical LOB", "Plan details are displaying for "+lobValue+" LOB", false);
					   }
					   else
					   {
						   log(PASS, "Validate Plan details for other than Medical LOB", "Plan details are not displaying for "+lobValue+" LOB", false);
					   }
				   }
			   }
		   }
		   if(!booMedicalPlanLOBFound)
		   {
			   log(FAIL, "Validate Plan details for Medical", "Medical LOB is not found for the given Contract code", false);
		   }
	   }catch(Exception e)
	   {
		   throw e;
	   }
	   return booMedicalPlanDetailsFound;
   }
   public String planLevelData(String streffectiveDate, String strLOB, String strContractCode,String returnBenefits)
	{
		String xmlInput="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.service.groupconfigurator.core.health.fja.com\">"
				+" <soapenv:Header/>\n"
				+" <soapenv:Body>\n"
				+" <ws:getContractDetail>\n"
				+" <correlationId>?</correlationId>\n"
				+"  <userId>?</userId>\n"
				+"  <vendorId>?</vendorId>\n"
				+" <appName>?</appName>\n"
				+"  <appVersion>?</appVersion>\n"
				+"  <timeStamp>?</timeStamp>\n"
				+" <visibilityAttr>?</visibilityAttr>\n"
				+" <functionalDomain>SBC</functionalDomain>\n"
				+" <contractCode>"+strContractCode+"</contractCode>\n"
				+" <effectiveDate>"+streffectiveDate+"</effectiveDate>\n"
				+" <asOfDate>"+streffectiveDate+"</asOfDate>\n"
				+" <returnKeyWords>true</returnKeyWords>\n"
				+"<Filter>\n"
				+" <!--Optional:-->\n"
				+" <lob>"+strLOB+"</lob>\n"
				+" <!--Optional:-->\n"
				+" <returnBenefits>\""+returnBenefits+"\"</returnBenefits>\n"
				+" </Filter>\n"
				+"</ws:getContractDetail>\n"
				+"</soapenv:Body>\n"
				+"</soapenv:Envelope>"	;

		  return xmlInput;
	}
   
   public String getResponseWithPlanOptBenefitOptBenefits(String streffectiveDate, String strContractCode)
	{
		String xmlInput="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.service.groupconfigurator.core.health.fja.com\">"
				+"<soapenv:Header/>\n"
				+"<soapenv:Body>\n"
				+"<ws:getContractDetail>\n"
				+"<correlationId>?</correlationId>\n"
				+"<userId>?</userId>\n"
				+"<vendorId>?</vendorId>\n"
				+"<appName>?</appName>\n"
				+"<appVersion>?</appVersion>\n"
				+"<timeStamp>?</timeStamp>\n"
				+"<visibilityAttr>?</visibilityAttr>\n"
				+"<functionalDomain>SBC</functionalDomain>\n"
				+"<contractCode>"+strContractCode+"</contractCode>\n"
				+"<effectiveDate>"+streffectiveDate+"</effectiveDate>\n"
				+"<asOfDate>"+streffectiveDate+"</asOfDate>\n"
				+"<returnKeyWords>true</returnKeyWords>\n"
				+"</ws:getContractDetail>\n"
				+"</soapenv:Body>\n"
				+"</soapenv:Envelope>";
		return xmlInput;
	}

	public String getResponseWithBenefitDetails(String streffectiveDate, String strLOB,String strContractCode,String returnPlanOptions,String returnBenefitOptions,String returnBenefits)
	{
		String xmlInput="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.service.groupconfigurator.core.health.fja.com\">"
				+"<soapenv:Header/>\n"
		        +"<soapenv:Body>\n"
				+"<ws:getContractDetail>\n"
				+"<correlationId>?</correlationId>\n"
				+"<userId>?</userId>\n"
				+"<vendorId>?</vendorId>\n"
				+"<appName>?</appName>\n"
				+"<appVersion>?</appVersion>\n"
				+"<timeStamp>?</timeStamp>\n"
				+"<visibilityAttr>?</visibilityAttr>\n"
				+"<functionalDomain>SBC</functionalDomain>\n"
				+"<contractCode>"+strContractCode+"</contractCode>\n"
				+"<effectiveDate>"+streffectiveDate+"</effectiveDate>\n"
				+"<asOfDate>"+streffectiveDate+"</asOfDate>\n"
				+"<returnKeyWords>true</returnKeyWords>\n"
				+"<Filter>\n"
				+"<!--Optional:-->\n"
				+"<lob>"+strLOB+"</lob>\n"
				+"<!--Optional:-->\n"
				+"<returnPlanOptions>"+returnPlanOptions+"</returnPlanOptions>\n" 
				+"<returnBenefitOptions>"+returnBenefitOptions+"</returnBenefitOptions>\n" 
				+"<returnBenefits>"+returnBenefits+"</returnBenefits>\n"
				+"</Filter>\n"
				+"</ws:getContractDetail>\n"
				+"</soapenv:Body>\n"
				+"</soapenv:Envelope>";
	
		return xmlInput;
	}
}
