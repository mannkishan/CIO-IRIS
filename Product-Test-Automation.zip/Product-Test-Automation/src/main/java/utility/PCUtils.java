package utility;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import com.anthem.selenium.utility.ExtentReportsUtility;

import page.planConfigurator.HomePage;
import page.planConfigurator.ImpactReviewPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;


public class PCUtils extends CoreSuperHelper{
	
	
	private static PCUtils thisTestObj;	
	public synchronized static PCUtils get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), PCUtils.class);
		return thisTestObj;
	}
	/**
	 * @author : 
	 * This method is used to execute the bulk update from the Impact review tab
	 * @param CreatedBy: ID of the user initiated the bulk update process 
	 * @param ReasonCode: Reason code selected in the Bulk Update tab
	 */
	public static void execute_ImpactReview(String CreatedBy,String ReasonCode)
	{
		boolean found = false;
		try{
			List<WebElement> impact_Review_resultstable=getWebDriver().findElements(By.xpath("//*[@id='DataTables_Table_3']/tbody/tr"));
			for(int k=1; k<impact_Review_resultstable.size();k++)
			{
				

				String userId=getWebDriver().findElement(By.xpath("//*[@id='DataTables_Table_3']/tbody/tr["+k+"]/td[2]")).getText();
				String resoncode=getWebDriver().findElement(By.xpath("//*[@id='DataTables_Table_3']/tbody/tr["+k+"]/td[5]")).getText();
				if(userId.equalsIgnoreCase(CreatedBy)                         
						&& resoncode.equalsIgnoreCase(ReasonCode))
				{  
					found = true;
					getWebDriver().findElement(By.xpath(".//*[@id='DataTables_Table_3']/tbody/tr["+k+"]/td[9]/div/button[4]")).click();
					Thread.sleep(10000);                                          
					ExtentReportsUtility.log(PASS,"Clicked Run Link in Impact Review table",
							"Verify BulkRepublish plan request is moved to pending review state & check whether Run link displays");
					break; 
				}
			} 
			if(!found)
			{
				ExtentReportsUtility.log(FAIL,"Verify Bulk plan request is moved to Completed state & able to download Update Report",
						"Not able to identify the given values in the table"+CreatedBy+ ", "+ ReasonCode);

			}

		}
		catch(Exception e){
			e.getLocalizedMessage();                               
		}
	}

	/**
	 * @author: AF12450
	 * This method is used to download the ImpactReview report in the ImpactReview tab
	 * @param id: id of the bulk update transaction
	 */
	public static String downloadImpactReviewReport()
	{
		boolean found = false;

		try{
			waitForPageLoad();
			WebTable impactReviewTable = new WebTable(getWebDriver().findElement(By.xpath("//div[@class='bulk-entries-container']/div/div[2]/div/table")), "Impact Review results");
			String userName=seGetText(HomePage.get().userName).toString().trim();
			int rowNum = impactReviewTable.getRowWithCellTextInColumn(1, 2, userName);
				
			if(rowNum>0)
			{
					ImpactReviewPage.get().seWaitForBulkRepubishImactStatus("Pending Review");
					impactReviewTable = new WebTable(getWebDriver().findElement(By.xpath("//div[@class='bulk-entries-container']/div/div[2]/div/table")), "Impact Review results");
					String completionStatus  =impactReviewTable.getCell(rowNum, 7).getText().toString();
					System.out.println(completionStatus);
					if(completionStatus.equalsIgnoreCase("Pending Review"))
					{
						found = true;
						getWebDriver().findElement(By.xpath("//div[@class='bulk-entries-container']/div/div[2]/div/table/tbody/tr["+rowNum+"]/td[8]/div")).click();
						ExtentReportsUtility.log(PASS,"The request is moved to Pending Review & downloaded the ImpactReview report",
								"Verify plan request is moved to Pending Review & able to download ImpactReview Report");
						Thread.sleep(5000);
						return impactReviewTable.getCell(rowNum, 1).getText().toString().trim();
					}
			}

			if(!found)
			{
				ExtentReportsUtility.log(FAIL,"The request is moved to Pending Review & downloaded the ImpactReview report",
						"Not able to find the user in the Impact Results table");
				return "";
				
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return "";
	}
	
	/**
	 * @author: AF12450
	 * This method is used to download the update report in the Mass bulk update history tab
	 * @param id: id of the bulk update transaction
	 */
	public static void downloadUpdateReport_History()
	{
		boolean found = false;

		try{
			List<WebElement> rows_PlanResultTable_History = getWebDriver().findElements(By.xpath("//div[@class='bulk-entries-container']/div/div[2]/div/table/tbody/tr")); 
			String userName=seGetText(HomePage.get().userName).toString().trim();
			for(int k=1; k<rows_PlanResultTable_History.size();k++)
			{
				String actualName  =getWebDriver().findElement(By.xpath("//div[@class='bulk-entries-container']/div/div[2]/div/table/tbody/tr["+k+"]/td[1]")).getText().toString().trim();			
				if(actualName.equalsIgnoreCase(userName))				 
				{
					String completionStatus  =getWebDriver().findElement(By.xpath("//div[@class='bulk-entries-container']/div/div[2]/div/table/tbody/tr["+k+"]/td[7]")).getText().toString().trim();
					int counter = 0;
					while(!completionStatus.equalsIgnoreCase("Completed"))
					{
						counter++;
					   getWebDriver().navigate().refresh();
						Thread.sleep(2);

						if(counter==120)
						{
							break;
						}
					}

					completionStatus  =getWebDriver().findElement(By.xpath("//div[@class='bulk-entries-container']/div/div[2]/div/table/tbody/tr["+k+"]/td[7]")).getText().toString().trim();

					if(completionStatus.equalsIgnoreCase("Completed"))
					{
						found = true;
						getWebDriver().findElement(By.xpath("//div[@class='bulk-entries-container']/div/div[2]/div/table/tbody/tr["+k+"]/td[7]")).click();
						ExtentReportsUtility.log(PASS,"Group Bulk Request is moved to Completed State and downloaded the update report",
								"Verify Bulk plan request is moved to Completed state & able to download Update Report");
					}
					break;


				}
			} 

			if(!found)
			{
				ExtentReportsUtility.log(FAIL,"Verify Bulk plan request is moved to Completed state & able to download Update Report",
						"Not able to identify the given values in the table for id ");
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static String  getdate()
	{
		String dateModified=null;
	try{	
		SimpleDateFormat df =new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		
		dateModified = df.format(date);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		log(FAIL,"Date is not present","Date is not present");
	}
		return dateModified;
	}
	
	
	/**
	 * The below is to edit all the required copay values in Spider application to validate Admin Method Copay value in XML
	 * @throws Exception
	 * strPlanOptionTab: Data sheet should have value "OptionsTab";
	 * strBenefitName: Data sheet should have value "BenefitName";
	 * strAccumName: Data sheet should have value "AccumName";
     * strCopayCriteria: Data sheet should have value "BasisPayment";
	 * strCopayMaxValue: Data sheet should have value "CopayMaxValue";
	 */
	public void updateCopayAccumDetails() throws Exception
	{
		String strPlanOptionTab = getCellValue("OptionsTab");
		String strBenefitName = getCellValue("BenefitName");
		String	strAccumName = getCellValue("AccumName");
		String strCopayCriteria = getCellValue("BasisPayment");
		String strCopayMaxValue = getCellValue("CopayMaxValue");
	    int intMaxWaitTime = 360;
		
		PlanOptionsPage.get();
		PlanOptionsPage.clickTab(strPlanOptionTab,strBenefitName, intMaxWaitTime);
		switch(strCopayCriteria)
		{
		case "Per Year":
		{
			log(INFO, "Validate Copay Per Year","Edit Copay Per Year value");
			seClick(PlanOptionsPage.get().clickPlanCopayMaxPerYear(strAccumName), "CopayMaxvalue PerYear");
			waitForPageLoad(100);
			seSetText(PlanOptionsPage.get().enterPlanCopayMaxPerYear(strAccumName), strCopayMaxValue, "Enter requiredCopyMaxValue as "+ strCopayMaxValue);
			seClick(PlanOptionsPage.get().selectPlanCopayMaxValue(strCopayMaxValue), "CopayMaxValue");
			waitForPageLoad(100);
			seVerifyFieldValue(PlanOptionsPage.get().clickPlanCopayMaxPerYear(strAccumName), strCopayMaxValue, "Verify Copay value for Per Year entered", true);
			seVerifyFieldValue(PlanOptionsPage.get().planCopayBasisPaymentPerYear(strAccumName), "Per Year", "BasisCode",true);
			break;
		}
		case "Per Visit":
		{
			log(INFO, "Validate Copay Per Visit","Edit Copay Per Visit value");
			seClick(PlanOptionsPage.get().clickPlanCopayAmountPerVisit(getCellValue("AccumName")), "CopayMaxvalue PerVisit");
			waitForPageLoad(100);
			seSetText(PlanOptionsPage.get().enterPlanCopayAmountPerVisit(getCellValue("AccumName")), getCellValue("CopayMaxValue"), "Enter requiredCopyMaxValue as "+ getCellValue("CopayMaxValue"));
			seClick(PlanOptionsPage.get().selectPlanCopayMaxValue(getCellValue("CopayMaxValue")), "CopayMaxValue");
			waitForPageLoad(100);
			seVerifyFieldValue(PlanOptionsPage.get().clickPlanCopayAmountPerVisit(strAccumName), strCopayMaxValue, "Verify Copay value for Per Visit entered",true);
			seVerifyFieldValue(PlanOptionsPage.get().planCopayBasisPaymentPerVisit(getCellValue("AccumName")), "Per Visit", "BasisCode",true);
			break;
		}
		case "Per Admission":
		{
			log(INFO, "Validate Copay Per Admission","Edit Copay Per Admission value");
			seClick(PlanOptionsPage.get().clickPlanCopayAmountPerAdmission(getCellValue("AccumName")), "CopayMaxvalue PerAdmission");
			waitForPageLoad(100);
			seSetText(PlanOptionsPage.get().enterPlanCopayAmountPerAdmission(getCellValue("AccumName")), getCellValue("CopayMaxValue"), "Enter requiredCopyMaxValue as "+ getCellValue("CopayMaxValue"));
			seClick(PlanOptionsPage.get().selectPlanCopayMaxValue(getCellValue("CopayMaxValue")), "CopayMaxValue");
			waitForPageLoad(100);
			seVerifyFieldValue(PlanOptionsPage.get().clickPlanCopayAmountPerAdmission(strAccumName), strCopayMaxValue, "Verify Copay value for Per Admission entered",true);
			seVerifyFieldValue(PlanOptionsPage.get().planCopayBasisPaymentPerAdmission(getCellValue("AccumName")), "Per Admission", "BasisCode",true);
			break;
		}
		case "Per Trip":
		{
			log(INFO, "Validate Copay Per Trip","Edit Copay Per Trip value");
			seClick(PlanOptionsPage.get().clickPlanCopayAmountPerTrip(getCellValue("AccumName")), "CopayMaxvalue PerTrip");
			waitForPageLoad(100);
			seSetText(PlanOptionsPage.get().enterPlanCopayAmountPerTrip(getCellValue("AccumName")), getCellValue("CopayMaxValue"), "Enter requiredCopyMaxValue as "+ getCellValue("CopayMaxValue"));
			seClick(PlanOptionsPage.get().selectPlanCopayMaxValue(getCellValue("CopayMaxValue")), "CopayMaxValue");
			waitForPageLoad(100);
			seVerifyFieldValue(PlanOptionsPage.get().clickPlanCopayAmountPerTrip(strAccumName), strCopayMaxValue, "Verify Copay value for Per Trip entered",true);
			seVerifyFieldValue(PlanOptionsPage.get().planCopayBasisPaymentPerTrip(getCellValue("AccumName")), "Per Trip", "BasisCode",true);
			break;
		}
		case "Per Pregnancy":
		{
			log(INFO, "Validate Copay Per Pregnancy","Edit Copay Per Pregnancy value");
			seClick(PlanOptionsPage.get().clickPlanCopayAmountPerPregnancy(getCellValue("AccumName")), "CopayMaxvalue PerPregnancy");
			waitForPageLoad(100);
			seSetText(PlanOptionsPage.get().enterPlanCopayAmountPerPregnancy(getCellValue("AccumName")), getCellValue("CopayMaxValue"), "Enter requiredCopyMaxValue as "+ getCellValue("CopayMaxValue"));
			seClick(PlanOptionsPage.get().selectPlanCopayMaxValue(getCellValue("CopayMaxValue")), "CopayMaxValue");
			waitForPageLoad(100);
			seVerifyFieldValue(PlanOptionsPage.get().clickPlanCopayAmountPerPregnancy(strAccumName), strCopayMaxValue, "Verify Copay value for Per Pregnancy entered",true);
			seVerifyFieldValue(PlanOptionsPage.get().planCopayBasisPaymentPerPregnancy(getCellValue("AccumName")), "Per Pregnancy", "BasisCode",true);
			break;
		}
		case "Per Day":
		{
			log(INFO, "Validate Copay Per Day","Edit Copay Per Day value");
			seClick(PlanOptionsPage.get().clickPlanCopayAmountPerDay(getCellValue("AccumName")), "CopayMaxvalue PerDay");
			waitForPageLoad(100);
			seSetText(PlanOptionsPage.get().enterPlanCopayAmountPerDay(getCellValue("AccumName")), getCellValue("CopayMaxValue"), "Enter requiredCopyMaxValue as "+ getCellValue("CopayMaxValue"));
			seClick(PlanOptionsPage.get().selectPlanCopayMaxValue(getCellValue("CopayMaxValue")), "CopayMaxValue");
			waitForPageLoad(100);
			seVerifyFieldValue(PlanOptionsPage.get().clickPlanCopayAmountPerDay(strAccumName), strCopayMaxValue, "Verify Copay value for Per Day entered",true);
			seVerifyFieldValue(PlanOptionsPage.get().planCopayBasisPaymentPerDay(getCellValue("AccumName")), "Per Day", "BasisCode",true);
			break;
		}
		case "No Member Copay":
		{
			log(INFO, "Validate when no Member Copayr","No member copay validation");
			if(!(PlanOptionsPage.get().checkboxPaidAsPlanLevel((getCellValue("OptionsTabValue")), getCellValue("AccumGroupName")).isSelected()))
			{
				seClick(true,PlanOptionsPage.get().checkboxPaidAsPlanLevel((getCellValue("OptionsTabValue")), getCellValue("AccumGroupName")), "Paid as Plan Level check box");
				waitForPageLoad(400);
			}
			break;
		}
		case "Zero Member Copay":
		{
			log(INFO, "Validate Zero Member Copay","Edit Copay value as Zero");
			seClick(PlanOptionsPage.get().clickPlanCopayAmountPerVisit(getCellValue("AccumName")), "CopayMaxvalue");
			waitForPageLoad(100);
			seSetText(PlanOptionsPage.get().enterPlanCopayAmountPerVisit(getCellValue("AccumName")), getCellValue("CopayMaxValue"), "Enter requiredCopyMaxValue as "+ getCellValue("CopayMaxValue"));
			seClick(PlanOptionsPage.get().selectPlanCopayMaxValue(getCellValue("CopayMaxValue")), "CopayMaxValue");
			seVerifyFieldValue(PlanOptionsPage.get().clickPlanCopayAmountPerVisit(strAccumName), strCopayMaxValue, "Verify Copay value for Zero Member Copay",true);
			break;
		}
		default :
			break;
		}
	}
	
	/**
	 *  The below is to edit all the required Copay Max values in Spider application to validate Admin Method Copay limitation value in XML
	 * @param strOptionsTab : Options tab to be clicked
	 * @param strAccumulatorType : Accumulator to be validated
	 * @param strAccumName : Accumulator name that to be changed
	 * @param strAccumMaxValue : Accumulator value to be entered
	 * @param strAccumBenefitValue : Basis Code that need to be entered
	 * @param intMaxWaitTime
	 * @throws Exception
	 */
	public  void updateCopayMaxAccumDetails(String strOptionsTab,String strAccumulatorType,String strAccumName,String strAccumMaxValue,String strAccumBenefitValue,int intMaxWaitTime) throws Exception
	{
		try{
			PlanOptionsPage.clickTab(strOptionsTab, strAccumulatorType, intMaxWaitTime);
			waitForPageLoad(5, intMaxWaitTime);
			seClick(PlanOptionsPage.get().CopayMax(strAccumName),"Accumulator Name");
			waitForPageLoad(intMaxWaitTime);
			seSetText(PlanOptionsPage.get().CopayMaxValue(strAccumName),strAccumMaxValue,"Accumulator Max Value");
			waitForPageLoad(intMaxWaitTime);
			seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
			waitForPageLoad(intMaxWaitTime);
			String benefit=seGetElementValue(PlanOptionsPage.get().CopayMaxBenefitPeriod(strAccumName)).toString().trim();			
			if(!benefit.equalsIgnoreCase(strAccumBenefitValue))
			{
			seClick(PlanOptionsPage.get().CopayMaxBenefitPeriod(strAccumName),"Accumulator Name");
			waitForPageLoad(intMaxWaitTime);
			seSetText(PlanOptionsPage.get().CopayMaxBenefitPeriodValue(strAccumName),strAccumBenefitValue,"Accumulator Max Value");
			waitForPageLoad(intMaxWaitTime);
			seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
			waitForPageLoad(intMaxWaitTime);
			}
			seVerifyFieldValue(PlanOptionsPage.get().CopayMax(strAccumName), strAccumMaxValue, "Accumulator Value",true);
			seVerifyFieldValue(PlanOptionsPage.get().CopayMaxBenefitPeriod(strAccumName), strAccumBenefitValue, "Basis Code",true);
		}
		catch(Exception e)
		{
			throw e;
		}
	}
	
	public void updateCopayOOPMax(String strOptionsTab,String strAccumulatorType,int intMaxWaitTime,String strAccum,String strCopayAppliesToOOP,String strCopayValue)throws Exception
	{
		try
		{
			PlanOptionsPage.clickTab(strOptionsTab, strAccumulatorType, intMaxWaitTime);
			if(strCopayAppliesToOOP.equalsIgnoreCase("Yes"))
			{
				seClick(PlanOptionsPage.get().Copay(strAccum),"Accumulator Limitation");
				waitForPageLoad(intMaxWaitTime);
				seSetText(PlanOptionsPage.get().CopayValue(strAccum),strCopayValue,"Limitation value");
				waitForPageLoad(intMaxWaitTime);
				seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
				waitForPageLoad(intMaxWaitTime);
				if(!PlanOptionsPage.get().OOP(strAccum).isSelected())
					seClick(PlanOptionsPage.get().OOP(strAccum),"OOP Check box");	
				waitForPageLoad(intMaxWaitTime);
			}
			else
			{
				seClick(PlanOptionsPage.get().Copay(strAccum),"Accumulator Limitation");
				waitForPageLoad(intMaxWaitTime);
				seSetText(PlanOptionsPage.get().CopayValue(strAccum),strCopayValue,"Limitation value");
				waitForPageLoad(intMaxWaitTime);
				seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
				waitForPageLoad(intMaxWaitTime);
				if(PlanOptionsPage.get().OOP(strAccum).isSelected())
					seClick(PlanOptionsPage.get().OOP(strAccum),"OOP Check box");
				waitForPageLoad(intMaxWaitTime);
			}

		}
		catch(Exception e)
		{
			throw e;
		}
	}
	
	public void writeLogForAdminXMLDedValidations(String adminMethodType, String expadminMethodValue,String actadminMethodValue, String paymentLevel)
	{
		if((adminMethodType.equalsIgnoreCase("Individual Deductible"))&&(expadminMethodValue.equalsIgnoreCase(actadminMethodValue)))
		{
			log(PASS, "Validate admin Method Individual Deductible value", "Individual Deductible value is displaying correctly for "+paymentLevel+" as "+actadminMethodValue, true);
		}
		else{
			log(FAIL, "Validate admin Method Individual Deductible value", "Individual Deductible value is not displaying correctly for "+paymentLevel, true);
		}
	}
	
	/**
	 * @throws Exception
	 */
	public void updateFamilyDeductibleAccumDetails() throws Exception{

		try{
			
			String strInNetworkFamilyDeductible=getCellValue("In Network Family Deductible");
			String strOutNetworkFamilyDeductible=getCellValue("Out of Network Family Deductible");
			String strAccumBasisDeductible=getCellValue("Accumulation Basis Deductible");
			String strCrossAccumRule=getCellValue("Deductible Cross Accumulation Rule");
			String strDedValue= "";
			String strPlanOptionTab = getCellValue("OptionsTab");
			String strBenefitName = getCellValue("OptionsTabValue");
			String strPlanOptionTab2 = getCellValue("OptionsTab2");
			String strBenefitName2 = getCellValue("OptionsTabValue2");
			String strAccumName = getCellValue("AccumName");
			int intMaxWaitTime = 450;
			
			//waitForPageLoad(20, intMaxWaitTime);
			waitForPageLoad(20, intMaxWaitTime);
			PlanOptionsPage.clickTab(strPlanOptionTab,strBenefitName, intMaxWaitTime);

			switch(getCellValue("PaymentLevel"))
			{
			case ("CPPO"):
			case("PREF"):
			{
				seClick(PlanLevelBenefitsPage.get().clickInFamDeductible, "In Network Family Deductible");
				waitForPageLoad(100);
				seSetText(PlanLevelBenefitsPage.get().enterInFamDeductible, strInNetworkFamilyDeductible, "Enter InNetwork FamillyDeductible as "+strInNetworkFamilyDeductible);
				seClick(PlanLevelBenefitsPage.get().selectDeductible, "Select highlighted Deductible");
				waitForPageLoad(100);
				seClick(PlanLevelBenefitsPage.get().clickOutFamDeductible, "Out of Network Family Deductible");
				waitForPageLoad(100);
				seSetText(PlanLevelBenefitsPage.get().enterOutFamDeductible, strOutNetworkFamilyDeductible, "Enter InNetwork FamillyDeductible as "+ strOutNetworkFamilyDeductible);
				seClick(PlanLevelBenefitsPage.get().selectDeductible, "Select highlighted Deductible");
				waitForPageLoad(100);
				seClick(PlanLevelBenefitsPage.get().clickAccumulationBasisDeductible, "Accumulation Basis Deductible");
				waitForPageLoad(100);
				seClick(PlanLevelBenefitsPage.get().enterAccumulationBasisDeductible(strAccumBasisDeductible), "Select Accumulation Basis Deductible as "+strAccumBasisDeductible);
				waitForPageLoad(50);
				seClick(PlanLevelBenefitsPage.get().clickDeductibleCrossAccumRule, "Deductible Cross Accumulation Rule");
				waitForPageLoad(100);
				seClick(true,PlanLevelBenefitsPage.get().enterDeductibleCrossAccumRule(strCrossAccumRule), "Select Deductible Cross Accumulation Rule as "+strCrossAccumRule);
				waitForPageLoad(100);
				((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",PlanOptionsPage.get().optionsTab("Plan Setup"));
				waitForPageLoad(400);
				seClick(PlanOptionsPage.get().optionsTabValues("Plan Tier Setup"), "Select Plan Tier Setup");
				waitForPageLoad(400);
				seClick(PlanSetupPage.get().innTier1Network, "In Network Tier 1 Network");
				waitForPageLoad(100);
				seClick(PlanSetupPage.get().innTier1NetworkCovered, "Select In Network Tier 1 Network as C");
				waitForPageLoad(100);
				break;


			}
			case ("NPPO"):
			{
				seClick(PlanLevelBenefitsPage.get().clickInFamDeductible, "In Network Family Deductible");
				waitForPageLoad(100);
				seSetText(PlanLevelBenefitsPage.get().enterInFamDeductible, strInNetworkFamilyDeductible, "Enter InNetwork FamillyDeductible as "+ strInNetworkFamilyDeductible);
				seClick(PlanLevelBenefitsPage.get().selectDeductible, "Select highlighted Deductible");
				waitForPageLoad(100);
				seClick(PlanLevelBenefitsPage.get().clickOutFamDeductible, "Out of Network Family Deductible");
				waitForPageLoad(100);
				seSetText(PlanLevelBenefitsPage.get().enterOutFamDeductible, strOutNetworkFamilyDeductible, "Enter InNetwork FamillyDeductible as "+ strOutNetworkFamilyDeductible);
				seClick(PlanLevelBenefitsPage.get().selectDeductible, "Select highlighted Deductible");
				waitForPageLoad(100);
				seClick(PlanLevelBenefitsPage.get().clickAccumulationBasisDeductible, "Accumulation Basis Deductible");
				waitForPageLoad(100);
				seClick(PlanLevelBenefitsPage.get().enterAccumulationBasisDeductible(strAccumBasisDeductible), "Select Accumulation Basis Deductible as "+strAccumBasisDeductible);
				waitForPageLoad(50);
				seClick(PlanLevelBenefitsPage.get().clickDeductibleCrossAccumRule, "Deductible Cross Accumulation Rule");
				waitForPageLoad(100);
				seClick(true,PlanLevelBenefitsPage.get().enterDeductibleCrossAccumRule(strCrossAccumRule), "Select Deductible Cross Accumulation Rule as "+strCrossAccumRule);
				waitForPageLoad(100);
				break;
			}

			case "CEPO":
			{
				seClick(PlanLevelBenefitsPage.get().clickInFamDeductible, "In Network Family Deductible");
				waitForPageLoad(100);
				seSetText(PlanLevelBenefitsPage.get().enterInFamDeductible, strInNetworkFamilyDeductible, "Enter InNetwork FamillyDeductible as "+strInNetworkFamilyDeductible);
				seClick(PlanLevelBenefitsPage.get().selectDeductible, "Select highlighted Deductible");
				waitForPageLoad(100);
				seClick(PlanLevelBenefitsPage.get().clickAccumulationBasisDeductible, "Accumulation Basis Deductible");
				waitForPageLoad(100);
				seClick(true,PlanLevelBenefitsPage.get().enterAccumulationBasisDeductible(strAccumBasisDeductible), "Select Accumulation Basis Deductible as "+strAccumBasisDeductible);
				waitForPageLoad(50);
				/*seClick(PlanLevelBenefitsPage.get().clickDeductibleCrossAccumRule, "Deductible Cross Accumulation Rule");
				waitForPageLoad(100);
				seClick(PlanLevelBenefitsPage.get().enterDeductibleCrossAccumRule(strCrossAccumRule), "Select Deductible Cross Accumulation Rule as "+strCrossAccumRule);
				waitForPageLoad(50);*/
				((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",PlanOptionsPage.get().optionsTab("Plan Setup"));
				waitForPageLoad(400);
				seClick(PlanOptionsPage.get().optionsTabValues("Plan Tier Setup"), " Select Plan Tier Setup");
				waitForPageLoad(400);
				seClick(PlanSetupPage.get().innTier1Network, "In Network Tier 1 Network");
				waitForPageLoad(100);
				seClick(PlanSetupPage.get().innTier1NetworkEPO, "Select In Network Tier 1 Network as Participating-EPO");
				waitForPageLoad(100);
				try
				{
					if(PlanSetupPage.get().outTier1Network.isDisplayed())
					{
						seClick(PlanSetupPage.get().outTier1Network, "Out Network Tier 1 Network");
						waitForPageLoad(100);
						seClick(PlanSetupPage.get().outTier1NetworkEPO(getCellValue("OutOfNetworkValue")), "Select Out Network Tier 1 Network as Remove from Plan");
						waitForPageLoad(100);
					}
				}
				catch(Exception e)
				{
					e.getMessage();
					log(INFO, "Select out f network in Plan Tier Setup", "Out of Network is not available for the created plan", true);
				}

				break;
			}

			case "cross accum":
			{
				seClick(PlanLevelBenefitsPage.get().clickInFamDeductible, "In Network Family Deductible");
				waitForPageLoad(100);
				seSetText(PlanLevelBenefitsPage.get().enterInFamDeductible, strInNetworkFamilyDeductible, "Enter InNetwork FamillyDeductible as "+ strInNetworkFamilyDeductible);
				seClick(PlanLevelBenefitsPage.get().selectDeductible, "Select highlighted Deductible");
				waitForPageLoad(100);
				seClick(PlanLevelBenefitsPage.get().clickOutFamDeductible, "Out of Network Family Deductible");
				waitForPageLoad(100);
				seSetText(PlanLevelBenefitsPage.get().enterOutFamDeductible, strOutNetworkFamilyDeductible, "Enter InNetwork FamillyDeductible as "+ strOutNetworkFamilyDeductible);
				seClick(PlanLevelBenefitsPage.get().selectDeductible, "Select highlighted Deductible");
				waitForPageLoad(100);
				seClick(PlanLevelBenefitsPage.get().clickAccumulationBasisDeductible, "Accumulation Basis Deductible");
				waitForPageLoad(100);
				seClick(PlanLevelBenefitsPage.get().enterAccumulationBasisDeductible(strAccumBasisDeductible), "Select Accumulation Basis Deductible as "+strAccumBasisDeductible);
				waitForPageLoad(50);
				seClick(PlanLevelBenefitsPage.get().clickDeductibleCrossAccumRule, "Deductible Cross Accumulation Rule");
				waitForPageLoad(100);
				seClick(true,PlanLevelBenefitsPage.get().enterDeductibleCrossAccumRule(strCrossAccumRule), "Select Deductible Cross Accumulation Rule as"+strCrossAccumRule);
				waitForPageLoad(100);
				break;	
			}

			default :
				break;
			}

			//Validate Deductible at plan level in Spider UI
			PlanOptionsPage.clickTab(strPlanOptionTab2,strBenefitName2, intMaxWaitTime);
			waitForPageLoad(100);
			boolean booPaidAtPlanLevel = (PlanOptionsPage.get().checkboxPaidAsPlanLevel(strBenefitName2,strAccumName)).isSelected();
			if(!booPaidAtPlanLevel)
			{
				strDedValue = seGetDropDownValue(PlanOptionsPage.get().applyDeductibleList(strAccumName));
			}
			if((strDedValue.equalsIgnoreCase("Yes"))||(booPaidAtPlanLevel))
			{
				log(PASS, "Validate Deductible applied to Plan", "Deductible is applied to required plan "+strBenefitName2, true);
			}
			else{
				log(FAIL, "Validate Deductible applied to Plan", "Deductible is not applied to required plan "+strBenefitName2, true);
			}
		}
		catch(Exception e)
		{
           throw e;
		}
	}
	
	public static void validateMedicareAdminMethodID(String strAdminMethod,String strParticiPatingadminMethodID,String strNonParticipatingID, String strXMLFilePath ) throws Exception
	{
		try
		{
			File file = new File(strXMLFilePath);
			System.out.println(file.exists());
			SAXReader reader = new SAXReader();
			org.dom4j.Document document = reader.read(file);
			List<Node> nodes = document.selectNodes("//adminMethodList/AdminMethodData/adminMethodType[@text='"+strAdminMethod+"']");
			if(nodes.size()>0)
			{
			for (Node node : nodes) {
				node = node.getParent();
				String adminMethodIDText = ((Element) (node.selectSingleNode("adminMethodIdType"))).attributeValue("text");
				
				if(!(adminMethodIDText.equalsIgnoreCase(strParticiPatingadminMethodID)))
				{
					String strSituationType = "";
					String strBenefit = "";
					String situationGroup = "";
					while(!node.getName().equalsIgnoreCase("benefitTypeCoverage"))
					{
						node = node.getParent();
						if(node.getName().equalsIgnoreCase("calculationSituation"))
						{
							strSituationType = ((Element) (node.selectSingleNode("situationType"))).attributeValue("text");
						}
						else if (node.getName().equalsIgnoreCase("benefitTypeCoverage"))
						{
						strBenefit = ((Element) (node.selectSingleNode("benefitLevel"))).attributeValue("text");
						}
						else if (node.getName().equalsIgnoreCase("situationGroup"))
						{
							situationGroup = ((Element)node).attributeValue("text");
						
						}
						
					}
					if(!(situationGroup.equalsIgnoreCase("Non-Participating") && (adminMethodIDText.equalsIgnoreCase(strNonParticipatingID))))
					{
					RESULT_STATUS = false;
					log(FAIL, "Validate admin method ID for "+strAdminMethod,"Admin method value is not as expected \""+strParticiPatingadminMethodID+"\" for \"situation type\" :"
							+ "\""+strSituationType+"\" for \"benefit\" : \""+strBenefit+"\" with an actual  value of \""+adminMethodIDText+"\"" );
					}
				}


			}
			if(RESULT_STATUS)
			{
				log(PASS, "Validate admin method ID for "+strAdminMethod,"All the benefits have the admin method ID as expected" );
			}
			}
			else {
				log(FAIL, "Validate admin method ID for "+strAdminMethod,"Not able to find the admin method in the XML" );
			}
			
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	}
	
	
	
	
	
}
