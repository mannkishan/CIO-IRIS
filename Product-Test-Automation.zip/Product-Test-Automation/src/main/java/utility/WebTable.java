package utility;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.SuperHelper;
import com.anthem.selenium.logging.AnthemLogger;
/*
'Revision History
'#############################################################################
'@rev.On	@rev.No		@rev.By				  @rev.Comments
'8-August-2017	1			AF30637 Rajat Mishra	Reviewed. Uni tested for PACT										
'#############################################################################
*/

/**
 * Class to handle all table related methods. This class does not contains methods specific to header i.e., thead tag.<br>
 * Works only when there is a tag called tbody in the table. If tag name is different, changes need to be made to the class.
 * </p>
 * Note: For the user, row and column index start from 1.
 * </p>
 * Usage: WebTable wtClaimsResult = new WebTable(HomePage.get().claimsResultTable, "Claims result");
 * </p>
 * </p>
 * 
 * @author AF37512 Santosh Bukkashetti
 * @since 1-August-2017
 */
public class WebTable extends SuperHelper {

	protected WebElement tblTable;
	private WebElement tbdyTableBody;
	private String strTableName;
	protected AnthemLogger logger = AnthemLogger.getLogger(WebTable.class.getName());;

	/**
	 * Parameterized Constructor for WebTable
	 * </p>
	 * 
	 * @param argTable
	 *            WebElement of Table
	 * @param strName
	 *            Table name
	 * 
	 * @autor AF34794 Usharani Arunachalam
	 * @since 8-August-2017
	 */
	public WebTable(WebElement argTable, String strName) {
		try {
			tblTable = argTable;
			tbdyTableBody = tblTable.findElement(By.tagName("tbody"));
			strTableName = strName;
		} catch (Exception excException) {
			processExceptions("Exception while executing WebTable constructor", excException);
			throw excException;
		}
	}

	/**
	 * Method to update the RESULT_STATUS flag and update the logger
	 * </p>
	 * 
	 * @param strStep-
	 *            Step at which exception occurred
	 * @param excException
	 *            Exception occurred
	 * 
	 * @author AF34794 Usharani Arunachalam
	 * @since 27-July-2017
	 */
	protected void processExceptions(String strStep, Exception excException) {
		RESULT_STATUS = false;
		logger.error(strStep);
		excException.printStackTrace();
		log(ERROR, strStep, "Exception: " + excException.getLocalizedMessage(), true);

	}

	/**
	 * Method to get the Row count of a Table
	 * </p>
	 * 
	 * @return intRowsCount number of rows in the table
	 * @author AF34794 Usharani Arunachalam
	 * @since 3-August-2017
	 */
	public int getRowsCount() {

		try {
			List<WebElement> findRowPath = tbdyTableBody.findElements(By.tagName("tr"));
			int intRowsCount = findRowPath.size();
			return intRowsCount;
		} catch (Exception excException) {
			processExceptions("Exception occured while fetching row count of table " + strTableName, excException);
			throw excException;
		}
	}

	/**
	 * Method to get the Column count in first row of a Table
	 * </p>
	 * 
	 * @return intColCount number of column in first row
	 * @author AF34794 Usharani Arunachalam
	 * @since 3-August-2017
	 */
	public int getColumnCount() {

		try {
			List<WebElement> findRowPath = tbdyTableBody.findElements(By.tagName("tr"));
			List<WebElement> findColPath = findRowPath.get(0).findElements(By.tagName("td"));
			int intColCount = findColPath.size();
			return intColCount;
		} catch (Exception excException) {
			processExceptions("Exception occured while fetching column count of table", excException);
			throw excException;
		}

	}

	/**
	 * Method to get Column count of a particular Row in a Table
	 * </p>
	 * 
	 * @param intRowNumber
	 *            Row number starting from 1
	 * @return intColCount Column count in a Row having intRowNumber in Table
	 * @author AF34794 Usharani Arunachalam
	 * @since 1-August-2017
	 */
	public int getColumnCountOfARow(int intRowNumber) {

		try {
			List<WebElement> findRowPath = tbdyTableBody.findElements(By.tagName("tr"));

			List<WebElement> findColPath = findRowPath.get(intRowNumber - 1).findElements(By.tagName("td"));
			int intColCount = findColPath.size();
			return intColCount;

		} catch (Exception excException) {
			processExceptions("Exception occured while getting column count of a row", excException);
			throw excException;
		}

	}

	/**
	 * Method to get the cell text value in the given Row and column
	 * </p>
	 * 
	 * @param intRowNumber
	 *            Row number starting from 1 eg-1,2,etc
	 * @param intColumnNumber
	 *            Column number starting from 1 of Row having intRowNumber eg-1,2,etc
	 * @return strCellText-text value of the cell eg- WebTable wb = new
	 * @author AF34794 Usharani Arunachalam
	 * @since 1-August-2017
	 */
	public String getCellData(int intRowNumber, int intColumnNumber) {

		try {
			List<WebElement> findRowPath = tbdyTableBody.findElements(By.tagName("tr"));
			List<WebElement> findColumnPath = findRowPath.get(intRowNumber - 1).findElements(By.tagName("td"));
			String strCellText = findColumnPath.get(intColumnNumber - 1).getText();

			return strCellText;
		} catch (Exception excException) {
			processExceptions("Exception occured in getting cell text value of given Row and column", excException);
			throw excException;
		}

	}

	/**
	 * Method to get the Row number with a specific text
	 * </p>
	 * 
	 * @param strText
	 *            String data to search in the Table
	 * @return intRowNumber Row number of strText
	 * @author AF34794 Usharani Arunachalam
	 * @since 3-August-2017
	 */

	public int getRowWithCellText(String strText) {
		int intRowNumber = -1;
		boolean flag = false;
		try {
			List<WebElement> findRowPath = tbdyTableBody.findElements(By.tagName("tr"));
			int rowsCount = findRowPath.size();
			for (int row = 0; row < rowsCount; row++) {
				List<WebElement> findColumnPath = findRowPath.get(row).findElements(By.tagName("td"));
				int columnCount = findColumnPath.size();
				for (int column = 0; column < columnCount; column++) {
					String strCellText = findColumnPath.get(column).getText();
					if (strCellText.equals(strText)) {
						intRowNumber = row + 1;
						flag = true;
						break;
					}
				} // column loop ends
				if (flag == true)
					break;
				else
					continue;
			} // row loop ends

		} catch (Exception excException) {
			processExceptions("Exception occured while getting Row number with a specific text", excException);
			throw excException;
		}
		return intRowNumber;
	}

	/**
	 * Method to get all Row number with a specific text
	 * </p>
	 * 
	 * @param strText
	 *            String data to search in the Table
	 * @return intRowNumber All rows with text strText
	 * @author AF30637 Rajat Mishra
	 * @since 3-August-2017
	 */

	public int[] getAllRowsWithCellText(String strText) {
		HashMap<Integer, String> mapValue = new HashMap<Integer, String>();
		int[] intAllRowIndex = null;
		int index = 0;
		try {
			List<WebElement> findRowPath = tbdyTableBody.findElements(By.tagName("tr"));
			int rowsCount = findRowPath.size();
			for (int row = 0; row < rowsCount; row++) {
				List<WebElement> findColumnPath = findRowPath.get(row).findElements(By.tagName("td"));
				int columnCount = findColumnPath.size();
				for (int column = 0; column < columnCount; column++) {
					String strCellText = findColumnPath.get(column).getText();
					if (strCellText.equals(strText)) {
						mapValue.put((row + 1), getCellData(row + 1, 2));
						break;
					}
				} // column loop ends

			} // row loop ends
			intAllRowIndex = new int[mapValue.size()];
			for (Map.Entry<Integer, String> entry : mapValue.entrySet()) {
				do {
					intAllRowIndex[index] = entry.getKey();
					index++;
				} while (index > mapValue.size());
			}

		} catch (Exception excException) {
			processExceptions("Exception occured while getting Row number with a specific text", excException);
			throw excException;
		}
		return intAllRowIndex;
	}

	/**
	 * Method to get the Row number with a specific text present in specific column
	 * </p>
	 * 
	 * @param intStartFromThisRow
	 * 			Function will start looking for strText from this row. Saves some time.
	 * @param intColumnNumber
	 *            Column number starting from 1 in a Row eg-1,2,etc
	 * @param strText
	 *            String data to be searched in the a specific column of Table
	 * @return int Row number
	 * @author AF34794 Usharani Arunachalam
	 * @since 3-August-2017
	 */

	public int getRowWithCellTextInColumn(int intStartFromThisRow, int intColumnNumber, String strText) {
		int intRowNumber = -1;
		try {
			List<WebElement> findRowPath = tbdyTableBody.findElements(By.tagName("tr"));
			int rowsCount = findRowPath.size();
			for (int row = intStartFromThisRow - 1; row < rowsCount; row++) {
				List<WebElement> findColumnPath = findRowPath.get(row).findElements(By.tagName("td"));
				String strCellText = findColumnPath.get(intColumnNumber - 1).getText();
				if (strCellText.equals(strText)) {
					intRowNumber = row + 1;
					break;
				}
			}

		} catch (Exception excException) {
			processExceptions("Exception occured while getting Row number with a specific text present in specific column", excException);
			throw excException;
		}
		return intRowNumber;
	}

	/**
	 * Method to get the Row number with a specific text present in specific column
	 * </p>
	 * 
	 * @param intStartFromThisRow
	 * 			Function will start looking for strText from this row. Saves some time.
	 * @param intColumnNumber
	 *            Column number starting from 1 in a Row eg-1,2,etc
	 * @param strText-String
	 *            data to be searched in the a specific column of Table
	 * @return int Row number
	 * @author AF34794 Usharani Arunachalam
	 * @since 3-August-2017
	 */

	public int[] getAllRowsWithCellTextInColumn(int intStartFromThisRow, int intColumnNumber, String strText) {
		HashMap<Integer, String> mapValue = new HashMap<Integer, String>();
		int[] intAllRowIndex = null;
		int index = 0;
		try {
			List<WebElement> findRowPath = tbdyTableBody.findElements(By.tagName("tr"));
			int rowsCount = findRowPath.size();
			for (int row = intStartFromThisRow - 1; row < rowsCount; row++) {
				List<WebElement> findColumnPath = findRowPath.get(row).findElements(By.tagName("td"));
				String strCellText = findColumnPath.get(intColumnNumber - 1).getText();
	
				if (strCellText.equals(strText)) {
					
					mapValue.put(row, findColumnPath.get(intColumnNumber - 1).getText());
					continue;
				}
			}
			intAllRowIndex = new int[mapValue.size()];
			for (Map.Entry<Integer, String> entry : mapValue.entrySet()) {
				do {
					intAllRowIndex[index] = entry.getKey() + 1;
					index++;
				} while (index > mapValue.size());
			}
		} catch (Exception excException) {
			processExceptions("Exception occured while getting Row number with a specific text present in specific column", excException);
			throw excException;
		}

		return intAllRowIndex;
	}



	/**
	 * Method to get the list of WEbElement in a table using xpath with a specific row and column
	 * </p>
	 * 
	 * @param intColumnNumber-Column
	 *            number starting from 1 in a Row eg-1,2,etc
	 * @param intRowNumber-Row
	 *            number starting from 1 in Table eg-1,2,etc
	 * @param strItemsXPATH-xpath
	 *            of element inside table cell
	 * @return List<WebElement> - childItems with a specific row and column
	 * @author Santosh Bukkashetti
	 * @since 3-August-2017
	 */
	public List<WebElement> getChildItemsByXPath(int intRowNumber, int intColumnNumber, String strItemsXPATH) {
		List<WebElement> childItems = null;
		try {
			List<WebElement> findRowPath = tbdyTableBody.findElements(By.tagName("tr"));
			List<WebElement> findColumnPath = findRowPath.get(intRowNumber - 1).findElements(By.tagName("td"));
			WebElement tableCell = findColumnPath.get(intColumnNumber - 1);
			childItems = tableCell.findElements(By.xpath(strItemsXPATH));

		} catch (Exception excException) {
			processExceptions("Exception occured while capturing webelement in a cell using xpath", excException);
			throw excException;
		}
		return childItems;
	}

	/**
	 * Method to get the list of WEbElement in a table using TagName with a specific row and column
	 * </p>
	 * 
	 * @param intColumnNumber-Column
	 *            number starting from 1 in a Row eg-1,2,etc
	 * @param intRowNumber-Row
	 *            number starting from 1 in Table eg-1,2,etc
	 * @param strTagName-tagName
	 *            of element inside table cell
	 * @return List<WebElement> - childItems with a specific row and column
	 * @author Santosh Bukkashetti
	 * @since 3-August-2017
	 */
	public List<WebElement> getChildItemsByTagName(int intRowNumber, int intColumnNumber, String strTagName) {
		List<WebElement> childItems = null;
		try {
			List<WebElement> rwTableRows = tbdyTableBody.findElements(By.tagName("tr"));
			List<WebElement> tableCells = rwTableRows.get(intRowNumber - 1).findElements(By.tagName("td"));

			WebElement tableCell = tableCells.get(intColumnNumber - 1);
			childItems = tableCell.findElements(By.tagName(strTagName));
		} catch (Exception excException) {
			processExceptions("Exception occured while capturing webelement in a cell using TagName", excException);
			throw excException;
		}
		return childItems;

	}

	/**
	 * Method returns Table details
	 * </p>
	 * Please Note- This method may take time depending on the table size. More Data More Time eg-1,2,etc
	 * </p>
	 * 
	 * @return String[][] arrAllCellValues- contains Table details in row column format
	 * @author AF30637 Rajat Mishra
	 * @since 3-August-2017
	 * 
	 */

	public String[][] getAllCellsValues() {
		String[][] arrAllCellValues = null;
		int index = 0;
		try {
			List<WebElement> findRowPath = tbdyTableBody.findElements(By.tagName("tr"));

			arrAllCellValues = new String[findRowPath.size()][];
			for (int rowsCount = 0; rowsCount < findRowPath.size(); rowsCount++) {
				List<WebElement> findColPath = findRowPath.get(rowsCount).findElements(By.tagName("td"));
				arrAllCellValues[index] = new String[findColPath.size()];
				for (int columnCount = 0; columnCount < findColPath.size(); columnCount++) {
					arrAllCellValues[rowsCount][columnCount] = findColPath.get(columnCount).getText();

				}
				index++;
			}

		} catch (Exception excException) {
			processExceptions("Exception occured while getting all cell values of Table", excException);
			throw excException;
		}

		return arrAllCellValues;

	}

	/**
	 * Method returns column values from Table Rows with specific column number
	 * </p>
	 * 
	 * @param intColumnNumber Column number from which vlaues need to be fetched
	 * @return String[] arrAllCellValuesOfAColumn column values from all rows with specific column number
	 * @author Gautam Kumar
	 * @since 8-August-2017
	 */

	public String[] getAllCellValuesOfAColumn(int intColumnNumber) {
		String[] arrAllCellValuesOfAColumn = null;
		try {
			List<WebElement> findRowPath = tbdyTableBody.findElements(By.tagName("tr"));
			arrAllCellValuesOfAColumn = new String[findRowPath.size()];
			WebElement cell;
			for (int rowsCount = 0; rowsCount < findRowPath.size(); rowsCount++) {
				cell = findRowPath.get(rowsCount).findElement(By.xpath("./td[" + intColumnNumber + "]"));
				arrAllCellValuesOfAColumn[rowsCount] = cell.getText();

			}

		} catch (Exception excException) {
			processExceptions("Exception occured while fetching values from a specific column number", excException);
			throw excException;
		}
		return arrAllCellValuesOfAColumn;
	}

	/**
	 * Method returns cell in table with specific row and column
	 * </p>
	 * 
	 * @param intRowNumber
	 *            Row number starting from 1
	 * @param intColumnNumber
	 *            Column number starting from 1
	 * @return Table cell as WebElement
	 * @author AF30637 Rajat Mishra
	 * @since 8-August-2017
	 */

	public WebElement getCell(int intRowNumber, int intColumnNumber) {
		WebElement findCellPath = null;
		try {
			List<WebElement> findRowPath = tbdyTableBody.findElements(By.tagName("tr"));
			findCellPath = findRowPath.get(intRowNumber - 1).findElement(By.xpath("./td[" + intColumnNumber + "]"));
		}

		catch (Exception excException) {
			processExceptions("Exception occured while fetching a cell with specific row and column", excException);
			throw excException;

		}

		return findCellPath;
	}
}
