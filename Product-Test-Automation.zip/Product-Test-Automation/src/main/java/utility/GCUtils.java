package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.bcel.generic.Select;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.wellpoint.cssd.spider.DownloadFinalizeXML;

import page.groupConfigurator.BulkUpdatePage;
import page.groupConfigurator.ContractInformationPage;
import page.groupConfigurator.ContractSearchPage;
import page.groupConfigurator.ContractTransitionPage;
import page.groupConfigurator.HomePage;
import page.groupConfigurator.ImpactReviewPage;

public class GCUtils extends CoreSuperHelper{
	
	private static GCUtils thisIsTestObj;
	public  synchronized static GCUtils get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), GCUtils.class);
		return thisIsTestObj;
		}
	
	public  void requestAudit() throws Exception
	{
		seWaitForClickableWebElement(ContractInformationPage.get().requestAudit, 60);
		WebElement requestAudit =  getWebDriver().findElement(By.xpath("//span[@class='btn_reqAuditBtn']/a/span[2]"));
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",requestAudit);
		seWaitForPageLoad(60);
		org.openqa.selenium.support.ui.Select approveReason = new org.openqa.selenium.support.ui.Select(ContractTransitionPage.get().reasonCode);
		approveReason.selectByVisibleText("Other");
		ContractTransitionPage.get().clickOK("Click Request Audit");
		ContractInformationPage.get().validateContractStatus("Pending Audit");
	}
	
	
	
	public  void approveAudit() throws Exception
	{
		
		Thread.sleep(2000);
		//seWaitForClickableWebElement(ContractInformationPage.get().approveAudit, 60);
		Actions act = new Actions(getWebDriver());
		act.moveToElement(ContractInformationPage.get().approveAudit).build().perform();
		seClick(ContractInformationPage.get().approveAudit, "Click Approve Audit");
//		seWaitForPageLoad(60);
		Thread.sleep(2000);
		seWaitForClickableWebElement(ContractTransitionPage.get().approveAuditCode, 60);
	org.openqa.selenium.support.ui.Select approveReason = new org.openqa.selenium.support.ui.Select(ContractTransitionPage.get().approveAuditCode);
	approveReason.selectByVisibleText("Approved");
	
		
		ContractTransitionPage.get().clickOK("Click Approve Audit");
		seWaitForPageLoad(60);
		ContractInformationPage.get().validateContractStatus("Audit Approved");
	}
	
	public void moveToTest() throws Exception
	{
		seWaitForClickableWebElement(ContractInformationPage.get().moveToTest, 60);
		Actions act = new Actions(getWebDriver());
		act.moveToElement(ContractInformationPage.get().moveToTest).build().perform();
		seClick(ContractInformationPage.get().moveToTest, "Click Move To Test");
		seWaitForPageLoad(60);
		ContractTransitionPage.get().clickOK("Click Move to Test");
		ContractInformationPage.get().validateContractStatus("Sent to Test");
	}
	
	public void approveTest() throws Exception
	{
		seWaitForClickableWebElement(ContractInformationPage.get().approveTest, 60);
		Actions act = new Actions(getWebDriver());
		act.moveToElement(ContractInformationPage.get().approveTest).build().perform();
		seClick(ContractInformationPage.get().approveTest, "Click Approve Test");
		seWaitForPageLoad(60);
		seWaitForClickableWebElement(ContractTransitionPage.get().approveAuditCode, 60);
//		seWaitForWebElement(60, ExpectedConditions.elementToBeSelected(ContractTransitionPage.get().approveAuditCode));
		seWaitForClickableWebElement(ContractTransitionPage.get().approveAuditCode, 60);
		org.openqa.selenium.support.ui.Select approveReason = new org.openqa.selenium.support.ui.Select(ContractTransitionPage.get().approveAuditCode);
		approveReason.selectByVisibleText("Approved");
		ContractTransitionPage.get().clickOK("Click Approve Test");
		seWaitForPageLoad(60);
		ContractInformationPage.get().validateContractStatus("Test Passed");
	}
	
	public void finalizeContract()
	{
		seWaitForClickableWebElement(ContractInformationPage.get().finalize, 60);
		Actions act = new Actions(getWebDriver());
		act.moveToElement(ContractInformationPage.get().finalize).build().perform();
		seClick(ContractInformationPage.get().finalize, "Click Finalize");
		seWaitForPageLoad(60);
		seWaitForClickableWebElement(ContractTransitionPage.get().requestAudit, 60);
		seClick(ContractTransitionPage.get().requestAudit, "Click Finalize");
		seWaitForPageLoad(60);
		ContractInformationPage.get().validateContractStatus("Pending Finalization");
		
	}
	
	/**
	 * author: AF12450
	 * This method is used to fetch the bulk update ID for the bulk  update initiated
	 * @param testObject: locator of the table object.
	 * @param findCol: column number from which we need identify the reference value
	 * @param findValue: reference value to fetch the ID
	 * @param getCol: column number from which you want to fetch the ID
	 * @return: returns string which contains the ID, if the reference value is not present in the table, method will return the empty string
	 */
	public static String getBulkUpdateID(By testObject, int findCol,String findValue,int getCol)
	{

		try
		{
			WebElement table = getWebDriver().findElement(testObject);
			if(table != null)
			{
				int rowIndex = 0;

				List<WebElement> rows = table.findElements(By.xpath("//tbody/tr[*]"));
				for(int i=0; i< rows.size(); i++)
				{
					WebElement column = rows.get(i).findElement(By.xpath("//tbody/tr["+(i+2)+"]/td["+findCol+"]"));
					String columnValue = column.getText();
					System.out.println(columnValue);
					if(columnValue.equalsIgnoreCase(findValue))
					{
						rowIndex = i+2;
						break;
					}
				}
				if(rowIndex !=0)
				{
					WebElement requiredColumn = table.findElement(By.xpath("//tr["+rowIndex+"]/td["+getCol+"]"));
					String cellValue = requiredColumn.getText();	
					if(!cellValue.isEmpty())
					{
						return cellValue;
					}
				}

			}
		}
		catch(Exception e)
		{
			e.printStackTrace();

		}
		return "";
	}
	
	/**
	 * @author : AF17403
	 * This method is used to execute the bulk update from the Impact review tab
	 * @param CreatedBy: ID of the user initiated the bulk update process 
	 * @param ReasonCode: Reason code selected in the Bulk Update tab
	 */
	public static void run(String CreatedBy,String ReasonCode)
	{
		boolean found = false;
		try{
			List<WebElement> impact_Review_resultstable=getWebDriver().findElements(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr"));
			for(int k=2; k<impact_Review_resultstable.size();k++)
			{

				String userId=getWebDriver().findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[5]")).getText();
				String resoncode=getWebDriver().findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[6]")).getText();
				
				if(userId.equalsIgnoreCase(CreatedBy)                         
						&& resoncode.equalsIgnoreCase(ReasonCode))
				{  
					found = true;
					getWebDriver().findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[9]/a[1]/img")).click();
					waitForPageLoad(100);                                         
					log(PASS,"Clicked Run Link in Impact Review table",
							"Verify Bulk plan request is moved to pending review state & check whether Run link displays");
					break; 
				}
			} 
			if(!found)
			{
				log(FAIL,"Verify Bulk plan request is moved to Completed state & able to download Update Report",
						"Not able to identify the given values in the table"+CreatedBy+ ", "+ ReasonCode);

			}

		}
		catch(Exception e){
			e.getLocalizedMessage();                               
		}
	}
	
	/**
	 * @author: AF12450
	 * This method is used to download the update report in the GC bulk update history tab
	 * @param id: id of the bulk update transaction
	 */
	public static void downloadUpdateReport(String id)
	{
		boolean found = false;

		try{
			List<WebElement> rows_PlanResultTable_History = getWebDriver().findElements(By.xpath("//table[@class='af_table_content']/tbody/tr")); 
			for(int k=2; k<rows_PlanResultTable_History.size();k++)
			{
				String actualID  =getWebDriver().findElement(By.xpath("//table[@class='af_table_content']/tbody/tr["+k+"]/td[2]")).getText();			
				if(actualID.equalsIgnoreCase(id))				 
				{
					String completionStatus  =getWebDriver().findElement(By.xpath("//table[@class='af_table_content']/tbody/tr["+k+"]/td[7]")).getText();
					int counter = 0;
					while(!completionStatus.equalsIgnoreCase("Completed"))
					{
						counter++;
						seClick(ImpactReviewPage.get().impactReview,"Impact Review");
						waitForPageLoad(100);   

						seClick(ImpactReviewPage.get().historyTab,"Bulk Update History Tab");
						completionStatus  =getWebDriver().findElement(By.xpath("//table[@class='af_table_content']/tbody/tr["+k+"]/td[7]")).getText();
						if(counter==120)
						{
							break;
						}
					}

					completionStatus  =getWebDriver().findElement(By.xpath("//table[@class='af_table_content']/tbody/tr["+k+"]/td[7]")).getText();

					if(completionStatus.equalsIgnoreCase("Completed"))
					{
						found = true;
						getWebDriver().findElement(By.xpath("//table[@class='af_table_content']/tbody/tr["+k+"]/td[9]/div/span/a/img")).click();
						log(PASS,"Group Bulk Request is moved to Completed State and downloaded the update report",
								"Verify Bulk plan request is moved to Completed state & able to download Update Report");
					}
					break;


				}
			} 

			if(!found)
			{
				log(FAIL,"Verify Bulk plan request is moved to Completed state & able to download Update Report",
						"Not able to identify the given values in the table for id "+id);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	/**
	 * @author : AF17403
	 * This method is used to download the update report in the GC bulk update history tab
	 * @param CreatedBy: ID of the user initiated the bulk update process 
	 * @param ReasonCode: Reason code selected in the Bulk Update tab
	 */
	public static void downloadUpdateReport(String CreatedBy,String ReasonCode)
	{
		boolean found = false;

		try{
			List<WebElement> rows_PlanResultTable_History = getWebDriver().findElements(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr")); 
			for(int k=2; k<rows_PlanResultTable_History.size();k++)
			{
				String userId_ExecutedBy=getWebDriver().findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[5]")).getText();                     
				String reasonCode=getWebDriver().findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[6]")).getText();
				String plan_Status=getWebDriver().findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[7]")).getText();
				if(userId_ExecutedBy.equalsIgnoreCase(CreatedBy)                            
						&& reasonCode.equalsIgnoreCase(ReasonCode)
						&& plan_Status.equalsIgnoreCase("Completed"))
				{
					found = true;
					getWebDriver().findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[9]/div/span/a/img")).click();

					log(PASS,"Group Bulk Request is moved to Completed State and downloaded the update report",
							"Verify Bulk plan request is moved to Completed state & able to download Update Report");
					break;

				}
			} 

			if(!found)
			{

				log(FAIL,"Verify Bulk plan request is moved to Completed state & able to download Update Report",
						"Not able to identify the given values in the table"+CreatedBy+ ", "+ ReasonCode);

			}
		}
		catch(Exception e){
			e.getLocalizedMessage();
		}
	}

	/**
	 * @author AF12450 
	 * This method is used to validate the details in the bulk update report in the SPIDER GC application
	 * @param contractCode: Contract code that needs to be found in the update report
	 * @param updateColumn: Column that is updated in the bulk update process
	 * @param updateValue: Value that needs to be  validated in the report
	 * @param reportPath: path of the report
	 * @param ignoreFailure: value whether to ignore the previous step failure
	 */
	public static void validateContractUpdateReport(String contractCode , String updateColumn, String updateValue, String reportPath)
	{
		try
		{
			int expectedColumn = 0;
			boolean found = false;
			FileInputStream      FILE = new FileInputStream(new File(reportPath));
			XSSFWorkbook WB = new XSSFWorkbook(FILE);
			XSSFSheet  SHEET = WB.getSheet("Contracts Updated");

			int rowNum = SHEET.getLastRowNum();
			int cellNum = SHEET.getRow(0).getLastCellNum();

			for(int i =0; i<cellNum; i++)
			{
				String cellValue=SHEET.getRow(0).getCell(i).toString().trim();
				if(cellValue.equals(updateColumn)){
					expectedColumn = i;
					break;
				}
			}
			if(expectedColumn != 0)
			{

				for(int index =1; index<= rowNum; index++)
				{
					String cellValue = SHEET.getRow(index).getCell(1).toString().trim();
					if(cellValue.equalsIgnoreCase(contractCode))
					{
						found = true;
						cellValue = SHEET.getRow(index).getCell(expectedColumn).toString().trim();
						if(cellValue.equalsIgnoreCase(updateValue))
						{
							log(PASS, "Validate the Contract Bulk Update report", "Contracts are updated successfully");

						}
						else
						{

							log(FAIL, "Validate the Contract Bulk Update report", "Contracts are not updated");
						}
					}
				}
				if(!found)
				{
					log(FAIL, "Validate the Contract Bulk Update report",  "Not able to find the contract code: "+ contractCode+ "in the Contracts Updated sheet");

				}
			}
			else
			{
				log(FAIL, "Validate the Contract Bulk Update report", "Not able to find the column name: "+ updateColumn);
			}
			WB.close();
		}
		catch(Exception e)
		{
			log(FAIL, "Validate the Contract Bulk Update report", e.getLocalizedMessage());
		}
	}
	

	/**
	 * @author : AF17403
	 * This method is used to execute the bulk update from the Impact review tab
	 * @param CreatedBy: ID of the user initiated the bulk update process 
	 * @param ReasonCode: Reason code selected in the Bulk Update tab
	 * @param EffectiveDateExpected: Effective date used while fetching data
	 */
	public static void run(String EffectiveDateExpected,String UserIDExpected,String ReasonCodeExpected)
	{
		boolean found = false;
		try{
			List<WebElement> rows_PlanResultTable_History = getWebDriver().findElements(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr")); 
			for(int k=2; k<rows_PlanResultTable_History.size();k++)
			{
				String EffectiveDateActual=getWebDriver().findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[3]")).getText();			
				String UserIDActual=getWebDriver().findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[5]")).getText();
				String ReasonCodeActual=getWebDriver().findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[6]")).getText();					
				if(EffectiveDateActual.equalsIgnoreCase(EffectiveDateExpected)				 
						&& UserIDActual.equalsIgnoreCase(UserIDExpected)
						&& ReasonCodeActual.equalsIgnoreCase(ReasonCodeExpected))
				{
					found=true;
					getWebDriver().findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[9]/a[1]")).click();
					waitForPageLoad();					
					log(PASS,"Clicked Run Link in Impact Review table",
							"Verify Bulk plan request is moved to pending review state & check whether Run link displays");
					break;	
				}
				if(!found)
				{
					log(FAIL,"Verify Bulk plan request is moved to Completed state & able to download Update Report",
							"Not able to identify the given values in the table"+UserIDExpected+ ", "+ ReasonCodeExpected);

				}

			} 
		}
		catch(Exception e){
			e.getLocalizedMessage();

		}
	}
	
	/**
	 * @author AF12450
	 * This method will help in getting a particular cellvalue by finding the rownumber with the reference from findCol and findValue 
	 * @param testObject:variable holding the locator value of the table object that needs to be validated 
	 * @param findCol:Column reference based on which the value needs to be fetched
	 * @param findValue:value to be identified in the table
	 * @param getCol:column number in the table in which click action needs to be performed
	 * @param stepName:
	 * @return
	 */
	public static String getCellValue(WebElement testObject,int findCol,String findValue,int getCol,String stepName)
	{
		try
		{
			WebElement table =testObject;
			if(table != null)
			{
				int rowIndex = 0;					
				List<WebElement> rows = getWebDriver().findElements(By.xpath("//tbody/tr[*]"));
				for(int i=0; i< rows.size(); i++)
				{
					WebElement column = rows.get(i).findElement(By.xpath("//tbody/tr["+(i+2)+"]/td["+findCol+"]"));
					String columnValue = column.getText();
					System.out.println(columnValue);
					if(columnValue.equals(findValue))
					{
						rowIndex = i+2;
						break;
					}
				}

				System.out.println(rowIndex);										
				if(rowIndex !=0)
				{
					WebElement requiredColumn = table.findElement(By.xpath("//tr["+rowIndex+"]/td["+getCol+"]"));
					String cellValue = requiredColumn.getText();	
					System.out.println(cellValue);
					if(!cellValue.isEmpty())
					{						
						log(PASS,"Click cell in the table","Click cell in the table");
						return cellValue;
					}
				}
				else
				{						
					log(FAIL,"Value not found in the table","Value not found in the table:"+findValue);
				}
			}
			else
			{
				log(FAIL,"Not able to identify the table with given properties","Not able to identify the table with given properties");
			}
		}
		catch(Exception e)
		{
			log(ERROR,"Exception caught in the get cell value","Exception caught in the get cell value is: "+e.getLocalizedMessage());
		}		
		return "";
	}
	/**
	 * @author : AF17403
	 * This method is used to get the status from the Impact review tab
	 * @param EffectiveDateExpected: Effective date used while fetching data
	 * @param UserIDExpected :ID of the user initiated the bulk update process
	 * @param ReasonCodeExpected:Reason code selected in the Bulk Update tab
	 * @return
	 */
	public static String getStatus(String EffectiveDateExpected,String UserIDExpected,String ReasonCodeExpected)
	{
		String status="";
		try{

			List<WebElement> rows_PlanResultTable_History = driver.findElements(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr")); 
			for(int k=2; k<rows_PlanResultTable_History.size();k++)
			{
				String EffectiveDateActual=driver.findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[3]")).getText();			
				String UserIDActual=driver.findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[5]")).getText();
				String ReasonCodeActual=driver.findElement(By.xpath(".//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[6]")).getText();
				status=driver.findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[7]")).getText();
				if(EffectiveDateActual.equalsIgnoreCase(EffectiveDateExpected)				 
						&& UserIDActual.equalsIgnoreCase(UserIDExpected)
						&& ReasonCodeActual.equalsIgnoreCase(ReasonCodeExpected))
				{
					log(PASS,"Get Bulk plan request record state.",
							"Bulk Update Requested record is in "+status+" status");
					break;
				}
			} 
		}
		catch(Exception e){
			e.getLocalizedMessage();

		}

		return status;
	}
	/**@author : AF15123
	 * This method is used to verify the expected and actual data in the Impact review tab
	 * @param EffectiveDateExpected:
	 * @param UserIDExpected:
	 * @param ReasonCodeExpected:
	 */
	public static void actionCodeColumnValidate(String EffectiveDateExpected,String UserIDExpected,String ReasonCodeExpected)
	{
		try{
			List<WebElement> rows_PlanResultTable_History = driver.findElements(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr")); 
			for(int k=2; k<rows_PlanResultTable_History.size();k++)
			{
				String EffectiveDateActual=driver.findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[3]")).getText();			
				String UserIDActual=driver.findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[5]")).getText();
				String ReasonCodeActual=driver.findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[6]")).getText();
				String status=driver.findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[7]")).getText();
				String Action=driver.findElement(By.xpath("//div[@id='impactReview']/div/table[@class='af_table_content']/tbody/tr["+k+"]/td[9]/a[1]")).getText();
				if(EffectiveDateActual.equalsIgnoreCase(EffectiveDateExpected)				 
						&& UserIDActual.equalsIgnoreCase(UserIDExpected)
						&& ReasonCodeActual.equalsIgnoreCase(ReasonCodeExpected)
						&& status.equalsIgnoreCase("Pending Review")
						&& Action.equalsIgnoreCase("Schedule"))
				{					
					log(PASS,"Run Link is not displayed in impact Review page,When User Selects more than 50 record",
							"Verify run link is not appeared in impact review table, if user selected more than 50 records");
					break;	
				}
			} 
		}
		catch(Exception e){
			e.getLocalizedMessage();

		}
	}
	/**@author : AF14733
	 * This method is used to verify the no of records fetched
	 * @return
	 */
	public static boolean recordFound()
	{
		boolean found =false;
		try{
			if(seGetElementValue(BulkUpdatePage.get().searchResult).toString().contains("No Plans meet the entered criteria"))
			{
				found =false;
				log(WARNING, "Criteria", "No Plans meet the entered criteria");
			}
			else{
				found =true;
				log(PASS, "Criteria", "Plans meet the entered criteria");
			}

		}catch(Exception e)
		{
			e.getLocalizedMessage();

		}		
		return found;
	}
	/**@author : AF14733
	 * This method is used to validate the record count
	 * @param recordCount: No of records to be selected
	 */
	public static void recordSelection(int recordCount)
	{		
		try
		{
			for(int i=0; i<recordCount; i++)
			{
				if(i<24){
					WebElement element =driver.findElement(By.xpath(".//*[@id='groupResults:"+i+":resSelected']"));
					element.click();
					waitForPageLoad(100);   
				}
				else if(i==24){
					WebElement element =driver.findElement(By.xpath(".//*[@id='groupResults:"+i+":resSelected']"));
					element.click();
					waitForPageLoad(100);   
					seClick(BulkUpdatePage.get().Next25_Link, "Next25_Link");
					waitForPageLoad(100);   
				}
				else if(i>24&&i<49)
				{
					WebElement element =driver.findElement(By.xpath(".//*[@id='groupResults:"+(i-25)+":resSelected']"));
					element.click();
					waitForPageLoad(100);   
					//	Web.get().SPIDERPC_WaitForPageLoad();	
				}
				else if(i==49){
					WebElement element =driver.findElement(By.xpath(".//*[@id='groupResults:"+(i-25)+":resSelected']"));
					element.click();
					waitForPageLoad(100);   
					seClick(BulkUpdatePage.get().Next25_Link, "Next25_Link");
					waitForPageLoad(100);   
				}
				else if(i>49)
				{
					WebElement element =driver.findElement(By.xpath(".//*[@id='groupResults:"+(i-50)+":resSelected']"));
					element.click();
					waitForPageLoad(100);   
				}

			}


		}
		catch(Exception e)
		{
			e.getLocalizedMessage();

		}

	}
	/**
	 * This method is used to verify error is displayed, When User not selecting  the required field in Group Bulk Update page.
	 * @param SectionType
	 *            : Criteria Name.
	 *  @param SrchVal1 is required field value
	 *   @param SrchVal2 is required field value
	 *  @param ExpectedErrmsg Expected Error should occur in Group Bulk Update page.
	 */
	public static void errorValidation(String SectionType,String SrchVal1,String SrchVal2,String ExpectedErrmsg)
	{
		try{	
			switch(SectionType)
			{
			case "PlanCriteria":
				seSelectText(false,BulkUpdatePage.get().planCriteria,SrchVal1, "Selects Plan Crietria type");
				waitForPageLoad();
				seClick(BulkUpdatePage.get().addPlanCriteria, "addPlanCriteria");
				waitForPageLoad();
				break;
			case "AdminCriteria":
				seSelectText(false,BulkUpdatePage.get().adminCriteriaDropDown,SrchVal1, "Selects Admin Crietria type");	
				waitForPageLoad();
				seClick(BulkUpdatePage.get().addAdminCriteria, "addAdminCriteria");
				waitForPageLoad();
				break;
			case "PlanAdminCriteria":
				seSelectText(false,BulkUpdatePage.get().planAdminCriteriaDropDown,SrchVal1, "Selects Plan Admin Crietria type");	
				waitForPageLoad();
				seClick(BulkUpdatePage.get().addPlanAdminCriteria,"addPlanAdminCriteria");
				waitForPageLoad();
				seSelectText(false,BulkUpdatePage.get().planAdminCritTabCol3,SrchVal2, "Selects PlanAdmin Criteria table column3 values");	
				waitForPageLoad();
				break;
			case "WaitingPerCriteria":
				seSelectText(false,BulkUpdatePage.get().waitingPeriodDropdown,SrchVal1, "Selects Waiting period type");	
				waitForPageLoad();
				seClick(BulkUpdatePage.get().addWaitingPeriod, "addWaitingPeriod");
				waitForPageLoad();
				seSelectText(false,BulkUpdatePage.get().waitingPeriodTabCol3,SrchVal2, "Selects Waiting Period table column3 values");	
				waitForPageLoad();
				break;
			}

			seClick(BulkUpdatePage.get().contractSearch, "contractSearch");
			waitForPageLoad(100);   
			if(seGetElementValue(BulkUpdatePage.get().errorMsg).contains(ExpectedErrmsg))
			{
				log(PASS,"Verify Error Message in Group Bulk Update Page","Error Message is displayed, When user not selecting required field in "+SectionType+" Section",true);
			}	
			else
			{
				log(FAIL,"Verify Error Message in Group Bulk Update Page","Error Message is displayed, When user not selecting required field in "+SectionType+" Section",true);
			}
			seClick(HomePage.get().link_ContractSerach,"link_ContractSerach");
			waitForPageLoad();
		}
		catch(Exception e)
		{
			e.getLocalizedMessage();

		}
	}
	
	/**
	 * @author AF12450
	 * This method fetches the modified file path
	 * @param dir:Path where the report is downloaded
	 * @return
	 */
	public static String lastModifiedFile(String dir) {
		try {
			File file = new File(dir);
			File[] files = file.listFiles();
			long lastMod = Long.MIN_VALUE;
			File choice = null;
			for (File index : files) {
				if (index.lastModified() > lastMod) {
					lastMod = index.lastModified();
					choice = index;
				}
			}

			return choice.getName();

		} catch (Exception e) {
			e.printStackTrace();
			log(FAIL,"Exception caught in "					
					+ e.getLocalizedMessage());			
		}

		return null;
	}
	
	/**
	 * @author AF14733
	 * 	This method is written for validate replaced proxy id is displayed for contracts.
	 * @param replaceProxyID - Pass the replacedProxy ID
	 * @param contractCode - Pass the Contract ID
	 */
	public static void validateReplaceproxyID(String replaceProxyID,String contractCode)
	{
		try {
			seClick(ContractInformationPage.get().planAdminTabLink,"Clicking on Plan Admin Tab");
			waitForPageLoad(100);   
			String proxyText=seGetElementValue(ContractInformationPage.get().proxyIDtable).toString();
			if(proxyText.contains(replaceProxyID)){
				log(PASS, "Verify Proxy id is replaced for Contracts"," ProxyID is replaced successfully for contract "+contractCode,true);
			}
			else
			{
				log(FAIL, "Verify Proxy id is not replaced for Contracts"," ProxyID is not replaced for contract "+contractCode,true);

			}
		} catch(Exception e)
		{
			log(FAIL, "Replaced proxy ID validation for Contract"+e.getLocalizedMessage());
		}	
	}	
	/**
	 * @author AF14733
	 * The Method is used to search a contract ID which has been replaced
	 * @param contractCode:Contract Code which is fetched from the updated report
	 * @throws InterruptedException 
	 */
	public static void verifyproxy(String contractCode)
	{
		try{
			String proxyText =seGetText(ContractInformationPage.get().cont_inf).toString();
			waitForPageLoad();
			if((proxyText.contains(contractCode)))
			{
				log(PASS, "Proxy ID Verification : "+getCellValue("ProxyId_Value")+ "should be present",
						"Verified the Proxy ID  is  changed: "+getCellValue("ProxyId_Value"),true);

			}
			else{
				log(FAIL, "Proxy ID Verification : "+getCellValue("ProxyId_Value")+ "should be present",
						"Verified the Proxy ID  is not changed: "+getCellValue("ProxyId_Value"),true);
			}  

		}catch(Exception e){

		}
	}	
	/**
	 * @author AF14733
	 * This method will validate the replace value in contact information for Contact Info Criteria for type Organization 
	 * @param replacepervalue:Replace value fetched from the data sheet
	 * @param contractCode:Contract code fetched from the results table
	 */
	public static void validateReplacevalue_org(String replacepervalue,String contractCode)
	{
		try {
			seClick(ContractInformationPage.get().contactinfotab,"contactinfotab");
			waitForPageLoad();
			String pervalue=seGetElementValue(ContractInformationPage.get().proxyIDtable);
			if(pervalue.contains(replacepervalue)){					
				log(PASS, "Verify Person role Value is replaced for Contracts",
						"Person role Value is replaced successfully for contract "+contractCode);
			}
			else
			{
				log(FAIL, "Verify Person role Value is replaced for Contracts",
						"Person role Value is replaced successfully for contract "+contractCode);
			}
		} catch(Exception e)
		{
			e.printStackTrace();
			log(FAIL, "To Replace Person role for Contract",
					"To Replace Person role for Contract"+e.getLocalizedMessage());
		}		
	}
	/**
	 * @author AF14733
	 * This method validates the table header in the WEB application.
	 * @param testObject: variable holding the locator value of the table object that needs to be validated
	 * @param className: Name of the class where testobject present
	 * @param header: Header values that needs to be validated in the object
	 * @param stepName: reporting purpose
	 */
	public static void VerifyTableHeader(WebElement ele,String header,String text)
	{
		ArrayList<String> failedHeader = new ArrayList<>();		
		boolean result = false;

		try
		{
			WebElement table = ele;
			if(table != null)
			{
				List<WebElement> columns = driver.findElements(By.xpath("//tr[1]/th"));
				String[] expectedValue = header.split(",");
				for(int i = 0; i< expectedValue.length; i++)
				{
					String actual  = "";
					for(int index = 0; index<columns.size(); index++)
					{
						actual = columns.get(index).getText();
						if(actual.equals(expectedValue[i]))
						{
							result = true;
							break;
						}
					}
					if(!result)
					{
						failedHeader.add(expectedValue[i]);
					}
					else
					{
						result = false;
					}

				}

				if(! (failedHeader.size()>0))
				{						
					log(PASS, "Validate table web element header: ","Expected values"+header+ " are present in the table");	
				}
				else
				{
					String failedValues = "";
					for(int i =0; i< failedHeader.size(); i++ )
					{
						failedValues= failedHeader.get(i)+","+failedValues;
					}
					log(FAIL, "Expected values","Expected values"+failedValues+ " are not present in the table");
				}
			}
			else
			{
				log(FAIL, "Table Verification", "Not able to identify the table with given properties");
			}
		}
		catch(Exception e)
		{				
			log(FAIL, "Exception", "Exception"+e.getLocalizedMessage());
		}

	}
	/**
	 * @author AF12450
	 * This method will help in clicking on  a particular cell by finding the rownumber with the reference from findCol and findValue
	 * @param testObject: variable holding the locator value of the table object that needs to be validated
	 * @param findCol: Column reference based on which the value needs to be fetched
	 * @param findValue: value to be identified in the table
	 * @param clickCol: column number in the table in which click action needs to be performed
	 * @param stepName
	 */
	public static void clickAtCell(WebElement testObject,int findCol,String findValue,int clickCol,String stepName)
	{
		try
		{
			WebElement table = testObject;
			if(table != null)
			{
				int rowIndex = 0;
				List<WebElement> rows = driver.findElements(By.xpath("//tbody/tr[*]"));
				System.out.println(rows.size());
				for(int i=0; i< rows.size(); i++)
				{
					WebElement column = rows.get(i).findElement(By.xpath("//tbody/tr["+(i+2)+"]/td["+findCol+"]"));
					String columnValue = column.getText();
					System.out.println(columnValue);
					if(columnValue.equalsIgnoreCase(findValue))
					{
						rowIndex = i+2;
						break;
					}
				}

				System.out.println(rowIndex);


				if(rowIndex !=0)
				{
					WebElement requiredColumn = table.findElement(By.xpath("//tbody/tr["+rowIndex+"]/td["+clickCol+"]"));

					if(requiredColumn.isEnabled())
					{
						requiredColumn.click();						
						log(PASS,"CVerified column header: ","Verified Column Header Exected Value:"+" Actual value: ");
					}
				}
				else
				{
					log(FAIL,"Value not found in the table","Value not found in the table:"+findValue);
				}
			}
			else
			{

				log(FAIL,"Not able to identify the table with given properties","Not able to identify the table with given properties");
			}
		}
		catch(Exception e)
		{
			log(ERROR,"Exception caught in the get cell value","Exception caught in the get cell value is: "+e.getLocalizedMessage());
		}		

	}
	
	/**
	 * @author AF15123
	 * This method will retrieve the value for attribute
	 * @param tagName - Pass the tagname of attribute
	 * @param attribute - Pass the attribute name
	 * @param path - Pass the xml file path 
	 * @return
	 */
	public static String  getAttributeValue(String tagName, String attribute, String path)
	{
		//	testStepActionText = "Retrieve value from XML tag ";
		String value = null;
		try{
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(new File(path));
			Element rootElement = document.getDocumentElement();
			NodeList list = rootElement.getElementsByTagName(tagName);
			if (list != null && list.getLength() > 0) {
				Node subList = list.item(0);
				value = subList.getAttributes().getNamedItem(attribute).getTextContent();
			}
			//				value= getString(tagName,rootElement);
			if (value != null)
			{
				log(PASS, "Retrieving value from xml","Retrieve  Successful value :"+value+" From Tag :"+ tagName);
			} 
			else {
				log(FAIL, "Retrieving value from xml","Retrieve Failed "+" From Tag :"+ tagName);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return value;
	}
	
	/**
	 * @author AF15123
	 * @param ID - Pass the Plan or Contract ID.
	 * @param region - Pass Application environment name
	 * @param downloadPath - Declare the path for downloding xml file.
	 */
	public static void DownloadXML(String ID, String region, String downloadPath)
	{
		try
		{
			DownloadFinalizeXML.downloadXML(region, downloadPath, ID);
			waitForPageLoad(100);   
			File currentFolder = new File(downloadPath +region+"_"+ID+".xml");
			if(currentFolder.exists())
			{
				log(PASS, "Validate XML file is downloadable", "Downloaded the XML from the region:"+region+" for "+ID);
			}
			else
			{
				log(FAIL, "Validate XML file is downloadable", "XML file is not exists");
			}
		}
		catch(Exception e){

			e.printStackTrace();
		}
	}
	/**
	 * @author AF15123
	 * This method will validate the xml file contains any error message or not.
	 * @ID - Pass the plan id or contract id
	 * @param FilePath- Pass the filename along with path.
	 */
	public static void XMLErrorValidation(String FilePath,String ID)
	{
		try{
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new File(FilePath));	
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
			DOMSource source = new DOMSource(doc);
			StringWriter writer =new StringWriter();
			StreamResult result =new StreamResult(writer);
			transformer.transform(source,result);
			String xmltext=writer.getBuffer().toString().replaceAll("\n|\r", "");
			if(xmltext.contains("Error")||xmltext.contains("error"))
			{
				log(FAIL,"XML content validation for "+ID,"Error in XML file");
			}
			else
			{
				log(PASS,"XML content validation for "+ID,"No error in XML file");
			}

		}
		catch(ParserConfigurationException |TransformerException|SAXException|IOException e){
			e.printStackTrace();
		}

	}
	/**
	 * @author AF15123
	 * This method will validate records are moved to Update Sheet or Not
	 * @param filePath-Pass the download file path.
	 * @param SheetName - Pass the sheet name to check records present in sheet.
	 * @param HeaderName - Pass the column name to get value of column name
	 * @return
	 * @throws IOException
	 */
	public static String getFirstRowData(String filePath,String SheetName,String HeaderName) throws IOException{
		int col=0;   
		String dataFound="";
		String tempData="";
		boolean found=false;
		FileInputStream  FILE;
		XSSFWorkbook WB=null;
		XSSFSheet  SHEET = null;
		try{
			FILE = new FileInputStream(new File(filePath));
			WB = new XSSFWorkbook(FILE);
			SHEET = WB.getSheet(SheetName);
			int cc=SHEET.getRow(0).getLastCellNum();
			for (int i = 0; i < cc; i++) {
				String data=SHEET.getRow(0).getCell(i).toString().trim();
				if(data.equals(HeaderName)){
					col=i;
					found=true;
					break;
				}
			}
			WB.close();
		} catch(Exception e){
			e.printStackTrace();
		}
		if(found){
			try{
				dataFound=SHEET.getRow(1).getCell(col).toString().trim();

			}catch(Exception e){
				dataFound="";
			}
		}
		if(!dataFound.equals("")){
			tempData= dataFound;
		}else{
			tempData="";
		}
		return tempData;
	}	
	/**
	 * @author AF15123
	 * This method is used to verify the contract values are replaced, When User tries to replaces values for bulk of contracts.
	 * @param AdminTabTextExpected
	 *            : Expected contract value to replace in Admin Criteria.
	 *  @param PlanAdminTabTextExpected
	 *            : : Expected contract value to replace in Plan Admin Criteria.
	 *  @param WaitingPerTabTextExpected
	 *            : : Expected contract value to replace in Waiting Period Criteria.
	 */
	public static void replaceValueValidation(String AdminTabTextExpected,String PlanAdminTabTextExpected,String WaitingPerTabTextExpected){

		try{
			seClick(ContractInformationPage.get().adminTab, "adminTabLink");
			Thread.sleep(5000);
			String AdminTabTextActual=seGetElementValue(HomePage.get().mainDoc);
			seClick(ContractInformationPage.get().planAdminTabLink, "planAdminTabLink");
			Thread.sleep(10000);
			String PlanAdminTabTextActual=seGetElementValue(HomePage.get().mainDoc);
			seClick(ContractInformationPage.get().waitingPerTabLink, "waitingPerTabLink");
			Thread.sleep(10000);
			String WaitingPerTabTextActual=seGetElementValue(HomePage.get().mainDoc);
			if(AdminTabTextActual.contains(AdminTabTextExpected)&&PlanAdminTabTextActual.contains(PlanAdminTabTextExpected)
					&&WaitingPerTabTextActual.contains(WaitingPerTabTextExpected))
			{
				log(PASS, "Replace Contract field values", 
						"Contract field values are replaced as expected");

			}
			else{
				log(FAIL, "Replace Contract field values", 
						"Error in Contract field values are replace");

			}
		}
		catch(Exception e){
			e.printStackTrace();
		}

	}
}
