package utility;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;


/**
 * @author shiva.katula
 *
 */
public class PlanXMLParser extends CoreSuperHelper{

	
	
	public static void validateEOBCode(String benefitHierarchy, String strSituationGroup, String strSituationType, String strCalculationGroup,
			String strSequenceID, String strAccumulator,String strXMLFile)
	{
		try {
			

			Node benefitNode = getBenefitNode(benefitHierarchy, strXMLFile);
			if(benefitNode!=null)
			{
				log(PASS, "Benefit found in XML","Benefit : \""+benefitHierarchy+"\" found in the XML");
			Node situationGroupNode = getSituationGroupNode(benefitNode, strSituationGroup);
			if(situationGroupNode!=null)
			{
				log(PASS, "Situation group found in XML","Situation group : \""+strSituationGroup+"\" found in the XML");
			Node situationTypeNode = getSituationTypeNode(situationGroupNode, strSituationType);
			if(situationTypeNode!=null)
			{
				log(PASS, "Situation type found in XML","Situation type : \""+strSituationType+"\" found in the XML");
				Node calculationGroupNode = getCalculationGroupNode(situationTypeNode, strCalculationGroup);
				if(calculationGroupNode != null)
				{
					log(PASS, "Calculation group found in XML","Calculation group : \""+strCalculationGroup+"\" found in the XML");
					Node accumulatorNode = getAccumulatorNode(calculationGroupNode, strSequenceID, strAccumulator);
					if(accumulatorNode != null)
					{
						log(PASS, "Accumulator found in XML","Accumulator : \""+strAccumulator+"\" found in the XML");
					}
					else
					{
						log(FAIL, "Not able to find the accumulator","Please check the text of accumulator");
					}
					
				}
				else
				{
					log(FAIL, "Not able to find the calculation group","Please check the text of calculation group");
				}
				
			}
			else
			{
				log(FAIL, "Not able to find the situation type","Please check the text of situation type");
			}
			}
			else
			{
				log(FAIL, "Not able to find the situation group","Please check the text of situation group");
			}
			}
			else
			{
				log(FAIL, "Not able to find the benefit","Please check the benefit hierarchy");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public static Node getAccumulatorNode(Node calculationGroupNode, String strSequenceID, String strAccumulator)
	{
		Node accumulatorNode = null;
		
		try
		{
			Node calculationStepNode = getCalculationStepNode(calculationGroupNode, strSequenceID);
			if(calculationStepNode!= null)
			{
				List<Node> nodes = calculationStepNode.selectNodes("accumulator");
				for(Node node: nodes)
				{
					String accumulatorText = ((Element)node.selectSingleNode("accumulatorName")).attributeValue("text");
					if(accumulatorText.equalsIgnoreCase(strAccumulator))
					{
						accumulatorNode = node;
						break;
					}
				}
			}
			else
			{
				log(FAIL, "Not able to find the calculation step","Please check the sequence id");
			}
			
		}
		catch (Exception e) {
				e.printStackTrace();
		}
		return accumulatorNode;
	}
	
	public static Node getCalculationStepNode(Node calculationGroupNode, String strSequenceID)
	{
		Node calculationStepNode = null;
		
		try
		{
			List<Node> nodes = calculationGroupNode.selectSingleNode("steps").selectNodes("calculationStep");
			for (Node node : nodes) {
				
					String adminMethodIdTypeText = ((Element) node.selectSingleNode("sequenceId"))
							.getText();
					if(adminMethodIdTypeText.equalsIgnoreCase(strSequenceID))
					{
					calculationStepNode = node;
					break;
					}
					
			}
			
		}
		catch (Exception e) {
				e.printStackTrace();
		}
		return calculationStepNode;
	}
	
	public static Node getCalculationGroupNode(Node situationtypeNode, String strCalculationGroup)
	{
		Node calculationGroupNode = null;
		
		try
		{
			List<Node> nodes = situationtypeNode.selectSingleNode("calculationGroups").selectNodes("calculationGroup");
			for (Node node : nodes) {
				List<Node> calculationNodes = node.selectNodes("calculation");
				for(Node individualNode: calculationNodes)
				{
					String adminMethodIdTypeText = ((Element) individualNode.selectSingleNode("calcChoiceType"))
							.attributeValue("text");
					if(adminMethodIdTypeText.equalsIgnoreCase(strCalculationGroup))
					{
					calculationGroupNode = individualNode;
					break;
					}
				}
			}
			
		}
		catch (Exception e) {
				e.printStackTrace();
		}
		return calculationGroupNode;
	}
	public static Node getSituationGroupNode(Node benefitNode, String strSituationGroup)
	{
		Node situationNode = null;
		
		try
		{
			List<Node> nodes = benefitNode.selectSingleNode("situationGroups").selectNodes("situationGroup");
			for (Node node : nodes) {
				String adminMethodIdTypeText = ((Element) node)
						.attributeValue("text");
				System.out.println(adminMethodIdTypeText);
				if(adminMethodIdTypeText.equalsIgnoreCase(strSituationGroup))
				{
					System.out.println(adminMethodIdTypeText);
					situationNode = node;
					break;
				}
			}
			
		}
		catch (Exception e) {
				e.printStackTrace();
		}
		return situationNode;
	}
	
	/**
	 * This method will give you the node of the situation type present in the Plan XML. The situation type node will be identified by the strSituationType text
	 * @param situationGroupNode: node of the situation group from  which situation type needs to be fetched
	 * @param strSituationType: situation type text that will help in identifying the situation type text
	 * Example usage : getBenefitNode(situationGroupNode, "In Network Coinsurance")	
	 */
	public static Node getSituationTypeNode(Node situationGroupNode, String strSituationType)
	{
		Node situationType = null;
		try
		{
			List<Node> nodes = situationGroupNode.selectNodes("calculationSituation");
			for (Node node : nodes) {
				String adminMethodIdTypeText = ((Element) (node.selectSingleNode("situationType")))
						.attributeValue("text");
				if(adminMethodIdTypeText.equalsIgnoreCase(strSituationType))
				{
					System.out.println(adminMethodIdTypeText);
					situationType = node;
					break;
				}
			}
		}
		catch (Exception e) {
				e.printStackTrace();
		}
		return situationType;
	}
	
	/**
	 * This method will give you the node of the benefit present in the Plan XML. The benefit node will be identified by the Benefit Hierarchy
	 * @param benefitHierarchy: benefit hierarchy of the benefit
	 * @param strXMLFile : location of the XML from which benefit node needs to be identified
	 * @return : benefit node
	 * Example usage : getBenefitNode("Physician and Medical Services/Exam Visit/Foot Care", "C:\\Application\\reports\\UAT.xml")	
	 */
	
	public static Node getBenefitNode(String benefitHierarchy, String strXMLFile)
	{
		Node benefit = null;
		
		try
		{
			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			List<Node> nodes = document.selectNodes("//benefitTypeCoverages/benefitTypeCoverage");
			boolean benefitFound = false;
			String[] benefitNameDetails = benefitHierarchy.split(";");
			int index = benefitNameDetails.length; 
		for(int i=0; i < index; i++)
		{
				String benefitName = benefitNameDetails[i];
				benefitFound = false;
			for (Node node : nodes) {
				String adminMethodIdTypeText = ((Element) (node.selectSingleNode("benefitLevel")))
						.attributeValue("text");
				if(adminMethodIdTypeText.equalsIgnoreCase(benefitName))
				{
					System.out.println(adminMethodIdTypeText);
					benefit = node;
					benefitFound = true;
					break;
				}
			}
			nodes = (benefit.selectSingleNode("childBenefits")).selectNodes("benefitTypeCoverage");
			
		}
		System.out.println(benefitFound);
		
		if(!benefitFound)
		{
			benefit = null;
		}
			
			
			
		}
		catch (Exception e) {
				e.printStackTrace();
		}
		
		return benefit;
		
	}
	
	
	
	/**
     * This method finds the value and text of a planDesign in the provided XML
     * 
      * @param strXMLFile : THe location of the XML file
     * @return Hashmap planDesign Value, PlanDesign Text
     */
     public static HashMap<String, String> getPlanDesign(String strXMLFile){
            HashMap<String, String> planDesign=new HashMap<>();
     try{
            File inputFile = new File(strXMLFile);
            SAXReader reader = new SAXReader();
            Document document = reader.read(inputFile);
            Node node = document.selectSingleNode("//planDesign");
            String planDesignText=((Element)node).attributeValue("text");
            String planDesignValue=((Element)node).attributeValue("value");
            planDesign.put("text", planDesignText);
            planDesign.put("value", planDesignValue);
                         
     }catch (Exception e) {
            e.printStackTrace();
     }
     return planDesign;
     }

     
     /**
      * This method will give the complete details of the admin method associated to a benefit in the Plan XML
     * @param strXMLFile
     * @param benefitHierarchy
     * @param situationGroupText
     * @param strSituationType
     * @param calcChoiceType
     * @param adminMethodType
     * @return
     */
    public static HashMap<String, String> getAdminMethodData(String strXMLFile,String benefitHierarchy,String situationGroupText, String strSituationType,String calcChoiceType,String adminMethodType){
         int count=0;
         String adminMethodIDType_text=null;
         String adminMethodIDType_value=null;
         String adminMethodType_text=null;
         String adminMethodType_value=null;
         String adminMethodData_value=null;
         HashMap<String, String> adminMethod=new HashMap<>();
         Node node=getBenefitNode(benefitHierarchy, strXMLFile);
         if(node!=null)
         {
                log(PASS, "Benefit found in XML","Benefit : \""+benefitHierarchy+"\" found in the XML");
                Node situationGroupNode=getSituationGroupNode(node,situationGroupText);
                if(situationGroupNode!=null){
                      log(PASS, "Situation group found in XML","Situation group : \""+situationGroupText+"\" found in the XML");
                      Node situationTypeNode=getSituationTypeNode(situationGroupNode, strSituationType);
                      if(situationTypeNode!=null){
                             log(PASS, "Situation type found in XML","Situation type : \""+strSituationType+"\" found in the XML");
                             Node calculationNode=getCalculationGroupNode(situationTypeNode,calcChoiceType);
                             if(calculationNode!=null){
                                    log(PASS, "Cal Choice Type Node found in XML","CalChoiceType Node : \""+calcChoiceType+"\" found in the XML");
                                    List<Node> adminMethodListNodes=((Element)calculationNode).selectNodes("adminMethodList");
                                    if(adminMethodListNodes.size()==0){
                                           log(FAIL, "Admin Method List not available","There should be atleast one Admin Method List should exist to validate Admin Method Data");
                                    }else{
                                           for(Node adminMethodList:adminMethodListNodes){
                                                  List<Node> adminMethodDataNodes=((Element)adminMethodList).selectNodes("AdminMethodData");
                                                  System.out.println(adminMethodDataNodes.size());
                                                  for (Node adminNode : adminMethodDataNodes) {
                                                         String nodes1=((Element)adminNode.selectSingleNode("adminMethodType")).attributeValue("text");
                                                         if(nodes1.equalsIgnoreCase(adminMethodType)){
                                                                adminMethodIDType_text=((Element)adminNode.selectSingleNode("adminMethodIdType")).attributeValue("text");
                                                                adminMethodIDType_value=((Element)adminNode.selectSingleNode("adminMethodIdType")).attributeValue("value");
                                                                adminMethodType_text=((Element)adminNode.selectSingleNode("adminMethodType")).attributeValue("text");
                                                                adminMethodType_value=((Element)adminNode.selectSingleNode("adminMethodType")).attributeValue("value");
                                                                adminMethodData_value=((Element)adminNode).selectSingleNode("value").getText();
                                                                adminMethod.put("Admin Method ID Type text", adminMethodIDType_text);
                                                                adminMethod.put("Admin Method ID Type  value", adminMethodIDType_value);
                                                                adminMethod.put("Admin Method Type text", adminMethodType_text);
                                                                adminMethod.put("Admin Method Type value", adminMethodType_value);
                                                                adminMethod.put("Admin Method Data value", adminMethodData_value);
                                                                count++;
                                                         }
                                                  }
                                                  if(count>0){
                                                         break;
                                                  }
                                           }
                                    }
                             }else{
                                    log(FAIL, "Not able to find the CalChoiceType","Please check the text of Cal Choice Type");
                             }
                      }else{
                             log(FAIL, "Not able to find the situation type","Please check the text of situation type");
                      }
                }else{
                      log(FAIL, "Not able to find the situation group","Please check the text of situation group");
                }
         }else{
                log(FAIL, "Not able to find the benefit","Please check the benefit hierarchy");
         }

         return adminMethod;
  }


	/**
	 * This method iterates for a node with requested name in a reverse way
	 * Bottom-up from current Node
	 * 
	 * @param currentNode
	 * @param searchNodeName
	 * @return Node requested Node
	 */
	
	private static Node getNode(Node currentNode, String searchNodeName) {

		if (currentNode.getName().equals(searchNodeName.trim())) {
			return currentNode;
		} else {
			return getNode(currentNode.getParent(), searchNodeName);
		}
	}
	
	/**
	 * This method validates plan design text and plan design value in xml with the expected values
	 * 
	 * @param strDownloadPath
	 * @param strPlanDesignValue
	 * @param strPlanDesignText
	 * @throws Exception
	 */
	public static boolean validatePlanDesign(String strDownloadPath,String strPlanDesignValue,String strPlanDesignText) throws Exception
	{
		boolean result=false;
		try{
			HashMap<String, String> planDesign = PlanXMLParser.getPlanDesign(strDownloadPath);

			String actualPlanDesignValue = planDesign.get("value");
			String actualPlanDesignText = planDesign.get("text");
			if(actualPlanDesignValue != null)
			{
				if(actualPlanDesignValue.equalsIgnoreCase(strPlanDesignValue))
				{
					result = true;
					log(PASS, "Validate Plan Design Value in XML", "Actual value "+actualPlanDesignValue+" is equal to Expected value "+strPlanDesignValue);
				}
				else
				{
					result = false;
					log(FAIL, "Validate Plan Design Value in XML", "Actual value "+actualPlanDesignValue+" is not equal to Expected value "+strPlanDesignValue);
				}
			}
			else
			{
				result = false;
				log(FAIL, "Validate Plan Design Value in XML", "Not able to find the plan design in the XML");

			}
			if(actualPlanDesignText!=null)
			{
				if(actualPlanDesignText.equalsIgnoreCase(strPlanDesignText))
				{
					result = true;
					log(PASS, "Validate Plan Design text in XML", "Actual text "+actualPlanDesignText+" is equal to Expected value "+strPlanDesignText);
				}
				else
				{
					result = false;
					log(FAIL, "Validate Plan Design text in XML", "Actual text "+actualPlanDesignText+" is equal to Expected value "+strPlanDesignText);
				}
			}
			else
			{
				result = false;
				log(FAIL, "Validate Plan Design text in XML", "Not able to find the plan design in the XML");
			}
		}
		catch (Exception e)
		{
			throw e;
		}
		return result;
	}

	
	/**
	 * This method validates plan option type text in xml with the expected value
	 * 
	 * @param strDownLoadPath
	 * @param strPlanOptionType
	 * @param strMailCoverage
	 * @throws Exception
	 */
	public static boolean validatePlanOptionType(String strDownLoadPath,String strPlanOptionType,String strExpectedValue) throws Exception
	{
		boolean result=false;
		try
		{
			String actualOptionName=PlanXMLParser.getPlanOptionType(strDownLoadPath, strPlanOptionType);
			if(actualOptionName!=null)
			{
				if(actualOptionName.equalsIgnoreCase(strExpectedValue))
				{
					result = true;
					log(PASS, "Validate planOptionName in XML", "Actual text "+actualOptionName+" is equal to Expected value "+strExpectedValue);
				}
				else
				{
					result = false;
					log(FAIL, "Validate planOptionName in XML", "Actual text "+actualOptionName+" is equal to Expected value "+strExpectedValue);
				}							
		}
			else
			{
				result = false;
				log(FAIL, "Validate planOptionName text in XML", "Not able to find the planOptionName in the XML");
			}
		}
		catch(Exception e)
		{
			throw e;
		}
		return result;
	}
	
	/**
	 * This method fetches the plan option name text from xml
	 * 
	 * @param strXMLFile
	 * @param reqPlanOptionType
	 * @return
	 * @throws Exception
	 */
	public static String getPlanOptionType(String strXMLFile,String reqPlanOptionType) throws Exception
	{
		String planOptionName="";
		try{
			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			List<Node> nodes = document.selectNodes("//planOptionGroup/planOption");
			for (Node node : nodes) {
				String planOptionType = ((Element) (node.selectSingleNode("planOptionType"))).attributeValue("text");
				if(planOptionType.equalsIgnoreCase(reqPlanOptionType))
				{
					planOptionName = ((Element)(node.selectSingleNode("planOptionName"))).attributeValue("text");
					break;
				}				
			}
		}
		catch(Exception e)
		{
			throw e;
		}
		return planOptionName;
	}
	
	
	public static String getAccumulatorDetail(String strXMLFile, String strPlanOptionType, String strAccumulatorText, String strAccumulatorNode,String strAccumAttribute ) throws Exception
	{
		String straccumulatorAttributeValue = "";
		String stepName = "Fetch the attribute"+strAccumAttribute+" for accumulator "+strAccumulatorText+" ";
		try{
			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			List<Node> nodes = document.selectNodes("//planOptionGroup/planOption");
			for (Node node : nodes) {
				boolean planOptionFound = false;
				String planOptionType = ((Element) (node.selectSingleNode("planOptionType"))).attributeValue("text");
				if(planOptionType.equalsIgnoreCase(strPlanOptionType))
				{
					planOptionFound = true;
					boolean accumFound = false;
					List<Node>  accumGroupsNode = node.selectSingleNode("accumulatorGroups").selectSingleNode("accumulatorGroup")
							.selectSingleNode("accumulatorList").selectSingleNode("accumulators").selectNodes("accumulator");
					for (Node accumNodes : accumGroupsNode) {
						String straccumulatorType = ((Element)(accumNodes.selectSingleNode("accumulatorName"))).attributeValue("text");
						if(straccumulatorType.equalsIgnoreCase(strAccumulatorText))
						{
							accumFound = true;
							straccumulatorAttributeValue =  ((Element)(accumNodes.selectSingleNode(strAccumulatorNode))).attributeValue(strAccumAttribute);
							System.out.println(straccumulatorAttributeValue);
							break;
						}
						
					}
					stepName = "Parse the XML for accumulator "+strAccumulatorText;
					if(!accumFound)
					{
						RESULT_STATUS = false;
						log(FAIL, stepName, " Not able to find the accumulator");
					}
			}
				if(planOptionFound)
				{
					break;
				}	
			}
			stepName = "Fetch the attribute"+strAccumAttribute+" for accumulator "+strAccumulatorText+" ";
			if(straccumulatorAttributeValue.isEmpty())
			{
				RESULT_STATUS = false;
				log(FAIL, stepName, "Not able to find the attribute");
			}
		}
		
		catch(Exception e)
		{
			throw e;
		}
		return straccumulatorAttributeValue;
	}
	
	/**
	 * This method fetches the accumulator value from xml
	 * 
	 * @param strXMLFile
	 * @param planOption
	 * @param reqdAccumulator
	 * @param strCostShare
	 * @return
	 * @throws Exception
	 */
	public static HashMap<String,String> getAccumulatorType(String strXMLFile,String planOption,String reqdAccumulator,String strCostShare) throws Exception
	{
		HashMap<String, String> accumulatorValue=new HashMap<>();
		String choiceText="";
		String choiceValue="";

		try{
			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			List<Node> nodes = document.selectNodes("//planOptionGroup/planOption");
			for (Node node : nodes) {
				String planOptionType = ((Element) (node.selectSingleNode("planOptionType"))).attributeValue("text");
				if(planOptionType.equalsIgnoreCase(planOption))
				{
					List<Node> accumulatorListNode=node.selectSingleNode("accumulatorGroups").selectNodes("accumulatorGroup");
					for (Node accmulatorGroupNode : accumulatorListNode) {						
						List<Node> accumulatorNodes=accmulatorGroupNode.selectSingleNode("accumulatorList").selectSingleNode("accumulators").selectNodes("accumulator");
						for (Node accumulator : accumulatorNodes) {
							String accmulatorName = ((Element)(accumulator.selectSingleNode("accumulatorName"))).attributeValue("text");
							if(accmulatorName.equalsIgnoreCase(reqdAccumulator))
							{
								String accmulatorTypeValue = ((Element)(accumulator.selectSingleNode("accumulatorType"))).attributeValue("text");
								if(accmulatorTypeValue.equalsIgnoreCase(strCostShare))
								{
									choiceText=((Element)(accumulator.selectSingleNode(strCostShare.toLowerCase()+"Value"))).attributeValue("text");
									choiceValue=((Element)(accumulator.selectSingleNode(strCostShare.toLowerCase()+"Value"))).attributeValue("value");
									break;
								}
							}
						}
					}

				}
			}
			
			accumulatorValue.put("text", choiceText);
			accumulatorValue.put("value", choiceValue);
		}
		catch(Exception e)
		{
			throw e;
		}
		return accumulatorValue;
	}

	/**
	 * This method validates accumulator text and  value in xml with the expected values
	 * 
	 * @param strDownloadPath
	 * @param strNetwork
	 * @param strNetworkType
	 * @param strExpectedText
	 * @param strExpectedValue
	 * @param strCostShare
	 * @throws Exception
	 */
	public static boolean validateAccumulatorType(String strDownloadPath,String strNetwork, String strNetworkType,String strExpectedText,String strExpectedValue,String strCostShare) throws Exception
	{
		boolean result=false;
		try{
			HashMap<String, String> accumulatorValue=PlanXMLParser.getAccumulatorType(strDownloadPath, strNetwork,strNetworkType,strCostShare);
			String actualChoiceText=accumulatorValue.get("text");
			String actualChoiceValue=accumulatorValue.get("value");
			if(actualChoiceText!=null)
			{
				if(actualChoiceText.equalsIgnoreCase(strExpectedText))
				{
					result = true;
					log(PASS, "Validate accumulator text in XML", "Actual text "+actualChoiceText+" is equal to Expected value "+strExpectedText);
				}
				else
				{
					result = false;
					log(FAIL, "Validate accumulator text in XML", "Actual text "+actualChoiceText+" is equal to Expected value "+strExpectedText);
				}
			}
			else
			{
				result = false;
				log(FAIL, "Validate accumlator text in XML", "Not able to find the accumlator in the XML");
			}
			if(actualChoiceValue!=null)
			{
				if(actualChoiceValue.equalsIgnoreCase(strExpectedValue))
				{
					result = true;
					log(PASS, "Validate accumulator value in XML", "Actual text "+actualChoiceValue+" is equal to Expected value "+strExpectedValue);
				}
				else
				{
					result = false;
					log(FAIL, "Validate accumulator value in XML", "Actual text "+actualChoiceValue+" is equal to Expected value "+strExpectedValue);
				}
			}
			else
			{
				result = false;
				log(FAIL, "Validate accumlator text in XML", "Not able to find the accumlator in the XML");
			}		
		}
		catch(Exception e)
		{
			throw e;
		}
	return result;	
	}
	
	public static String getOOPValue(String strXMLFile,String planOption,String reqdAccumulator) throws Exception
	{
		String applyToXrefAccum="";
		try{
			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			List<Node> nodes = document.selectNodes("//planOptionGroup/planOption");
			for (Node node : nodes) {
				String planOptionType = ((Element) (node.selectSingleNode("planOptionType"))).attributeValue("text");
				if(planOptionType.equalsIgnoreCase(planOption))
				{
					List<Node> accumulatorListNode=node.selectSingleNode("accumulatorGroups").selectNodes("accumulatorGroup");
					for (Node accmulatorGroupNode : accumulatorListNode) {						
						List<Node> accumulatorNodes=accmulatorGroupNode.selectSingleNode("accumulatorList").selectSingleNode("accumulators").selectNodes("accumulator");
						for (Node accumulator : accumulatorNodes) {
							String accmulatorName = ((Element)(accumulator.selectSingleNode("accumulatorName"))).attributeValue("text");
							if(accmulatorName.equalsIgnoreCase(reqdAccumulator))
							{
								applyToXrefAccum = ((Element)(accumulator.selectSingleNode("applyToXrefAccum"))).getText();
								break;
							}
						}
					}

				}
			}
		}
		catch(Exception e)
		{
			throw e;
		}
		return applyToXrefAccum;
	}
	public static HashMap<String,String> getAccumulator(String strXMLFile,String planOption,String reqdAccumulator) throws Exception
	{
		String benefitPeriod="";
		String accmulatorTypeValue="";
		String unitCode="";
		HashMap<String, String> accumulatorValue=new HashMap<>();
		try{
			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			List<Node> nodes = document.selectNodes("//planOptionGroup/planOption");
			for (Node node : nodes) {
				String planOptionType = ((Element) (node.selectSingleNode("planOptionType"))).attributeValue("text");
				if(planOptionType.equalsIgnoreCase(planOption))
				{
					List<Node> accumulatorListNode=node.selectSingleNode("accumulatorGroups").selectNodes("accumulatorGroup");
					for (Node accmulatorGroupNode : accumulatorListNode) {						
						List<Node> accumulatorNodes=accmulatorGroupNode.selectSingleNode("accumulatorList").selectSingleNode("accumulators").selectNodes("accumulator");
						for (Node accumulator : accumulatorNodes) {
							String accmulatorName = ((Element)(accumulator.selectSingleNode("accumulatorName"))).attributeValue("text");
							if(accmulatorName.equalsIgnoreCase(reqdAccumulator))
							{
								accmulatorTypeValue = ((Element)(accumulator.selectSingleNode("accumulatorType"))).attributeValue("text");
								if(accmulatorTypeValue.equalsIgnoreCase("Unit"))
									unitCode=((Element)(accumulator.selectSingleNode("unitCode"))).attributeValue("text");
								benefitPeriod=((Element)(accumulator.selectSingleNode("benefitPeriod"))).attributeValue("text");
								break;
							}
						}
					}

				}
			}
			accumulatorValue.put("accmulatorTypeValue", accmulatorTypeValue);
			accumulatorValue.put("unitCode", unitCode);
			accumulatorValue.put("benefitPeriod", benefitPeriod);
		}
		catch(Exception e)
		{
			throw e;
		}
		return accumulatorValue;
	}

	public static void validateAdminMethod(String strAdminMethod, String strValue, String strXMLFilePath) throws Exception
	{
		try
		{
			File file = new File(strXMLFilePath);
			System.out.println(file.exists());
			SAXReader reader = new SAXReader();
			org.dom4j.Document document = reader.read(file);
			List<Node> nodes = document.selectNodes("//adminMethodList/AdminMethodData/adminMethodType[@text='"+strAdminMethod+"']");
			if(nodes.size()>0)
			{
			for (Node node : nodes) {
				node = node.getParent();
				String adminMethodTypeText = ((Element) (node.selectSingleNode("value"))).getText();
				if(!adminMethodTypeText.equalsIgnoreCase(strValue))
				{
					String strSituationType = "";
					String strBenefit = "";
					while(!node.getName().equalsIgnoreCase("benefitTypeCoverage"))
					{
						node = node.getParent();
						System.out.println(node.getName());
						
						if(node.getName().equalsIgnoreCase("calculationSituation"))
						{
							strSituationType = ((Element) (node.selectSingleNode("situationType"))).attributeValue("text");
						}
						else if (node.getName().equalsIgnoreCase("benefitTypeCoverage"))
						{
						strBenefit = ((Element) (node.selectSingleNode("benefitLevel"))).attributeValue("text");
						}
					}
					RESULT_STATUS = false;
					log(FAIL, "Validate admin method value for "+strAdminMethod,"Admin method value is not as expected \""+strValue+"\" for \"situation type\" :"
							+ "\""+strSituationType+"\" for \"benefit\" : \""+strBenefit+"\" with a value of \""+adminMethodTypeText+"\"" );
				}
				

			}
			if(RESULT_STATUS)
			{
				log(PASS, "Validate admin method value for "+strAdminMethod,"All the benefits have the admin method value as expected" );
			}
			}
			else {
				log(FAIL, "Validate admin method value for "+strAdminMethod,"Not able to find the admin method in the XML" );
			}
			
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	}
	
	public static void validateAdminMethodID(String strAdminMethod,String stradminMethodID, String strXMLFilePath) throws Exception
	{
		try
		{
			File file = new File(strXMLFilePath);
			System.out.println(file.exists());
			SAXReader reader = new SAXReader();
			org.dom4j.Document document = reader.read(file);
			List<Node> nodes = document.selectNodes("//adminMethodList/AdminMethodData/adminMethodType[@text='"+strAdminMethod+"']");
			if(nodes.size()>0)
			{
			for (Node node : nodes) {
				node = node.getParent();
				String adminMethodIDText = ((Element) (node.selectSingleNode("adminMethodIdType"))).attributeValue("text");
				
				if(!adminMethodIDText.equalsIgnoreCase(stradminMethodID))
				{
					String strSituationType = "";
					String strBenefit = "";
					while(!node.getName().equalsIgnoreCase("benefitTypeCoverage"))
					{
						node = node.getParent();
						if(node.getName().equalsIgnoreCase("calculationSituation"))
						{
							strSituationType = ((Element) (node.selectSingleNode("situationType"))).attributeValue("text");
						}
						else if (node.getName().equalsIgnoreCase("benefitTypeCoverage"))
						{
						strBenefit = ((Element) (node.selectSingleNode("benefitLevel"))).attributeValue("text");
						}
					}
					RESULT_STATUS = false;
					log(FAIL, "Validate admin method ID for "+strAdminMethod,"Admin method value is not as expected \""+stradminMethodID+"\" for \"situation type\" :"
							+ "\""+strSituationType+"\" for \"benefit\" : \""+strBenefit+"\" with an actual  value of \""+adminMethodIDText+"\"" );
				}


			}
			if(RESULT_STATUS)
			{
				log(PASS, "Validate admin method ID for "+strAdminMethod,"All the benefits have the admin method ID as expected" );
			}
			}
			else {
				log(FAIL, "Validate admin method ID for "+strAdminMethod,"Not able to find the admin method in the XML" );
			}
			
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	}
	
	/**This Method will Validate the Accumulator in XML For Limitation
	 * @param strPath : Path of XML
	 * @param accumulator : Accumulator
	 * @param strAccumulatorTypeValue : calc AccumulatorType passed from the DataSheet
	 * @param strAccumulatorName
	 * @param strBenefitPeriod
	 * @param strUnitCode
	 */
	public static void validateLimitationAccumulator(String strPath,String accumulator,String strAccumulatorTypeValue,String strAccumulatorName,String strBenefitPeriod,String strUnitCode){
		try{
         HashMap<String, String> acumulatorValue= PlanXMLParser.getAccumulator(strPath, accumulator, strAccumulatorName);
         String accmulatorTypeValue = acumulatorValue.get("accmulatorTypeValue").toString().trim();
         String unitCode=acumulatorValue.get("unitCode").toString().trim();
         String benefitPeriod = acumulatorValue.get("benefitPeriod").toString().trim();
         if(accmulatorTypeValue.equalsIgnoreCase(strAccumulatorTypeValue)){
            	log(PASS, "Validate AcumulatorType", "AcumulatorType is displaying correctly as "+accmulatorTypeValue);
            }
            else{
            	log(FAIL, "Validate AcumulatorType", "AcumulatorType is not displaying correctly as "+accmulatorTypeValue);
            }
            if(benefitPeriod.contains(strBenefitPeriod)){
            	log(PASS, "Validate Benefit Period", "Benefit Period is displaying correctly as "+strBenefitPeriod);
            }
            else{
            	log(FAIL, "Validate Benefit Period", "Benefit Period is not displaying correctly as "+strBenefitPeriod);
            }
            if(strUnitCode.contains(strUnitCode)){
            	log(PASS, "Validate Unit Code", "Unit Code is displaying correctly as "+unitCode);
            }
            else{
            	log(FAIL, "Validate Unit Code", "Unit Code is not displaying correctly as "+unitCode);
		}
		}
         catch (Exception e) {
 			e.printStackTrace();
 		}
	}
	
	
	public static String getAccumulatorAmount(String strXMLFile,String planOption,String reqdAccumulator,String accumulatorType) throws Exception
    {
           String Amount="";
           String accmulatorTypeValue="";
                      try{
        	   
                  File inputFile = new File(strXMLFile);
                  SAXReader reader = new SAXReader();
                  Document document = reader.read(inputFile);
                  List<Node> nodes = document.selectNodes("//planOptionGroup/planOption");
                  for (Node node : nodes) {
                         String planOptionType = ((Element) (node.selectSingleNode("planOptionType"))).attributeValue("text");
                        if(planOptionType.equalsIgnoreCase(planOption))
                        {
                               List<Node> accumulatorListNode=node.selectSingleNode("accumulatorGroups").selectNodes("accumulatorGroup");
                               for (Node accmulatorGroupNode : accumulatorListNode) {                                   
                                      List<Node> accumulatorNodes=accmulatorGroupNode.selectSingleNode("accumulatorList").selectSingleNode("accumulators").selectNodes("accumulator");
                                      for (Node accumulator : accumulatorNodes) {
                                             String accmulatorName = ((Element)(accumulator.selectSingleNode("accumulatorName"))).attributeValue("text");
                                             if(accmulatorName.equalsIgnoreCase(reqdAccumulator))
                                             {
                                                    accmulatorTypeValue = ((Element)(accumulator.selectSingleNode("accumulatorType"))).attributeValue("text");
                                                    switch (accumulatorType) {
                                                    case "Copayment":
                                                           Amount=((Element)(accumulator.selectSingleNode("amount"))).getText();
                                                           break;
                                                    case "CopaymentMax":
                                                           Amount=((Element)(accumulator.selectSingleNode("individualMax"))).getText();
                                                           break;
                                                    case "Deductible":
                                                           Amount=((Element)(accumulator.selectSingleNode("individualMax"))).getText();
                                                           break;
                                                           
                                                    case "Coinsurance":
                                                           Amount=((Element)(accumulator.selectSingleNode("percentage"))).getText();
                                                           break;
                                                    case "Dollar Limit":
                                                           Amount=((Element)(accumulator.selectSingleNode("individualMax"))).getText();
                                                           
                                                           break;
                                                    case "Unit":
                                                           Amount=((Element)(accumulator.selectSingleNode("individualUnits"))).getText();
                                                           break;
                                                           
                                                    case "Penalty":
                                                        Amount=((Element)(accumulator.selectSingleNode("individualMax"))).getText();
                                                        break;    

                                                    default:
                                                           break;
                                                    }
                                                  System.out.println(Amount);  
                                                    
                                             }
                                      }
                               }

                        }
                  }

           }
           catch(Exception e)
           {
                  throw e;
           }
           return Amount;
    }  
	
	public static void validatePlanStatus(String strXMLFile){
		String strplanStatusType="";
		try {
			File inputFile = new File(strXMLFile);
            SAXReader reader = new SAXReader();
            Document document = reader.read(inputFile);
            Node node=document.selectSingleNode("//plan");
            strplanStatusType = ((Element) (node.selectSingleNode("planStatusType"))).attributeValue("text");
            if(strplanStatusType.equalsIgnoreCase("Processing in Progress")){
            	log(PASS, "Validate Plan Status in XML", "Plan Status is as expected "+strplanStatusType);
            }
            else{
            	log(PASS, "Validate Plan Status in XML", "Plan Status is not as expected "+strplanStatusType);
            }
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public static  String getPlanID(String strLOB, String strXMLPath) throws Exception
	{
		String strPlanID = "";
		try
		{
			boolean booPlanLOBFound = false;
			File file = new File(strXMLPath);
			SAXReader reader = new SAXReader();
			org.dom4j.Document document = reader.read(file);
			List<Node> nodes = document.selectNodes("//plans/planStub");
			System.out.println(nodes.size());
			for (Node node : nodes) {
				Element lob = (Element) (node.selectSingleNode("lob"));
				if(lob!= null)
				{
					String lobValue = lob.attributeValue("name");
					if(lobValue.equalsIgnoreCase(strLOB))
					{
						booPlanLOBFound = true;
						strPlanID = ((Element) (node)).attributeValue("planId");
						break;
					}
				}

			}
			if(booPlanLOBFound)
			{
				RESULT_STATUS = true;
				log(PASS, "Get Plan ID from the response XML for LOB"+strLOB, "Plan ID: "+strPlanID+" found in the response XML");

			}
			else
			{
				RESULT_STATUS = false;
				log(FAIL, "Get Plan ID from the response XML for LOB"+strLOB, "Plan ID: not found in the response XML for the given LOB");
			}

		}
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Exception occured in the get plan id from the web service response"+e.getLocalizedMessage());
		}
		return strPlanID;
	}

	public static HashMap<String, String> getOptions(String strXMLFile,String optionType) throws Exception
	{
		String planOptionName=null;
		HashMap<String, String> planOptions=new HashMap<>();
		try
		{			
			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			List<Node> nodes = document.selectNodes("//planOptionAreaMap/planOptionList");
			for(Node node : nodes)
			{
				String area=((Element) (node.selectSingleNode("area"))).attributeValue("text");
				if(area.equalsIgnoreCase(optionType))
				{
					List<Node> nodeValue=node.selectSingleNode("optionGroups").selectNodes("planOptionGroup");
					int i=0;
					for (Node optionNode : nodeValue) {	
						i=i+1;							
						planOptionName=((Element) (optionNode.selectSingleNode("planOption").selectSingleNode("planOptionType"))).attributeValue("text");
						System.out.println(planOptionName);
						planOptions.put(planOptionName+i, planOptionName);
					}		
				}
			}			
		}
		catch(Exception e)
		{
			throw e;
		}
		return planOptions;
	}
	
	public static HashMap<String, String> getChildNodes(String strXMLFile,String expChildBenefit) throws Exception
	{
		String childrenNode = null;
		HashMap<String, String> childBenefits=new HashMap<>();
		try
		{			

			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			List<Node> nodes = document.selectNodes("//benefitTypeCoverage");				
			for (Node node : nodes) {								
				List<Node> child=node.selectNodes("//benefitTypeCoverage");
				for(Node childNode:child){
					String childBenefit = ((Element) (childNode.selectSingleNode("benefitLevel"))).attributeValue("text");
					if(childBenefit.equalsIgnoreCase(expChildBenefit))
					{
						List<Node> childNodes=childNode.selectSingleNode("childBenefits").selectNodes("benefitTypeCoverage");	
						int i=0;
						for (Node childrenNodes : childNodes) {	
							i=i+1;
							if(!childrenNodes.equals(null)){
							childrenNode=((Element) (childrenNodes.selectSingleNode("benefitLevel"))).attributeValue("text");
							childBenefits.put(childrenNode+i, childrenNode);
							}
							else
							{
								log(FAIL,"No Child Nodes are present","No Children nodes are present for given benefit");
							}
						}
					}
				}
			}				
		}
		catch(Exception e)
		{
			throw e;
		}
		return childBenefits;
	}
	
	public static HashMap<String, String> getParentAndChildNodes(String strXMLFile,String expectedParentBenefit) throws Exception
	{
		String childrenNode = null;
		String parentBenefit=null;
		HashMap<String, String> Benefits=new HashMap<>();
		try
		{			
			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			List<Node> nodes = document.selectNodes("//benefitTypeCoverages");				
			for (Node node : nodes) {
				List<Node> parent=node.selectNodes("//benefitTypeCoverage");
				int i=0;
				for(Node parentNode:parent){
					i=i+i;
					parentBenefit = ((Element) (parentNode.selectSingleNode("benefitLevel"))).attributeValue("text");
					Benefits.put(parentBenefit+i, parentBenefit);
					System.out.println(parentBenefit);
					if(!expectedParentBenefit.isEmpty() || !expectedParentBenefit.equalsIgnoreCase(null)){
						if(parentBenefit.equalsIgnoreCase(expectedParentBenefit)){
							List<Node> childNodes=parentNode.selectSingleNode("childBenefits").selectNodes("benefitTypeCoverage");
							int j=0;
							for (Node childrenNodes : childNodes) {	
								j=j+1;
								if(!childrenNodes.equals(null)){
									childrenNode=((Element) (childrenNodes.selectSingleNode("benefitLevel"))).attributeValue("text");
									Benefits.put(childrenNode+j, childrenNode);
									System.out.println(childrenNode);
								}
								else
								{
									log(FAIL,"No Child Nodes are present","No Children nodes are present for given benefit");
								}	
							}

						}
					}
					else
					{
						List<Node> childNodes=parentNode.selectSingleNode("childBenefits").selectNodes("benefitTypeCoverage");
						int j=0;
						for (Node childrenNodes : childNodes) {	
							j=j+1;
							if(!childrenNodes.equals(null)){
								childrenNode=((Element) (childrenNodes.selectSingleNode("benefitLevel"))).attributeValue("text");
								Benefits.put("childBenefits"+j, childrenNode);
								System.out.println(childrenNode);
							}
							else
							{
								log(FAIL,"No Child Nodes are present","No Children nodes are present for given benefit");
							}	
						}
					}

				}
			}

		}
		catch(Exception e)
		{
			throw e;
		}
		return Benefits;
	}

	public static HashMap<String, String> getAllSituations(String strXMLFile,String expBenefit) throws Exception
	{
		HashMap<String, String> situations=new HashMap<>();
		try
		{                                        
			Node benefitNode=PlanXMLParser.getBenefitNode(expBenefit, strXMLFile);
			List<Node> benefit=benefitNode.selectSingleNode("situationGroups").selectNodes("situationGroup"); 
			int j=0;
			for(Node situationGroup:benefit)
			{                                        
				List<Node> situationgrp = situationGroup.selectNodes("calculationSituation"); 

				for(Node situationType:situationgrp)
				{
					String situationTypeValue=((Element) (situationType.selectSingleNode("situationType"))).attributeValue("text");
					System.out.println("Lower Child " +situationTypeValue);
					situations.put("situation "+j, situationTypeValue); 
					j++;
				}                                                                           
			}

		}
		catch(Exception e)
		{
			throw e;
		}

		return situations;
	}
	public static HashMap<String, String> getAccumlatorValue(String strXMLFile,String expBenefit) throws Exception
	{
		HashMap<String, String> accumulatorValues=new HashMap<>();
		String Amount="";
		try
		{
			Node benefitNode=PlanXMLParser.getBenefitNode(expBenefit, strXMLFile);
			List<Node> benefit=benefitNode.selectSingleNode("situationGroups").selectNodes("situationGroup");   

			for(Node situationGroup:benefit)
			{                                        
				List<Node> situationgrp = situationGroup.selectNodes("calculationSituation");
				for(Node calc:situationgrp){
					List<Node> calculationNode=calc.selectNodes("calculationGroups");

					for(Node calculationGrps: calculationNode){                   
						List<Node> calculationgrp=calculationGrps.selectSingleNode("calculationGroup").selectSingleNode("calculation").selectSingleNode("steps").selectNodes("calculationStep");

						for(Node accumulator:calculationgrp)
						{
							List<Node> accum=accumulator.selectNodes("accumulator");
							for(Node accumulatorlevel:accum){
								String accumulatoreName=((Element) (accumulatorlevel.selectSingleNode("accumulatorName"))).attributeValue("text");
								System.out.println(accumulatoreName);
								//accumulatorValues.put("Accumulator Name "+j, accumulatoreName);
								String accumulatorValue=((Element) (accumulatorlevel.selectSingleNode("accumulatorType"))).attributeValue("text");
								System.out.println(accumulatorValue);
								switch (accumulatorValue) {
								case "Copayment":
									Amount=((Element) (accumulatorlevel.selectSingleNode("accumulatorType"))).getText();
									System.out.println(Amount);
									accumulatorValues.put(accumulatoreName, Amount);
									break;
								case "CopaymentMax":
									Amount=((Element)(accumulatorlevel.selectSingleNode("individualMax"))).getText();
									System.out.println(Amount);
									accumulatorValues.put(accumulatoreName, Amount);
									break;
								case "Deductible":
									Amount=((Element)(accumulatorlevel.selectSingleNode("individualMax"))).getText();
									System.out.println(Amount);
									accumulatorValues.put(accumulatoreName, Amount);
									break;
								case "Coinsurance":
									Amount=((Element)(accumulatorlevel.selectSingleNode("percentage"))).getText();
									System.out.println(Amount);
									accumulatorValues.put(accumulatoreName, Amount);
									break;
								case "Dollar Limit":
									Amount=((Element)(accumulatorlevel.selectSingleNode("individualMax"))).getText();
									System.out.println(Amount);
									accumulatorValues.put(accumulatoreName, Amount);
									break;
								case "Unit":
									Amount=((Element)(accumulatorlevel.selectSingleNode("individualUnits"))).getText();
									System.out.println(Amount);
									accumulatorValues.put(accumulatoreName, Amount);
									break;

								default:
									break;
								}
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			throw e;
		}

		return accumulatorValues;
	}
	
	public static boolean validateBenefits(String strXMLFile) throws Exception
	{
		boolean result=false;
		try
		{                    

			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			List<Node> nodes = document.selectNodes("//benefitTypeCoverages");                       
			for (Node node : nodes) {                                                  
				List<Node> benefit=node.selectNodes("//benefitTypeCoverage");
				if(!(benefit.size()>0)){
					result=true;
				}
				else{
					result=false;
				}

			}                          
		}
		catch(Exception e)
		{
			throw e;
		}
      return result;
	} 
	
	public static void validatePlanBenefitOptions(ArrayList<String> optionTypeSpider,HashMap<String, String> OptionTypeXML,String OptionType){
		try{
			for (String expChildBenefits : optionTypeSpider) 
			{
				String actualChildBenefit=""; 
				boolean isFound=false;
				for (Map.Entry<String, String> entry : OptionTypeXML.entrySet())
				{
					actualChildBenefit=entry.getValue(); 
					{
						if(actualChildBenefit.contains(expChildBenefits))
						{
							isFound=true;
							RESULT_STATUS=true;
							log(PASS,OptionType+" is found for :"+expChildBenefits,expChildBenefits +"is Equal to :"+actualChildBenefit);
						}
					}                                                      

				}
				if(!isFound)
				{
					RESULT_STATUS=false;
					log(FAIL,OptionType+" is not found for :"+expChildBenefits,expChildBenefits +"is not Equal to :"+actualChildBenefit);
				}

			}
		}
		catch(Exception e)
		{
			throw e;
		}
	}
	
	public static HashMap<String,String> validatePlanOptionType(String strXMLFile) throws Exception
	{
		HashMap<String,String> POT=new HashMap<String,String>();
		String planOptionType="";
		try{
			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			List<Node> nodes = document.selectNodes("//planOptionGroup/planOption");
			for (Node node : nodes) {
				planOptionType = ((Element) (node.selectSingleNode("planOptionType"))).attributeValue("value");	
				POT.put(planOptionType, planOptionType);
			}
		}
		catch(Exception e)
		{
			throw e;
		}
		return POT;
	}

	public static HashMap<String,String> validateAccumulatorGroupType(String strXMLFile,String reqPlanOptionType) throws Exception
	{
		HashMap<String,String> accumGroupType=new HashMap<String,String>();
		String accmulator = "";
		try{
			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			List<Node> nodes = document.selectNodes("//planOptionGroup/planOption");
			for (Node node : nodes) {
				String planOptionType = ((Element) (node.selectSingleNode("planOptionType"))).attributeValue("value");
				if(planOptionType.equalsIgnoreCase(reqPlanOptionType))
				{
					List<Node> accumulatorListNode=node.selectSingleNode("accumulatorGroups").selectNodes("accumulatorGroup");
					for (Node accmulatorGroupNode : accumulatorListNode) {	
						accmulator= ((Element)(accmulatorGroupNode.selectSingleNode("accumulatorList").selectSingleNode("groupType"))).attributeValue("value");
						accumGroupType.put(accmulator, accmulator);
					}
				}				
			}
		}
		catch(Exception e)
		{
			throw e;
		}
		return accumGroupType;
	}

	public static HashMap<String,String> validateAccumulatorGroupName(String strXMLFile,String reqPlanOptionType) throws Exception
	{
		HashMap<String,String> accumGroupName=new HashMap<String,String>();
		String accmulatorName = "";
		try{
			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			List<Node> nodes = document.selectNodes("//planOptionGroup/planOption");
			for (Node node : nodes) {
				String planOptionType = ((Element) (node.selectSingleNode("planOptionType"))).attributeValue("value");
				if(planOptionType.equalsIgnoreCase(reqPlanOptionType))
				{
					List<Node> accumulatorListNode=node.selectSingleNode("accumulatorGroups").selectNodes("accumulatorGroup");
					for (Node accmulatorGroupNode : accumulatorListNode) {						
						List<Node> accumulatorNodes=accmulatorGroupNode.selectSingleNode("accumulatorList").selectSingleNode("accumulators").selectNodes("accumulator");
						for (Node accumulator : accumulatorNodes) {
							accmulatorName = ((Element)(accumulator.selectSingleNode("accumulatorName"))).attributeValue("value");	
							accumGroupName.put(accmulatorName, accmulatorName);
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			throw e;
		}
		return accumGroupName;
	}
	
	public static String validateClaimsAccumName(String strXMLFile,String reqPlanOptionType,String strAccumName) throws Exception
	{
		String claimsAccumName = "";
		try{
			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			List<Node> nodes = document.selectNodes("//planOptionGroup/planOption");
			for (Node node : nodes) {
				String planOptionType = ((Element) (node.selectSingleNode("planOptionType"))).attributeValue("value");
				if(planOptionType.equalsIgnoreCase(reqPlanOptionType))
				{
					List<Node> accumulatorListNode=node.selectSingleNode("accumulatorGroups").selectNodes("accumulatorGroup");
					for (Node accmulatorGroupNode : accumulatorListNode) {						
						List<Node> accumulatorNodes=accmulatorGroupNode.selectSingleNode("accumulatorList").selectSingleNode("accumulators").selectNodes("accumulator");
						for (Node accumulator : accumulatorNodes) {
							String accmulatorName = ((Element)(accumulator.selectSingleNode("accumulatorName"))).attributeValue("value");
							if(accmulatorName.equalsIgnoreCase(strAccumName))
							{
								claimsAccumName=((Element)(accumulator.selectSingleNode("claimsAccumulatorName"))).attributeValue("value");	
								break;
							}
						}						
					}
				}
			}
		}
		catch(Exception e)
		{
			throw e;
		}
		return claimsAccumName;
	}
	public static void validateProductFamily(String strXMLFile,String strProductFamily) throws Exception{
		String strproductFamilyType="";
		try {
			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			Node node=document.selectSingleNode("//plan");
			strproductFamilyType = ((Element) (node.selectSingleNode("productFamilyType"))).attributeValue("text");
			if(strproductFamilyType.equalsIgnoreCase(strProductFamily)){
				log(PASS, "Validate Plan Product Family in XML", "Plan Product Family is as expected "+strproductFamilyType);
			}
			else{
				log(FAIL, "Validate Plan Product Family in XML", "Plan Product Family is not as expected "+strproductFamilyType);
			}
		} catch (Exception e) {
			throw e;
		}
	}

	public static void validateState(String strXMLFile,String strState) throws Exception{
		String State="";
		try {
			File inputFile = new File(strXMLFile);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			Node node=document.selectSingleNode("//plan");
			State = ((Element) (node.selectSingleNode("state"))).attributeValue("text");
			if(State.equalsIgnoreCase(strState)){
				log(PASS, "Validate State in XML", "State is as expected "+State);
			}
			else{
				log(FAIL, "Validate State in XML", "State is not as expected "+State);
			}
		} catch (Exception e) {
			throw e;
		}
	}

}
