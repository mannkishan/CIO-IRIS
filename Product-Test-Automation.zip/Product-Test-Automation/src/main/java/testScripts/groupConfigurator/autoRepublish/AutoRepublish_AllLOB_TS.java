package testScripts.groupConfigurator.autoRepublish;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.w3c.dom.Document;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.groupConfigurator.AutoRepublishPage;
import page.groupConfigurator.ContractSearchPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MasterProductAndLegacyPlanOptionsXMLPage;
import page.planConfigurator.PlanHeaderPage;
import utility.CoreSuperHelper;
import utility.WebTable;

public class AutoRepublish_AllLOB_TS extends CoreSuperHelper
{
	static String strPcURL = EnvHelper.getValue("pc.url");
	static String strGcURL=EnvHelper.getValue("gc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	
	public static void main(String[] args) {
		try {
			initiateTestScript();


						try {
							logExtentReport("Test Script/ Functionality Descrtiption");
							seOpenBrowser(BrowserConstants.Chrome, strGcURL);
							page.groupConfigurator.LoginPage.get().loginApplication(strUserProfile);
							seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(ContractSearchPage.get().createNewContract));
							String contract="334R";
							String PcDate;
							ContractSearchPage.get().seSearchContract(contract);
							waitForPageLoad();
							WebElement wb=driver.findElement(By.xpath("(//tbody/tr/td/a[contains(text(),'Production')]/..)[1]"));
                            Actions act=new Actions(driver);
                            act.moveToElement(wb).click(wb).build().perform();
                            WebElement Medical=driver.findElement(By.xpath("//div/div/span[text()='Medical']/../../div[@class='offerDetPlanBoxContents']/div//div/div"));
							String MedicalPlan=Medical.getText();
							WebElement Dental=driver.findElement(By.xpath("//div/div/span[text()='Dental']/../../div[@class='offerDetPlanBoxContents']/div//div/div"));
                            String DentalPlan=Dental.getText();
						    WebElement Vision=driver.findElement(By.xpath("//div/div/span[text()='Vision']/../../div[@class='offerDetPlanBoxContents']/div//div/div"));
							String VisionPlan=Vision.getText();
							WebElement Pharamacy=driver.findElement(By.xpath("//div/div/span[text()='Pharmacy']/../../div[@class='offerDetPlanBoxContents']/div//div/div"));
							String PharmacyPlan=Pharamacy.getText();
							System.out.println(MedicalPlan);
							System.out.println(DentalPlan);
							System.out.println(VisionPlan);
							System.out.println(PharmacyPlan);
							
							 seCloseBrowser();
							 seOpenBrowser(BrowserConstants.Chrome, strPcURL);
								LoginPage.get().loginApplication(strUserProfile);
								waitForPageLoad();
	                            
							 String MedicalPlanId=AutoRepublishPage.get().seAutoRepublish_RequestAudit(contract, MedicalPlan, 50);
								String DentalPlanId=AutoRepublishPage.get().seAutoRepublish_RequestAudit(contract, DentalPlan,100);
								String PharmacyPlanId=AutoRepublishPage.get().seAutoRepublish_RequestAudit(contract, PharmacyPlan,100);
								String VisionPlanId=AutoRepublishPage.get().seAutoRepublish_RequestAudit(contract, VisionPlan,100);
								 seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
									waitForPageLoad();
									seClick(PlanHeaderPage.get().userLogout, "Logout");
									waitForPageLoad(); 
									seCloseBrowser();
									seOpenBrowser(BrowserConstants.Chrome, strPcURL);							
							            LoginPage.get().loginApplication(strUserProfileApprover);
								     	waitForPageLoad();
									    PlanHeaderPage.get().seMovePlanToSentToTest(MedicalPlanId);
									    PlanHeaderPage.get().seMovePlanToSentToTest(DentalPlanId);
									    PlanHeaderPage.get().seMovePlanToSentToTest(PharmacyPlanId);
									    PlanHeaderPage.get().seMovePlanToSentToTest(VisionPlanId);
                                seCloseBrowser();
								seOpenBrowser(BrowserConstants.Chrome, strGcURL);
								page.groupConfigurator.LoginPage.get().loginApplication(strUserProfile);
								ContractSearchPage.get().seSearchContract(contract);
								WebTable searchResults = new WebTable(ContractSearchPage.get().searchResults, "Contract Search Results");
								if(searchResults.getRowsCount()>0)
								{
									java.util.List<WebElement> ContractName = getWebDriver().findElements(By.xpath("//*[@id=\"groupResults\"]/table[2]/tbody/tr/td[2]/a"));
									Set<String> Names=new LinkedHashSet<>();

								try{	for(int i=0;i<6;i++)
									{
										String textName = ContractName.get(i).getText().trim();
										Names.add(textName);
										System.out.println(Names);
									}}catch(Exception e){}
									Iterator<String> i=Names.iterator();
									while(i.hasNext()){
									String Name=i.next();
									ContractSearchPage.get().seSearchContract(Name);									
								try{	for(int k=1;k<15;k++){
										String status=getWebDriver().findElement(By.xpath("(//*[@id='groupResults']/table[2]/tbody/tr/td[3]/a)["+k+"]")).getText();
										System.out.println(status);
										if(status.replaceAll("\\s", "").contains("Production")||status.replaceAll("\\s", "").contains("Archived")){}
										else if(status.replaceAll("\\s", "").contains("SenttoTest")){
										log(PASS," Contract Name= "+Name,status);}
										else{
											log(FAIL, Name);}									
									}}catch(Exception e){}
									}
									}
									seCloseBrowser();
									 seOpenBrowser(BrowserConstants.Chrome, strPcURL);
					                    LoginPage.get().loginApplication(strUserProfileApprover);
										waitForPageLoad();
										String MedicalVersionID=PlanHeaderPage.get().seMovePlanSentToTest_To_Production(MedicalPlanId); 
										seClick(AutoRepublishPage.get().history,"history");
				                        waitForPageLoad();
										String MedicalDate=AutoRepublishPage.get().getRepublishedDate(MedicalVersionID);
										seClick(AutoRepublishPage.get().closehistory, "close history");
										seWaitForClickableWebElement(HomePage.get().find, 12);			
										String DentalVersionID=PlanHeaderPage.get().seMovePlanSentToTest_To_Production(DentalPlanId); 
										seClick(AutoRepublishPage.get().history,"history");
				                        waitForPageLoad();
										String DentalDate=AutoRepublishPage.get().getRepublishedDate(DentalVersionID);
										seClick(AutoRepublishPage.get().closehistory, "close history");
										seWaitForClickableWebElement(HomePage.get().find, 12);
										String VisionVersionID=PlanHeaderPage.get().seMovePlanSentToTest_To_Production(VisionPlanId); 
										seClick(AutoRepublishPage.get().history,"history");
				                        waitForPageLoad();
										String VisionDate=AutoRepublishPage.get().getRepublishedDate(VisionVersionID);
										seClick(AutoRepublishPage.get().closehistory, "close history");
										seWaitForClickableWebElement(HomePage.get().find, 12);
										String PharmacyVersionID=PlanHeaderPage.get().seMovePlanSentToTest_To_Production(PharmacyPlanId); 
										seClick(AutoRepublishPage.get().history,"history");
				                        waitForPageLoad();
										String PharmacyDate=AutoRepublishPage.get().getRepublishedDate(PharmacyVersionID);
									    seCloseBrowser();
				                        seOpenBrowser(BrowserConstants.Chrome, strGcURL);
										page.groupConfigurator.LoginPage.get().loginApplication(strUserProfile);
										seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(ContractSearchPage.get().createNewContract));
										waitForPageLoad();
										ContractSearchPage.get().seSearchContract(contract);
										seWaitForClickableWebElement(ContractSearchPage.get().searchResults, 120);
										WebTable searchResult1 = new WebTable(ContractSearchPage.get().searchResults, "Contract Search Results");
										if(searchResult1.getRowsCount()>0)
										{
											java.util.List<WebElement> ContractName1 = getWebDriver().findElements(By.xpath("//*[@id=\"groupResults\"]/table[2]/tbody/tr/td[2]/a"));
											Set<String> Names1=new LinkedHashSet<>();

										try{	for(int j=0;j<6;j++)
											{
												String textName = ContractName1.get(j).getText().trim();
												Names1.add(textName);
											}}catch(Exception e){}
											Iterator<String> j=Names1.iterator();
											while(j.hasNext()){
												String Name=j.next();
												ContractSearchPage.get().seSearchContract(Name);									
											try{	for(int k=1;k<4;k++){
													String status=getWebDriver().findElement(By.xpath("(//*[@id='groupResults']/table[2]/tbody/tr/td[3]/a)["+k+"]")).getText().trim();
		                                            if(status.replaceAll("\\s", "").contains("Production")||status.replaceAll("\\s", "").contains("Archived")||status.replaceAll("\\s", "").contains("PendingFinalization")){
													log(PASS," Contract Name= "+Name,status);}
													else{
														log(FAIL, Name);}									
												}}catch(Exception e){}
												}
											}
										waitForPageLoad();
										waitForPageLoad();
										WebElement wb2=driver.findElement(By.xpath("(//tbody/tr/td/a[contains(text(),'Production')]/..)[1]"));
			                            Actions act2=new Actions(driver);
			                            act2.moveToElement(wb2).click(wb2).build().perform();
			                            waitForPageLoad(12,32);
			                            String contractDate=driver.findElement(By.xpath("//span[contains(text(),'Effective Date')]")).getText().split(": ")[1];
			                            System.out.println(contractDate);
			                            seClick(driver.findElement(By.xpath("//span/span/a[@title='Show versions']")), "Version");
			                            waitForPageLoad();
			                            String GcTime=driver.findElement(By.xpath("//div[@id='versionTable']/table/tbody/tr[2]/td[6]")).getText();
		                               
			                            if(GcTime.contains(MedicalDate)&&GcTime.contains(VisionDate))
		                                {
		                                	log(PASS, MedicalDate,GcTime);
		                                }else{log(FAIL,MedicalDate,GcTime);}
		                             
			                            MasterProductAndLegacyPlanOptionsXMLPage.get().seFileDownloadXML(contract,
												"UAT", getReportPathFolder());
										
										String strXMLFileName = getReportPathFolder() + "UAT" + "_" + contract
										+ ".xml";
										
										DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
										DocumentBuilder builder = factory.newDocumentBuilder();
										Document doc = builder.parse(strXMLFileName);
										XPathFactory xPathfactory = XPathFactory.newInstance();
										XPath xpath = xPathfactory.newXPath();
										XPathExpression expr1 = xpath.compile("//planStub[@planName='"+MedicalPlan.trim()+"']/@proxyId");
										String strMedicalproxyIDXml=(String)expr1.evaluate(doc, XPathConstants.STRING);
										System.out.println(strMedicalproxyIDXml);
										XPathExpression expr2 = xpath.compile("//planStub[@planName='"+DentalPlan.trim()+"']/@proxyId");
										String strDentalproxyIDXml=(String)expr2.evaluate(doc, XPathConstants.STRING);
										System.out.println(strDentalproxyIDXml);
										XPathExpression expr3= xpath.compile("//planStub[@planName='"+VisionPlan.trim()+"']/@proxyId");
										String VisionproxyID=(String)expr3.evaluate(doc, XPathConstants.STRING);
										System.out.println(VisionproxyID);
										XPathExpression expr4= xpath.compile("//effectiveDate/text()");
										String ContractEffDate=(String)expr4.evaluate(doc, XPathConstants.STRING);
										System.out.println(ContractEffDate);
										XPathExpression expr5 = xpath.compile("//DateSegment/segment[@segmentEffectiveDate='"+ContractEffDate+"']/@segmentEffectiveDate");
										String SegmentEffDate=(String)expr5.evaluate(doc, XPathConstants.STRING);
										System.out.println(SegmentEffDate);
										XPathExpression expr6 = xpath.compile("//DateSegment/segment[@segmentEffectiveDate='"+ContractEffDate+"']/@medicalPlanId");
										String MedicalPlanIdXml=(String)expr6.evaluate(doc, XPathConstants.STRING);
										XPathExpression expr7 = xpath.compile("//DateSegment/segment[@segmentEffectiveDate='"+ContractEffDate+"']/@dentalPlanId");
										String DentalPlanIdXml=(String)expr7.evaluate(doc, XPathConstants.STRING);
										XPathExpression expr8 = xpath.compile("//DateSegment/segment[@segmentEffectiveDate='"+ContractEffDate+"']/@visionPlanId");
										String VisionPlanIdXml=(String)expr8.evaluate(doc, XPathConstants.STRING);

										 if(strMedicalproxyIDXml.equalsIgnoreCase(MedicalPlanId)){
			                                	log(PASS, "the contract id "+contract+" has Medical="+strMedicalproxyIDXml, MedicalPlanId);
			                                }
			                                else{log(FAIL,"failure");}
										 if(strDentalproxyIDXml.equalsIgnoreCase(DentalPlanId)){
			                                	log(PASS, "the contract id "+contract+" has dental="+strDentalproxyIDXml, DentalPlanId);
			                                }
			                                else{log(FAIL,"failure");}

			                                if(VisionPlanIdXml.trim().equalsIgnoreCase(VisionVersionID)){
			                                 	log(PASS, "the contract id "+contract+" has "+VisionPlanIdXml, VisionVersionID);
			                                }
			                                else{log(FAIL,VisionPlanIdXml,VisionVersionID);}
			                                
			                                if(SegmentEffDate.equals(ContractEffDate)){
			                                	log(PASS,SegmentEffDate,ContractEffDate);
			                                }else log(FAIL, "fail");
						} catch (Exception e) {
							e.printStackTrace();
							log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
						} finally {
							
							//seCloseBrowser();
						}
					
					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
				} finally {
					endTestScript();
				}

			}	
							
							
						}


