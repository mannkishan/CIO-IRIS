package testScripts.groupConfigurator.autoRepublish;


import java.awt.List;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.w3c.dom.Document;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.groupConfigurator.AutoRepublishPage;
import page.groupConfigurator.ContractInformationPage;
import page.groupConfigurator.ContractSearchPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MasterProductAndLegacyPlanOptionsXMLPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanSetupPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;
import utility.WebTable;

public class AutoRepublish_TS extends CoreSuperHelper
{
	static String strPcURL = EnvHelper.getValue("pc.url");
	static String strGcURL=EnvHelper.getValue("gc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	
	public static void main(String[] args) {
		try {
			initiateTestScript();


						try {
							logExtentReport("Test Script/ Functionality Descrtiption");
							seOpenBrowser(BrowserConstants.Chrome, strGcURL);
							page.groupConfigurator.LoginPage.get().loginApplication(strUserProfile);
							seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(ContractSearchPage.get().createNewContract));
							String contract="152W";
							String PcDate;
							String contractStatus="Production";
							ContractSearchPage.get().seSearchContract(contract);
							waitForPageLoad();
							WebElement wb=driver.findElement(By.xpath("(//tbody/tr/td/a[contains(text(),'"+contractStatus+"')]/..)[1]"));
                            Actions act=new Actions(driver);
                            act.moveToElement(wb).click(wb).build().perform();
                            WebElement wb1=driver.findElement(By.xpath("//div/div/span[text()='Medical']/../../div[@class='offerDetPlanBoxContents']/div//div/div"));
							String planName=wb1.getText();
							System.out.println(planName);
							
							seCloseBrowser();
							seOpenBrowser(BrowserConstants.Chrome, strPcURL);
							LoginPage.get().loginApplication(strUserProfile);
							waitForPageLoad();
                            
							   String proxyId= AutoRepublishPage.get().seAutoRepublish_Plan_SentToTest(contract, planName,250);   
							    seCloseBrowser();
								seOpenBrowser(BrowserConstants.Chrome, strGcURL);
								page.groupConfigurator.LoginPage.get().loginApplication(strUserProfile);
								Select planCriteria=new Select(driver.findElement(By.xpath("//div/span[contains(text(),'Plan Criteria')]/..//select[1]")));
								planCriteria.selectByVisibleText("Proxy ID");
								waitForPageLoad();
							    new Actions(getWebDriver()).click(driver.findElement(By.xpath("//div/span[contains(text(),'Plan Criteria')]/..//span/a[1]"))).build().perform();
								waitForPageLoad();
							    seSetText(driver.findElement(By.xpath("//div/span[contains(text(),'Plan Criteria')]/..//span/a[1]/following::div/span/div/table//tr/td/span/input[contains(@class,'inputText')]")), proxyId);
							    seClick(ContractSearchPage.get().search, "Click Search button");
								seWaitForClickableWebElement(ContractSearchPage.get().searchResults, 120);
								WebTable searchResults = new WebTable(ContractSearchPage.get().searchResults, "Contract Search Results");
								if(searchResults.getRowsCount()>0)
								{
									java.util.List<WebElement> ContractName = getWebDriver().findElements(By.xpath("//*[@id=\"groupResults\"]/table[2]/tbody/tr/td[2]/a"));
									Set<String> Names=new LinkedHashSet<>();

								try{	for(int i=0;i<6;i++)
									{
										String textName = ContractName.get(i).getText().trim();
										Names.add(textName);
										System.out.println(Names);
									}}catch(Exception e){}
									Iterator<String> i=Names.iterator();
									while(i.hasNext()){
									String Name=i.next();
									ContractSearchPage.get().seSearchContract(Name);									
								try{	for(int k=1;k<15;k++){
										String status=getWebDriver().findElement(By.xpath("(//*[@id='groupResults']/table[2]/tbody/tr/td[3]/a)["+k+"]")).getText();
										System.out.println(status);
										if(status.replaceAll("\\s", "").contains("Production")||status.replaceAll("\\s", "").contains("Archived")){}
										else if(status.replaceAll("\\s", "").contains("SenttoTest")){
										log(PASS," Contract Name= "+Name,status);}
										else{
											log(FAIL, Name);}									
									}}catch(Exception e){}
									}
									}
										
							    seCloseBrowser();
							    seOpenBrowser(BrowserConstants.Chrome, strPcURL);
			                    LoginPage.get().loginApplication(strUserProfileApprover);
								waitForPageLoad();
								String planVersionID=PlanHeaderPage.get().seMovePlanSentToTest_To_Production(proxyId);                        
		                        seClick(AutoRepublishPage.get().history,"history");
		                        waitForPageLoad();
		                        PcDate=AutoRepublishPage.get().getRepublishedDate(planVersionID);
		                        System.out.println(PcDate);
		                        seCloseBrowser();
		                        seOpenBrowser(BrowserConstants.Chrome, strGcURL);
								page.groupConfigurator.LoginPage.get().loginApplication(strUserProfile);
								seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(ContractSearchPage.get().createNewContract));
								waitForPageLoad();
								Select planCriteria1=new Select(driver.findElement(By.xpath("//div/span[contains(text(),'Plan Criteria')]/..//select[1]")));
								planCriteria1.selectByVisibleText("Proxy ID");
								waitForPageLoad();
							    new Actions(getWebDriver()).click(driver.findElement(By.xpath("//div/span[contains(text(),'Plan Criteria')]/..//span/a[1]"))).build().perform();								waitForPageLoad();
							    seSetText(driver.findElement(By.xpath("//div/span[contains(text(),'Plan Criteria')]/..//span/a[1]/following::div/span/div/table//tr/td/span/input[contains(@class,'inputText')]")), proxyId);
							    seClick(ContractSearchPage.get().search, "Click Search button");
								seWaitForClickableWebElement(ContractSearchPage.get().searchResults, 120);
								WebTable searchResult1 = new WebTable(ContractSearchPage.get().searchResults, "Contract Search Results");
								if(searchResult1.getRowsCount()>0)
								{
									java.util.List<WebElement> ContractName1 = getWebDriver().findElements(By.xpath("//*[@id=\"groupResults\"]/table[2]/tbody/tr/td[2]/a"));
									Set<String> Names1=new LinkedHashSet<>();

								try{	for(int j=0;j<6;j++)
									{
										String textName = ContractName1.get(j).getText().trim();
										Names1.add(textName);
									}}catch(Exception e){}
									Iterator<String> j=Names1.iterator();
									while(j.hasNext()){
										String Name=j.next();
										ContractSearchPage.get().seSearchContract(Name);									
									try{	for(int k=1;k<4;k++){
											String status=getWebDriver().findElement(By.xpath("(//*[@id='groupResults']/table[2]/tbody/tr/td[3]/a)["+k+"]")).getText().trim();
                                            if(status.replaceAll("\\s", "").contains("Production")||status.replaceAll("\\s", "").contains("Archived")||status.replaceAll("\\s", "").contains("PendingFinalization")){
											log(PASS," Contract Name= "+Name,status);}
											else{
												log(FAIL, Name);}									
										}}catch(Exception e){}
										}
									}
								waitForPageLoad();
								ContractSearchPage.get().searchContract(contract);
								waitForPageLoad();
								WebElement wb2=driver.findElement(By.xpath("(//tbody/tr/td/a[contains(text(),'')]/..)[1]"));
	                            Actions act2=new Actions(driver);
	                            act2.moveToElement(wb2).click(wb2).build().perform();
	                            waitForPageLoad(12,32);
	                            String contractDate=driver.findElement(By.xpath("//span[contains(text(),'Effective Date')]")).getText().split(": ")[1];
	                            System.out.println(contractDate);
	                            seClick(driver.findElement(By.xpath("//span/span/a[@title='Show versions']")), "Version");
	                            waitForPageLoad();
	                            String GcTime=driver.findElement(By.xpath("//div[@id='versionTable']/table/tbody/tr[2]/td[6]")).getText();
                               
	                            if(GcTime.contains(PcDate))
                                {
                                	log(PASS, PcDate,GcTime);
                                }else{log(FAIL,PcDate,GcTime);}
                             
                              
                                
		                        MasterProductAndLegacyPlanOptionsXMLPage.get().seFileDownloadXML(contract,
										"UAT", getReportPathFolder());
								
								String strXMLFileName = getReportPathFolder() + "UAT" + "_" + contract
								+ ".xml";

								DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
								DocumentBuilder builder = factory.newDocumentBuilder();
								Document doc = builder.parse(strXMLFileName);
								XPathFactory xPathfactory = XPathFactory.newInstance();
								XPath xpath = xPathfactory.newXPath();
								XPathExpression expr = xpath.compile("//planStub[@planName='"+planName.trim()+"']/@proxyId");
								String proxyIdXml=(String)expr.evaluate(doc, XPathConstants.STRING);
								System.out.println(proxyIdXml);														
								XPathExpression expr3 = xpath.compile("//effectiveDate/text()");
								String contractEffDateXml=(String)expr3.evaluate(doc, XPathConstants.STRING);
								System.out.println(contractEffDateXml);
								XPathExpression expr2 = xpath.compile("//DateSegment/segment[@segmentEffectiveDate='"+contractEffDateXml+"']/@segmentEffectiveDate");
								String segmentEffDateXml=(String)expr2.evaluate(doc, XPathConstants.STRING);
								System.out.println(segmentEffDateXml);
								XPathExpression expr1 = xpath.compile("//DateSegment/segment[@segmentEffectiveDate='"+contractEffDateXml+"']/@medicalPlanId");
								String planIdXml=(String)expr1.evaluate(doc, XPathConstants.STRING);
								System.out.println(planIdXml);	
                                if(proxyId.equalsIgnoreCase(proxyIdXml)){
                                	log(PASS, "the contract id "+contract+" has "+proxyId, proxyIdXml);
                                }
                                else{log(FAIL,"failure");}

                                if(planVersionID.trim().equalsIgnoreCase(planIdXml)){
                                 	log(PASS, "the contract id "+contract+" has "+planVersionID, planIdXml);
                                }
                                else{log(FAIL,planVersionID,planIdXml);}
                                
                                if(segmentEffDateXml.equals(contractEffDateXml)){
                                	log(PASS,segmentEffDateXml,contractEffDateXml);
                                }else log(FAIL, "fail");
                         
						} catch (Exception e) {
							e.printStackTrace();
							log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
						} finally {
							
							//seCloseBrowser();
						}
					
					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
				} finally {
					endTestScript();
				}

			}	
							
							
						}

