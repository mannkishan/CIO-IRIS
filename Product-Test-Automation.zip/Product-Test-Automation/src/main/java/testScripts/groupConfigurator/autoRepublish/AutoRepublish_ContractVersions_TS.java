package testScripts.groupConfigurator.autoRepublish;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.w3c.dom.Document;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.groupConfigurator.AutoRepublishPage;
import page.groupConfigurator.ContractSearchPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MasterProductAndLegacyPlanOptionsXMLPage;
import page.planConfigurator.PlanHeaderPage;
import utility.CoreSuperHelper;
import utility.WebTable;

public class AutoRepublish_ContractVersions_TS extends CoreSuperHelper
{
	static String strPcURL = EnvHelper.getValue("pc.url");
	static String strGcURL=EnvHelper.getValue("gc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	
	public static void main(String[] args) {
		try {
			initiateTestScript();


						try {
							logExtentReport("Test Script/ Functionality Descrtiption");
							seOpenBrowser(BrowserConstants.Chrome, strGcURL);
							page.groupConfigurator.LoginPage.get().loginApplication(strUserProfile);
							seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(ContractSearchPage.get().createNewContract));
							String contract="152W";
							String PcDate;
							ContractSearchPage.get().seSearchContract(contract);
							waitForPageLoad();
							WebElement wb=driver.findElement(By.xpath("(//tbody/tr/td/a[contains(text(),'Production')]/..)[1]"));
                            Actions act=new Actions(driver);
                            act.moveToElement(wb).click(wb).build().perform();
                            seWaitForClickableWebElement(AutoRepublishPage.get().medicalPlan, 60);
							String MedicalPlanNew=AutoRepublishPage.get().medicalPlan.getText();
							
							ContractSearchPage.get().seSearchContract(contract);
							waitForPageLoad();
							WebElement wb1=driver.findElement(By.xpath("(//tbody/tr/td/a[contains(text(),'Archived')]/..)[1]"));
                            act.moveToElement(wb1).click(wb1).build().perform();
                            seWaitForClickableWebElement(AutoRepublishPage.get().medicalPlan, 60);
							String MedicalPlanOld=AutoRepublishPage.get().medicalPlan.getText();
							
							ContractSearchPage.get().seSearchContract(contract);
							waitForPageLoad();
							WebElement wb2=driver.findElement(By.xpath("(//tbody/tr/td/a[contains(text(),'Archived')]/..)[2]"));
                            act.moveToElement(wb2).click(wb2).build().perform();
                            seWaitForClickableWebElement(AutoRepublishPage.get().medicalPlan, 60);
							String MedicalPlanOlder=AutoRepublishPage.get().medicalPlan.getText();
							
							
							 seCloseBrowser();
							 seOpenBrowser(BrowserConstants.Chrome, strPcURL);
								LoginPage.get().loginApplication(strUserProfile);
								waitForPageLoad();
	                            
							 String MedicalPlanIdNew=AutoRepublishPage.get().seAutoRepublish_RequestAudit(contract, MedicalPlanNew, 60);
								String MedicalPlanIdOld=AutoRepublishPage.get().seAutoRepublish_RequestAudit(contract, MedicalPlanOld,60);
								String MedicalPlanIdOlder=AutoRepublishPage.get().seAutoRepublish_RequestAudit(contract, MedicalPlanOlder,60);
								 seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
									waitForPageLoad();
									seClick(PlanHeaderPage.get().userLogout, "Logout");
									waitForPageLoad(); 
									seCloseBrowser();
									seOpenBrowser(BrowserConstants.Chrome, strPcURL);							
							            LoginPage.get().loginApplication(strUserProfileApprover);
								     	waitForPageLoad();
									    PlanHeaderPage.get().seMovePlanToSentToTest(MedicalPlanIdNew);
									    PlanHeaderPage.get().seMovePlanToSentToTest(MedicalPlanIdOld);
									    PlanHeaderPage.get().seMovePlanToSentToTest(MedicalPlanIdOlder);
                                seCloseBrowser();
								seOpenBrowser(BrowserConstants.Chrome, strGcURL);
								page.groupConfigurator.LoginPage.get().loginApplication(strUserProfile);
								ContractSearchPage.get().seSearchContract(contract);
								WebTable searchResults = new WebTable(ContractSearchPage.get().searchResults, "Contract Search Results");
								if(searchResults.getRowsCount()>0)
								{
									java.util.List<WebElement> ContractName = getWebDriver().findElements(By.xpath("//*[@id=\"groupResults\"]/table[2]/tbody/tr/td[2]/a"));
									Set<String> Names=new LinkedHashSet<>();

								try{	for(int i=0;i<6;i++)
									{
										String textName = ContractName.get(i).getText().trim();
										Names.add(textName);
										System.out.println(Names);
									}}catch(Exception e){}
									Iterator<String> i=Names.iterator();
									while(i.hasNext()){
									String Name=i.next();
									ContractSearchPage.get().seSearchContract(Name);									
								try{	for(int k=1;k<15;k++){
										String status=getWebDriver().findElement(By.xpath("(//*[@id='groupResults']/table[2]/tbody/tr/td[3]/a)["+k+"]")).getText();
										System.out.println(status);
										if(status.replaceAll("\\s", "").contains("Production")||status.replaceAll("\\s", "").contains("Archived")){}
										else if(status.replaceAll("\\s", "").contains("SenttoTest")){
										log(PASS," Contract Name= "+Name,status);}
										else{
											log(FAIL, Name);}									
									}}catch(Exception e){}
									}
									}
									seCloseBrowser();
									 seOpenBrowser(BrowserConstants.Chrome, strPcURL);
					                    LoginPage.get().loginApplication(strUserProfileApprover);
										waitForPageLoad();
										String MedicalVersionIDNew=PlanHeaderPage.get().seMovePlanSentToTest_To_Production(MedicalPlanIdNew); 
										seClick(AutoRepublishPage.get().history,"history");
				                        waitForPageLoad();
										String MedicalDateNew=AutoRepublishPage.get().getRepublishedDate(MedicalVersionIDNew);
										seClick(AutoRepublishPage.get().closehistory, "close history");
										seWaitForClickableWebElement(HomePage.get().find, 12);
     									String MedicalVersionIDOld=PlanHeaderPage.get().seMovePlanSentToTest_To_Production(MedicalPlanIdOld); 
										seClick(AutoRepublishPage.get().history,"history");
				                        waitForPageLoad();
										String MedicalDateOld=AutoRepublishPage.get().getRepublishedDate(MedicalVersionIDOld);
										seClick(AutoRepublishPage.get().closehistory, "close history");
										seWaitForClickableWebElement(HomePage.get().find, 12);
										String MedicalVersionIDOlder=PlanHeaderPage.get().seMovePlanSentToTest_To_Production(MedicalPlanIdOlder); 
										seClick(AutoRepublishPage.get().history,"history");
				                        waitForPageLoad();
										String MedicalDateOlder=AutoRepublishPage.get().getRepublishedDate(MedicalVersionIDOlder);
										
										seCloseBrowser();
				                        seOpenBrowser(BrowserConstants.Chrome, strGcURL);
										page.groupConfigurator.LoginPage.get().loginApplication(strUserProfile);
										seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(ContractSearchPage.get().createNewContract));
										waitForPageLoad();
										ContractSearchPage.get().seSearchContract(contract);
										seWaitForClickableWebElement(ContractSearchPage.get().searchResults, 120);
										WebTable searchResult1 = new WebTable(ContractSearchPage.get().searchResults, "Contract Search Results");
										if(searchResult1.getRowsCount()>0)
										{
											java.util.List<WebElement> ContractName1 = getWebDriver().findElements(By.xpath("//*[@id=\"groupResults\"]/table[2]/tbody/tr/td[2]/a"));
											Set<String> Names1=new LinkedHashSet<>();

										try{	for(int j=0;j<6;j++)
											{
												String textName = ContractName1.get(j).getText().trim();
												Names1.add(textName);
											}}catch(Exception e){}
											Iterator<String> j=Names1.iterator();
											while(j.hasNext()){
												String Name=j.next();
												ContractSearchPage.get().seSearchContract(Name);									
											try{	for(int k=1;k<4;k++){
													String status=getWebDriver().findElement(By.xpath("(//*[@id='groupResults']/table[2]/tbody/tr/td[3]/a)["+k+"]")).getText().trim();
		                                            if(status.replaceAll("\\s", "").contains("Production")||status.replaceAll("\\s", "").contains("Archived")||status.replaceAll("\\s", "").contains("PendingFinalization")){
													log(PASS," Contract Name= "+Name,status);}
													else{
														log(FAIL, Name);}									
												}}catch(Exception e){}
												}
											}
										waitForPageLoad();
										waitForPageLoad();
			                            Actions act2=new Actions(driver);
			                            act2.moveToElement(wb).click(wb).build().perform();
			                            waitForPageLoad(12,32);
			                            String contractDateNew=driver.findElement(By.xpath("//span[contains(text(),'Effective Date')]")).getText().split(": ")[1];
			                            System.out.println(contractDateNew);
			                            seClick(driver.findElement(By.xpath("//span/span/a[@title='Show versions']")), "Version");
			                            waitForPageLoad();
			                            String GcTimeNew=driver.findElement(By.xpath("//div[@id='versionTable']/table/tbody/tr[2]/td[6]")).getText();
		                               
			                            if(GcTimeNew.contains(MedicalDateNew))
		                                {
		                                	log(PASS, "Effective date for production contract="+MedicalDateNew,GcTimeNew);
		                                }else{log(FAIL,MedicalDateNew,GcTimeNew);}
			                            
			                            
			                        	ContractSearchPage.get().seSearchContract(contract);
										waitForPageLoad();
			                            act2.moveToElement(wb1).click(wb1).build().perform();
			                            waitForPageLoad(12,32);
			                            String contractDateOld=driver.findElement(By.xpath("//span[contains(text(),'Effective Date')]")).getText().split(": ")[1];
			                            System.out.println(contractDateOld);
			                            seClick(driver.findElement(By.xpath("//span/span/a[@title='Show versions']")), "Version");
			                            waitForPageLoad();
			                            String GcTimeOld=driver.findElement(By.xpath("//div[@id='versionTable']/table/tbody/tr[2]/td[6]")).getText();
		                               
			                            ContractSearchPage.get().seSearchContract(contract);
										waitForPageLoad();
			                            act2.moveToElement(wb2).click(wb2).build().perform();
			                            waitForPageLoad(12,32);
			                            String contractDateOlder=driver.findElement(By.xpath("//span[contains(text(),'Effective Date')]")).getText().split(": ")[1];
			                            System.out.println(contractDateOlder);
			                            seClick(driver.findElement(By.xpath("//span/span/a[@title='Show versions']")), "Version");
			                            waitForPageLoad();
			                            String GcTimeOlder=driver.findElement(By.xpath("//div[@id='versionTable']/table/tbody/tr[2]/td[6]")).getText();
		                               
			                            MasterProductAndLegacyPlanOptionsXMLPage.get().seFileDownloadXML(contract,
												"UAT", getReportPathFolder());
										
										String strXMLFileName = getReportPathFolder() + "UAT" + "_" + contract
										+ ".xml";
										
										DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
										DocumentBuilder builder = factory.newDocumentBuilder();
										Document doc = builder.parse(strXMLFileName);
										XPathFactory xPathfactory = XPathFactory.newInstance();
										XPath xpath = xPathfactory.newXPath();
										XPathExpression expr1 = xpath.compile("//planStub[@planName='"+MedicalPlanNew.trim()+"']/@proxyId");
										String strMedicalproxyIDXml=(String)expr1.evaluate(doc, XPathConstants.STRING);
										System.out.println(strMedicalproxyIDXml);
									
										XPathExpression expr4= xpath.compile("//effectiveDate/text()");
										String ContractEffDate=(String)expr4.evaluate(doc, XPathConstants.STRING);
										System.out.println(ContractEffDate);
										XPathExpression expr5 = xpath.compile("//DateSegment/segment[@segmentEffectiveDate='"+ContractEffDate+"']/@segmentEffectiveDate");
										String SegmentEffDate=(String)expr5.evaluate(doc, XPathConstants.STRING);
										System.out.println(SegmentEffDate);
										XPathExpression expr6 = xpath.compile("//DateSegment/segment[@segmentEffectiveDate='"+contractDateNew+"']/@medicalPlanId");
										String MedicalPlanIdXmlNew=(String)expr6.evaluate(doc, XPathConstants.STRING);
										XPathExpression expr7 = xpath.compile("//DateSegment/segment[@segmentEffectiveDate='"+contractDateOld+"']/@medicalPlanId");
										String MedicalPlanIdXmlOld=(String)expr7.evaluate(doc, XPathConstants.STRING);
										XPathExpression expr8 = xpath.compile("//DateSegment/segment[@segmentEffectiveDate='"+contractDateOlder+"']/@medicalPlanId");
										String MedicalPlanIdXmlOlder=(String)expr8.evaluate(doc, XPathConstants.STRING);

										 if(strMedicalproxyIDXml.equalsIgnoreCase(MedicalPlanIdNew)){
			                                	log(PASS, "the contract id "+contract+" has Medical="+strMedicalproxyIDXml, MedicalPlanIdNew);
			                                }
			                                else{log(FAIL,"failure");}
										

			                                if(MedicalPlanIdXmlNew.trim().equalsIgnoreCase(MedicalVersionIDNew)){
			                                 	log(PASS, "the contract id "+contract+" has "+MedicalPlanIdXmlNew, MedicalVersionIDNew);
			                                }
			                                else{log(FAIL,MedicalPlanIdXmlNew,MedicalVersionIDNew);}
			                                
			                                if(MedicalPlanIdXmlOld.trim().equalsIgnoreCase(MedicalVersionIDOld)){
			                                 	log(PASS, "the contract id "+contract+" has "+MedicalPlanIdXmlOld, MedicalVersionIDOld);
			                                }
			                                else{log(FAIL,MedicalPlanIdXmlOld,MedicalVersionIDOld);}
			                                
			                                if(MedicalPlanIdXmlOlder.trim().equalsIgnoreCase(MedicalVersionIDOlder)){
			                                 	log(PASS, "the contract id "+contract+" has "+MedicalPlanIdXmlOlder, MedicalVersionIDOlder);
			                                }
			                                else{log(FAIL,MedicalPlanIdXmlOlder,MedicalVersionIDOlder);}
			                                
			                               
						} catch (Exception e) {
							e.printStackTrace();
							log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
						} finally {
							
							//seCloseBrowser();
						}
					
					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
				} finally {
					endTestScript();
				}

			}	
							
							
						}


