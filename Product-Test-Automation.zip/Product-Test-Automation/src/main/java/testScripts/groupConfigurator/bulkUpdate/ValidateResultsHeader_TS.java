package testScripts.groupConfigurator.bulkUpdate;


import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import com.anthem.selenium.utility.ExtentReportsUtility;


import page.groupConfigurator.BulkUpdatePage;
import page.groupConfigurator.HomePage;
import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;
import utility.ExcelUtility;
import utility.GCUtils;
import page.groupConfigurator.ContractSearchPage;

public class ValidateResultsHeader_TS extends CoreSuperHelper{

	static String BASE_URL = EnvHelper.getValue("gc.url");
	static String header = "";
	static String searchresultsHeader = "";
	static String impactHeader = "";
	static String proxyID = "";
	static String state = "";
	static String adminCriteria = "";
	static String adminCriteriaValue = "";
	static String effectiveDate;
	static String updateEffectiveDate;
	static String userProfile=EnvHelper.getValue("user.profile");
	
	public static  void main(String[] args) {

		try{
			initiateData();
			startExtentReport();
			for(iROW=1;iROW<=getRowCount();iROW++) {
				try {
					String runflag = getCellValue("RunFlag");
					if(runflag.equalsIgnoreCase("Yes"))
					{
						logExtentReport("Validating Results Header");
						seOpenBrowser(BrowserConstants.Chrome, BASE_URL, getReportPathFolder());
						LoginPage.get().loginApplication(userProfile);
						proxyID =	getCellValue("ProxyId_Value");
						header = getCellValue("TableHeader");
						searchresultsHeader = getCellValue("SearchResultsHeader");
						impactHeader = getCellValue("ImpactReportHeader");
						state = getCellValue("State");					
						adminCriteria = getCellValue("AdminCriteria");
						adminCriteriaValue = getCellValue("AdminCriteria_Value");
						effectiveDate = getCellValue("EffectiveDate");
						updateEffectiveDate = getCellValue("UpdatedEffectiveDate");
						String userID= getLoginInfo(userProfile)[0];
						seClick(HomePage.get().groupBulkUpdate,"groupBulkUpdate");
						seSetText(BulkUpdatePage.get().effectiveThrough,  effectiveDate,"Enter effective through date");
						seSelectText(true,BulkUpdatePage.get().planCriteria,"Proxy ID", "Select Plan criteria value "+"Proxy ID");
						waitForPageLoad();
						seClick(BulkUpdatePage.get().addPlanCriteria, "addPlanCriteria");

						seSetText(BulkUpdatePage.get().proxyIdValue,proxyID,"Enter proxy id value in the Plan criteria proxy id");
						seSelectText(false,BulkUpdatePage.get().planCriteria,"State", "Select Plan criteria value "+"State");
						seClick(BulkUpdatePage.get().addPlanCriteria, "addPlanCriteria");

						seSelectText(false,BulkUpdatePage.get().planCriteria2,state, "Select Plan criteria State value "+state);

						seSelectText(false,BulkUpdatePage.get().adminCriteriaDropDown,adminCriteria, "Select Admin criteria"+adminCriteria);
						seClick(BulkUpdatePage.get().addAdminCriteria, "addAdminCriteria");

						seSelectText(false,BulkUpdatePage.get().adminCriteriaValue,adminCriteriaValue, "Select Admin criteria value"+adminCriteriaValue);

						seClick(BulkUpdatePage.get().contractSearch, "contractSearch");
						log(PASS, "Search Link", "Warning Message is not displayed, When user selects records");
						GCUtils.VerifyTableHeader(BulkUpdatePage.get().searchResults,header,"Verify the header of bulk update contract search results");

						seClick(BulkUpdatePage.get().exportResults, "exportResults");
						String strreportFolder = getReportPathFolder();
						String filePath=strreportFolder+"\\"+GCUtils.lastModifiedFile(getReportPathFolder());
						ExcelUtility.validateHeaderDataFromExcel(filePath, "Search Contract Results", searchresultsHeader);
						seClick(ContractSearchPage.get().chk_row_1,"Checking 1 row");
						waitForPageLoad();
						seClick(ContractSearchPage.get().chk_row_2,"Checking 2 row");
						waitForPageLoad();
						seClick(BulkUpdatePage.get().UpdateSelectedContracts,"UpdateSelectedContracts");	
						seSelectText(false,BulkUpdatePage.get().reasonCode,"Add Dental Benefit Plan", "Select reason code"+"Add Dental Benefit Plan");
						seClick(BulkUpdatePage.get().currentEffectiveDate, "currentEffectiveDate");
						waitForPageLoad();
						seSetText( BulkUpdatePage.get().effectiveDate,  updateEffectiveDate,"Enter effective through date");
						waitForPageLoad();
						seClick(BulkUpdatePage.get().bulkUpdateSubmit,"bulkUpdateSubmit");
						waitForPageLoad();
						//String id = GCUtils.getCellValue(BulkUpdatePage.get().impactRevewDetails,5,userID,2,"Capture the ID of the bulk update");
						GCUtils.clickAtCell(BulkUpdatePage.get().impactRevewDetails,5,userID,8,"Click on Impact report");
						waitForPageLoad();
						strreportFolder = getReportPathFolder();
						filePath=strreportFolder+"\\"+GCUtils.lastModifiedFile(getReportPathFolder());
						ExcelUtility.validateHeaderDataFromExcel(filePath,"Contracts Impacted",impactHeader);									
						seCloseBrowser();
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}finally{
			endTestScript();
			closeExcelFile();
			System.gc();
		}
	}


}

