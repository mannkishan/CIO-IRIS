package testScripts.groupConfigurator.bulkUpdate;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;

import page.groupConfigurator.BulkUpdatePage;
import page.groupConfigurator.HomePage;
import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;
import utility.GCUtils;



public class WarningMsgValidation_TS extends CoreSuperHelper {
	static String BASE_URL = EnvHelper.getValue("gc.url");	
	static String header = "";
	static String searchresultsHeader = "";
	static String impactHeader = "";
	static String proxyID = "";
	static String state = "";
	static String adminCriteria = "";
	static String adminCriteriaValue = "";
	static String effectiveDate;
	static String updateEffectiveDate;
	static String userProfile=EnvHelper.getValue("user.profile");

	public static  void main(String[] args) {

		try{
			initiateData();
			startExtentReport();
			for(iROW=1;iROW<=getRowCount();iROW++) {
				try {
					String runflag = getCellValue("RunFlag");
					if(runflag.equalsIgnoreCase("Yes"))
					{
						
										    
						String effec_Thru_Date =getCellValue("EffectiveDate");
						String subType = getCellValue("AdminCriteria");
						String subTypeValue =getCellValue("AdminCriteria_Value");
						String Totalcheckbox =getCellValue("Number_Of_Record");
						String effectiveDate=getCellValue("UpdatedEffectiveDate");
						String reasonCode =getCellValue("ReasonCode");
						String newValue =getCellValue("Admin Criteria");
						String userID =getLoginInfo(userProfile)[0];
						int checkboxSize=Integer.parseInt(Totalcheckbox);
						logExtentReport("Validating Warning Message Validation");
						seOpenBrowser(BrowserConstants.Chrome,BASE_URL,"testScripts");
						LoginPage.get().loginApplication(userProfile);
						seClick(HomePage.get().groupBulkUpdate,"groupBulkUpdate");
						seSetText(BulkUpdatePage.get().effectiveThrough,effec_Thru_Date, "Enters Effective Through date in Find Contracts Page");
						seSelectText(false,BulkUpdatePage.get().adminCriteriaDropDown,subType, "Selects Admin Crietria type");	
						seClick(BulkUpdatePage.get().addAdminCriteria, "Clicking on '+' button");
						seSelectText(false,BulkUpdatePage.get().adminCriteriaValue,subTypeValue, "Selects Admin Crietria value");	
						seClick(BulkUpdatePage.get().contractSearch, "Clicking on Contract Search");
						GCUtils.recordFound();
						GCUtils.recordSelection(checkboxSize);
						seClick(BulkUpdatePage.get().UpdateSelectedContracts, "Clicking on UpdateSelectedContracts button");
						seClick(BulkUpdatePage.get().currentEffectiveDate, "currentEffectiveDate");
						waitForPageLoad();
						seSetText(BulkUpdatePage.get().effectiveDate,effectiveDate, "Enters Effective Date");
						seSelectText(false,BulkUpdatePage.get().reasonCode,reasonCode, "Selects reason code");
						waitForPageLoad();
						seSelectText(false,BulkUpdatePage.get().adminCritReplacevalue,newValue, "Selects new value");
						waitForPageLoad();
						seClick(BulkUpdatePage.get().bulkUpdateSubmit, "Submit Button");
						if(checkboxSize<=50)
						{
							GCUtils.run(effectiveDate, userID, reasonCode);
							String WarningMessageExpected="Are you sure you want to execute this Bulk Update process? This Bulk Update process contains "
									+Totalcheckbox+" contracts. It is strongly recommended that you schedule processes with more than 15"
									+" contracts";
							if(checkboxSize<15 && GCUtils.getStatus(effectiveDate, userID, reasonCode).equalsIgnoreCase("Scheduled"))
							{
								log(PASS, "Check whether warning message appeared, When user click Run link", 
										"Warning Message is not displayed, When user selects "+Totalcheckbox+" records");
							}
							else if((checkboxSize>=15&&checkboxSize<=50)&&seGetElementValue(BulkUpdatePage.get().WarningMsg).equalsIgnoreCase(WarningMessageExpected))
							{
								log(PASS, "Check whether warning message appeared, When user click Run link", "Warning Message is displayed, When user selects "+Totalcheckbox+" records");
								seClick(BulkUpdatePage.get().yesLink, "Yes Link");
								waitForPageLoad();
							}
							else{
								log(ERROR, "Error in Warning message validation", 
										"Check whether warning message appeared, When user click Run link");
							}
						}
						else if(checkboxSize>50)
						{
							GCUtils.actionCodeColumnValidate(effectiveDate, userID, reasonCode);
						}
						seCloseBrowser();
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}finally{
			endTestScript();
			closeExcelFile();
			System.gc();
		}
	}


}
