package testScripts.groupConfigurator.bulkUpdate;

import org.openqa.selenium.By;

import com.anthem.selenium.SuperHelper;
import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import com.anthem.selenium.utility.ExtentReportsUtility;

import page.groupConfigurator.BulkUpdatePage;
import page.groupConfigurator.ContractSearchPage;
import page.groupConfigurator.HomePage;
import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;
import utility.ExcelUtility;
import utility.GCUtils;

public class ProxyIdUpdateSameState_TS extends CoreSuperHelper  {
	
	static String strbaseURL = EnvHelper.getValue("gc.url");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	static String strpath=getReportPathFolder();	
	static String strcontractsNotUpdated="Contracts Not Updated";
	static String strcontractsUpdated="Contracts Updated";
	static String strcontractCode="";
	static String struserProfile = EnvHelper.getValue("user.profile");
	
public static  void main(String[] args) {
		
		try{
			initiateData();
			startExtentReport();
			String createdBy = "";
			
			for(iROW=1;iROW<=getRowCount();iROW++) {
				try {
			logExtentReport("Validate Spider GCL Login");
			if (getCellValue("Run_Flag").trim().equalsIgnoreCase("Yes")){
				
			seOpenBrowser(BrowserConstants.Chrome,strbaseURL,getReportPathFolder());
			LoginPage.get().loginApplication(struserProfile);
			createdBy = getLoginInfo(struserProfile)[0];
			seClick(HomePage.get().groupBulkUpdate, "Click on Group bulk Update");
			Thread.sleep(10000);
			
			String effectivedate = getCellValue("EffectivethruDate");
			String proxyid =getCellValue("PlanCriteria_ProxyId");
			String proxyidvalue = getCellValue("ProxyId_Value");
			String ProxyId_Value_New = getCellValue("ProxyId_Value_New");
			String PlanCriteria_LOB = getCellValue("PlanCriteria_LOB");
			String LOB = getCellValue("LOB");
			String reasonCode =getCellValue("ReasonCode");
			//String Totalcheckbox =getCellValue("Number_Of_Record");
			//int checkboxSize=Integer.parseInt(Totalcheckbox);
			//String newValue =getCellValue("SubType_NewValue");
			String UserId =getCellValue("UserId");
			
			seSetText(BulkUpdatePage.get().effectiveThrough, effectivedate, "Enter Effective Thru Date");
			seSelectText(true,BulkUpdatePage.get().planCriteria, proxyid, "Select Proxy ID");
			seClick(BulkUpdatePage.get().addPlanCriteria,"Click on Add Button");
			seSetText(BulkUpdatePage.get().proxyIdValue, proxyidvalue, "Enter Proxy ID value");
			seSelectText(true,BulkUpdatePage.get().planCriteria, PlanCriteria_LOB, "Select LOB");
			seClick(BulkUpdatePage.get().addPlanCriteria,"Click on Add Button");
			seSelectText(true,BulkUpdatePage.get().planCriteria2,LOB,"Select LOB value");
			seCaptureScreenshot(driver, "Entered the search criteria");
			seClick(BulkUpdatePage.get().contractSearch, "Clicking on Contract Search");
			BulkUpdatePage.get().recordFound();
			BulkUpdatePage.get().recordSelection(2);
			
			seClick(BulkUpdatePage.get().UpdateSelectedContracts, "Clicking on UpdateSelectedContracts button");
			seSelectText(false,BulkUpdatePage.get().reasonCode,reasonCode, "Selects reason code");	
			seSetText(BulkUpdatePage.get().proxyIdValue,ProxyId_Value_New, "Enters Proxy Id New Value");
			seClick(BulkUpdatePage.get().bulkUpdateSubmit, "Submit Button");
			waitForPageLoad();
			seClick(BulkUpdatePage.get().clickHistory, "History Button");
			waitForPageLoad();
			seClick(BulkUpdatePage.get().impactReview, "impact_review Button");
			waitForPageLoad();
			
			String id = GCUtils.getBulkUpdateID(By.className("af_table_content"), 5, createdBy, 2);
			String strreportFolder = getReportPathFolder();
			GCUtils.run(createdBy, reasonCode);
			waitForPageLoad();
			seClick(BulkUpdatePage.get().clickHistory, "History Tab");
			waitForPageLoad();
			GCUtils.downloadUpdateReport(id);
			waitForPageLoad();
			String filePath=strreportFolder+"\\"+GCUtils.lastModifiedFile(getReportPathFolder());
			String rowData= ExcelUtility.validateexcelData(filePath,strcontractsUpdated,"Eff. Date");
			if(rowData.equals(""))

			{
				strcontractCode= ExcelUtility.validateexcelData(filePath,strcontractsNotUpdated,"Contract Code");
				ExtentReportsUtility.log(WARNING,"Proxy ID  not  replaced"," No Contract available for updation with replaced values ");
				
			}
			else
			{              
				strcontractCode=ExcelUtility.validateexcelData(filePath,strcontractsUpdated,"Contract Code");
				log(PASS,"Proxy ID should  be replaced","Contracts are available for updation with replace values ");
				seClick(HomePage.get().link_ContractSerach,"Click Home");
				seSetText(ContractSearchPage.get().contractCode,strcontractCode, "Setting Contract id to search ");
				seClick(ContractSearchPage.get().button_Contract_Search,"Enter Contract Code");
				seClick(ContractSearchPage.get().row,"Click CONTRACT_SEARCH");
				GCUtils.validateReplaceproxyID(ProxyId_Value_New,strcontractCode);
				
			}
			
			seCloseBrowser();
			}
				}catch (Exception e) {
					e.printStackTrace();
				}
		}
		
		}
			
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{			
			endExtentReport();
			closeExcelFile();
			System.gc();
			
		}
	}

}
