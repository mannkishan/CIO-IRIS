package testScripts.groupConfigurator.bulkUpdate;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import com.anthem.selenium.utility.ExtentReportsUtility;

import page.groupConfigurator.BulkUpdatePage;
import page.groupConfigurator.ContractSearchPage;
import page.groupConfigurator.HomePage;
import page.groupConfigurator.ImpactReviewPage;
import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;
import utility.ExcelUtility;
import utility.GCUtils;

public class ProxyidVerifDiffLOB_TS extends CoreSuperHelper {
	static String BASE_URL = EnvHelper.getValue("gc.url");
	static String path = "C:\\Application\\reports\\";
	static String contractsNotUpdated="Contracts Not Updated";
	static String contractsUpdated="Contracts Updated";
	static String contractCode="";
	static String userProfile = EnvHelper.getValue("user.profile");
	static String userID="";
	public static void main(String[] args) {		
		try{
			initiateData();
			startExtentReport();
			for(iROW=1;iROW<=getRowCount();iROW++) {
				try {
					String runflag = getCellValue("Run_Flag");
					if(runflag.equalsIgnoreCase("Yes"))
					{
						logExtentReport("Validate Spider GCL Login");
						if (getCellValue("Run_Flag").trim().equalsIgnoreCase("Yes")){
							seOpenBrowser(BrowserConstants.Chrome,BASE_URL,getReportPathFolder());
							LoginPage.get().loginApplication(userProfile);
							seClick(HomePage.get().groupBulkUpdate, "Click on Group bulk Update");
							Thread.sleep(5000);
							String effectivedate = getCellValue("EffectivethruDate");
							String proxyid =getCellValue("PlanCriteria_ProxyId");
							String proxyidvalue = getCellValue("ProxyId_Value");
							String PlanCriteria_LOB = getCellValue("PlanCriteria_LOB");
							String LOB = getCellValue("LOB");
							String ProxyId_Value_New=getCellValue("ProxyId_Value_New");
							String reasonCode =getCellValue("ReasonCode");
							//String newValue =getCellValue("SubType_NewValue");
							userID = getLoginInfo(userProfile)[0];
							seSetText(BulkUpdatePage.get().effectiveThrough, effectivedate, "Enter Effective Thru Date");
							seSelectText(true,BulkUpdatePage.get().planCriteria, proxyid, "Select Proxy ID");
							seClick(BulkUpdatePage.get().addPlanCriteria,"Click on Add Button");
							seSetText(BulkUpdatePage.get().proxyIdValue, proxyidvalue, "Enter Proxy ID value");
							seSelectText(true,BulkUpdatePage.get().planCriteria, PlanCriteria_LOB, "Select LOB");
							seClick(BulkUpdatePage.get().addPlanCriteria,"Click on Add Button");
							seSelectText(true,BulkUpdatePage.get().planCriteria2,LOB,"Select LOB value");
							seClick(BulkUpdatePage.get().contractSearch, "Clicking on Contract Search");
							GCUtils.recordFound();
							GCUtils.recordSelection(2);
							seClick(BulkUpdatePage.get().UpdateSelectedContracts, "Clicking on UpdateSelectedContracts button");
							seSelectText(false,BulkUpdatePage.get().reasonCode,reasonCode, "Selects reason code");	
							seSetText(BulkUpdatePage.get().proxyIdValue,ProxyId_Value_New, "Enters Proxy Id New Value");
							seClick(BulkUpdatePage.get().bulkUpdateSubmit, "Submit Button");	
							seClick(ImpactReviewPage.get().historyTab, "Click History Button");
							waitForPageLoad(200);
							seClick(ImpactReviewPage.get().impactReview, "Click impact_review Button");
							GCUtils.run(userID,reasonCode);
							seClick(ImpactReviewPage.get().historyTab, "Click History Button");
							GCUtils.downloadUpdateReport(userID,reasonCode);
							String strreportFolder = getReportPathFolder();
							String filePath=strreportFolder+"\\"+GCUtils.lastModifiedFile(getReportPathFolder());
							String rowData= ExcelUtility.validateexcelData(filePath,contractsUpdated,"Eff. Date");			
							if(rowData.equals(""))

							{
								contractCode= ExcelUtility.validateexcelData(filePath,contractsNotUpdated,"Contract Code");

								log(PASS,"Proxy ID should not be replaced","Verify No Contract available for updation with replace values ",true);
								seClick(HomePage.get().link_ContractSerach,"Click Home");
								seSetText(ContractSearchPage.get().contractCode,contractCode, "Setting Contract id to search ");			
								seClick(ContractSearchPage.get().button_Contract_Search,"Enter Contract Code");
								seClick(ContractSearchPage.get().row,"Click CONTRACT_SEARCH");
								GCUtils.verifyproxy(contractCode);

							}
							else
							{              
								contractCode=ExcelUtility.validateexcelData(filePath,contractsUpdated,"Contract Code");
								log(WARNING,"Proxy ID should not be replaced",
										"Verify No Contract available for updation with replace values ",true);

							}														
							seCloseBrowser();
						}
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}

		}

		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{			
			endTestScript();
			closeExcelFile();
			System.gc();

		}
	}


}
