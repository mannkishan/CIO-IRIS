package testScripts.groupConfigurator.bulkUpdate;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import com.anthem.selenium.utility.ExtentReportsUtility;
import page.groupConfigurator.BulkUpdatePage;
import page.groupConfigurator.ContractInformationPage;
import page.groupConfigurator.ContractSearchPage;
import page.groupConfigurator.HomePage;
import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;
import utility.GCUtils;

public class XMLValidation_TS extends CoreSuperHelper {
	static String BASE_URL = EnvHelper.getValue("gc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	public static void main(String[] args) {
		try {
			initiateData();
			startExtentReport();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String createdBy = "";
					String proxyID = getCellValue("ProxyID");
					String PLCStatus=getCellValue("PLC_Status");
					String ExpectedPLCStatus=getCellValue("ExpectedPLC_Status");
					String[] contractList = getCellValue("ContractCodes").trim().split(",");
					String runflag = getCellValue("RunFlag");
					String effec_Thru_Date =getCellValue("EffectiveThrough");
					String reasonCode =getCellValue("ReasonCode");
					//String path = "c:\\TestData\\report";
					String region ="UAT";
					String XMLFileName="";
					if(runflag.equalsIgnoreCase("YES"))
					{
						logExtentReport("XML validation in GC Application");
						//System.out.println(path);
						seOpenBrowser(BrowserConstants.Chrome, BASE_URL, getReportPathFolder());
						LoginPage.get().loginApplication(userProfile);
						createdBy = getLoginInfo(userProfile)[0];
						waitForPageLoad();
						seClick(HomePage.get().groupBulkUpdate,"Click on Home Page");
						waitForPageLoad();
						seSetText(BulkUpdatePage.get().effectiveThrough,effec_Thru_Date,"Enters Effective Through date in Find Contracts Page");
						seSelectText(true, BulkUpdatePage.get().planCriteria, "Proxy ID", "Selects Plan Criteria type");
						seClick(BulkUpdatePage.get().addPlanCriteria, "addPlanCriteria");
						seSetText(BulkUpdatePage.get().proxyIdValue,proxyID,"Selects Plan Criteria type");
						seSelectText(true,BulkUpdatePage.get().contractCriteria, "Product Lifecycle Status", "Select PLC Status from the contract criteria");
						seClick(BulkUpdatePage.get().addContractCriteria, "addContractCriteria");
						seSelectText(true,BulkUpdatePage.get().dropDown_PLCState,PLCStatus, "Select searchStatus from the approval status");
						seClick(BulkUpdatePage.get().contractSearch, "click contractSearch");
						waitForPageLoad();
						seClick(BulkUpdatePage.get().link_SelectAll, "link_SelectAll");
						seClick(BulkUpdatePage.get().UpdateSelectedContracts, "UpdateSelectedContracts");
						waitForPageLoad(200);
						seSelectText(true,BulkUpdatePage.get().reasonCode,reasonCode, "Selects reason code");
						waitForPageLoad(200);
						seSelectText(true,BulkUpdatePage.get().newPLCStatus,ExpectedPLCStatus,"change the PLC status of the contract to"+ExpectedPLCStatus);
						waitForPageLoad(200);
						seClick(BulkUpdatePage.get().bulkUpdateSubmit, "bulkUpdateSubmit");
						waitForPageLoad(200);
						String id = GCUtils.getBulkUpdateID(By.className("af_table_content"),5,createdBy,2);
						System.out.println("id value--->"+id);
						GCUtils.run(createdBy, reasonCode);
						waitForPageLoad(200);
						seClick(BulkUpdatePage.get().clickHistory, "clickHistory");
						GCUtils.downloadUpdateReport(id);
						waitForPageLoad(200);
						for(int index =0; index< contractList.length; index++)
						{
							GCUtils.validateContractUpdateReport(contractList[index], "Product Lifecycle State", ExpectedPLCStatus, getReportPathFolder()+"BulkUpdate_UpdateReport_"+id+".xlsx");
						}
						waitForPageLoad(200);
						for(int index =0; index< contractList.length; index++)
						{
							ContractSearchPage.get().searchContract(contractList[index]);
							String webValue =seGetElementValue(ContractInformationPage.get().PLCState);
							GCUtils.DownloadXML(contractList[index], region, getReportPathFolder());
							XMLFileName = getReportPathFolder() + region + "_"+ contractList[index] + ".xml";
							
							String xmlvalue =GCUtils.getAttributeValue("productLifecycleState", "name", XMLFileName);
							GCUtils.XMLErrorValidation(XMLFileName,contractList[index]);
							if(webValue.equalsIgnoreCase(xmlvalue))
							{
							log(PASS,"Verify Product Life cycle updated value present in XML","XML file contains the updated Product life cycle value as "+xmlvalue+" for "+contractList[index]);
								
							}
						}
					}
				}
				catch (Exception e) {e.printStackTrace();}
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally
		{			
			endTestScript();
			closeExcelFile();
			System.gc();
			seCloseBrowser();

		}
	}
}
