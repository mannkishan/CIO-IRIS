package testScripts.groupConfigurator.bulkUpdate;

import org.openqa.selenium.By;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import page.groupConfigurator.BulkUpdatePage;
import page.groupConfigurator.ContractSearchPage;
import page.groupConfigurator.HomePage;
import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;
import utility.GCUtils;
import page.groupConfigurator.ImpactReviewPage;


public class ProxyIdVerification_TS extends CoreSuperHelper{

	static String BASE_URL = EnvHelper.getValue("gc.url");	
	static String contractsUpdated="Contracts Updated";
	static String contractsNotUpdated="Contracts Not Updated";
	static String FailureReason="";
	static String contractCode="";
	static String filename=" ";
	static String userProfile = EnvHelper.getValue("user.profile");
	static String userID = "";
	public static void main(String[] args) {

		try{
			initiateData();
			startExtentReport();
			String path = getReportPathFolder();
			System.out.println(path);
			for(iROW=1;iROW<=getRowCount();iROW++) {
				try {
					String runflag = getCellValue("RunFlag");
					if(runflag.equalsIgnoreCase("Yes"))
					{
						logExtentReport("Validating Proxy Id");
						seOpenBrowser(BrowserConstants.Chrome, BASE_URL, getReportPathFolder());
						LoginPage.get().loginApplication(userProfile);
						seClick(HomePage.get().groupBulkUpdate,"groupBulkUpdate");
						String reasonCode =getCellValue("ReasonCode");
						userID =getLoginInfo(userProfile)[0];
						System.out.println(userID);
						String[] contractList = getCellValue("ContractCodes").trim().split(",");
						String replaceProxyID =getCellValue("ProxyId_Value_New");					
						seSetText(BulkUpdatePage.get().effectiveThrough, getCellValue("EffectiveDate"),"Setting effective through date text");
						seSelectText(true,BulkUpdatePage.get().planCriteria,"Proxy ID", "Select Plan criteria value "+"Proxy ID");
						seClick(BulkUpdatePage.get().addPlanCriteria,"Clicking on add Plan criteria button");
						seSetText(BulkUpdatePage.get().proxyIdValue,getCellValue("ProxyId_Value"),"Enter proxy id value in the Plan criteria proxy id");
						seSelectText(false,BulkUpdatePage.get().planCriteria,"State", "Select Plan criteria value "+"State");
						waitForPageLoad();	
						seClick(BulkUpdatePage.get().addPlanCriteria,"Clicking on add Plan criteria button");
						seSelectText(true,BulkUpdatePage.get().planCriteria2,getCellValue("State"), "Selecting State Value from State dropdown");  
						seSelectText(true,BulkUpdatePage.get().adminCriteriaDropDown,getCellValue("AdminCriteria"),"Selecting Admin Criteria");
						seClick(BulkUpdatePage.get().addAdminCriteria, "Clicking on add Admin criteria button");
						seSelectText(false,BulkUpdatePage.get().adminCriteriaValue,getCellValue("AdminCriteria_Value"), "Select Admin criteria value");
						seClick(BulkUpdatePage.get().button_Search,"Clicking on search button");
						BulkUpdatePage.get().recordFound();
						seClick(BulkUpdatePage.get().link_SelectAll, "Clicking on Select All button");
						waitForPageLoad(200);
						seClick(BulkUpdatePage.get().UpdateSelectedContracts, "UpdateSelectedContracts");
						seSelectText(true,BulkUpdatePage.get().reasonCode,reasonCode,"Selecting Reason Code From DropDown");
						seSetText(BulkUpdatePage.get().replaceProxyValue, replaceProxyID, "Setting text in Proxy Id field");
						seClick(BulkUpdatePage.get().bulkUpdateSubmit,"Clicking on submit button");
						waitForPageLoad();	
						String id = GCUtils.getBulkUpdateID(By.className("af_table_content"), 5, userID, 2);
						utility.GCUtils.run(userID,reasonCode);
						waitForPageLoad(100);
						seClick(ImpactReviewPage.get().historyTab, "Clicking on history link");
						waitForPageLoad(100);
						utility.GCUtils.downloadUpdateReport(id);
						String strreportFolder = getReportPathFolder();
						String filePath=strreportFolder+"\\"+GCUtils.lastModifiedFile(getReportPathFolder());
						System.out.println("FILE Path-->"+filePath);
						String rowData= utility.ExcelUtility.validateexcelData(filePath,contractsUpdated,"Contract Code");
						if(rowData.equals("")){
							contractCode=utility.ExcelUtility.validateexcelData(filePath,contractsNotUpdated,"Contract Code");
							FailureReason=utility.ExcelUtility.validateexcelData(filePath,contractsNotUpdated,"Reason");						
							log(WARNING, "Contracts are  not updated","Contracts are  not updated in "+filePath);
						}
						else
						{
							for(int index =0; index< contractList.length; index++)
							{
								ContractSearchPage.get().searchContract(contractList[index]);
								utility.GCUtils.validateReplaceproxyID(replaceProxyID,contractList[index]);
							}
						}
						seCloseBrowser();
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}finally{
			endTestScript();
			closeExcelFile();
			System.gc();
		}
	}


}

