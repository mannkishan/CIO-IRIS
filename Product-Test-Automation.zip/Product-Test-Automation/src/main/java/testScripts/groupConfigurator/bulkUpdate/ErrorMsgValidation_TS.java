package testScripts.groupConfigurator.bulkUpdate;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import page.groupConfigurator.BulkUpdatePage;
import page.groupConfigurator.HomePage;
import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;
import utility.GCUtils;

public class ErrorMsgValidation_TS extends CoreSuperHelper {

	static String strbaseURL = EnvHelper.getValue("gc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	public static  void main(String[] args) {

		try{
			initiateData();
			startExtentReport();
			for(iROW=1;iROW<=getRowCount();iROW++)
			{
				try{
					String runflag = getCellValue("RunFlag");
					if(runflag.equalsIgnoreCase("Yes"))
					{
						String streffec_Thru_Date =getCellValue("EffecThru_Date");
						String strSectionType =getCellValue("SectionType");
						String strSrchVal1=getCellValue("SearchValue1");
						String strSrchVal2=getCellValue("SearchValue2");
						String strExpectedErrmsg =getCellValue("ExpectedErrorMessage");
						logExtentReport("Error Message validation in GC Application");
						seOpenBrowser(BrowserConstants.Chrome,strbaseURL,"testScripts");
						LoginPage.get().loginApplication(struserProfile);
						waitForPageLoad(200);
						seClick(HomePage.get().groupBulkUpdate,"Click on Home Page");
						waitForPageLoad(200);
						seSetText(BulkUpdatePage.get().effectiveThrough,streffec_Thru_Date,"Enters Effective Through date in Find Contracts Page");
						waitForPageLoad(200);
						GCUtils.errorValidation(strSectionType, strSrchVal1, strSrchVal2,strExpectedErrmsg);
						waitForPageLoad(200);
					}
					setResult("STATUS", RESULT_STATUS);
					System.out.println("Number of row in data sheet"+getRowCount());
				}
				catch(Exception e){
					e.printStackTrace(); }
			}
		}
		catch(Exception e){e.printStackTrace();}
		finally{
			endTestScript();
			closeExcelFile();
			seCloseBrowser();
		}
	}
}
