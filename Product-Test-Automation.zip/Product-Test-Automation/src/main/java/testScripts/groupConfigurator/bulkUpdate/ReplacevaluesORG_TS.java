package testScripts.groupConfigurator.bulkUpdate;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import com.anthem.selenium.utility.ExtentReportsUtility;

import page.groupConfigurator.BulkUpdatePage;
import page.groupConfigurator.ContractInformationPage;
import page.groupConfigurator.ContractSearchPage;
import page.groupConfigurator.HomePage;
import page.groupConfigurator.ImpactReviewPage;
import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;
import utility.GCUtils;

public class ReplacevaluesORG_TS extends CoreSuperHelper {

	static String BASE_URL = EnvHelper.getValue("gc.url");
	static String path = "C:\\Application\\reports\\";
	static String contractsNotUpdated="Contracts Not Updated";
	static String contractsUpdated="Contracts Updated";
	static String FailureReason="";
	static String userProfile = EnvHelper.getValue("user.profile");
	static String userID = "";
	public static  void main(String[] args) {		
		try{
			initiateData();
			startExtentReport();
			for(iROW=1;iROW<=getRowCount();iROW++) {
				try {
					logExtentReport("Update Reason code and  Contact info for : Organization ");
					if (getCellValue("Run_Flag").trim().equalsIgnoreCase("Yes")){
						seOpenBrowser(BrowserConstants.Chrome,BASE_URL,getReportPathFolder());
						LoginPage.get().loginApplication(userProfile);
						seClick(HomePage.get().groupBulkUpdate, "Click on Group bulk Update");
						Thread.sleep(10000);
						userID =getLoginInfo(userProfile)[0];
						String reasonCode =getCellValue("ReasonCode");
						seSetText(BulkUpdatePage.get().effectiveThrough,getCellValue("EffectiveDate"),"Setting effective through date text");
						waitForPageLoad();
						seSelectText(true,BulkUpdatePage.get().dropDown_ContactInfoCriteria,getCellValue("Org_info"), "Selecting Proxy Id from plan criteria dropdown");
						waitForPageLoad();
						seClick(BulkUpdatePage.get().addContactInfoCriteria,"Clicking on addContactInfoCriteria");
						seSelectText(true,BulkUpdatePage.get().dropDown_Name_OrgValue,getCellValue("OrgName"),"Selecting OrgnRole value from Contact Info dropdown");
						waitForPageLoad();
						seClick(BulkUpdatePage.get().button_Search,"Clicking on Search button");
						waitForPageLoad();
						GCUtils.recordFound();
						waitForPageLoad();
						GCUtils.recordSelection(2);
						waitForPageLoad();
						seClick(BulkUpdatePage.get().UpdateSelectedContracts, "Clicking on Update Selected Contracts button");
						waitForPageLoad();
						seSelectText(true,BulkUpdatePage.get().reasonCode,getCellValue("ReasonCode"),"Selecting Reason Code From DropDown");
						waitForPageLoad();
						seSelectText(false,BulkUpdatePage.get().dropDown_Role_OrgValue,getCellValue("OrgRole"), "Selecting " + getCellValue("OrgRole") + " value for ORG Role field");
						waitForPageLoad();
						seSetText(BulkUpdatePage.get().communication,getCellValue("communication"), "Setting " + getCellValue("communication") + " value for ORG communicationfield");
						waitForPageLoad();					
						seSetText(BulkUpdatePage.get().ext,getCellValue("ext"), "Setting " + getCellValue("ext") + " value for ORG ext field");
						waitForPageLoad();
						seClick(BulkUpdatePage.get().bulkUpdateSubmit, "Clicking on submit button");
						waitForPageLoad();						
						GCUtils.run(userID,reasonCode);
						waitForPageLoad();
						seClick(ImpactReviewPage.get().historyTab,"Clicking on history tab");
						waitForPageLoad();
						String id = GCUtils.getBulkUpdateID(By.className("af_table_content"), 5, userID, 2);
						seClick(ImpactReviewPage.get().impactReview,"Clicking on Impact Review tab");
						waitForPageLoad();
						seClick(ImpactReviewPage.get().historyTab,"Clicking on history tab");
						waitForPageLoad();
						utility.GCUtils.downloadUpdateReport(id);
						String strreportFolder = getReportPathFolder();
						String filePath=strreportFolder+"\\"+GCUtils.lastModifiedFile(strreportFolder);
						System.out.println("FILE Path-->"+filePath);
						waitForPageLoad();
						String rowData= utility.ExcelUtility.validateexcelData(filePath,contractsUpdated,"Contract Code");
						if(rowData.equals(""))

						{
							String contractCode=utility.ExcelUtility.validateexcelData(filePath,contractsNotUpdated,"Eff. Date");
							FailureReason=utility.ExcelUtility.validateexcelData(filePath,contractsNotUpdated,"Reason");						
							log(WARNING, "Contracts are  not updated","Contracts are  not updated in "+filePath);
						}
						else
						{   
							String contractCode=utility.ExcelUtility.validateexcelData(filePath,contractsUpdated,"Contract Code");
							log(PASS, "Contracts are present","Contracts For Update sheet has values: ("+contractCode+")");							
							seClick(HomePage.get().link_ContractSerach, "Clicking on Search Link");
							Thread.sleep(2000);
							//utility.SpiderUtils.selectsProdStatusContract(contractCode);
							seSetText(ContractSearchPage.get().contractCode,
									contractCode, "Enters contract code");
							seClick(ContractSearchPage.get().button_Contract_Search, "Clicking on contract search button");
							Thread.sleep(4000);
							List<WebElement> rows_groupResult = driver.findElements(By.xpath(".//*[@id='groupResults']/table[2]/tbody/tr")); 
							for(int k=2; k<rows_groupResult.size();k++)
							{
								String statusCol=driver.findElement(By.xpath(".//*[@id='groupResults']/table[2]/tbody/tr["+k+"]/td[3]/a")).getText();		
								System.out.println("---------------->"+statusCol);
								if(statusCol.equalsIgnoreCase("Production"))
								{
									driver.findElement(By.xpath("//*[@id='groupResults']/table[2]/tbody/tr["+k+"]/td[3]/a")).click();
									ExtentReportsUtility.log(PASS,"Search and Click Production Status Contract",
											"Clicked the production status contract from Group result");
									break;

								}
							}
							waitForPageLoad();
							//utility.SpiderUtils.validateReplacevalue_org(getCellValue("OrgRole") ,contractCode );
							seClick(ContractInformationPage.get().contactinfotab,"contactinfotab");
							Thread.sleep(3000);
							String pervalue=seGetElementValue(ContractInformationPage.get().proxyIDtable);
							if(pervalue.contains(getCellValue("OrgRole"))){					
								ExtentReportsUtility.log(PASS, "Verify Person role Value is replaced for Contracts",
										"Person role Value is replaced successfully for contract "+contractCode);
							}
							else
							{
								ExtentReportsUtility.log(FAIL, "Verify Person role Value is replaced for Contracts",
										"Person role Value is not replaced successfully for contract "+contractCode);
							}
						}
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}

		}

		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{			
			endTestScript();
			closeExcelFile();
			System.gc();

		}
	}


}