package testScripts.groupConfigurator.bulkUpdate;

import org.openqa.selenium.By;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.groupConfigurator.BulkUpdatePage;
import page.groupConfigurator.ContractInformationPage;
import page.groupConfigurator.ContractSearchPage;
import page.groupConfigurator.HomePage;
import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;
import utility.GCUtils;

public class ChangeContractApprovalStatus_TS extends CoreSuperHelper {

	static String strbaseURL = EnvHelper.getValue("gc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	static String strdownloadPath = "";

	public static void main(String[] args) {

		try {
			initiateTestScript();
			String createdBy = "";

			for (iROW = 1; iROW <= 1; iROW++) {
				try {
					logExtentReport("Test Script/ Functionality Descrtiption");
					String[] contractList = getCellValue("ContractCodes").split(",");
					String expectedStatus = getCellValue("ExpectedStatus");
					String strdownloadPath = getReportPathFolder();
					System.out.println(strdownloadPath);
					
					seOpenBrowser(BrowserConstants.Chrome, strbaseURL,strdownloadPath);
					LoginPage.get().loginApplication(struserProfile);
					createdBy = getLoginInfo(struserProfile)[0];
					seClick(HomePage.get().groupBulkUpdate, "Bulk Update");
					seSetText(BulkUpdatePage.get().effectiveThrough, getCellValue("EffectiveThrough"), "Effective through");
					seSelectText(BulkUpdatePage.get().planCriteria, "Proxy ID", "Plan Criteria");
					waitForPageLoad();
					seClick(BulkUpdatePage.get().addPlanCriteria, "Add Plan Criteria");
					seSetText(BulkUpdatePage.get().proxyIdValue, getCellValue("ProxyID"), "Proxy ID");
					seSelectText(BulkUpdatePage.get().contractCriteria, "Approval Status", "Contract Criteria");
					seClick(BulkUpdatePage.get().addContractCriteria, "Add Contract Criteria");
					seSelectText(BulkUpdatePage.get().approvalStatus, getCellValue("SearchStatus"),"Approval status");
					seCaptureScreenshot(getWebDriver(), "Entered the search criteria");
					seClick(BulkUpdatePage.get().contractSearch, "Contract Search");
					waitForPageLoad(200);
					seCaptureScreenshot(getWebDriver(), "Search Results");
					seClick(BulkUpdatePage.get().link_SelectAll, "Select All");
					waitForPageLoad(200);
					seClick(BulkUpdatePage.get().UpdateSelectedContracts, "Update Selected Contracts");
					seSelectText(BulkUpdatePage.get().reasonCode, "Benefit Change", "Reason Code");
					seSelectText(BulkUpdatePage.get().newApprovalStatus, getCellValue("ExpectedStatus"),"New Approval status");
					seCaptureScreenshot(getWebDriver(), "Updated the contract status to " + getCellValue("ExpectedStatus"));
					seClick(BulkUpdatePage.get().bulkUpdateSubmit, "Bulk Update Submit");
					waitForPageLoad();
					String id = GCUtils.getBulkUpdateID(By.className("af_table_content"), 5, createdBy, 2);
					GCUtils.run(createdBy, "Benefit Change");
					seClick(BulkUpdatePage.get().clickHistory, "History Tab");
					GCUtils.downloadUpdateReport(id);
					waitForPageLoad();
					for(int index =0; index< contractList.length; index++)
					{
						GCUtils.validateContractUpdateReport(contractList[index], "Approval Status", expectedStatus, strdownloadPath+"BulkUpdate_UpdateReport_"+id+".xlsx");
					}
					waitForPageLoad();
					for(int index =0; index< contractList.length; index++)
					{
						ContractSearchPage.get().searchContract(contractList[index]);			
						seVerifyFieldValue(ContractInformationPage.get().approvalStatus,  expectedStatus, "Approval Status");
							
					}
					waitForPageLoad();									
					//setResult("STATUS", RESULT_STATUS);
					seCloseBrowser();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {			
			endTestScript();
			endExtentReport();
		}
	}

}
