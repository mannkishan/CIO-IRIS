package testScripts.groupConfigurator.bulkUpdate;

import org.openqa.selenium.By;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.groupConfigurator.BulkUpdatePage;
import page.groupConfigurator.ContractInformationPage;
import page.groupConfigurator.ContractSearchPage;
import page.groupConfigurator.HomePage;
import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;
import utility.GCUtils;

public class ChangeContractPLCValue_TS extends CoreSuperHelper {

	static String strbaseURL = EnvHelper.getValue("gc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	
	public static  void main(String[] args) {
	try{
			initiateTestScript();
			String userID = "";
			for(iROW=1;iROW<=getRowCount();iROW++)
			{
				try{
					String proxyID = getCellValue("ProxyID");
					String PLCStatus=getCellValue("PLC_Status");
					String ExpectedPLCStatus=getCellValue("ExpectedPLC_Status");
					String[] contractList = getCellValue("ContractCodes").trim().split(",");
					String runflag = getCellValue("RunFlag");
					String effec_Thru_Date =getCellValue("EffectiveThrough");
					String reasonCode =getCellValue("ReasonCode");					
					if(runflag.equalsIgnoreCase("Yes"))
					{
						logExtentReport("Change Contract PLC Value validation in GC Application");						
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL,getReportPathFolder());
						LoginPage.get().loginApplication(struserProfile);
						userID = getLoginInfo(struserProfile)[0];
						waitForPageLoad();
						seClick(HomePage.get().groupBulkUpdate,"Click on Home Page");
						waitForPageLoad();
						seSetText(BulkUpdatePage.get().effectiveThrough,effec_Thru_Date,"Enters Effective Through date in Find Contracts Page");
						waitForPageLoad();
						seSelectText(BulkUpdatePage.get().planCriteria, "Proxy ID", "Selects Plan Criteria type");
						waitForPageLoad();
						seClick(BulkUpdatePage.get().addPlanCriteria, "addPlanCriteria");
						waitForPageLoad();
						seSetText(BulkUpdatePage.get().proxyIdValue,proxyID,"Selects Plan Criteria type");
						waitForPageLoad();
						seSelectText(BulkUpdatePage.get().contractCriteria, "Product Lifecycle Status", "Select PLC Status from the contract criteria");
						waitForPageLoad();
						seClick(BulkUpdatePage.get().addContractCriteria, "addContractCriteria");
						waitForPageLoad();
						seSelectText(BulkUpdatePage.get().dropDown_PLCState,PLCStatus, "Select searchStatus from the approval status");
						waitForPageLoad();
						seClick(BulkUpdatePage.get().contractSearch, "click contractSearch");
						waitForPageLoad();						
						seClick(BulkUpdatePage.get().link_SelectAll, "link_SelectAll");
						waitForPageLoad();
						seClick(BulkUpdatePage.get().UpdateSelectedContracts, "UpdateSelectedContracts");
						waitForPageLoad();
						seSelectText(BulkUpdatePage.get().reasonCode,reasonCode, "Selects reason code");
						waitForPageLoad();
						seSelectText(BulkUpdatePage.get().newPLCStatus,ExpectedPLCStatus,"change the PLC status of the contract to"+ExpectedPLCStatus);
						waitForPageLoad();
						seClick(BulkUpdatePage.get().bulkUpdateSubmit, "BulkUpdatePageSubmit");
						waitForPageLoad();
						String id = GCUtils.getBulkUpdateID(By.className("af_table_content"), 5, userID, 2);
						System.out.println("id value--->"+id);
						GCUtils.run(userID, reasonCode);
						waitForPageLoad();
						seClick(BulkUpdatePage.get().clickHistory, "clickHistory");
						GCUtils.downloadUpdateReport(id);
						waitForPageLoad();
						for(int index =0; index< contractList.length; index++)
						{
							GCUtils.validateContractUpdateReport(contractList[index], "Product Lifecycle State", ExpectedPLCStatus, getReportPathFolder()+"BulkUpdate_UpdateReport_"+id+".xlsx");
						}
						Thread.sleep(5000);
						for(int index =0; index< contractList.length; index++)
						{
							ContractSearchPage.get().searchContract(contractList[index]);
						    seVerifyFieldValue(ContractInformationPage.get().PLCState, ExpectedPLCStatus, "Product Lifecycle State");
						}
						
					//setResult("STATUS", RESULT_STATUS);
					System.out.println("Number of row in data sheet"+getRowCount());
					//seCloseBrowser();
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			endTestScript();
			endExtentReport();
			closeExcelFile();
			seCloseBrowser();
		}
	}

}

