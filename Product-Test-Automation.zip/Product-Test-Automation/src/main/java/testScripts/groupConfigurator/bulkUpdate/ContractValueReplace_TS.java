package testScripts.groupConfigurator.bulkUpdate;

import org.openqa.selenium.By;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import com.anthem.selenium.utility.ExtentReportsUtility;

import page.groupConfigurator.BulkUpdatePage;
import page.groupConfigurator.ContractSearchPage;
import page.groupConfigurator.HomePage;
import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;
import utility.GCUtils;

public class ContractValueReplace_TS extends CoreSuperHelper {

	static String strbaseURL = EnvHelper.getValue("gc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	static String strdownloadPath = "";

	public static  void main(String[] args) {
		try{
			initiateTestScript();
			String userID ="";
			for(iROW=1;iROW<=getRowCount();iROW++)
			{
				try{
					String runflag = getCellValue("RunFlag");
					String effec_Thru_Date =getCellValue("EffectiveThrough");
					String AdminCritType =getCellValue("AdminCriteria");
					String AdminCritTypeNewValue =getCellValue("AdminCritType_NewValue");
					String PlanAdminCritType =getCellValue("PlanAdminCritType");
					String PlanAdminCritTypeNewvalue =getCellValue("PlanAdminCritType_NewValue");
					String WaitingPerType =getCellValue("WaitingPertype");
					String WaitingPerTypeNewvalue =getCellValue("WaitingPerType_NewValue");
					String NumOfRecordToSelect =getCellValue("Number_Of_Record");
					int checkboxSize=Integer.parseInt(NumOfRecordToSelect);
					String effectiveDate=getCellValue("UpdatedEffectiveDate");
					String reasonCode =getCellValue("ReasonCode");					
					String ContractsUpdatedSheet ="Contracts Updated";
					String ContractsNotUpdatedSheet ="Contracts Not Updated";
					String ColHdrName ="Contract Code";
					String ContractCode="";
					String FailureReason="";
					if(runflag.equalsIgnoreCase("Yes"))
					{
						logExtentReport("Error Message validation in GC Application");
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL, getReportPathFolder());
						LoginPage.get().loginApplication(struserProfile);
						userID = getLoginInfo(struserProfile)[0];
						waitForPageLoad();
						seClick(HomePage.get().groupBulkUpdate,"Click on Home Page");
						seSetText(BulkUpdatePage.get().effectiveThrough,effec_Thru_Date,"Enters Effective Through date in Find Contracts Page");
						seSelectText(BulkUpdatePage.get().planCriteria, getCellValue("PlanCriteria_ProxyId"), "Selects Plan Criteria type");
						waitForPageLoad();
						seClick(BulkUpdatePage.get().addPlanCriteria, "addPlanCriteria");
						seSetText(BulkUpdatePage.get().proxyIdValue,getCellValue("PlanCritTypeValue"),"Selects Plan Criteria type");
						seSelectText(BulkUpdatePage.get().adminCriteriaDropDown,AdminCritType, "Selects Admin Crietria type");
						seClick(BulkUpdatePage.get().addAdminCriteria, "addAdminCriteria");
						
						seSelectText(BulkUpdatePage.get().adminCriteriaValue,getCellValue("AdminCriteria_Value"), "Selects Admin Crietria type");
					
						seSelectText(BulkUpdatePage.get().planAdminCriteriaDropDown,PlanAdminCritType, "Selects Plan Admin Crietria type");
					
						seClick(BulkUpdatePage.get().addPlanAdminCriteria, "addPlanAdminCriteria");
		
						seSelectText(BulkUpdatePage.get().planAdminCritTabCol3,getCellValue("PlanAdminCritTypeCol3_value"), "Selects PlanAdmin Criteria table column3 values");
		
						seSelectText(BulkUpdatePage.get().planAdminCritTabCol4,getCellValue("PlanAdminCritTypeCol4_value"), "Selects PlanAdmin Criteria table column4 values");

						seSelectText(BulkUpdatePage.get().waitingPeriodDropdown,WaitingPerType, "Selects Waiting period type");

						seClick(BulkUpdatePage.get().addWaitingPeriod, "addWaitingPeriod");
	
						seSelectText(BulkUpdatePage.get().waitingPeriodTabCol3,getCellValue("WaitingPerCol3_value"), "Selects Waiting Period table column3 values");

						seSelectText(BulkUpdatePage.get().waitingPeriodTabCol4,getCellValue("WaitingPerCol4_value"), "Selects Waiting Period table column4 values");
		
						seClick(BulkUpdatePage.get().contractSearch, "click contractSearch");

						BulkUpdatePage.get().recordFound();
						BulkUpdatePage.get().recordSelection(checkboxSize);
						seClick(BulkUpdatePage.get().UpdateSelectedContracts, "UpdateSelectedContracts");

						seClick(BulkUpdatePage.get().currentEffectiveDate,"currentEffectiveDate");
						waitForPageLoad();
						seSetText(BulkUpdatePage.get().effectiveDate,effectiveDate,"Enters Effective Date");

						seSelectText(BulkUpdatePage.get().reasonCode,reasonCode, "Selects reason code");

						seSelectText(BulkUpdatePage.get().adminCritReplacevalue,AdminCritTypeNewValue, "Selects new value for admin criteria");
		
						seSelectText(BulkUpdatePage.get().planAdminCritReplacevalue,PlanAdminCritTypeNewvalue, "Selects new value for plan admin criteria");

						seSelectText(BulkUpdatePage.get().waitingPerReplacevalue,WaitingPerTypeNewvalue, "Selects new value for waiting period section");

						seClick(BulkUpdatePage.get().bulkUpdateSubmit, "bulkUpdateSubmit");

						String id = GCUtils.getBulkUpdateID(By.className("af_table_content"), 5, userID, 2);
						System.out.println("id value--->"+id);
						GCUtils.run(userID, reasonCode);

						seClick(BulkUpdatePage.get().clickHistory, "clickHistory");
						GCUtils.downloadUpdateReport(id);

						String filePath= getReportPathFolder()+"\\"+GCUtils.lastModifiedFile(getReportPathFolder());
						String rowData= GCUtils.getFirstRowData(filePath,ContractsUpdatedSheet,ColHdrName);
						if(rowData.equals("")){
							ContractCode= GCUtils.getFirstRowData(filePath,ContractsNotUpdatedSheet,ColHdrName);
							FailureReason= GCUtils.getFirstRowData(filePath,ContractsNotUpdatedSheet,"Reason");
							log(FAIL, "Verify contract values are replaced", 
									"Contract("+ContractCode+") is not updated with replace value and Failure Reason is ='"+FailureReason+"'");
						}else{
							ContractCode=GCUtils.getFirstRowData(filePath,ContractsUpdatedSheet,ColHdrName);  
							ExtentReportsUtility.log(PASS, "Verify contract values are replaced", 
									"Contract("+ContractCode+") is updated with replace value");
							seClick(HomePage.get().link_ContractSerach,"link_ContractSerach");
							seSetText(ContractSearchPage.get().contractCode,ContractCode,"Enter Contract code as "
									+ ContractCode);
							seClick(ContractSearchPage.get().contractSearch, "Contract button search");
							seClick(ContractSearchPage.get().row_ContractResults_Table,"row_ContractResults_Table");
							GCUtils.replaceValueValidation(AdminCritTypeNewValue,PlanAdminCritTypeNewvalue,WaitingPerTypeNewvalue);
						}
					}
					System.out.println("Number of row in data sheet"+getRowCount());
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			endTestScript();
			endExtentReport();
			closeExcelFile();
			seCloseBrowser();
		}
	}

}
