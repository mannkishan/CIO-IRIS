package testScripts.groupConfigurator.bulkUpdate;


import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import page.groupConfigurator.BulkUpdatePage;
import page.groupConfigurator.HomePage;
import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;
import utility.GCUtils;
import page.groupConfigurator.ImpactReviewPage;
import page.groupConfigurator.ContractSearchPage;

public class Replacevalues_TS extends CoreSuperHelper {
	
	static String BASE_URL = EnvHelper.getValue("URL");
	static String path = "C:\\Application\\reports\\";
	static String contractsNotUpdated="Contracts Not Updated";
	static String contractsUpdated="Contracts Updated";
	static String strcontractCode="";
	static String FailureReason="";
	static String userProfile = EnvHelper.getValue("User_Profile");
	static String userID = "";
	
	public static  void main(String[] args) {		
		try{
			initiateData();
			startExtentReport();
			for(iROW=1;iROW<=getRowCount();iROW++) {
				try {
			logExtentReport("Update Reason code and  Contact info for : Person ");
			if (getCellValue("Run_Flag").trim().equalsIgnoreCase("Yes")){
			seOpenBrowser(BrowserConstants.Chrome,BASE_URL,path);
			LoginPage.get().loginApplication(userProfile);
			seClick(HomePage.get().groupBulkUpdate, "Click on Group bulk Update");
			waitForPageLoad();
			userID =getLoginInfo(userProfile)[0];
			String reasonCode =getCellValue("ReasonCode");
			seSetText(BulkUpdatePage.get().effectiveThrough,getCellValue("EffectiveDate"),"Setting effective through date text");
			waitForPageLoad();
            seSelectText(true,BulkUpdatePage.get().dropDown_ContactInfoCriteria,getCellValue("Contactinfo"), "Selecting Proxy Id from plan criteria dropdown");
            waitForPageLoad();
			seClick(BulkUpdatePage.get().addContactInfoCriteria,"Clicking on addContactInfoCriteria");
			waitForPageLoad();
            seSelectText(true,BulkUpdatePage.get().dropDown_Name_Person,getCellValue("Personname"),"Selecting PersonName from Contact Info dropdown");
            waitForPageLoad();
			seClick(BulkUpdatePage.get().button_Search,"Clicking on Search button");
			waitForPageLoad();
			utility.GCUtils.recordFound();
			waitForPageLoad();
			utility.GCUtils.recordSelection(2);
			waitForPageLoad();
			seClick(BulkUpdatePage.get().UpdateSelectedContracts, "Clicking on Update Selected Contracts button");
			waitForPageLoad();
			seSelectText(true,BulkUpdatePage.get().reasonCode,getCellValue("ReasonCode"),"Selecting Reason Code From DropDown");
			waitForPageLoad();
			seSelectText(true,BulkUpdatePage.get().per_role,getCellValue("PersonRole"), "Selecting " + getCellValue("PersonRole") + " value for Person Role field");
			waitForPageLoad();			
			seClick(BulkUpdatePage.get().bulkUpdateSubmit,"Clicking on Submit Button");
			waitForPageLoad();
			seClick(ImpactReviewPage.get().historyTab, "Clicking on History Link");
			waitForPageLoad();
			seClick(ImpactReviewPage.get().impactReview,"Clicking on Impact Review tab");
			waitForPageLoad();
			utility.GCUtils.run(userID,reasonCode);
			waitForPageLoad();
			seClick(ImpactReviewPage.get().historyTab,"Clicking on history tab");
			waitForPageLoad();
			utility.GCUtils.downloadUpdateReport(userID,reasonCode);
			String filePath=path+"\\"+utility.GCUtils.lastModifiedFile(path);
			System.out.println("FILE Path-->"+filePath);
			String rowData= utility.ExcelUtility.validateexcelData(path,contractsUpdated,"Contracts Updated ");
			if(rowData.equals(""))

				{
					strcontractCode=utility.ExcelUtility.validateexcelData(filePath,contractsNotUpdated,"Effective Date");
					FailureReason=utility.ExcelUtility.validateexcelData(filePath,contractsNotUpdated,"Reason");					
					log(PASS, "Contracts are present","Contracts For Update sheet has values:("+strcontractCode+")");
					log(PASS, "Contracts are   available for updation","Contracts  available "+filePath);
				}
				else
				{              
					strcontractCode=utility.ExcelUtility.validateexcelData(filePath,contractsUpdated,"Effective Date");					
					log(FAIL, "Contracts are present","Contracts For Update sheet has values:("+strcontractCode+")");
				}
					ContractSearchPage.get().searchContract(strcontractCode);
					Thread.sleep(2000);
					GCUtils.validateReplacevalue_org(getCellValue("PersonRole") ,strcontractCode);
			}
				}catch (Exception e) {
					e.printStackTrace();
				}
		}
		
		}
			
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{			
			endTestScript();
			closeExcelFile();
			System.gc();
			
		}
	}
		

}
