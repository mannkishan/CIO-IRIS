package testScripts.groupConfigurator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.SendKeysAction;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.groupConfigurator.ContractInformationPage;
import page.groupConfigurator.ContractSearchPage;
import page.groupConfigurator.ContractTransitionPage;
import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;
import utility.GCUtils;

public class EditContract_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("gc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static String approver = EnvHelper.getValue("user.profile.approver");
	public static void main(String[] args) {
		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strContractCode =getCellValue("ContractCode");
					String strCDHVendor =getCellValue("CDHVendor");
					String strHRAPaymentOption =getCellValue("HRAPaymentOption");
					String strEmpHealthAccountContribution =getCellValue("EmpHealthAccountContribution");
					logExtentReport("Edit a Contract");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);
					seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(ContractSearchPage.get().contractCode));
					ContractSearchPage.get().searchContract(strContractCode);
					ContractInformationPage.get().validateContractStatus("Production");
					seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(ContractInformationPage.get().editContract));
					seClick(ContractInformationPage.get().editContract, "Edit Contract");
					seSelectText(ContractTransitionPage.get().reasonCode,"Other", "Select Other from reasonCode");
					seSetText(ContractTransitionPage.get().comment, getCellValue("Comment"), "Comment");
					seClick(ContractTransitionPage.get().buttonOk, "Ok");
					seClick(ContractInformationPage.get().adminTab, "Admin");
					String strAppCDHVendor=seGetDropDownValue(ContractInformationPage.get().CDHVendro);
					if(strAppCDHVendor.equalsIgnoreCase("CCA")){
						seSelectText(ContractInformationPage.get().CDHVendro, "Lites", "Select Lites from CDHVendro");
						strAppCDHVendor="Lites";
					}
					else{
						seSelectText(ContractInformationPage.get().CDHVendro, "CCA", "Select CCA from CDHVendro");
						strAppCDHVendor="CCA";
					}
					String strAppHRAPaymentOption=seGetDropDownValue(ContractInformationPage.get().HRAPaymentOption);
					if(strAppHRAPaymentOption.equalsIgnoreCase("Member Pay")){
						seSelectText(ContractInformationPage.get().HRAPaymentOption, "Provider Pay", "Select Provider Pay from HRAPaymentOption");
						strAppHRAPaymentOption="Provider Pay";
					}
					else{
						seSelectText(ContractInformationPage.get().HRAPaymentOption, "Member Pay", "Select Member Pay from HRAPaymentOption");
						strAppHRAPaymentOption="Member Pay";
					}
					seSetText(ContractInformationPage.get().empHealthAccountContribution, strEmpHealthAccountContribution, "Set text for empHealthAccountContribution");
					WebElement Save=getWebDriver().findElement(By.xpath(".//*[@id='content']/div[4]/span[4]/a"));
					((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",Save);
					GCUtils.get().requestAudit();
					seCloseBrowser();
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(approver);
					seWaitForClickableWebElement(ContractSearchPage.get().contractSearch, 60);
					ContractSearchPage.get().searchContract(strContractCode);
					GCUtils.get().approveAudit();
					GCUtils.get().moveToTest();
					GCUtils.get().approveTest();
					GCUtils.get().finalizeContract();
					seCloseBrowser();
								
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);
					ContractSearchPage.get().sewaitForContractStatus(strContractCode, "Production");
					ContractSearchPage.get().searchContract(strContractCode);
					ContractInformationPage.get().validateContractStatus("Production");
					ContractInformationPage.get().validateEditContract(strAppCDHVendor, strAppHRAPaymentOption, strEmpHealthAccountContribution);
					
					
					
			} catch (Exception e) {
				e.printStackTrace();
				log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
			}
		}

	} catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
	} finally {
		if(getWebDriver() != null)
		{
			seCloseBrowser();
		}
		endTestScript();
	}
		
}
	
}
