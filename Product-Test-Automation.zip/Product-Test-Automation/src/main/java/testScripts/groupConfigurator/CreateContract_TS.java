package testScripts.groupConfigurator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.groupConfigurator.ContractInformationPage;
import page.groupConfigurator.ContractPlanAdmin;
import page.groupConfigurator.ContractSearchPage;
import page.groupConfigurator.CreateNewContractPage;
import page.groupConfigurator.LoginPage;
import page.groupConfigurator.ModifyTheContractPage;
import utility.CoreSuperHelper;
import utility.GCUtils;

public class CreateContract_TS extends CoreSuperHelper{
	static String baseURL = EnvHelper.getValue("gc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static String approver = EnvHelper.getValue("user.profile.approver");
	public static void main(String[] args) {
		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strplanID = getCellValue("PlanID");
					String strContractCode =getCellValue("ContractCode");
					String strLOB = getCellValue("LOB");
					logExtentReport("Create a Contract");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);
					seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(ContractSearchPage.get().createNewContract));
					seClick(ContractSearchPage.get().createNewContract, "Create New Contract");
					seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(CreateNewContractPage.get().effectiveDate));
					seSetText(CreateNewContractPage.get().effectiveDate, getCellValue("EffectiveDate"), "Set text for effectivedate");
					seSelectText(CreateNewContractPage.get().productLifeCycle,"Certification", "Select Certification from product life cycle");
					seSelectText(CreateNewContractPage.get().state, getStateCode(getCellValue("State")), "Select "+getCellValue("State")+" from state");
					seSelectText(CreateNewContractPage.get().marketSegment,  getCellValue("MarketSegment"), "Select "+getCellValue("MarketSegment")+" from Market Segment");
					seSelectText(CreateNewContractPage.get().lineOfBusiness, strLOB, "Select "+getCellValue("LOB")+" from Line of Business");
					seClick(CreateNewContractPage.get().moveToRight, "Move to Right(LOB)");
					seSelectText(CreateNewContractPage.get().businessEntity, getCellValue("BusinessEntity"), "Select "+getCellValue("BusinessEntity")+" from Business Entity");
					seSelectText(CreateNewContractPage.get().businessUnit, getCellValue("BusinessUnit"), "Select "+getCellValue("BusinessUnit")+" from Business Unit");
					seClick(CreateNewContractPage.get().nextAvailableCode, "Next Available Code");
					seClick(CreateNewContractPage.get().create, "Create");
					strContractCode = ContractInformationPage.get().getContractCode();
					setCellValue("ContractCode", strContractCode);
					
					seClick(ContractInformationPage.get().adminTab, "Admin");
					seSelectText(ContractInformationPage.get().adminLifetimeLimitRestriction, "Yes", "Select Yes from Life time limit restriction");
					seSelectText(ContractInformationPage.get().adminPricerCoverage, "MED", "Select 1 from Pricer Coverage Code");
					seSelectText(ContractInformationPage.get().adminPricerCode, "0001", "Select 0001 from Pricer Code");
					seSelectText(ContractInformationPage.get().adminPricerNetwork, "HMO", "Select HMO from Pricer Network");
					if(strLOB.equalsIgnoreCase("Medical"))
					{
						seSelectText(ContractInformationPage.get().CDHVendro, "CCA", "Select CCA from CDH Vendor");
						seSelectText(ContractInformationPage.get().HRAPaymentOption, "Member Pay", "Select Member Pay from HRA Payment Option");
					}
					seSelectText(ContractInformationPage.get().adminPreExisting, "Yes", "Select Yes from Pre-Existing");
					seSelectText(ContractInformationPage.get().adminLiabilityPriorityRule, "Birthday Rule", "Select Birthday Rule from Liability Priority Rule");
					seSelectText(ContractInformationPage.get().adminQHPIndicator, "Multi-State", "Select Multi-State from QHP Indicator");
					seSetText(ContractInformationPage.get().adminProductMarketName, "Automation Testing", "Set text for Product Market Name");
					seSetText(ContractInformationPage.get().adminProductMarketCode, "001", "Set text for Product Market Code");
					seSelectText(ContractInformationPage.get().adminCompanyCode, "385C", "Select 385C from Company Code");
					seSelectText(ContractInformationPage.get().adminCoverageLimitedTo, "Family", "Select Family from Coverage Limited to");
					seSelectText(ContractInformationPage.get().adminMaximumEnrollmentAge, "60", "Select 60 from Maximum Enrollment Age");
					seSetText(ContractInformationPage.get().adminSalesEffective, getCellValue("EffectiveDate"), "Set text for Sales Effective Date");
					seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(ContractInformationPage.get().adminSave));
					WebElement save = ContractInformationPage.get().adminSave;
					((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",save);
					
					boolean planAddStatus = ModifyTheContractPage.get().addPlanToContract(strplanID);
					if(planAddStatus)
					{
						ContractPlanAdmin.get().updatePlanDetails();
						GCUtils.get().requestAudit();
						seCloseBrowser();
						Thread.sleep(2000);
						seOpenBrowser(BrowserConstants.Chrome, baseURL);
						LoginPage.get().loginApplication(approver);
						seWaitForClickableWebElement(ContractSearchPage.get().contractSearch, 60);
//						seClick(ContractSearchPage.get().contractSearch, "Click Contract Search link");
						ContractSearchPage.get().searchContract(strContractCode);
						GCUtils.get().approveAudit();
						GCUtils.get().moveToTest();
						GCUtils.get().approveTest();
						GCUtils.get().finalizeContract();
						seCloseBrowser();
						Thread.sleep(2000);
						seOpenBrowser(BrowserConstants.Chrome, baseURL);
						LoginPage.get().loginApplication(userProfile);
						ContractSearchPage.get().sewaitForContractStatus(strContractCode, "Production");
						ContractSearchPage.get().searchContract(strContractCode);
						ContractInformationPage.get().validateContractStatus("Production");
					}
					
					
					
					
//					seCloseBrowser();
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			if(getWebDriver() != null)
			{
				seCloseBrowser();
			}
			endTestScript();
		}
	}
	
	
	
	public static String getStateCode(String state)
	{
		String strCode = "";
		
		switch (state.toUpperCase()) {
		case "NEWYORK":
			strCode= "NY";
			break;
			
//		case "NEWYORK":
//			strCode= "NY";
//			break;
			
		default:
			throw new IllegalArgumentException("Please provide the correct state information");
		}
		
		return strCode;
	}
	
	
	public static void findContract()
	{
		
	}

}
