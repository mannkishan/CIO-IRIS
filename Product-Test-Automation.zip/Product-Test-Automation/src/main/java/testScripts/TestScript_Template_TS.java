package testScripts;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import utility.CoreSuperHelper;

/*
'Revision History
'#############################################################################
'@rev.On	@rev.No		@rev.By				  @rev.Comments
'										
'#############################################################################
*/

/**
 * Manual test case: <Could provide manual test case reference here>
 * <p>
 * Test script template
 * <p>
 * Please refer this test script while creating other test scripts
 * 
 * @author TP&E
 * @since 14-July-2017
 *
 */
public class TestScript_Template_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("url");

	public static void main(String[] args) {

		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("Test Script/ Functionality Descrtiption");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);

					// Scripting steps starts here.

					// Scripting steps end here.

					seCloseBrowser();
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}

}
