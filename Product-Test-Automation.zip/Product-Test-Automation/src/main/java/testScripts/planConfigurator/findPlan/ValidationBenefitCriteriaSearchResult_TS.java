package testScripts.planConfigurator.findPlan;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import utility.CoreSuperHelper;

public class ValidationBenefitCriteriaSearchResult_TS extends CoreSuperHelper {
	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	
	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					    String strNetwork = getCellValue("Network");
					    String strSituation = getCellValue("Situation");
					    String strBenefit =getCellValue("Benefit");
					    String strSituatonTab =getCellValue("SituationTab");
					    String strNetworkTab=getCellValue("NetworkTab");
					    String strRunFlag = getCellValue("Run_Flag");
					    String strTCName = getCellValue("TCName"); 
					    if(strRunFlag.equalsIgnoreCase("YES")) {
					    	logExtentReport(strTCName); 
						if(getWebDriver()==null)
						{
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
						waitForPageLoad();
						LoginPage.get().loginApplication(struserProfile);
						waitForPageLoad(300);					
						}
						seClick(HomePage.get().find, "Find");
						waitForPageLoad(300);
						seClick(HomePage.get().findPlan, "Find Plan");
						waitForPageLoad(300);
						seClick(FindPlanPage.get().benefitCriteria, "Benefit Criteria");
						waitForPageLoad(300);
						FindPlanPage.get().selectTheBenefit(strBenefit);
						waitForPageLoad(300);
						FindPlanPage.get().situationGroup(strNetwork);
						waitForPageLoad(300);
						FindPlanPage.get().situationType(strSituation);
						seClick(FindPlanPage.get().searchoption, "Search");
						waitForPageLoad(360);
						waitForPageLoad(360);
						seClick(FindPlanPage.get().plandetails, "List of panel");
						waitForPageLoad(360);
						waitForPageLoad(360);
						FindPlanPage.get().benefit();
						waitForPageLoad(360);
						waitForPageLoad(360);
						
						seClick(FindPlanPage.get().completePlan, "Complete Plan");
						waitForPageLoad(360);
						waitForPageLoad(360);
						FindPlanPage.get().verifyNetwork(strNetworkTab);
						FindPlanPage.get().verifySituation(strSituatonTab);
						setResult("STATUS", RESULT_STATUS);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null)
			{
				seCloseBrowser();
			}
			endTestScript();

		}
	}
}
