package testScripts.planConfigurator.findPlan;

import java.util.List;

import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HistoryPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import utility.CoreSuperHelper;

public class ValidateTransitionalCriteriaSearchResults_TS extends CoreSuperHelper {
	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	
	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
				
					
					    String strRunFlag = getCellValue("Run_Flag");
					    if(strRunFlag.equalsIgnoreCase("YES")) {
						String strCreateFormDate = getCellValue("Createfrom");
						String strCreateToDate = getCellValue("CreateThrough");
						String dtmValueFromDate =getCellValue("CreatedformDate");
						String dtmValueTodate =getCellValue("Createthroughdate");
						String strCreated = getCellValue("Created");
						String strCopied =getCellValue("Copied");
						String strEdited =getCellValue("Edited");
						String strTCName =getCellValue("TCName");
						int intValueFromDate = Integer.parseInt(dtmValueFromDate);
						int intValueTodate = Integer.parseInt(dtmValueTodate);
						logExtentReport(strTCName);
						if(getWebDriver()==null)
						{
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
						waitForPageLoad();
						LoginPage.get().loginApplication(struserProfile);
						waitForPageLoad(300);					
						}
						seClick(HomePage.get().find, "Find");
						waitForPageLoad(300);
						seClick(HomePage.get().findPlan, "Find Plan");
						waitForPageLoad(300);
					    FindPlanPage.get().createFormDate(strCreateFormDate);
					    waitForPageLoad(100);
					    FindPlanPage.get().createToDate(strCreateToDate);
					    waitForPageLoad(100);
					    seClick(FindPlanPage.get().createFrom, "Create From");
						seClick(FindPlanPage.get().searchoption, "Search");
						waitForPageLoad(360);
						seClick(FindPlanPage.get().plandetails, "List of panel");
						waitForPageLoad(360);
						seClick(FindPlanPage.get().history, "History Icon Clicked");
						waitForPageLoad(360);
						List<WebElement> arrCreatedMode = FindPlanPage.get().createdtext();
						for(int i=0;i<arrCreatedMode.size();i++){
							if(arrCreatedMode.get(i).getText().equalsIgnoreCase(strCreated)){
								String dateValue=FindPlanPage.get().createdValueCreated.getText().toString().trim();
								FindPlanPage.get().verifyDate(dateValue, intValueTodate, intValueFromDate);
								break;
							}else if(arrCreatedMode.get(i).getText().equalsIgnoreCase(strCopied)){
								String dateValue=FindPlanPage.get().createdValueCopied.getText().toString().trim();
								FindPlanPage.get().verifyDate(dateValue, intValueTodate, intValueFromDate);
								break;
							}else if(arrCreatedMode.get(i).getText().equalsIgnoreCase(strEdited)){
								String dateValue=FindPlanPage.get().createdValueEdited.getText().toString().trim();
								FindPlanPage.get().verifyDate(dateValue, intValueTodate, intValueFromDate);
								break;
							}
							else{
								if(i==arrCreatedMode.size())
								log(FAIL, "No Record Present");
							}
						}
						seClick(HistoryPage.get().close,"Close");
						waitForPageLoad(300);
						seClick(HomePage.get().homePageBtn, "Home");
						waitForPageLoad(300);
						seClick(HomePage.get().find, "Find ");
						waitForPageLoad(300);
						seClick(HomePage.get().findPlan, "Find Plan ");
						waitForPageLoad(300);
						
						FindPlanPage.get().modifiedToDate(strCreateFormDate);
						FindPlanPage.get().modifiedFromDate(strCreateToDate);
						seClick(FindPlanPage.get().modifiedToDate, "Modified to date");
						waitForPageLoad(300);
						seClick(FindPlanPage.get().searchoption, "Search");
						waitForPageLoad(360);
						String strmodifiedDate = FindPlanPage.get().modifiedFirstRow.getText();
						
						int intModifiedDates =Integer.parseInt(strmodifiedDate.substring(3, 5));
						if(intModifiedDates>intValueFromDate ||intModifiedDates< intValueTodate){
							log(PASS, "Modified date is in between "+strmodifiedDate+" and "+strmodifiedDate);
						}else{
							log(FAIL, "Modified date is not in between "+strmodifiedDate+" and "+strmodifiedDate);
						}
						setResult("STATUS", RESULT_STATUS);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null)
			{
				seCloseBrowser();
			}
			endTestScript();

		}
	}

}
