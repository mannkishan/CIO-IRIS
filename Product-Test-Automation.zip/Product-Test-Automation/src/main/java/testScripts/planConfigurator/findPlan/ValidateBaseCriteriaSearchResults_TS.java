package testScripts.planConfigurator.findPlan;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import utility.CoreSuperHelper;

public class ValidateBaseCriteriaSearchResults_TS extends CoreSuperHelper {
	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	public static void main(String[] args) {
		try {
			MANUAL_TC_EXECUTION_EFFORT = "00:05:00";
			String strRunFlag ="";
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					strRunFlag = getCellValue("Run_Flag");
					if(strRunFlag.equalsIgnoreCase("YES")) {
						String strTestCaseID = getCellValue("Test_Case_ID");
						String strPlanName = getCellValue("PlanName");
						String strPlanDescription = getCellValue("PlanDescription");
						String strPlanVersionId = getCellValue("PlanVersionId");
						String strProxyPlanID = getCellValue("ProxyPlanID");
						String strEffDate = getCellValue("EffDate");
						String actualSearchValue="";
						logExtentReport(getCellValue("TCName"));
						if(getWebDriver()==null){
							seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
							LoginPage.get().loginApplication(struserProfile);
						}
						waitForPageLoad(300);
						seClick(HomePage.get().find, "Find link");
						waitForPageLoad(300);
						seClick(HomePage.get().findPlan, "Find Plan link");
						waitForPageLoad(300);

						switch (strTestCaseID) {
						case "Find Plan with Base Criteria Plan Name":
							actualSearchValue=FindPlanPage.get().validateBaseCriteriaSearch(strPlanName, "Plan Name");
							RESULT_STATUS = actualSearchValue.equalsIgnoreCase(strPlanName) ? true: false;
							log(!actualSearchValue.equalsIgnoreCase(strPlanName) ? FAIL :PASS , "Verify Plan Name","Expected  Plan Name: " + strPlanName + " Actual Plan Name: "+ actualSearchValue, true);
							break;
						case "Find Plan with Base Criteria Plan Description":
							actualSearchValue=FindPlanPage.get().validateBaseCriteriaSearch(strPlanDescription,"Plan Description");
							RESULT_STATUS = actualSearchValue.equalsIgnoreCase(strPlanDescription) ? true: false;
							log(!actualSearchValue.equalsIgnoreCase(strPlanDescription) ? FAIL :PASS, "Verify Plan Description","Expected  planDescription: " + strPlanDescription + " Actual planDescription: "+ actualSearchValue, true);
							break;
						case "Find Plan with Base Criteria Plan Id":
							actualSearchValue=FindPlanPage.get().validateBaseCriteriaSearch(strPlanVersionId, "Plan Version Id");
							RESULT_STATUS = actualSearchValue.equalsIgnoreCase(strPlanVersionId) ? true: false;
							log(!actualSearchValue.equalsIgnoreCase(strPlanVersionId) ? FAIL :PASS, "Verify Plan VersionID","Expected  planVersionID: " + strPlanVersionId + " Actual planVersionID: "+ actualSearchValue, true);
							break;
						case "Find Plan with Base Criteria Proxy Plan Id":
							actualSearchValue=FindPlanPage.get().validateBaseCriteriaSearch(strProxyPlanID, "Proxy Plan ID");
							RESULT_STATUS = actualSearchValue.equalsIgnoreCase(strProxyPlanID) ? true: false;
							log(!actualSearchValue.equalsIgnoreCase(strProxyPlanID) ? FAIL :PASS, "Verify Plan Proxy ID","Expected  Plan ProxyID: " + strProxyPlanID + " Actual planProxyID: "+ actualSearchValue, true);
							break;
						case "Find Plan with Base Criteria Effective Date":
							actualSearchValue=FindPlanPage.get().validateBaseCriteriaSearch(strEffDate, "Effective Date");
							RESULT_STATUS = actualSearchValue.equalsIgnoreCase(strEffDate) ? true: false;
							log(!actualSearchValue.equalsIgnoreCase(strEffDate) ? FAIL :PASS, "Verify Effective From Date","Expected  Effective From: " + strEffDate + " Actual effectiveFrom: "+ actualSearchValue, true);
							break;
						default:
							break;

						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					RESULT_STATUS = false;
					log(FAIL, "Validate search results for Base Criteria", "Exception occured "+e.getLocalizedMessage(), true);
				}
				finally {
					setResult("STATUS", RESULT_STATUS);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null){
				seCloseBrowser();
			}
			endTestScript();
		}
	}
}