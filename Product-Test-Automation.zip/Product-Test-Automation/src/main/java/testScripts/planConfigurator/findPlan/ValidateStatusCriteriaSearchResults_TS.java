package testScripts.planConfigurator.findPlan;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.groupConfigurator.LoginPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanSetupPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;

public class ValidateStatusCriteriaSearchResults_TS extends CoreSuperHelper {

	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
			try {
				String strRunFlag = getCellValue("Run_Flag");
				if(strRunFlag.equalsIgnoreCase("YES")) {
					String strStatus="Test Passed";	
					String strTCName =getCellValue("TCName");
					logExtentReport(strTCName);
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);
					waitForPageLoad();
					seWaitForClickableWebElement(HomePage.get().find, 10);
					seClick(HomePage.get().find, "on Find Menu");
					seClick(HomePage.get().findPlan, "Find Plan Option");
					waitForPageLoad(75);
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].style.border='2px groove green'", FindPlanPage.get().headerCriteria);
					waitForPageLoad();
					seClick(FindPlanPage.get().headerCriteria,"header criteria");
					waitForPageLoad();
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].style.border='2px groove green'", FindPlanPage.get().headerCriteriaType);
					waitForPageLoad();
					seClick(FindPlanPage.get().headerCriteriaType, "Status");
					WebElement wb=getWebDriver().findElement(By.xpath("//div[@id='header-criteria']/div/div[2]/div/div[1]/div[1]/div[1]/span[2]/span/span[1]/input"));
					WebElement wb1=getWebDriver().findElement(By.xpath("//div[@id='header-criteria']/div/div[2]/div/div[1]/div[1]/div[1]/span[2]/span/span[2]/ul/li[text()='Status']"));
					waitForPageLoad();
					seClick(wb, "status");
					seClick(wb1,"status"); 

					waitForPageLoad();
					seClick(FindPlanPage.get().selectStatus, "select status");
					seClick(getWebDriver().findElement(By.xpath("//span/span/span/ul/li/span[text()='"+strStatus+"']")),"");
					waitForPageLoad(1,120);
					seWaitForClickableWebElement(FindPlanPage.get().optionCriteria, 2);
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].style.border='2px groove green'", FindPlanPage.get().planSearch);
					seClick(FindPlanPage.get().planSearch, "Search");
					waitForPageLoad(100);

					int i=1;
					while(i!=6)   {

						if(seGetText(By.xpath("(//table[contains(@class,'table searchResultsTable fjaTable dataTable')]/tbody/tr/td[9])["+i+"]")).equals(strStatus)){

							String strPlan=seGetText(By.xpath("(//table[contains(@class,'table searchResultsTable fjaTable dataTable')]/tbody/tr/td[3])["+i+"]"));
							log(PASS, "Search result status are correct","plan "+strPlan+" is in "+strStatus+" status,RESULT=PASS");
							RESULT_STATUS=true;
						}
						else{
							log(FAIL, "Search result status are NOT correct","plan is NOT in "+strStatus+" status,RESULT=FAIL");
						}
						i++;
					}
				}

					setResult("STATUS", RESULT_STATUS);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null)
			{
				seCloseBrowser();
			}
			endTestScript();

		}
	}

}