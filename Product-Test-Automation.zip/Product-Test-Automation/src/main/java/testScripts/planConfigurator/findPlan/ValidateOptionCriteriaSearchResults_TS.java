package testScripts.planConfigurator.findPlan;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import utility.CoreSuperHelper;

public class ValidateOptionCriteriaSearchResults_TS extends CoreSuperHelper {
	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	public static void main(String[] args) {
		try {
			MANUAL_TC_EXECUTION_EFFORT = "00:05:00";
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					if(strRunFlag.equalsIgnoreCase("YES")) {
						String strTestCaseName = getCellValue("TCName");
						String strTestCaseID = getCellValue("Test_Case_ID");
						String strplanOptionAreaType = getCellValue("PlanOptionArea");
						String strplanOptionTypeValue = getCellValue("PlanOptionType");
						String strplanOptionNameValue = getCellValue("PlanOptionName");
						String strActualOptionCriteriaValue="";
						logExtentReport(strTestCaseName);
						if(getWebDriver()==null){
							seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad(300);
						}
						seClick(HomePage.get().find, "Find link");
						waitForPageLoad(300);
						seClick(HomePage.get().findPlan, "Find Plan link");
						waitForPageLoad(400);
						if(!strTestCaseID.equals(null))
						{
							strActualOptionCriteriaValue=FindPlanPage.get().verifyOptionCriteriaSearch(strplanOptionAreaType,strplanOptionTypeValue,strplanOptionNameValue);
							RESULT_STATUS = strActualOptionCriteriaValue.equalsIgnoreCase(strplanOptionNameValue) ? true: false;
							log(strActualOptionCriteriaValue.equalsIgnoreCase(strplanOptionNameValue) ? PASS : FAIL, strTestCaseName,"Expected Option Criteria Value :" +strplanOptionNameValue+ " Actual Option Criteria Value :"+strActualOptionCriteriaValue,true);
						}
						else
						{
							RESULT_STATUS = false;
							log(FAIL,"Input Data need to be verified","Input Data need to be verified",true);
						}	
					}
				} catch (Exception e) {
					e.printStackTrace();
					RESULT_STATUS = false;
					log(FAIL, "Validate search results for OptionCriteria", "Exception occured "+e.getLocalizedMessage(), true);
				}
				finally {
					setResult("STATUS", RESULT_STATUS);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null){
				seCloseBrowser();
			}
			endTestScript();
		}
	}


}
