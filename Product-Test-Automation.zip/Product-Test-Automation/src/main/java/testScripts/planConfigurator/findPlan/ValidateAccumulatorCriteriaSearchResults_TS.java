package testScripts.planConfigurator.findPlan;


import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import utility.CoreSuperHelper;

public class ValidateAccumulatorCriteriaSearchResults_TS extends CoreSuperHelper{

	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strAccumType="";	
	static String strAccumValue="";
	static String strDollarMax="";
	static String strDollarMaxValue="";
	static String strTestCaseID= "";

	public static void main(String[] args) {

		try {
			MANUAL_TC_EXECUTION_EFFORT = "00:05:00";
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					strTestCaseID = getCellValue("Test_Case_ID");
					String strTestCaseDescription=getCellValue("TCName");
					String strRunFlag = getCellValue("Run_Flag");
					System.out.println(strTestCaseDescription);
					int intMaxTime=1200;
					if(strRunFlag.equalsIgnoreCase("YES")) {
						logExtentReport(strTestCaseDescription);
						strAccumType=getCellValue("AccumType");
						strAccumValue=getCellValue("AccumValue");
						strDollarMax=getCellValue("DollarMax");	
						strDollarMaxValue=getCellValue("DollarMaxValue");
						String expectedValue="";
						boolean strResult=false;
						if(getWebDriver()==null)
						{
							seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
							waitForPageLoad(2,intMaxTime);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad(2,intMaxTime);					
						}
						if(!strTestCaseID.equals(null))
						{
							seClick(HomePage.get().find, "Find");
							waitForPageLoad(2,intMaxTime);
							seClick(HomePage.get().findPlan, "Find Plan");
							waitForPageLoad(5,intMaxTime);
							waitForPageLoad(300);
							seClick(FindPlanPage.get().accumulatorCriteria, "Accumulatory Criteria");
							waitForPageLoad(2,intMaxTime);		
							seClick(FindPlanPage.get().accumType,"Accumulator Type");
							waitForPageLoad(2,intMaxTime);
							waitForPageLoad();
							seClick(FindPlanPage.get().selectAccumType(strAccumType),"Accumulator Type"+strAccumType);
							waitForPageLoad(2,intMaxTime);
							seClick(FindPlanPage.get().accumValue,"Accumulator Value");
							waitForPageLoad(2,intMaxTime);
							seClick(FindPlanPage.get().selectAccumValue(strAccumValue),"Accumulator Type"+strAccumValue);
							waitForPageLoad(2,intMaxTime);
							expectedValue=seGetElementValue(FindPlanPage.get().accumValue).toString().trim();
							strResult=FindPlanPage.get().verifySearchUsingAccumulatorCriteria(strAccumType,strAccumValue,strDollarMax,strDollarMaxValue,expectedValue,intMaxTime);
							RESULT_STATUS = strResult;
							log(strResult?PASS:FAIL, strTestCaseID,strTestCaseDescription,true);
							seClick(PlanHeaderPage.get().close,"Close");
							waitForPageLoad();

						}
						else
						{
							RESULT_STATUS = false;
							log(FAIL,"Data need to be verified","Data need to be verified");
						}
						
					}
				} catch (Exception e) {
					RESULT_STATUS = false;
					e.printStackTrace();
					log(FAIL,"Verify Accumulator criteria "+strTestCaseID,"Exception occured :"+e.getStackTrace());
				}
				finally {
					setResult("STATUS", RESULT_STATUS);
					
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null)
			{
				seCloseBrowser();
			}
			endTestScript();

		}
	}


}
