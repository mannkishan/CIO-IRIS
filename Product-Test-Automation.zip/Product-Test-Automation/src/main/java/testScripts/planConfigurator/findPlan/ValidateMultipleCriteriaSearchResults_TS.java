package testScripts.planConfigurator.findPlan;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;
import utility.WebTableWithHeader;

public class ValidateMultipleCriteriaSearchResults_TS extends CoreSuperHelper {
	
	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String actualSearchValue="";
	static String strActualOptionCriteriaValue="";
	static String strSearchCriteriaValue;
	static String expectedValue="";
	static String actualValue="";
	static boolean result=false;
	static String actualoptionCriteria="";
	static String stractualSearchCriteriaValue="";
	static String strSearchCriteria="Expected value";
	
	
	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					
					String strRunFlag = getCellValue("Run_Flag");
					if(strRunFlag.equalsIgnoreCase("YES")) {
						
						logExtentReport(getCellValue("TCName"));
						String strTestCaseID = getCellValue("Test_Case_ID");
						String strHeaderCriteria=getCellValue("HeaderCriteria");
						String strValueType=getCellValue("ValueType");
						String strEffDate = getCellValue("EffDate");
						String strplanOptionAreaType = getCellValue("PlanOptionArea");
						String strplanOptionTypeValue = getCellValue("PlanOptionType");
						String strplanOptionNameValue = getCellValue("PlanOptionName");
						int intcolumnNum=8;
						if(getWebDriver()==null)
						{
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
						waitForPageLoad(2,360);	
						LoginPage.get().loginApplication(struserProfile);
						waitForPageLoad(2,360);					
						}
						seClick(HomePage.get().find, "Find link");
						waitForPageLoad(2,360);	
						seClick(HomePage.get().findPlan, "Find Plan link");
						waitForPageLoad(2,360);							
						if(!strTestCaseID.equals(null))
						{
						waitForPageLoad(2,360);
						seSetText(FindPlanPage.get().effectiveFrom, strEffDate, "Effective Date");
						waitForPageLoad(2,360);
						WebElement webElement=FindPlanPage.get().effectiveFrom;
						webElement.sendKeys(Keys.ENTER);
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().headerCriteria,"Header criteria");
						waitForPageLoad(2,360);
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().headerCriteriaType,"Header criteria type");
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().headerCritTypeValue(strHeaderCriteria),"Benefit period value from header criteria drop dowm");
						waitForPageLoad(2,360);			
						expectedValue = FindPlanPage.get().valueType(strValueType);
						waitForPageLoad(360);
						seClick(FindPlanPage.get().optionCriteria, "optionCriteria");
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().planOptionArea, "Plan Option Area");
						seClick(FindPlanPage.get().planOptionAreaValue(strplanOptionAreaType),"PlanOptionArea "+strplanOptionAreaType);
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().planOptionType, "Plan Option Type");
						seClick(FindPlanPage.get().planOptionTypeValue(strplanOptionTypeValue),"PlanOptionType "+strplanOptionTypeValue);
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().planOptionName, "Plan Option Name");
						seClick(FindPlanPage.get().planOptionAreaValue(strplanOptionNameValue),"PlanOptionName "+strplanOptionNameValue);
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().planSearch, "Search");
						waitForPageLoad(500);
						seWaitForClickableWebElement(FindPlanPage.get().searchResults, 120);
						if(FindPlanPage.get().searchResults.isDisplayed())
						{
							WebTableWithHeader searchResults = new WebTableWithHeader(FindPlanPage.get().searchResults, "Plan Search Results");
							waitForPageLoad(300);
							log(PASS, "Find Plan","Plan found with given header Criteria: "+strHeaderCriteria);	
							for (int i = 1; i < 5; i++) {
							
								stractualSearchCriteriaValue=searchResults.getCellData(i, intcolumnNum);
								if(!stractualSearchCriteriaValue.equalsIgnoreCase(strEffDate))
									log(FAIL, "Verify Plan in search results","Plans do not match with "+strSearchCriteria+": " +strEffDate+" ActualVAlue: "+stractualSearchCriteriaValue);
								else
									log(PASS, "Verify Plan in search results","Plans match with "+strSearchCriteria+": " +strEffDate+" ActualVAlue: "+stractualSearchCriteriaValue);
												
								if(strHeaderCriteria.equalsIgnoreCase("Status"))
								{
									waitForPageLoad(2,360);
									WebElement status=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div/table/tbody/tr["+i+"]/td[9]"));
									actualValue=status.getText().toString().trim();
									if(expectedValue.equalsIgnoreCase(actualValue))
									{
										result=true;
										log(PASS,"Validate search results using "+strHeaderCriteria,"Expected Value "+expectedValue+"Actual Value "+actualValue);
									}
									else
									{
										log(FAIL,"Validate search results using "+strHeaderCriteria,"Expected Value "+expectedValue+"Actual Value "+actualValue);
									}
								}
								else
								{						
									WebElement planInfo=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div/table/tbody/tr["+i+"]/td[12]/i"));
									seClick(planInfo,"Plan Info Option");
									waitForPageLoad(2,360);			
									Actions actions = new Actions(getWebDriver());
									actions.moveToElement(PlanHeaderPage.get().valueType(strHeaderCriteria)).build().perform();;
									waitForPageLoad(2,360);
									actualValue=seGetElementValue(PlanHeaderPage.get().valueType(strHeaderCriteria));
									if(expectedValue.equalsIgnoreCase(actualValue))
									{
										result=true;
										log(PASS,"Validate search results using "+strHeaderCriteria,"Expected Value "+expectedValue+"Actual Value "+actualValue,true);
									}
									else
									{
										log(FAIL,"Validate search results using "+strHeaderCriteria,"Expected Value "+expectedValue+"Actual Value "+actualValue,true);
									}
									seClick(PlanHeaderPage.get().closebutton,"Close button");
									waitForPageLoad(2,360);
								}
							}
							
							seClick(searchResults.getCell(1, 9), "Plan");
							waitForPageLoad(500);
							PlanOptionsPage.clickTab(strplanOptionAreaType, strplanOptionTypeValue, 600);
							waitForPageLoad(200);
							for (WebElement element : PlanOptionsPage.get().optionsTypeValues) {
								String strOptionValue = element.getText();
								if(strOptionValue.equalsIgnoreCase(strplanOptionNameValue))
								{
									actualoptionCriteria=strOptionValue;
									log(PASS,"Validate search results using "+strplanOptionTypeValue,"Expected Value "+strplanOptionNameValue+"Actual Value "+actualoptionCriteria,true);
									break;
								}
							}	
	
						}
						else if(FindPlanPage.get().searchPlanErrorMsg.isDisplayed())
						{
							log(FAIL, "Find Plan","Plan not found with given Criteria "+strHeaderCriteria);
						}
						}
						else
						{
							log(FAIL,"Data need to be verified","Data need to be verified");
						}

					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null)
			{
				seCloseBrowser();
			}
			endTestScript();

		}
	
	}


}


