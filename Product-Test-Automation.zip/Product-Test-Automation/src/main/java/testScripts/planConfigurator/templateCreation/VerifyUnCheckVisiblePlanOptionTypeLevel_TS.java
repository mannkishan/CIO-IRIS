package testScripts.planConfigurator.templateCreation;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitsPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.CreateTemplatePage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanTransitionPage;
import page.planConfigurator.SwitchTemplatePage;
import page.planConfigurator.TemplateCreation;
import page.planConfigurator.VisibilityChangeabilityPage;
import utility.CoreSuperHelper;

//MPRO-1795: Verify If the visible checkbox is deselected at the Plan Option Type level, none of the associated (child) attributes/accumulators will be visible on the Plan even though the visible checkboxes are still checked in the Template..
//MPRO-1796: Verify if the visible checkbox is rechecked at the Plan Option Type level in template, the associated attributes/accumulators to that POT will be visible and changeable in the plan
//sample data :  before changeability checked :  1609220454 after Visibility checked temp id:2941130549      planid:  2951590654
public class VerifyUnCheckVisiblePlanOptionTypeLevel_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("Verify for a limit, accumulator, Plan Option Name, Plan Option type, Accumulator Groups, situation type, benefits in benefit tree and Network the visible is unchecked in Template, it will not be visible in the plan."
							+ "Verify if the visible checkbox is rechecked at the Plan Option Type level in template, the associated attributes/accumulators to that POT will be visible and changeable in the plan");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL, "testscripts");
					LoginPage.get().loginApplication(strUserProfile);
					waitForPageLoad(65);
					seWaitForElementLoad(CreatePlanPage.get().homepage);
					
					//create template
					seClick(HomePage.get().create, "Clicking on create link");
					waitForPageLoad();
					seClick(TemplateCreation.get().createTemplate, "Clicking on plan option");
					waitForPageLoad();
					CreateTemplatePage.get().seCreateTemplate();
					waitForPageLoad();
					String strTemplateVersionIDold = seGetElementValue(PlanHeaderPage.get().templateVersion).split(":")[1];
		            waitForPageLoad();
		            setCellValue("TemplateIDold", strTemplateVersionIDold);
		            setCellValue("TemplateIDnew",strTemplateVersionIDold);
		            setCellValue("TemplateVersionID",strTemplateVersionIDold);
		            waitForPageLoad();seClick(PlanHeaderPage.get().save, "Save button");
					waitForPageLoad(45);
					seClick(PlanHeaderPage.get().close, "Close button");
					waitForPageLoad();
					seCloseBrowser();
					TemplateCreation.seTemplateCreation(strTemplateVersionIDold.trim(),getCellValue("MP_File_path"));
					waitForPageLoad();System.out.println("created template sucessfully");waitForPageLoad();
					seClick(PlanHeaderPage.get().save, "Save button");
					waitForPageLoad(45);
				/*	
					
					//FIND TEMPLATE
					//search for the template trTemplateVersionIDold
					
					seClick(HomePage.get().find, "Find");waitForPageLoad();
					seClick(HomePage.get().findTemplate, "Find Template");waitForPageLoad();
					seSetText(PlanTransitionPage.get().inputTemplate,"1609220454", "Enter Plan ID");waitForPageLoad();									
					seWaitForClickableWebElement(FindPlanPage.get().planSearch, 30);waitForPageLoad();
					seClick(FindPlanPage.get().planSearch, "Search Plan");waitForPageLoad();
					System.out.println("searched need to click");
					seWaitForClickableWebElement(PlanHeaderPage.get().searchTemplates, 10);waitForPageLoad();
					//seClick(PlanHeaderPage.get().searchTemplate, "Search");
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",PlanHeaderPage.get().searchTemplates);
					System.out.println("click sucess");
					waitForPageLoad(30,10);*/
		      
					//visible checkbox is deselected at the Plan Option Type level, 
					WebElement objPlansetup = getWebDriver().findElement(By.xpath("//a[contains(text(),'Plan Setup')]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
					seClick(objPlansetup, "Option Tab :  Plan Setup");waitForPageLoad();
					WebElement objPediatricVisionBenefits = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Vision')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
					seClick(objPediatricVisionBenefits, "Option Tab :  Plan Setup");waitForPageLoad();
					
					WebElement objPediatricVisionVisibles = getWebDriver().findElement(By.xpath("(//h4[contains(text(),'Pediatric Vision')]/following::span[@class='groupTemplateConfig']/div/span/input)[1]"));
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objPediatricVisionVisibles);waitForPageLoad();
					
					
					//verifing if visible checkboxes are still checked in the Template for associated (child) 
					WebElement objPediatricChangeable = getWebDriver().findElement(By.xpath("(//h4[contains(text(),'Pediatric Vision')]/following::span[text()='Covered Exam And Hardware']/following::span/div/span/input)[1]"));
					waitForPageLoad();boolean blnPediatricChangeable = seIsElementSelected(objPediatricChangeable, "Covered Exam And Hardware");waitForPageLoad();
					WebElement objPediatricVisible= getWebDriver().findElement(By.xpath("//h4[contains(text(),'Pediatric Vision')]/following::span[contains(text(),'Covered Exam And Hardware')][1]/following::span[contains(text(),'In Network Pediatric Vision Coinsurance')]/following::td/div/span/div/span/input[@class='visible']"));
					waitForPageLoad();boolean blnPediatricVisible = seIsElementSelected(objPediatricVisible, "In Network Pediatric Vision Coinsurance");waitForPageLoad();
					System.out.println(blnPediatricChangeable);waitForPageLoad();
					System.out.println(blnPediatricVisible);
					if (blnPediatricChangeable == true && blnPediatricVisible == true ){log(PASS, "Verified that, visible checkboxes are still checked in the Template for associated child accumulators","RESULT=PASS");}
					else{log(FAIL, "visible checkboxes  Behaviour not as expected","RESULT=FAIL");}

					waitForPageLoad();
					seClick(PlanHeaderPage.get().save, "Save button");
					waitForPageLoad(45);
					//moving template to production
					PlanHeaderPage.get().seMoveToProductionTemplate();waitForPageLoad();
					System.out.println("Template moved to production");
					waitForPageLoad(45);
					seCloseBrowser();
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL, "testscripts");
					LoginPage.get().loginApplication(strUserProfile);
					waitForPageLoad(65);
					seWaitForElementLoad(CreatePlanPage.get().homepage);
					//create plan
					CreatePlanPage.get().createPlan(true,50);waitForPageLoad(45);
					
					try{
						 getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Vision')])[1]/preceding::li[1]/following::li/a[1])[1]"));
						waitForPageLoad();} catch (Exception e){
						log(PASS, "Verified that the visible checkbox is which were deselected at the Plan Option Type level, none of the associated (child) attributes/accumulators are visible on the Plan","RESULT=PASS");}
						
					
					//Moving plan to production
					waitForPageLoad(35);
					
					seClick(PlanHeaderPage.get().save, "Save button");waitForPageLoad(15);
					VisibilityChangeabilityPage.get().seMoveMPlanToProduction();
					seCloseBrowser();
					
					//recheck visibility
					waitForPageLoad(35);
					VisibilityChangeabilityPage.get().seRecheckVisibility();
					
					
					
					
					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					//seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
	
}


