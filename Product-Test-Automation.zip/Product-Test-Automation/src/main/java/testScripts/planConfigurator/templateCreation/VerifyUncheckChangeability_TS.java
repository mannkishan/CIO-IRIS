package testScripts.planConfigurator.templateCreation;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitsPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.CreateTemplatePage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanTransitionPage;
import page.planConfigurator.SwitchTemplatePage;
import page.planConfigurator.TemplateCreation;
import page.planConfigurator.VisibilityChangeabilityPage;
import utility.CoreSuperHelper;

//MPRO-1947 : Verify Plan Template user, has the ability to make Plan Options, Benefit Options, and Plan Setup not changeable on Plans created from the Template

//sample data :  before changeability checked :  2733390706 after changeablity checkedtemp id: 2745120466 planid: 2752350108
public class VerifyUncheckChangeability_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("Verify Plan Template user, has the ability to make Plan Options, Benefit Options, and Plan Setup not changeable on Plans created from the Template");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL, "testscripts");
					LoginPage.get().loginApplication(strUserProfile);
					waitForPageLoad(65);
					seWaitForElementLoad(CreatePlanPage.get().homepage);
					//Boolean boolean1 = seIsElementDisplayed(CreatePlanPage.get().homepage,"Home page");
					//create template
								seClick(HomePage.get().create, "Clicking on create link");
					waitForPageLoad();
					seClick(TemplateCreation.get().createTemplate, "Clicking on plan option");
					waitForPageLoad();
					CreateTemplatePage.get().seCreateTemplate();
					waitForPageLoad();
					String strTemplateVersionIDold = seGetElementValue(PlanHeaderPage.get().templateVersion).split(":")[1];
		            waitForPageLoad();
		            setCellValue("TemplateIDold", strTemplateVersionIDold);
		            setCellValue("TemplateIDnew",strTemplateVersionIDold);
		            setCellValue("TemplateVersionID",strTemplateVersionIDold);
		            waitForPageLoad();seClick(PlanHeaderPage.get().save, "Save button");
					waitForPageLoad(45);
					seClick(PlanHeaderPage.get().close, "Close button");
					waitForPageLoad();
					seCloseBrowser();
					TemplateCreation.seTemplateCreation(strTemplateVersionIDold.trim(),getCellValue("MP_File_path"));
					waitForPageLoad();System.out.println("created template sucessfully");waitForPageLoad();
					seClick(PlanHeaderPage.get().save, "Save button");
					waitForPageLoad(45);
	
					VisibilityChangeabilityPage.get().seUncheckChangeability();
					
					waitForPageLoad(45);
					
					//moving template to production
					PlanHeaderPage.get().seMoveToProductionTemplate();waitForPageLoad();
					System.out.println("Template moved to production");
					waitForPageLoad(45);
					seCloseBrowser();
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL, "testscripts");
					LoginPage.get().loginApplication(strUserProfile);
					waitForPageLoad(65);
					seWaitForElementLoad(CreatePlanPage.get().homepage);
					
					//create plan
					CreatePlanPage.get().createPlan(true,50);waitForPageLoad(45);
					
					//check if the above three are not changeable
					VisibilityChangeabilityPage.get().seChangeabilityCheck();
											
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}