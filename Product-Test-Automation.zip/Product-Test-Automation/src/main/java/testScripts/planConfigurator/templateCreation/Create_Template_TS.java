
package testScripts.planConfigurator.templateCreation;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.TemplateCreation;
import utility.CoreSuperHelper;

/**
 * Manual test case: Create Template :
 * This Test script creates a template and filling all the drop down text box values and moving it to production status.
 * One input sheet with all the text box values is required to fill template fields.
 * Another input sheet is required to get the header details required for template creation. 
 * @author AF47903
 * @since 10-October-2017
 *
 */
public class Create_Template_TS extends CoreSuperHelper {

	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {

					logExtentReport("Test Script/ Functionality Descrtiption");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL, "testscripts");
					LoginPage.get().loginApplication(strUserProfile);
					waitForPageLoad(65);
					seClick(HomePage.get().create, "Clicking on create link");
					waitForPageLoad();
					seClick(TemplateCreation.get().createTemplate, "Clicking on plan option");
					waitForPageLoad();
					seSetText(FindPlanPage.get().planEffectiveDate, getCellValue("Temp_EffectiveDate"),"Effective date");
					WebElement pressEnter = FindPlanPage.get().planEffectiveDate;
					pressEnter.sendKeys(Keys.ENTER);
					waitForPageLoad();
					seClick(TemplateCreation.get().templateNameBox, "template name text box");
					seSetText(TemplateCreation.get().templateNameBox, getCellValue("Temp_Name"), "Template name");
					waitForPageLoad();
					String strStates = getCellValue("Temp_state").trim();
					String[] strSplitStateValues = strStates.split(",");
					for (int j = 0; j < strSplitStateValues.length; j++) {
						seClick(TemplateCreation.get().templateState, "State");
						seSetText(TemplateCreation.get().templateState, strSplitStateValues[j], "state name");
						TemplateCreation.get().templateState.sendKeys(Keys.ENTER);
						waitForPageLoad();
					}
					seClick(TemplateCreation.get().templateMarketSegment, "Market segment");
					seSetText(TemplateCreation.get().templateMarketSegment, getCellValue("Temp_MarketSegment"),"Market segment");
					TemplateCreation.get().templateMarketSegment.sendKeys(Keys.ENTER);
					waitForPageLoad();
					seClick(TemplateCreation.get().templateLOB, "Line of Business");
					seClick(TemplateCreation.get().medicalLOB, "Line of Business");
					waitForPageLoad();
					String strProductFamilies = getCellValue("Temp_Product_family").trim();
					String[] strSplitPfValues = strProductFamilies.split(",");
					for (int i = 0; i < strSplitPfValues.length; i++) {
						seClick(TemplateCreation.get().templateProductFamily, "Product family");
						seSetText(TemplateCreation.get().templateProductFamily, strSplitPfValues[i], "Product family");
						TemplateCreation.get().templateProductFamily.sendKeys(Keys.ENTER);
						waitForPageLoad();
					} 
					seClick(TemplateCreation.get().networkTier, "Network Tier");
					seClick(TemplateCreation.get().network2Tier, "Network tier");
					waitForPageLoad();
					String strCdhp = getCellValue("Temp_cdhp").trim();
					String[] strSplitCdhpValues = strCdhp.split(",");

					for (int i = 0; i < strSplitCdhpValues.length; i++) {
						seClick(TemplateCreation.get().Cdhp, "CDHP");
						seSetText(TemplateCreation.get().Cdhp, strSplitCdhpValues[i], "CDHP");
						TemplateCreation.get().Cdhp.sendKeys(Keys.ENTER);
						waitForPageLoad();
					}

					seClick(TemplateCreation.get().fundingArrangement, "Funding arrangement");
					seSetText(TemplateCreation.get().fundingArrangement, getCellValue("Temp_FundindArrangement"),"funding arrangement");
					TemplateCreation.get().fundingArrangement.sendKeys(Keys.ENTER);
					waitForPageLoad();
					seClick(TemplateCreation.get().create, "create");
					waitForPageLoad(105);
					String strPlanID = TemplateCreation.get().getPlanId.getText();
					String strPlan = strPlanID.substring(strPlanID.lastIndexOf(" ") + 1);
                    seWaitForClickableWebElement(PlanHeaderPage.get().save, 145);   
					seClick(PlanHeaderPage.get().save, "Save button");
					waitForPageLoad();
					seWaitForClickableWebElement(PlanHeaderPage.get().close, 12);
					seClick(PlanHeaderPage.get().close, "Close button");
					waitForPageLoad();
					seCloseBrowser();
					String strTemplateId = TemplateCreation.seTemplateCreation(strPlan.trim(),getCellValue("MP_File_path"));
					setCellValue("TemplateVersionID", strTemplateId);
					page.planConfigurator.TemplateCreation.seMoveTemplateToProduction(strTemplateId);

				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					 //seCloseBrowser();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}

	}
}
