
package testScripts.planConfigurator.templateCreation;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;

/**
 * Manual test case: Create Master Plan :
 * This Test script creates a Master Plan using a completed template ID and moves the Plan to Production status. 
 * @author AF47903
 * @since 10-October-2017
 *
 */
public class CreateMasterPlan_TS extends CoreSuperHelper {

	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) { 
				try {
					logExtentReport("Test Script/ Functionality Descrtiption");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL, "testscripts");
					LoginPage.get().loginApplication(strUserProfile);
					waitForPageLoad();
					CreatePlanPage.get().createPlan(true, 55);
					waitForPageLoad(45);
					seClick(PlanHeaderPage.get().save, "Save button");
					waitForPageLoad(45);
					seWaitForClickableWebElement(PlanHeaderPage.get().requestAudit, 12);
					seClick(PlanHeaderPage.get().requestAudit, "request Audit button");
					waitForPageLoad();
					PlanTransitionPage.get().updateReasonCode("Other");
					seClick(PlanTransitionPage.get().requestAudit, "Request Audit button");
					waitForPageLoad();
					try {
						seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 360);
					}
					catch (TimeoutException e) {
						seClick(PlanHeaderPage.get().close, "Close button");
						waitForPageLoad();
					}
					seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
					waitForPageLoad();
					seClick(PlanHeaderPage.get().userLogout, "Logout");
					waitForPageLoad();
					seCloseBrowser();
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
					LoginPage.get().loginApplication(strUserProfileApprover);
					waitForPageLoad();
					FindPlanPage.seSearchPlanByPlanVersionID(getCellValue("PlanVersionID"));
					waitForPageLoad();
					Boolean blnAuditStatus = PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
					if (blnAuditStatus == true) {
						log(PASS, "plan takes correct time to load", "plan is in Pending Audit status,RESULT=PASS");
					} else {
						throw new TimeoutException("Plan is not in Pending Audit status");
					}
					seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 36);
					seClick(PlanHeaderPage.get().approveAudit, "Approve Audit");
					waitForPageLoad(45);
					seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
					PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
					PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
					PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ENTER);
					seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, 10);
					seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
					seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeText, 1);
					seSetText(PlanTransitionPage.get().planTransitionReasonCodeText, "Approved", "as " + "Approved");
					seClick(PlanTransitionPage.get().approved, "approved reason code");
					seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
					waitForPageLoad(45);
					seWaitForClickableWebElement(PlanHeaderPage.get().moveToTestPHPage, 12);
					seClick(PlanHeaderPage.get().moveToTestPHPage, "Move to test button");
					waitForPageLoad();
					seClick(PlanTransitionPage.get().moveToTest, "Move to test ");
					waitForPageLoad(45);
					seWaitForClickableWebElement(PlanHeaderPage.get().approveTestForFinalize, 12);
					seClick(PlanHeaderPage.get().approveTestForFinalize, "Approve test button");
					waitForPageLoad();
					seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "test approval");
					seClick(PlanTransitionPage.get().approved, "approved");
					seClick(PlanTransitionPage.get().approvedTest, "approve test");
					waitForPageLoad(45);
					seWaitForClickableWebElement(PlanHeaderPage.get().finalize, 12);
					seClick(PlanHeaderPage.get().finalize, "Finalize button");
					waitForPageLoad();
					seClick(PlanTransitionPage.get().finalizeButtoninPT, "finalize");
					waitForPageLoad();
					try {
						seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 300);
					}
					catch (TimeoutException e) {
						seClick(PlanHeaderPage.get().close, "Close button");
						waitForPageLoad();
					}
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",
							FindPlanPage.get().selectSearchedPlan);
					waitForPageLoad(45);
					Boolean blnFinalStatus = PlanHeaderPage.get().seVerifyPlanStatus("Production");
					if (blnFinalStatus == true) {
						log(PASS, "plan takes correct time to load", "plan is in Production status,RESULT=PASS");
					} else {
						throw new TimeoutException("Plan is not in Production status");
					}
					waitForPageLoad();
					seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
					seClick(PlanHeaderPage.get().userLogout, "Logout");
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {

					//seCloseBrowser();
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}

	}
}
