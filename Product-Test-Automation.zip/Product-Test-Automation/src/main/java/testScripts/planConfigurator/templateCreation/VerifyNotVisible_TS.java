package testScripts.planConfigurator.templateCreation;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitsPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.CreateTemplatePage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanTransitionPage;
import page.planConfigurator.SwitchTemplatePage;
import page.planConfigurator.TemplateCreation;
import page.planConfigurator.VisibilityChangeabilityPage;
import utility.CoreSuperHelper;

//MPRO-1792 : Verify for a limit, accumulator, Plan Option Name, Plan Option type, Accumulator Groups, situation type, benefits in benefit tree and Network the visible is unchecked in Template, it will not be visible in the plan.
//MPRO-1948 : Verify if a limit, accumulator, PON�s, Plan Option type, Accumulator Groups, situation type, benefits in benefit tree and Network is marked as not visible in the Template, it must also be not changeable and must have a default defined.
//sample data :  before changeability checked :  1609220454 after Visibility checked temp id:2941130549      planid:  2951590654
public class VerifyNotVisible_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("Verify for a limit, accumulator, Plan Option Name, Plan Option type, Accumulator Groups, situation type, benefits in benefit tree and Network the visible is unchecked in Template, it will not be visible in the plan.");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL, "testscripts");
					LoginPage.get().loginApplication(strUserProfile);
					waitForPageLoad(65);
					seWaitForElementLoad(CreatePlanPage.get().homepage);
					
					//create template
					seClick(HomePage.get().create, "Clicking on create link");
					waitForPageLoad();
					seClick(TemplateCreation.get().createTemplate, "Clicking on plan option");
					waitForPageLoad();
					CreateTemplatePage.get().seCreateTemplate();
					waitForPageLoad();
					String strTemplateVersionIDold = seGetElementValue(PlanHeaderPage.get().templateVersion).split(":")[1];
		            waitForPageLoad();
		            setCellValue("TemplateIDold", strTemplateVersionIDold);
		            setCellValue("TemplateIDnew",strTemplateVersionIDold);
		            setCellValue("TemplateVersionID",strTemplateVersionIDold);
		            waitForPageLoad();seClick(PlanHeaderPage.get().save, "Save button");
					waitForPageLoad(45);
					seClick(PlanHeaderPage.get().close, "Close button");
					waitForPageLoad();
					seCloseBrowser();
					TemplateCreation.seTemplateCreation(strTemplateVersionIDold.trim(),getCellValue("MP_File_path"));
					waitForPageLoad();System.out.println("created template sucessfully");waitForPageLoad();
					seClick(PlanHeaderPage.get().save, "Save button");
					waitForPageLoad(45);
		      
					//uncheck visible check box for the following
					VisibilityChangeabilityPage.get().seUncheckVisibility();						
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					//seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
	
}


