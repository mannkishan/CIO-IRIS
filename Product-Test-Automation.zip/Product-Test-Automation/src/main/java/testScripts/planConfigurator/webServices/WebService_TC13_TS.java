package testScripts.planConfigurator.webServices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.anthem.selenium.utility.EnvHelper;
import page.planConfigurator.PlanBenefitOptionsPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;
import utility.SOAPServiceUtils;
import utility.SpiderWebService;

public class WebService_TC13_TS extends CoreSuperHelper{
	static String endPointURL="https://spider-eps.uat.va.wellpoint.com/spidergcl/services/GroupXMLService";
	static String strDownloadPath = "";
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCID=getCellValue("Test_Case_ID");
					String strTCName = getCellValue("TCName");
					if(strRunFlag.equalsIgnoreCase("YES"))
					{
						logExtentReport(strTCName);
						strDownloadPath = getReportPathFolder();
						String proxyId=getCellValue("ProxyID");
						String strXMLFile=strDownloadPath+proxyId+".xml";
						String effectiveDate=getCellValue("EffectiveDate");
						String LOB=getCellValue("LOB");
						String contractCode=getCellValue("ContractCode");
						String returnPlanOptions=getCellValue("ReturnPlanOptions");
						String returnBenefitOptions=getCellValue("ReturnBenefitOptions");
						String returnBenefits=getCellValue("ReturnChildBenefits");
						boolean isFound=false;
						String optionType=getCellValue("OptionType");
						String optionName=getCellValue("OptionName");
						HashMap<String, String> ElementValue=new HashMap<>();
						String xmlInput=SpiderWebService.get().getResponseWithBenefitOptions(effectiveDate, LOB, contractCode, returnPlanOptions,returnBenefitOptions,returnBenefits);
						SOAPServiceUtils.get_Save_SOAPResponsefromRequestString(xmlInput, ElementValue, endPointURL,strXMLFile);
						String strVersionID=PlanXMLParser.getPlanID(LOB,strXMLFile);
						ArrayList<String> optionsText=PlanBenefitOptionsPage.getOptionsText_SpiderUI(strBaseURL,struserProfile,strTestRegion,strVersionID,optionType);												
						HashMap<String, String> childBenefits=PlanXMLParser.getOptions(strXMLFile,optionName);
						String actualChildBenefit="";						
						for (String expChildBenefits : optionsText) 
						{
							isFound=false;
							for (Map.Entry<String, String> entry : childBenefits.entrySet())
							{
								actualChildBenefit=entry.getValue(); 
								{
									if(actualChildBenefit.contains(expChildBenefits))
									{
										isFound=true;
										RESULT_STATUS=true;
										log(PASS,"ChildBenfit is found for :"+optionType,expChildBenefits +"is Equal to :"+actualChildBenefit);
									}
								}								

							}
							if(!isFound)
							{
								RESULT_STATUS=false;
								log(FAIL,"ChildBenfit is not found for :"+optionType,expChildBenefits +"is not Equal to :"+actualChildBenefit);
							}
						}
						HashMap<String, String> planOptions=PlanXMLParser.getOptions(strXMLFile,"Base");
						if(planOptions.isEmpty())
						{
							RESULT_STATUS=true;
							log(PASS,"Plan Option details are not present","Plan Option details are not present");
						}
						else
						{
							RESULT_STATUS=false;
							log(FAIL,"Plan Option details are present","Plan Option details are present");
						}
						isFound=PlanXMLParser.validateBenefits(strXMLFile);
						if(isFound)
						{
							RESULT_STATUS=true;
							log(PASS,"Benefit details are not present","Benefit details are not present");
						}
						else
						{
							RESULT_STATUS=false;
							log(FAIL,"Benefit details are present","Benefit details are present");	
						}
						log(RESULT_STATUS?PASS:FAIL, strTCID,strTCName);	

					}
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {		
			endTestScript();

		}
	}

}
