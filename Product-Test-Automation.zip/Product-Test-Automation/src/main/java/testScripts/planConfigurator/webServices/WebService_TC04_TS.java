package testScripts.planConfigurator.webServices;

import java.util.HashMap;
import java.util.Map;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;
import utility.SOAPServiceUtils;
import utility.SpiderWebService;

public class WebService_TC04_TS extends CoreSuperHelper{
	static String endPointURL="https://spider-eps.uat.va.wellpoint.com/spidergcl/services/GroupXMLService";
	static String strDownloadPath = "";

	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCID=getCellValue("Test_Case_ID");
					String strTCName = getCellValue("TCName");
					if(strRunFlag.equalsIgnoreCase("YES"))
					{
						logExtentReport(strTCName);
						strDownloadPath = getReportPathFolder();
						String proxyId=getCellValue("ProxyID");
						String strXMLFile=strDownloadPath+proxyId+".xml";
						String effectiveDate=getCellValue("EffectiveDate");
						String LOB=getCellValue("LOB");
						String contractCode=getCellValue("ContractCode");
						String returnChildBenefits=getCellValue("ReturnChildBenefits");
						String returnChildBenefits2=getCellValue("ReturnChildBenefits2");
						boolean isFound=false;
						String expBenefit=getCellValue("Benefit");
						String expBenefit2=getCellValue("Benefit2");
						HashMap<String, String> ElementValue=new HashMap<>();
						String xmlInput=SpiderWebService.get().getResponseWithBenefitDetailsForExamVistAndRehabTherapy(effectiveDate, LOB, contractCode, returnChildBenefits,returnChildBenefits2);
						SOAPServiceUtils.get_Save_SOAPResponsefromRequestString(xmlInput, ElementValue, endPointURL,strXMLFile);											
						String actualChildBenefit="";
						String actualChildBenefit2="";
						String[] expectedChildBenefits=getCellValue("ChildBenefits").split(";");
						String[] expectedChildBenefits2=getCellValue("ChildBenefits2").split(";"); 
						HashMap<String, String> childBenefits=PlanXMLParser.getChildNodes(strXMLFile,expBenefit);
						for (String expChildBenefits : expectedChildBenefits) 			
						{ 
							isFound=false;				
							for (Map.Entry<String, String> entry : childBenefits.entrySet())
							{
								actualChildBenefit=entry.getValue(); 
								{
									if(actualChildBenefit.equals(expChildBenefits))
									{
										isFound=true;
										RESULT_STATUS=true;
										log(PASS,"ChildBenfit is found for:"+expBenefit,expChildBenefits +"is Equal to :"+actualChildBenefit);
									}
								}					
							}
							if(!isFound)
							{
								RESULT_STATUS=false;
								log(FAIL,"ChildBenfit is not found for :"+expBenefit,"No child Benefits are present");
							}
						}  
						
						HashMap<String, String> childBenefits2=PlanXMLParser.getChildNodes(strXMLFile,expBenefit2);
						for (String expChildBenefits2 : expectedChildBenefits2) 			
						{ 
							isFound=false;				
							for (Map.Entry<String, String> entry : childBenefits2.entrySet())
							{
								actualChildBenefit2=entry.getValue(); 
								{
									if(actualChildBenefit2.equals(expChildBenefits2))
									{
										isFound=true;
										RESULT_STATUS=false;
										log(FAIL,"ChildBenfit is found for :"+expBenefit2,expChildBenefits2 +"is Equal to :"+actualChildBenefit2);
									}
								}					
							}
							if(!isFound)
							{
								RESULT_STATUS=true;
								log(PASS,"ChildBenfit is not found for :"+expBenefit2,"No child Benefits are present");
							}
						} 
						log(RESULT_STATUS?PASS:FAIL, strTCID,strTCName);	
					}
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {		
			endTestScript();

		}
	}

}
