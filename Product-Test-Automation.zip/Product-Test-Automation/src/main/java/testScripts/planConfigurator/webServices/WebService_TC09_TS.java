package testScripts.planConfigurator.webServices;

import java.util.HashMap;

import utility.CoreSuperHelper;
import utility.PlanXMLParser;
import utility.SOAPServiceUtils;
import utility.SpiderWebService;

public class WebService_TC09_TS extends CoreSuperHelper{
	
	static String endPointURL="https://spider-eps.uat.va.wellpoint.com/spidergcl/services/GroupXMLService";
	static String strDownloadPath = "";
	public static void main(String[] args) {
		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					String strTCID = getCellValue("Test_Case_ID");
					if(strRunFlag.equalsIgnoreCase("YES"))
					{
						logExtentReport(strTCName);
						strDownloadPath = getReportPathFolder();
						String proxyId=getCellValue("ProxyID");
						String strXMLFile=strDownloadPath+proxyId+".xml";
						String effectiveDate=getCellValue("EffectiveDate");
						String LOB=getCellValue("LOB");
						boolean result=false;
						String contractCode=getCellValue("ContractCode");
						String returnPlanOption=getCellValue("ReturnPlanOption");
						String returnBenefitOption=getCellValue("ReturnBenefitOption");
						String returnBenefit=getCellValue("ReturnBenefit");
						HashMap<String, String> ElementValue=new HashMap<>();
						String xmlInput=SpiderWebService.get().getResponseWithBenefitDetails(effectiveDate,LOB,contractCode,returnPlanOption,returnBenefitOption,returnBenefit);
						SOAPServiceUtils.get_Save_SOAPResponsefromRequestString(xmlInput, ElementValue, endPointURL,strXMLFile);
						HashMap<String, String> planOptions=PlanXMLParser.getOptions(strXMLFile,"Base");
						if(planOptions.isEmpty())
						{
							RESULT_STATUS=true;
							log(PASS,"Plan Option details are not present","Plan Option details are not present");
						}
						else
						{
							RESULT_STATUS=false;
							log(FAIL,"Plan Option details are present","Plan Option details are present");
						}
						HashMap<String, String> benefitOptions=PlanXMLParser.getOptions(strXMLFile,"Benefit Option");
						if(benefitOptions.isEmpty())
						{
							RESULT_STATUS=true;
							log(PASS,"Benefit Option details are not present","Plan Option details are not present");
						}
						else
						{
							RESULT_STATUS=false;
							log(FAIL,"Benefit Option details are present","Plan Option details are present");
						}
						result=PlanXMLParser.validateBenefits(strXMLFile);
						if(result)
						{
							RESULT_STATUS=true;
							log(PASS,"Validate Benefit Details","Benefit data is displayed");
						}
						else
						{
							RESULT_STATUS=false;
							log(FAIL,"Validate Benefit Details","No Benefit data is displayed");
						}
						log(RESULT_STATUS?PASS:FAIL, strTCID,strTCName);	
						
					}
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {		
			endTestScript();

		}
	}



}
