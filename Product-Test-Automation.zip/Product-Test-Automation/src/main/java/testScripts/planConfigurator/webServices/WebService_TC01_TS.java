package testScripts.planConfigurator.webServices;


import java.util.HashMap;
import java.util.Map;

import utility.CoreSuperHelper;
import utility.PlanXMLParser;
import utility.SOAPServiceUtils;
import utility.SpiderWebService;

public class WebService_TC01_TS extends CoreSuperHelper{
	static String endPointURL="https://spider-eps.uat.va.wellpoint.com/spidergcl/services/GroupXMLService";
	static String strDownloadPath = "";

	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					String strTCID = getCellValue("Test_Case_ID");
					if(strRunFlag.equalsIgnoreCase("YES"))
					{
						logExtentReport(strTCName);
						strDownloadPath = getReportPathFolder();
						String proxyId=getCellValue("ProxyID");
						String strXMLFile=strDownloadPath+proxyId+".xml";
						String effectiveDate=getCellValue("EffectiveDate");
						String LOB=getCellValue("LOB");
						String contractCode=getCellValue("ContractCode");
						String returnChildBenefits=getCellValue("ReturnChildBenefits");
						boolean isFound=false;
						String expBenefit=getCellValue("Benefit");
						HashMap<String, String> ElementValue=new HashMap<>();
						String xmlInput=SpiderWebService.get().getResponseWithParentAndChildBenefits(effectiveDate, LOB, contractCode, returnChildBenefits);
						SOAPServiceUtils.get_Save_SOAPResponsefromRequestString(xmlInput, ElementValue, endPointURL,strXMLFile);											
						String actualChildBenefit="";
						String[] expectedChildBenefits=getCellValue("ChildBenefits").split(";"); 
						HashMap<String, String> childBenefits=PlanXMLParser.getChildNodes(strXMLFile,expBenefit);

						for (String expChildBenefits : expectedChildBenefits) 			
						{ 
							isFound=false;				
							for (Map.Entry<String, String> entry : childBenefits.entrySet())
							{
								actualChildBenefit=entry.getValue(); 
								{
									if(actualChildBenefit.equals(expChildBenefits))
									{
										isFound=true;
										RESULT_STATUS=true;
										log(PASS,"ChildBenfit is found for :"+expBenefit,expChildBenefits +"is Equal to :"+actualChildBenefit);
									}
								}					
							}
							if(!isFound)
							{
								RESULT_STATUS=false;
								log(FAIL,"ChildBenfit is not found for :"+expBenefit,expChildBenefits +"is not Equal to :"+actualChildBenefit);
							}
						}
						log(RESULT_STATUS?PASS:FAIL, strTCID,strTCName);
					}
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {		
			endTestScript();

		}
	}

	
	


}
