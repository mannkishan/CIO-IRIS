package testScripts.planConfigurator.webServices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.PlanBenefitOptionsPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;
import utility.SOAPServiceUtils;
import utility.SpiderWebService;

public class WebService_TC05_TS extends CoreSuperHelper{
	static String endPointURL="https://spider-eps.uat.va.wellpoint.com/spidergcl/services/GroupXMLService";
	static String strDownloadPath = "";
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCID=getCellValue("Test_Case_ID");
					String strTCName = getCellValue("TCName");
					if(strRunFlag.equalsIgnoreCase("YES"))
					{
						logExtentReport(strTCName);
						strDownloadPath = getReportPathFolder();
						String proxyId=getCellValue("ProxyID");
						String strXMLFile=strDownloadPath+proxyId+".xml";
						String effectiveDate=getCellValue("EffectiveDate");
						String LOB=getCellValue("LOB");
						String contractCode=getCellValue("ContractCode");						
						boolean isFound=false;
						HashMap<String, String> ElementValue=new HashMap<>();
						String xmlInput=SpiderWebService.get().getResponseWithPlanOptBenefitOptBenefits(effectiveDate,contractCode);
						SOAPServiceUtils.get_Save_SOAPResponsefromRequestString(xmlInput, ElementValue, endPointURL,strXMLFile);
						String strVersionID=PlanXMLParser.getPlanID(LOB,strXMLFile);
						ArrayList<String> benefitOption=PlanBenefitOptionsPage.getOptionsText_SpiderUI(strBaseURL,struserProfile,strTestRegion,strVersionID,"Benefit Options");												
						HashMap<String, String> benefitOptions=PlanXMLParser.getOptions(strXMLFile,"Benefit Option");
						String actualChildBenefit="";						
						for (String expChildBenefits : benefitOption) 
						{
							if(expChildBenefits.contains("-"))
							{
								expChildBenefits=expChildBenefits.replace("-", " ");
							}
							isFound=false;
							for (Map.Entry<String, String> entry : benefitOptions.entrySet())
							{
								actualChildBenefit=entry.getValue(); 
								{
									if(actualChildBenefit.contains(expChildBenefits))
									{
										isFound=true;
										RESULT_STATUS=true;
										log(PASS,"ChildBenfit is found for Benefit Options",expChildBenefits +"is Equal to :"+actualChildBenefit);
									}
								}								

							}
							if(!isFound)
							{
								RESULT_STATUS=false;
								log(FAIL,"ChildBenfit is found for Benefit Options",expChildBenefits +"is not Equal to :"+actualChildBenefit);
							}
						}
						ArrayList<String> planOption=PlanBenefitOptionsPage.getOptionsText_SpiderUI(strBaseURL,struserProfile,strTestRegion,strVersionID,"Plan Level Benefits");												
						HashMap<String, String> planOptions=PlanXMLParser.getOptions(strXMLFile,"Base");					
						for (String expChildBenefits : planOption) 
						{
							isFound=false;
							for (Map.Entry<String, String> entry : planOptions.entrySet())
							{
								actualChildBenefit=entry.getValue(); 
								{
									if(actualChildBenefit.contains(expChildBenefits))
									{
										isFound=true;
										RESULT_STATUS=true;
										log(PASS,"ChildBenfit is found for Plan Options",expChildBenefits +"is Equal to :"+actualChildBenefit);
									}
								}								

							}
							if(!isFound)
							{
								RESULT_STATUS=false;
								log(FAIL,"ChildBenfit is found for Plan Options",expChildBenefits +"is not Equal to :"+actualChildBenefit);
							}
						}
						isFound=PlanXMLParser.validateBenefits(strXMLFile);
						if(isFound)
						{
							RESULT_STATUS=true;
							log(PASS,"Validate Benefit Details","Benefit data is displayed");
						}
						else
						{
							RESULT_STATUS=false;
							log(FAIL,"Validate Benefit Details","No Benefit data is displayed");
						}
						log(RESULT_STATUS?PASS:FAIL, strTCID,strTCName);	
						
					}
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {		
			endTestScript();

		}
	}


}
