package testScripts.planConfigurator.webServices;

import java.util.HashMap;

import utility.CoreSuperHelper;
import utility.SOAPServiceUtils;
import utility.SpiderWebService;

public class WebService_TC12_TS extends CoreSuperHelper{
	static String endPointURL="https://spider-eps.uat.va.wellpoint.com/spidergcl/services/GroupXMLService";
	static String strDownloadPath = "";

	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					boolean booMedicalPlanDetailsFound = false;
					if(strRunFlag.equalsIgnoreCase("YES"))
					{
						logExtentReport(strTCName);
						strDownloadPath = getReportPathFolder();
						String proxyId=getCellValue("ProxyID");
						String strXMLFile=strDownloadPath+proxyId+".xml";
						String effectiveDate=getCellValue("EffectiveDate");
						String strLOB=getCellValue("LOB");
						String contractCode=getCellValue("ContractCode");
						String returnBenefits=getCellValue("ReturnBenefits");
						String returnPlanOptions=getCellValue("ReturnPlanOptions");
						String returnBenefitOptions=getCellValue("ReturnBenefitOptions");
						HashMap<String, String> ElementValue=new HashMap<>();
						String xmlInput=SpiderWebService.get().webServcRequestGetMedicalLOBPlanDetails(effectiveDate, contractCode,strLOB,returnPlanOptions,returnBenefitOptions,returnBenefits);
						SOAPServiceUtils.get_Save_SOAPResponsefromRequestString(xmlInput, ElementValue, endPointURL,strXMLFile);
						booMedicalPlanDetailsFound =SpiderWebService.get().verifyMedicalLOBFilter(strXMLFile);
						if(booMedicalPlanDetailsFound)
						{
							log(PASS, "Validate Plan details for Medical", "Plan details are displaying for Medical LOB", false);
						}
						else{
							log(FAIL, "Validate Plan details for Medical", "Plan details are not displaying for Medical LOB", false);
						}
					}
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {		
			endTestScript();

		}
	}
}

