package testScripts.planConfigurator.webServices;

import java.util.ArrayList;
import java.util.HashMap;

import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.PlanBenefitOptionsPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;
import utility.SOAPServiceUtils;
import utility.SpiderWebService;

public class WebService_TC08_TS extends CoreSuperHelper {

	static String endPointURL="https://spider-eps.uat.va.wellpoint.com/spidergcl/services/GroupXMLService";
	static String strDownloadPath = "";
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					if(strRunFlag.equalsIgnoreCase("YES"))
					{
						logExtentReport(strTCName);
						strDownloadPath = getReportPathFolder();
						String proxyId=getCellValue("ProxyID");
						String benefitOptionType="";
						String planOptionType="";
						String strXMLFile=strDownloadPath+proxyId+".xml";
						String effectiveDate=getCellValue("EffectiveDate");
						String LOB=getCellValue("LOB");
						String contractCode=getCellValue("ContractCode");
						String returnBenefits=getCellValue("ReturnBenefits");
						String returnPlanOptions=getCellValue("ReturnPlanOptions");
						String returnBenefitOptions=getCellValue("ReturnBenefitOptions");
						HashMap<String, String> ElementValue=new HashMap<>();
						String xmlInput=SpiderWebService.get().getResponseWithBenefitDetails(effectiveDate, LOB, contractCode,returnPlanOptions,returnBenefitOptions, returnBenefits);
						SOAPServiceUtils.get_Save_SOAPResponsefromRequestString(xmlInput, ElementValue, endPointURL,strXMLFile);	
						String strVersionID=PlanXMLParser.getPlanID(LOB,strXMLFile);
						if(Boolean.parseBoolean(returnBenefitOptions)){
							benefitOptionType=getCellValue("BenefitOptionType");
							ArrayList<String> benefitOptions=PlanBenefitOptionsPage.getOptionsText_SpiderUI(strBaseURL,struserProfile,strTestRegion,strVersionID,benefitOptionType);
							HashMap<String, String> benefitOptionsxml=PlanXMLParser.getOptions(strXMLFile,"Benefit Option");
							PlanXMLParser.validatePlanBenefitOptions(benefitOptions, benefitOptionsxml, "Benefit Options");
					}
						if(Boolean.parseBoolean(returnPlanOptions)){
							planOptionType=getCellValue("PlanOptionType");
							ArrayList<String> planOptions=PlanBenefitOptionsPage.getOptionsText_SpiderUI(strBaseURL,struserProfile,strTestRegion,strVersionID,planOptionType); 
							HashMap<String, String> planOptionsxml=PlanXMLParser.getOptions(strXMLFile,"Base");
							PlanXMLParser.validatePlanBenefitOptions(planOptions, planOptionsxml, "Plan Options");
						}
						if(!PlanXMLParser.validateBenefits(strXMLFile)){
							RESULT_STATUS=true;
							log(PASS,"Validate Benefits are Displayed","No Benefit Data is Displayed");
						}
						else{
							RESULT_STATUS=false;
							log(FAIL,"Validate Benefits are Displayed","Benefit Data are Displayed");
						}
					}
				}
				catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					setResult("STATUS", RESULT_STATUS);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {		
			endTestScript();

		}
	}


}
