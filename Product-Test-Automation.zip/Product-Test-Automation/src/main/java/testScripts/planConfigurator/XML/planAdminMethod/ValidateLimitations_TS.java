package testScripts.planConfigurator.XML.planAdminMethod;

import java.util.HashMap;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.benefitQuery.FindPlanPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;
import utility.WebTableWithHeader;

/**
 * @author AF14735
 *
 */
public class ValidateLimitations_TS extends CoreSuperHelper {


	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime = 600;
	static String strDownloadPath = "";
	static String strPlanVersionID = "";
	static String strProxyID = "";
	public static void main(String[] args) {
		try {
			MANUAL_TC_EXECUTION_EFFORT="00:15:00";
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					String strTCID=getCellValue("Test_Case_ID");
					String stractualadminMethodValue = getCellValue("AdminMethodValue");
					if (strRunFlag.equalsIgnoreCase("YES")) {
						logExtentReport(strTCName);
						strDownloadPath = getReportPathFolder();
						if (getWebDriver() == null) {
							seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad();
						}
						if(strTCID.equals("TestDataCreation")){
							CreatePlanPage.get().createPlan(true, intMaxWaitTime);
							strPlanVersionID = getCellValue("PlanVersionID");
							strProxyID = getCellValue("PlanProxyID");
							for(iROW=2;iROW<=getRowCount();iROW++){
								String strAccumRunFlag = getCellValue("Run_Flag");
								if(strAccumRunFlag.equalsIgnoreCase("YES")){
									String strAccumulatorName = getCellValue("AccumName");
									String strLimitValue = getCellValue("LimitValue");
									String strBenefitPeriod = getCellValue("BasisPayment");
									String strOptionsTab=getCellValue("OptionsTab");
									String strAccumulatorType = getCellValue("OptionsTabValue");
									waitForPageLoad(intMaxWaitTime);
									PlanOptionsPage.clickTab(strOptionsTab, strAccumulatorType, intMaxWaitTime);
									waitForPageLoad(intMaxWaitTime);
									PlanOptionsPage.get().updateLimitation(intMaxWaitTime,strAccumulatorName, strLimitValue, strBenefitPeriod);
								}
							}
							PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, intMaxWaitTime);
							iROW= 1;
						}
						else{
							//if (RESULT_STATUS) {
								DownloadXML(strPlanVersionID, strTestRegion, strDownloadPath);
								String strBenefitHierarchy=getCellValue("BenefitHierarchy");
								String strSituationGroupText=getCellValue("SituationGroup");
								String strSituationType=getCellValue("SituationType");
								String strCalChoiceType=getCellValue("CalculationChoiceType");
								String strAdminMethodType=getCellValue("AdminMethodType");
								String strAccumulatorType = getCellValue("OptionsTabValue");
								String strAccumulatorTypeValue = getCellValue("AccmulatorTypeValue");
								String strBenefitPeriod = getCellValue("BasisPayment");
								String strAccumulatorName = getCellValue("AccumName");
								String strUOM=getCellValue("unitCode");
								HashMap<String, String> adminMethodData = PlanXMLParser.getAdminMethodData(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", strBenefitHierarchy, strSituationGroupText, strSituationType,strCalChoiceType, strAdminMethodType);
								String adminMethodType = adminMethodData.get("Admin Method Type text").toString().trim();
								String actualadminMethodValue = adminMethodData.get("Admin Method Data value").toString().trim();
								PlanXMLParser.validateLimitationAccumulator(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", strAccumulatorType,strAccumulatorTypeValue, strAccumulatorName, strBenefitPeriod, strUOM);
								if((adminMethodType.equalsIgnoreCase("Limitation"))&&(actualadminMethodValue.equalsIgnoreCase(stractualadminMethodValue)))
								{
									//RESULT_STATUS = true;
									log(PASS, "Validate admin Method Limitation", "Admin Method value is displaying correctly for Limitation as "+actualadminMethodValue, true);
								}
								else{
									//RESULT_STATUS = false;
									log(FAIL, "Validate admin Method Limitation", "Admin Method value is not displaying correctly for Limitation "+actualadminMethodValue);
								}
							/*} else {
								//RESULT_STATUS = false;
								log(FAIL, "Validate Limitation values in the XML based for every calculation and plan level data", "Plan not moved to pending audit", true);
							}*/

						}
					}
				} catch (Exception e) {
					RESULT_STATUS = false;
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
				finally {
					endTestScript();
					if(getWebDriver()!=null){
						seCloseBrowser();
					}
					setResult("STATUS", RESULT_STATUS);
				}
			} 
		}catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			if(getWebDriver()!=null){
				seCloseBrowser();
			}
		}
	}	
}

