package testScripts.planConfigurator.XML.planAdminMethod;

import java.util.HashMap;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanBenefitOptionsPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;
/**
 * @author AF14735
 * This script is used to validate Fail value in the XML generated.
 */
public class ValidateFail_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static String strPlanVersionID = "";
	static String strProxyID = "";
	static int intMaxWaitTime = 650;

	public static void main(String[] args) {
		int maxWaitTime=100;
		try {
			MANUAL_TC_EXECUTION_EFFORT="00:15:00";
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strTCName = getCellValue("TCName");
					logExtentReport(strTCName);
					String strTCID=getCellValue("Test_Case_ID");
					String strDownloadPath=getReportPathFolder();
					if(getWebDriver()==null)
					{
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
						LoginPage.get().loginApplication(struserProfile);
						waitForPageLoad(2,360);
					}
					if(strTCID.equals("TestDataCreation")){
						CreatePlanPage.get().createPlan(true,maxWaitTime);
						strPlanVersionID = getCellValue("PlanVersionID");
						strProxyID = getCellValue("PlanProxyID");
						for(iROW=2;iROW<=getRowCount();iROW++){
							String strAccumRunFlag = getCellValue("Run_Flag");
							if(strAccumRunFlag.equalsIgnoreCase("YES")){
								String strAccumulatorName = getCellValue("AccumName");
								String strLimitValue = getCellValue("LimitValue");
								String strBenefitPeriod = getCellValue("BenefitPeriod");
								String strOptionsTab=getCellValue("OptionsTab");
								String strAccumulatorType = getCellValue("OptionsTabValue");
								PlanOptionsPage.clickTab(strOptionsTab, strAccumulatorType, intMaxWaitTime);
								waitForPageLoad(intMaxWaitTime);
								PlanOptionsPage.get().updateLimitation(intMaxWaitTime,strAccumulatorName, strLimitValue, strBenefitPeriod);
								seClick(PlanOptionsPage.get().saveButton, "saveButton");
								waitForPageLoad(300);
							}
						}
						PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, maxWaitTime);
						iROW= 1;
					}
					else{
						if(RESULT_STATUS){
							DownloadXML(strProxyID, strTestRegion, strDownloadPath);
							waitForPageLoad(500);
							String strExpectedAdminMethodValue=getCellValue("AdminMethodValue");
							String strBenefitPeriod = getCellValue("BenefitPeriod");
							String strAccumulatorName = getCellValue("AccumName");
							String strAccumulatorType = getCellValue("OptionsTabValue");
							String strUnitCode=getCellValue("UnitCode");
							String strBenefitHierarchy=getCellValue("BenefitHierarchy");
							String strSituationGroupText=getCellValue("SituationGroup");
							String strSituationType=getCellValue("SituationType");
							String strCalChoiceType=getCellValue("CalculationChoiceType");
							String strAdminMethodType=getCellValue("AdminMethodType");
							String strAccumulatorTypeValue=getCellValue("AccumulatorTypeValue");
							HashMap<String, String> adminMethodData = PlanXMLParser.getAdminMethodData(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", strBenefitHierarchy, strSituationGroupText, strSituationType,strCalChoiceType, strAdminMethodType);
							String adminMethodType = adminMethodData.get("Admin Method Type text").toString().trim();
							String adminMethodIdType=adminMethodData.get("Admin Method ID Type  value").toString().trim();
							String actualadminMethodValue = adminMethodData.get("Admin Method Data value").toString().trim();
							PlanXMLParser.validateLimitationAccumulator(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", strAccumulatorType,strAccumulatorTypeValue, strAccumulatorName, strBenefitPeriod, strUnitCode);
							//seCompareStrings(true, adminMethodType, strAdminMethodType, "Validate admin Method For Fail Scenario", "Admin Method Fail value is displaying correctly "+actualadminMethodValue);
							if(adminMethodType.equalsIgnoreCase("Fail")&&adminMethodIdType.equalsIgnoreCase("2054")&&actualadminMethodValue.equalsIgnoreCase(strExpectedAdminMethodValue)){
								RESULT_STATUS = true;
								log(PASS, "Validate admin Method For Fail Scenario", "Admin Method Fail value is displaying correctly "+actualadminMethodValue);
							}
							else{
								RESULT_STATUS = false;
								log(FAIL, "Validate admin Method For Fail Scenario", "Admin Method Fail value is not displaying correctly ");
							}
						}
						else
						{
							RESULT_STATUS = false;
							log(FAIL, "Validate Plan Design in XML", "Plan not moved to pending audit", true);
						}
					}
				} catch (Exception e) {
					RESULT_STATUS = false;
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
				finally {
					endTestScript();
					if(getWebDriver()!=null){
						seCloseBrowser();
					}
					setResult("STATUS", RESULT_STATUS);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			if(getWebDriver()!=null){
				seCloseBrowser();
			}
		}
	}

}
