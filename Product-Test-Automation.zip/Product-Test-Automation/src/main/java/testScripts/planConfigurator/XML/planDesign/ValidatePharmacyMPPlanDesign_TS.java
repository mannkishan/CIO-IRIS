package testScripts.planConfigurator.XML.planDesign;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanSetupPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;

public class ValidatePharmacyMPPlanDesign_TS extends CoreSuperHelper{

	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int maxWaitTime = 600;
	static String strDownloadPath = "";
	public static void main(String[] args) {
		try {
			MANUAL_TC_EXECUTION_EFFORT = "00:18:00";
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {

					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					String strTCID = getCellValue("Test_Case_ID");
					String strPlanVersionID = "";
					String strProxyID = "";
					if(strRunFlag.equalsIgnoreCase("YES"))
					{
						logExtentReport(strTCName);
						strDownloadPath = getReportPathFolder();				
						String strMailSetup=getCellValue("MailCoverage");
						String strRetailSetup=getCellValue("RetailCoverage");
						String strNetworkType = getCellValue("NetworkType");
						String strPlanDesignText = getCellValue("PlanDesignText");
						String strPlanDesignValue = getCellValue("PlanDesignValue");
						String strExpectedChoiceText="";
						String strExpectedChoiceValue="";
						String strMailCoverage="";
						String strRetailCoverage="";
						boolean strResult=false;
						if(getWebDriver()==null)
						{
							seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad();
						}
						CreatePlanPage.get().createPlan(true,maxWaitTime);
						strPlanVersionID = getCellValue("PlanVersionID");
						strProxyID = getCellValue("PlanProxyID");
						strMailCoverage=PlanSetupPage.get().setMailCoverage(strMailSetup);
                        strRetailCoverage=PlanSetupPage.get().setRetailCoverage(strRetailSetup);
						strExpectedChoiceText=PlanSetupPage.get().setNetworkType(strNetworkType);
						strExpectedChoiceValue=strExpectedChoiceText.replace(" ", "");
						waitForPageLoad(5, maxWaitTime);
						seClick(PlanHeaderPage.get().save, "Save Plan");
						PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, maxWaitTime);
						if(RESULT_STATUS)
						{
							DownloadXML(strProxyID, strTestRegion, strDownloadPath);
						}
						else
						{
							log(FAIL, "Validate Plan Design in XML", "Plan not moved to pending audit", true);
						}
						strResult=PlanXMLParser.validatePlanDesign(strDownloadPath+strTestRegion+"_"+strProxyID+".xml",strPlanDesignValue,strPlanDesignText);
						
						strResult=PlanXMLParser.validatePlanOptionType(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", "Mail Coverage", strMailCoverage);
							
						strResult=PlanXMLParser.validatePlanOptionType(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", "Retail Coverage", strRetailCoverage);
						
						strResult=PlanXMLParser.validateAccumulatorType(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", "Network", "Network Type", strExpectedChoiceText, strExpectedChoiceValue, "Choice");
						log(strResult?PASS:FAIL,strTCID,strTCName);
					}

				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					if (getWebDriver() != null) {
						seCloseBrowser();
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			if (getWebDriver() != null) {
				seCloseBrowser();
			}
			endTestScript();
		}
	}

}

