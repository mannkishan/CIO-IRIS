package testScripts.planConfigurator.XML.planAdminMethod;


import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import utility.CoreSuperHelper;
import utility.PCUtils;
import utility.PlanXMLParser;

/*
'Revision History
'#############################################################################
'@rev.On	@rev.No		@rev.By				  @rev.Comments
'										
'#############################################################################
*/

/**
 * Manual test case: Validate Medicare admin method for the below conditions
 * Order of Processing Admin Method Value Choice Accumulator Choice Value 1
 * <choice value> MCOBAdmMtd -- 2 <choice value> MCOBAdmMtdHMO -- 3 5 -- -- 6
 * MedicareCOBCarveOutApplies Y
 * 
 * @author AF12450
 * @since 17-OCT-2017
 *
 */
public class ValidateMedicareCOB_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static String strDownloadPath = "";
	static int intMaxWaitTime = 300;

	public static void main(String[] args) {

		try {
			MANUAL_TC_EXECUTION_EFFORT = "00:20:00";
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strTCName = getCellValue("TCName");
					String strRunFlag = getCellValue("Run_Flag");
					String strPlanVersionID = "";
					String strProxyID = "";
					if (strRunFlag.equalsIgnoreCase("Yes")) {
						logExtentReport(strTCName);
						String strMedicareCOBApplies = getCellValue("MedicareCOBApplies");
						String strCOBAdminMethod = getCellValue("COBAdminMethod");
						String strCOBBenefitReserve = getCellValue("COBBenefitReserve");
						String strCOBNonDuplication = getCellValue("COBNonDuplication");
						String strCOBCarveOutAPplies = getCellValue("COBCarveOutApplies");
						String strAdminMethodValue = getCellValue("AdminMethodValue");
						String strAdminMethodID = getCellValue("AdminMethodID");
						strPlanVersionID = getCellValue("PlanVersionID");
						strProxyID = getCellValue("PlanProxyID");
						strDownloadPath = getReportPathFolder();
						 seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
						 LoginPage.get().loginApplication(strUserProfile);
						 waitForPageLoad(2,360);
						 CreatePlanPage.get().createPlan(true,intMaxWaitTime);
						 waitForPageLoad(2,intMaxWaitTime);
						 strPlanVersionID = getCellValue("PlanVersionID");
						 strProxyID = getCellValue("PlanProxyID");
						 String strProductFamily = getCellValue("ProductFamily");
						 if(strProductFamily.equalsIgnoreCase("HMO"))
						 {
							 String strINNValue=getCellValue("InNetworkTier1");
								String strOONValue=getCellValue("OutNetworkTier1");
								 PlanLevelBenefitsPage.get().updatePlanTierSetUp(intMaxWaitTime, strINNValue, strOONValue);
						 }
						
						 
						 PlanOptionsPage.clickTab("Plan Setup", "Plan Administration", intMaxWaitTime);
						 waitForPageLoad(2,intMaxWaitTime);
						 sePCSelectText(PlanSetupPage.get().COBAdminMethod,
						 "COB Admin Method", strCOBAdminMethod,
						 intMaxWaitTime);
						 PlanOptionsPage.clickTab("Plan Setup", "Medicare COB", intMaxWaitTime);
						 waitForPageLoad(2,intMaxWaitTime);
						 sePCSelectText(PlanSetupPage.get().medicareCOBApplies,
						 "COB Applies", strMedicareCOBApplies,
						 intMaxWaitTime);
						 sePCSelectText(PlanSetupPage.get().medicareCOBBenefitReserve,
						 "COB Benefit Reserve", strCOBBenefitReserve,
						 intMaxWaitTime);
						 sePCSelectText(PlanSetupPage.get().medicareCOBNonDuplication,
						 "COB Non Duplication", strCOBNonDuplication,
						 intMaxWaitTime);
						 sePCSelectText(PlanSetupPage.get().medicareCOBCarveOutApplies,
						 "COB Carve Out Applies", strCOBCarveOutAPplies,
						 intMaxWaitTime);
						 waitForPageLoad(5, intMaxWaitTime);
						 seClick(PlanHeaderPage.get().save, "Save Plan");
						 waitForPageLoad(5, intMaxWaitTime);
						 PlanHeaderPage.get().requestAuditPlan(strPlanVersionID,
						 intMaxWaitTime);
						if (RESULT_STATUS) {
							DownloadXML(strProxyID, strTestRegion, strDownloadPath);
							String xmlPath = strDownloadPath + strTestRegion + "_" + strPlanVersionID + ".xml";
							if(!strTCName.equalsIgnoreCase("Validate Medicare Admin method when Medicare COB applies is No and COB carve out applies is No"))
							{
							String choiceText = PlanXMLParser.getAccumulatorDetail(xmlPath, "Medicare COB",
									"Medicare COB Applies", "choiceValue", "text");
							seCompareStrings(choiceText, strMedicareCOBApplies, "=",
									"Validate choice text for accumulator Medicare COB Applies");
							choiceText = PlanXMLParser.getAccumulatorDetail(xmlPath, "Medicare COB",
									"Medicare COB Non-Duplication", "choiceValue", "text");
							seCompareStrings(choiceText, strCOBNonDuplication, "=",
									"Validate choice text for accumulator Medicare COB Non-Duplication");
							choiceText = PlanXMLParser.getAccumulatorDetail(xmlPath, "Medicare COB",
									"Medicare COB Benefit Reserve", "choiceValue", "text");
							seCompareStrings(choiceText, strCOBBenefitReserve, "=",
									"Validate choice text for accumulator Medicare COB Benefit Reserve");
							choiceText = PlanXMLParser.getAccumulatorDetail(xmlPath, "Medicare COB",
									"Medicare COB Carve Out Applies", "choiceValue", "text");
							seCompareStrings(choiceText, strCOBCarveOutAPplies, "=",
									"Validate choice text for accumulator Medicare COB Carve Out Applies");
							choiceText = PlanXMLParser.getAccumulatorDetail(xmlPath, "Medicare COB",
									"Medicare COB Carve Out Applies", "choiceValue", "text");
							seCompareStrings(choiceText, strCOBCarveOutAPplies, "=",
									"Validate choice text for accumulator Medicare COB Carve Out Applies");
							choiceText = PlanXMLParser.getAccumulatorDetail(xmlPath, "Plan Administration",
									"COB Admin Method", "choiceValue", "text");
							seCompareStrings(choiceText, strCOBAdminMethod, "=",
									"Validate choice text for accumulator COB Admin Method");
							}
							PlanXMLParser.validateAdminMethod("Medicare", strAdminMethodValue, xmlPath);
							if(strProductFamily.equalsIgnoreCase("HMO"))
							{
								String strNonParticipatingID = getCellValue("NonParticipatingID");
							PCUtils.validateMedicareAdminMethodID("Medicare", strAdminMethodID, strNonParticipatingID, xmlPath);
							}
							else
							{
								PlanXMLParser.validateAdminMethodID("Medicare",strAdminMethodID, xmlPath);
							}
							
						}
						else
						{
							log(FAIL, "XML validation", "XML validation is failed as the plan is not moved to pending audit");
							
						}
						setResult("STATUS", RESULT_STATUS);	
					}
					
					

				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
				 finally {
				 if(getWebDriver() != null)
				 {
				 seCloseBrowser();
				 }
				 }
				
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}

	}

	

}
