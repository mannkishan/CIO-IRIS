package testScripts.planConfigurator.XML.planAdminMethod;



import java.util.HashMap;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;
import utility.PCUtils;
import utility.PlanXMLParser;


/**
 * Manual test case: Verify that correct value is displaying for Family Deductible admin method in the Plan XML 
 * @author AF19349
 * @since 5-Oct-2017
 */
public class ValidateFamilyDeductible_TS extends CoreSuperHelper{

	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int maxWaitTime = 450;
	static String strDownloadPath = "";	

	public static void main(String[] args) {

		try {
			MANUAL_TC_EXECUTION_EFFORT="00:15:00";
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					if(strRunFlag.equalsIgnoreCase("YES"))
					{
						logExtentReport("Validate AdminMethod: Family Deductible");
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
						LoginPage.get().loginApplication(struserProfile);
						waitForPageLoad(5,maxWaitTime);

						CreatePlanPage.get().createPlan(true,maxWaitTime);
						String strPlanVersionID = getCellValue("PlanVersionID");
						String strProxyID = getCellValue("PlanProxyID");
						String expXMLAdminMethodValue = getCellValue("XMLFamDedValue");
						String strDedCriteria = getCellValue("PaymentLevel");
						strDownloadPath=getReportPathFolder();

						PCUtils.get().updateFamilyDeductibleAccumDetails();
						waitForPageLoad(maxWaitTime);
						seClick(PlanOptionsPage.get().saveButton, "saveButton");
						waitForPageLoad(maxWaitTime);
						PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, maxWaitTime);

						//Download XML
						if(RESULT_STATUS)
						{
							DownloadXML(strProxyID, strTestRegion, strDownloadPath);
							System.out.println(strDownloadPath);
						}
						else
						{
							log(FAIL, "Validate Plan Design in XML", "Plan not moved to pending audit", true);
						}

						//Validate XML
						HashMap<String, String> adminMethodData = PlanXMLParser.getAdminMethodData(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", getCellValue("BenefitHierarchy"), getCellValue("SituationGroup"), getCellValue("SituationType"),getCellValue("CalculationChoiceType"), getCellValue("AdminMethodType"));
						String adminMethodType = adminMethodData.get("Admin Method Type text").toString().trim();
						String actXMLAdminMethodValue = adminMethodData.get("Admin Method Data value").toString().trim();

						if((adminMethodType.equalsIgnoreCase("Family Deductible"))&&(expXMLAdminMethodValue.equalsIgnoreCase(actXMLAdminMethodValue)))
						{
							log(PASS, "Validate admin Method Family Deductible value", "Family Deductible value is displaying correctly for "+strDedCriteria+" as "+actXMLAdminMethodValue, true);
						}
						else{
							log(FAIL, "Validate admin Method Family Deductible value", "Family Deductible value is not displaying correctly for "+strDedCriteria, true);
						}
						seCloseBrowser();
					}
				} catch (Exception e) {
					RESULT_STATUS = false;
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
				finally {
					endTestScript();
					if(getWebDriver()!=null){
						seCloseBrowser();
					}
					setResult("STATUS", RESULT_STATUS);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			if(getWebDriver()!=null){
				seCloseBrowser();
			}
		}
	}
}
