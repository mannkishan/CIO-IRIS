package testScripts.planConfigurator.XML.planAdminMethod;


import java.io.File;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.w3c.dom.NodeList;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import com.gargoylesoftware.htmlunit.javascript.host.dom.Document;

import net.sourceforge.htmlunit.corejs.javascript.ast.SwitchCase;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;

/**
 * @author AF14735
 *This script is used to validate Coordination of Benefits value in the XML generated.
 */
public class ValidateMPPPOPlanCOB_TS extends CoreSuperHelper{
	
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime = 450;
	static String strDownloadPath = "";

	public static void main(String[] args) {

		try {
			MANUAL_TC_EXECUTION_EFFORT="00:15:00";
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {

					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					String strPlanVersionID = "";
					String strProxyID = "";
					String strAccumulatorName = getCellValue("AccumulatorName");
					String strChoiceText = getCellValue("ChoiceText");
					String strChoiceValue = getCellValue("ChoiceValue");
					String strAdminMethodValue = getCellValue("AdminMethodValue");
					if (strRunFlag.equalsIgnoreCase("YES")) {
						logExtentReport(strTCName);
						strDownloadPath = getReportPathFolder();
						if (getWebDriver() == null) {
							seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad();
						}
						CreatePlanPage.get().createPlan(true, intMaxWaitTime);
						strPlanVersionID = getCellValue("PlanVersionID");
						strProxyID = getCellValue("PlanProxyID");
						waitForPageLoad(5, intMaxWaitTime);
						PlanOptionsPage.clickTab("Plan Setup", "COB", intMaxWaitTime);
						PlanSetupPage.get().updateCOB(strAccumulatorName, strChoiceText);
						if(strAccumulatorName.equalsIgnoreCase("COB Benefit Reserve")){
							PlanSetupPage.get().updateCOB("COB Highest Allowed Amount", "Yes");
						}
						PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, intMaxWaitTime);
						if (RESULT_STATUS) {
							DownloadXML(strProxyID, strTestRegion, strDownloadPath);
							PlanXMLParser.validateAccumulatorType(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", "COB", strAccumulatorName, strChoiceText, strChoiceValue, "Choice");
							PlanXMLParser.validateAdminMethod("Coordination Of Benefits", strAdminMethodValue, strDownloadPath+strTestRegion+"_"+strProxyID+".xml");
						} else {
							RESULT_STATUS = false;
							log(FAIL, "Validate COB values in the XML based on the Choice value", "Plan not moved to pending audit", true);
						}
				
					}
				} catch (Exception e) {
					RESULT_STATUS = false;
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					endTestScript();
					if(getWebDriver()!=null){
						seCloseBrowser();
					}
					setResult("STATUS", RESULT_STATUS);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			if (getWebDriver() != null) {
				seCloseBrowser();
			}
		}
	}

}
