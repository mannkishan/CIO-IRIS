package testScripts.planConfigurator.XML;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitsPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import utility.CoreSuperHelper;

public class ValidateMPXMLBenefitsConfiguration_TS extends CoreSuperHelper{
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime = 400;
	static String strDownloadPath = "";
	static String strPlanVersionID = "";
	static String strProxyID = "";

	public static void main(String[] args) {
		try {

			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");	
					if(strRunFlag.equalsIgnoreCase("YES")){
						strDownloadPath = getReportPathFolder();
						if(strTCName.equals("TestDataCreation")){
							logExtentReport(strTCName);
							if(getWebDriver()==null){
								seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
								LoginPage.get().loginApplication(struserProfile);
								waitForPageLoad(2,360);
							}
							waitForPageLoad(2,360);
							CreatePlanPage.get().createPlan(true,intMaxWaitTime);
							strPlanVersionID = getCellValue("PlanVersionID");
							strProxyID = getCellValue("PlanProxyID");
							waitForPageLoad(5, intMaxWaitTime);
							PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, intMaxWaitTime);
							RESULT_STATUS= true;
							if(RESULT_STATUS){
								DownloadXML(strPlanVersionID, strTestRegion, strDownloadPath);
								BenefitsPage.get().clickBenefitstab();
							}
							else
							{
								log(FAIL, "Validate XML Downloaded", "Plan not moved to pending audit", true);
							} 
						}
						else{
							for(iROW=2;iROW<=getRowCount();iROW++){
								strRunFlag = getCellValue("Run_Flag");
								if(strRunFlag.equalsIgnoreCase("YES")){
									logExtentReport(strTCName);	
									String strBenefitHierachy=getCellValue("Benefit");
									waitForPageLoad(5, intMaxWaitTime);
									BenefitsPage.get().clickBenefits(strBenefitHierachy);
									waitForPageLoad(5, intMaxWaitTime);
									RESULT_STATUS=BenefitsPage.get().validateSituation(strBenefitHierachy,strDownloadPath+strTestRegion+"_"+strPlanVersionID+".xml");
								}
							}
						}
					}				
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			if(getWebDriver()!=null){
				seCloseBrowser();
			}
			endTestScript();
			
		}
	}
}
