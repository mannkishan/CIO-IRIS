package testScripts.planConfigurator.XML.planAdminMethod;


import java.util.HashMap;
import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;


/**
 * Manual test case: Verify that correct value is represented for Basis Payment admin method in the Plan XML 
 * <p>
 * Test script template
 * <p>
 * 
 * 
 * @author AF17403
 * @since 18-Sep-2017
 *
 */
public class ValidateBasisPayment_TS extends CoreSuperHelper{

	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime = 400;
	static String strDownloadPath = "";
	public static void main(String[] args) {

		try {
			MANUAL_TC_EXECUTION_EFFORT="00:15:00";
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					String strPlanVersionID = "";
					String strProxyID = "";
					if(strRunFlag.equalsIgnoreCase("YES"))
					{
						logExtentReport(strTCName);						
						strDownloadPath = getReportPathFolder();
						String strCoinsuranceValue=getCellValue("CoinsuranceValue");
						String strCoinsuranceType=getCellValue("CoinsuranceType");
						String strOptionsTab=getCellValue("OptionsTab");
						String strOptionsTypeTextValue=getCellValue("OptionsTypeTextValue");
						String strOOPCheckBoxValue=getCellValue("OOPCheckBox");
						String strAccumulatorType=getCellValue("AccumulatorType");
						String strCoinsuranceDoesNotApply=getCellValue("CoinsuranceDoesNotApply");
						String strBenefitHierarchy=getCellValue("BenefitHierarchy");
						String strSituationGroupText=getCellValue("SituationGroup");
						String strSituationType=getCellValue("SituationType");
						String strCalChoiceType=getCellValue("CalculationChoiceType");
						String strAdminMethodType=getCellValue("AdminMethodType");
						String strAdminMethodValue=getCellValue("AdminMethodValue");
						if(getWebDriver()==null)
						{
							seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad(2,360);
						}
						waitForPageLoad(2,360);
						CreatePlanPage.get().createPlan(true,intMaxWaitTime);
						strPlanVersionID = getCellValue("PlanVersionID");
						strProxyID = getCellValue("PlanProxyID");
						waitForPageLoad(5, intMaxWaitTime);
						PlanOptionsPage.clickTab("Plan Level Benefits", "Coinsurance", intMaxWaitTime);
						PlanLevelBenefitsPage.updateCoinsuranceValue(strCoinsuranceValue,strCoinsuranceType);
						PlanOptionsPage.clickTab(strOptionsTab, strAccumulatorType, intMaxWaitTime);
						PlanOptionsPage.get().updateOOP(strOOPCheckBoxValue, strOptionsTypeTextValue, strCoinsuranceValue);
						seClick(PlanHeaderPage.get().save, "Save Plan");
						waitForPageLoad(5, intMaxWaitTime);
						PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, intMaxWaitTime);
						if(RESULT_STATUS)
						{
							DownloadXML(strProxyID, strTestRegion, strDownloadPath);
							if(strCoinsuranceDoesNotApply.equalsIgnoreCase("No"))
							{
								String applyToXrefAccum=PlanXMLParser.getOOPValue(strDownloadPath+strTestRegion+"_"+strProxyID+".xml",strAccumulatorType,strOptionsTypeTextValue);
								if(applyToXrefAccum!=null)
								{
									if(strOOPCheckBoxValue.equalsIgnoreCase("UnCheck"))
									{
										if(applyToXrefAccum.equalsIgnoreCase("false"))
										{
											RESULT_STATUS = true;
											log(PASS,"Validate if applyToXrefAccum text is displayed as false in xml","Verifying if applyToXrefAccum value is "+applyToXrefAccum);
										}
										else
										{
											RESULT_STATUS = false;
											log(FAIL,"Validate if applyToXrefAccum text is displayed as false in xml","Verifying if applyToXrefAccum value is "+applyToXrefAccum);
										}
									}
									else
									{
										if(applyToXrefAccum.equalsIgnoreCase("true"))
										{
											RESULT_STATUS = true;
											log(PASS,"Validate if applyToXrefAccum text is displayed as true in xml","Verifying if applyToXrefAccum value is "+applyToXrefAccum);
										}
										else
										{
											RESULT_STATUS = false;
											log(FAIL,"Validate if applyToXrefAccum text is displayed as true in xml","Verifying if applyToXrefAccum value is "+applyToXrefAccum);
										}
									}
								}
								else
								{
									RESULT_STATUS = false;
									log(FAIL, "Validate applyToXrefAccumin XML", "Not able to find the applyToXrefAccum in the XML");
								}	
							}
							else{
								RESULT_STATUS = true;
								log(PASS, "Validate applyToXrefAccumin XML", "applyToXrefAccum will not be Available in xml for Coinsurance Not Applicable");
							}
							HashMap<String, String> adminMethodData = PlanXMLParser.getAdminMethodData(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", strBenefitHierarchy, strSituationGroupText, strSituationType,strCalChoiceType, strAdminMethodType);
							String adminMethodType = adminMethodData.get("Admin Method Type text").toString().trim();
							String adminMethodIdType=adminMethodData.get("Admin Method ID Type  value").toString().trim();
							String actualadminMethodValue = adminMethodData.get("Admin Method Data value").toString().trim();
							if(adminMethodType.equalsIgnoreCase("Basis of Payment")&&adminMethodIdType.equalsIgnoreCase("0102")&&actualadminMethodValue.equalsIgnoreCase(strAdminMethodValue)){
								RESULT_STATUS = true;
								log(PASS, "Validate admin Method For Basis of Payment Scenario", "Admin Method Basis of Payment is displaying correctly "+actualadminMethodValue, true);
							}
							else{
								RESULT_STATUS = true;
								log(FAIL, "Validate admin Method For Basis of Payment Scenario", "Admin Method Basis of Payment value is not displaying correctly ", true);
							}
						}
						else
						{
							RESULT_STATUS = false;
							log(FAIL, "Validate Accumulator OOP value in XML", "Plan not moved to pending audit", true);
						}
					}

				} catch (Exception e) {
					RESULT_STATUS = false;
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
				finally {
					endTestScript();
					if(getWebDriver()!=null){
						seCloseBrowser();
					}
					setResult("STATUS", RESULT_STATUS);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			if(getWebDriver()!=null){
				seCloseBrowser();
			}
		}
	}
}
