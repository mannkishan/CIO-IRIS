package testScripts.planConfigurator.XML.planDesign;

import java.util.HashMap;

import org.apache.poi.util.SystemOutLogger;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanSetupPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;

/**
 * Manual test case: Verify that the correct plan design is displayed in the XML
 * based on the planOption selection for Vision Master product plan
 * <p>
 * Test script template
 * <p>
 * Please refer this test script while creating other test scripts
 * 
 * @author TP&E
 * @since 14-July-2017
 *
 */
public class ValidateVisionMPPlanDesign_TS extends CoreSuperHelper {

	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime = 360;
	static String strDownloadPath = "";
	

	public static void main(String[] args) {

		try {
			MANUAL_TC_EXECUTION_EFFORT = "00:20:00";
		
			initiateTestScript();
			System.out.println("HI");
			
			String strRunFlag="";

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {

					strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					String strPlanVersionID = "";
					String strProxyID = "";
					if (strRunFlag.equalsIgnoreCase("YES")) {
						logExtentReport(strTCName);
						strDownloadPath = getReportPathFolder();
						String strPediatricVision = getCellValue("PediatricVision");
						String strAdultVision = getCellValue("AdultVision");
						String strPlanDesignText = getCellValue("PlanDesignText");
						String strPlanDesignValue = getCellValue("PlanDesignValue");
						if (getWebDriver() == null) {
							seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad();
						}
						CreatePlanPage.get().createPlan(true, intMaxWaitTime);
						strPlanVersionID = getCellValue("PlanVersionID");
						strProxyID = getCellValue("PlanProxyID");
						PlanSetupPage.get().setPediatricVision(strPediatricVision);
						PlanSetupPage.get().setAdultVision(strAdultVision);
						waitForPageLoad(5, intMaxWaitTime);
						seClick(PlanHeaderPage.get().save, "Save Plan");
						PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, intMaxWaitTime);
						if (RESULT_STATUS) {
							DownloadXML(strProxyID, strTestRegion, strDownloadPath);
						} else {
							log(FAIL, "Validate Plan Design in XML", "Plan not moved to pending audit", true);
						}
						HashMap<String, String> planDesign = PlanXMLParser
								.getPlanDesign(strDownloadPath + strTestRegion + "_" + strProxyID + ".xml");
						String actualPlanDesignValue = planDesign.get("value");
						String actualPlanDesignText = planDesign.get("text");
						if (actualPlanDesignValue != null) {
							if (actualPlanDesignValue.equalsIgnoreCase(strPlanDesignValue)) {
								RESULT_STATUS = true;
								log(PASS, "Validate Plan Design Value in XML", "Actual value :" + actualPlanDesignValue
										+ " is equal to Expected value: " + strPlanDesignValue);
							} else {
								RESULT_STATUS = false;
								log(FAIL, "Validate Plan Design Value in XML", "Actual value :" + actualPlanDesignValue
										+ " is not equal to Expected value: " + strPlanDesignValue);
							}
						} else {
							RESULT_STATUS = false;
							log(FAIL, "Validate Plan Design Value in XML",
									"Not able to find the plan design in the XML");

						}
						if (actualPlanDesignText != null) {
							if (actualPlanDesignText.equalsIgnoreCase(strPlanDesignText)) {
								RESULT_STATUS = true;
								log(PASS, "Validate Plan Design text in XML", "Actual text :" + actualPlanDesignText
										+ " is equal to Expected value: " + strPlanDesignText);
							} else {
								RESULT_STATUS = false;
								log(FAIL, "Validate Plan Design text in XML", "Actual text :" + actualPlanDesignText
										+ " is equal to Expected value: " + strPlanDesignText);
							}
						} else {
							RESULT_STATUS = false;
							log(FAIL, "Validate Plan Design text in XML",
									"Not able to find the plan design in the XML");
						}
							
					}
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					
					setResult("STATUS", RESULT_STATUS);
					if (getWebDriver() != null) {
						seCloseBrowser();
					}
					endTestScript();
					
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			if (getWebDriver() != null) {
				seCloseBrowser();
			}
		
			
		}
	}

}
