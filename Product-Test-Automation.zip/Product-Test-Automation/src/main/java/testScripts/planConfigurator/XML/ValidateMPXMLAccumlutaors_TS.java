package testScripts.planConfigurator.XML;

import java.util.HashMap;
import java.util.Map;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;

public class ValidateMPXMLAccumlutaors_TS extends CoreSuperHelper{
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime = 600;
	static String strDownloadPath = "";
	static String strPlanVersionID = "";
	static String strProxyID = "";

	public static void main(String[] args) {
		try {
			MANUAL_TC_EXECUTION_EFFORT="00:20:00";
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					boolean isFound=false;
					if(strRunFlag.equalsIgnoreCase("YES")){
						logExtentReport(strTCName);
						strDownloadPath = getReportPathFolder();						
						if(getWebDriver()==null){
							seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad(2,360);
						}
						waitForPageLoad(2,intMaxWaitTime);
						CreatePlanPage.get().createPlan(true,intMaxWaitTime);
						strPlanVersionID = getCellValue("PlanVersionID");
						strProxyID = getCellValue("PlanProxyID");
						PlanOptionsPage.clickTab("Plan Setup", "Plan Tier Setup", intMaxWaitTime);
						String strInNetworkTier1=getCellValue("Tier1");
						String strInNetworkTier2=getCellValue("Tier2");
						sePCSelectText(PlanLevelBenefitsPage.get().inNetTier1Network, "In Network Tier 1", strInNetworkTier1, intMaxWaitTime);
						sePCSelectText(PlanLevelBenefitsPage.get().inNetTier2Network, "In Network Tier 2", strInNetworkTier2, intMaxWaitTime);  
						waitForPageLoad(5, intMaxWaitTime);
						PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, intMaxWaitTime);
						String expectedPOT=getCellValue("POT");
						String[] expectedGroupType=getCellValue("GroupType").split(";");						
						String[] expectedGroupName_ChiroExam=getCellValue("ChiroExam").split(";");
						String[] expectedGroupName_HearingAid=getCellValue("HearingAid").split(";");
						String[] expectedGroupName_OfficeExams=getCellValue("OfficeExams").split(";");
						RESULT_STATUS= true;
						if(RESULT_STATUS){
							DownloadXML(strPlanVersionID, strTestRegion, strDownloadPath);
						}
						else
						{
							log(FAIL, "Validate XML Downloaded", "Plan not moved to pending audit", true);
						} 
						String strXMLFile=strDownloadPath+strTestRegion+"_"+strProxyID+".xml";
						HashMap<String,String> planOptionType=PlanXMLParser.validatePlanOptionType(strXMLFile);						
						String actualPOT="";
						for (Map.Entry<String, String> entry : planOptionType.entrySet())
						{
							actualPOT=entry.getValue(); 
							{
								if(actualPOT.equalsIgnoreCase(expectedPOT))
								{
									isFound=true;
									RESULT_STATUS=true;
									log(PASS,"Validate Plan Option type Value",expectedPOT+" is equal to :"+actualPOT);
								}
							}					
						}
						if(!isFound)
						{
							RESULT_STATUS=false;
							log(FAIL,"Validate Plan Option type Value",expectedPOT+" is not equal to :"+actualPOT);
						}

						String actualGroupType="";
						HashMap<String,String> groupType=PlanXMLParser.validateAccumulatorGroupType(strXMLFile, expectedPOT);
						for (String expGroupType : expectedGroupType) 			
						{ 
							isFound=false;				
							for (Map.Entry<String, String> entry : groupType.entrySet())
							{
								actualGroupType=entry.getValue(); 
								{
									if(actualGroupType.equalsIgnoreCase(expGroupType))
									{
										isFound=true;
										RESULT_STATUS=true;
										log(PASS,"Accumulators are found for Plan Type :"+expectedPOT,expGroupType +"is Equal to :"+actualGroupType);
									}
								}					
							}
							if(!isFound)
							{
								RESULT_STATUS=false;
								log(FAIL,"Accumulators are not found for Plan Type :"+expectedPOT,expGroupType +"is not Equal to :"+actualGroupType);
							}
						}

						String actualGroupName="";
						HashMap<String,String> groupName_Chiro=PlanXMLParser.validateAccumulatorGroupName(strXMLFile, expectedPOT);
						for (String expGroupName : expectedGroupName_ChiroExam) 			
						{ 
							isFound=false;				
							for (Map.Entry<String, String> entry : groupName_Chiro.entrySet())
							{
								actualGroupName=entry.getValue(); 
								{
									if(actualGroupName.equalsIgnoreCase(expGroupName))
									{
										isFound=true;
										RESULT_STATUS=true;
										log(PASS,"Accumulators are found for Plan Type :"+expectedPOT,expGroupName +"is Equal to :"+actualGroupName);
									}
								}					
							}
							if(!isFound)
							{
								RESULT_STATUS=false;
								log(FAIL,"Accumulators are not found for Plan Type :"+expectedPOT,expGroupName +"is not Equal to :"+actualGroupName);
							}
						}
						String LASIKMX=PlanXMLParser.validateClaimsAccumName(strXMLFile, "Lasik", "DlrLmtLasikComb");
						if(LASIKMX.equalsIgnoreCase("LASIKMX"))
						{
							log(PASS,"Validate if claim accum name is present","LASIKMX is equal to:"+LASIKMX);
						}
						else
						{
							log(FAIL,"Validate if claim accum name is present","LASIKMX is not equal to:"+LASIKMX);
						}
						String IPRTNURS=PlanXMLParser.validateClaimsAccumName(strXMLFile, "InptFac", "UnitDayInptNewbornCare");
						if(IPRTNURS.equalsIgnoreCase("IPRTNURS"))
						{
							log(PASS,"Validate if claim accum name is present","IPRTNURS is equal to :"+IPRTNURS);
						}
						else
						{
							log(FAIL,"Validate if claim accum name is present","IPRTNURS is not equal to :"+IPRTNURS);
						}
						String SSHE02TB=PlanXMLParser.validateClaimsAccumName(strXMLFile, "DiabeticDMESupplies", "UnitDiabeticCopayLmt");
						if(SSHE02TB.equalsIgnoreCase("SSHE02TB"))
						{
							log(PASS,"Validate if claim accum name is present","SSHE02TB is equal to :"+SSHE02TB);
						}
						else
						{
							log(FAIL,"Validate if claim accum name is present","SSHE02TB is not equal to :"+SSHE02TB);
						}

						HashMap<String,String> UnitPapSmearVstLmt=PlanXMLParser.validateAccumulatorGroupName(strXMLFile, "PrevCare");				
						for (Map.Entry<String, String> entry : UnitPapSmearVstLmt.entrySet())
						{
							actualGroupName=entry.getValue(); 
							{
								if(actualGroupName.equalsIgnoreCase("UnitPapSmearVstLmt"))
								{
									isFound=true;
									RESULT_STATUS=true;
									log(PASS,"Accumulators are found for Plan Type : PrevCare","UnitPapSmearVstLmt is Equal to :"+actualGroupName);
								}
							}					
						}
						if(!isFound)
						{
							RESULT_STATUS=false;
							log(FAIL,"Accumulators are not found for Plan Type : PrevCare","UnitPapSmearVstLmt is not Equal to :"+actualGroupName);
						}

						HashMap<String,String> DlrLmtLasikComb=PlanXMLParser.validateAccumulatorGroupName(strXMLFile, "Lasik");				
						for (Map.Entry<String, String> entry : DlrLmtLasikComb.entrySet())
						{
							actualGroupName=entry.getValue(); 
							{
								if(actualGroupName.equalsIgnoreCase("DlrLmtLasikComb"))
								{
									isFound=true;
									RESULT_STATUS=true;
									log(PASS,"Accumulators are found for Plan Type : Lasik","DlrLmtLasikComb is Equal to :"+actualGroupName);
								}
							}					
						}
						if(!isFound)
						{
							RESULT_STATUS=false;
							log(FAIL,"Accumulators are not found for Plan Type : Lasik","DlrLmtLasikComb is not Equal to :"+actualGroupName);
						}

						HashMap<String,String> DlrLmtDME=PlanXMLParser.validateAccumulatorGroupName(strXMLFile, "DME");				
						for (Map.Entry<String, String> entry : DlrLmtDME.entrySet())
						{
							actualGroupName=entry.getValue(); 
							{
								if(actualGroupName.equalsIgnoreCase("DlrLmtDME"))
								{
									isFound=true;
									RESULT_STATUS=true;
									log(PASS,"Accumulators are found for Plan Type : DME","DlrLmtDME is Equal to :"+actualGroupName);
								}
							}					
						}
						if(!isFound)
						{
							RESULT_STATUS=false;
							log(FAIL,"Accumulators are not found for Plan Type : DME","DlrLmtDME is not Equal to :"+actualGroupName);
						}

						HashMap<String,String> groupName_HearingAid=PlanXMLParser.validateAccumulatorGroupName(strXMLFile, "HearingAid");
						for (String expGroupName : expectedGroupName_HearingAid) 			
						{ 
							isFound=false;				
							for (Map.Entry<String, String> entry : groupName_HearingAid.entrySet())
							{
								actualGroupName=entry.getValue(); 
								{
									if(actualGroupName.equalsIgnoreCase(expGroupName))
									{
										isFound=true;
										RESULT_STATUS=true;
										log(PASS,"Accumulators are found for Plan Type : HearingAid",expGroupName +"is Equal to :"+actualGroupName);
									}
								}					
							}
							if(!isFound)
							{
								RESULT_STATUS=false;
								log(FAIL,"Accumulators are not found for Plan Type : HearingAid",expGroupName +"is not Equal to :"+actualGroupName);
							}
						}

						HashMap<String,String> groupName_OfficeExams=PlanXMLParser.validateAccumulatorGroupName(strXMLFile,"OtherDiagnostics");
						for (String expGroupName : expectedGroupName_OfficeExams) 			
						{ 
							isFound=false;				
							for (Map.Entry<String, String> entry : groupName_OfficeExams.entrySet())
							{
								actualGroupName=entry.getValue(); 
								{
									if(actualGroupName.equalsIgnoreCase(expGroupName))
									{
										isFound=true;
										RESULT_STATUS=true;
										log(PASS,"Accumulators are found for Plan Type : OtherDiagnostics",expGroupName +"is Equal to :"+actualGroupName);
									}
								}					
							}
							if(!isFound)
							{
								RESULT_STATUS=false;
								log(FAIL,"Accumulators are not found for Plan Type : OtherDiagnostics",expGroupName +"is not Equal to :"+actualGroupName);
							}
						}							
					}
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			if(getWebDriver()!=null){
				seCloseBrowser();
			}
			endTestScript();

		}
	}


}

