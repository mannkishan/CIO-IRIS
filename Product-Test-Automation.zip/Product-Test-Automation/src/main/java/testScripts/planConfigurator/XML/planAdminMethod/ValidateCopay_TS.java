package testScripts.planConfigurator.XML.planAdminMethod;

import java.util.HashMap;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;
import utility.PCUtils;
import utility.PlanXMLParser;

/**
 * Manual test case: Verify that correct value is displaying for Copay admin method in the Plan XML 
 * @author AF19349
 * @since 21-Sep-2017
 */
public class ValidateCopay_TS extends CoreSuperHelper {

	
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime = 360;
	static String strDownloadPath = "";	
	static String strProxyID = "";
	public static void main(String[] args) {
	try {
		MANUAL_TC_EXECUTION_EFFORT="00:15:00";
		initiateTestScript();
		for (iROW = 1; iROW <= getRowCount(); iROW++) {

			try {
				if(getCellValue("Run_Flag").equalsIgnoreCase("YES")) {

					String strTCName = getCellValue("TCName");
					String strTCID= getCellValue("Test_Case_ID");
					strDownloadPath=getReportPathFolder();
					String strPlanVersionID =getCellValue("PlanVersionID");
					String strCopayCriteria=getCellValue("CopayCriteria");
					
					logExtentReport(strTCName);
					
					if(strTCID.equals("TestDataCreation"))	
					{
						if(getWebDriver()==null)
						{
							seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad(intMaxWaitTime);
						}
						CreatePlanPage.get().createPlan(true,intMaxWaitTime);
						strPlanVersionID = getCellValue("PlanVersionID");
						strProxyID = getCellValue("PlanProxyID");

						for (iROW = 1; iROW <= getRowCount(); iROW++) 
						{
							String strAccumRunFlag = getCellValue("Run_Flag");
							strTCID= getCellValue("Test_Case_ID");
							if((strAccumRunFlag.equalsIgnoreCase("YES"))&&(!strTCID.equals("TestDataCreation")))
							{
								PCUtils.get().updateCopayAccumDetails();
							}
						}
					    waitForPageLoad(intMaxWaitTime);
						seClick(PlanOptionsPage.get().saveButton, "saveButton");
						waitForPageLoad(intMaxWaitTime);
						PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, intMaxWaitTime);
						waitForPageLoad(intMaxWaitTime);
						if(RESULT_STATUS)
						{
							DownloadXML(strProxyID, strTestRegion, strDownloadPath);
						}
						else
						{
							log(FAIL, "Validate Plan Design in XML", "Plan not moved to pending audit", true);
						}
						iROW= 1;
					}
					else{
						
							String strBenefitHierarchy=getCellValue("BenefitHierarchy");
							String strSituationGroup = getCellValue("SituationGroup"); 
							String strSituationType = getCellValue("SituationType");
							String strCalculationChoiceType = getCellValue("CalculationChoiceType"); 
							String strAdminMethodType = getCellValue("AdminMethodType");	
							String expXMLAdminMethodValue = getCellValue("XMLCopayValue");
							
							HashMap<String, String> adminMethodData = PlanXMLParser.getAdminMethodData(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", strBenefitHierarchy, strSituationGroup, strSituationType,strCalculationChoiceType, strAdminMethodType);
							String adminMethodType = adminMethodData.get("Admin Method Type text").toString().trim();
							String actXMLAdminMethodValue = adminMethodData.get("Admin Method Data value").toString().trim();
							PlanOptionsPage.get().writeLogForAdminXMLCopayValidations(adminMethodType, expXMLAdminMethodValue, actXMLAdminMethodValue, strCopayCriteria);

					}
				}
			} catch (Exception e) {
				RESULT_STATUS = false;
				e.printStackTrace();
				log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
			}
			finally {
				endTestScript();
				if(getWebDriver()!=null){
					seCloseBrowser();
				}
				setResult("STATUS", RESULT_STATUS);
			}
		} 
		}catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
	} finally {
		if(getWebDriver()!=null){
			seCloseBrowser();
		}
	}
}	
}
