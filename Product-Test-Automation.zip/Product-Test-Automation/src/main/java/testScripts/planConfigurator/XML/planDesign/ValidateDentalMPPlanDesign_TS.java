package testScripts.planConfigurator.XML.planDesign;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanSetupPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;

/**
 * Manual test case: Verify that the correct plan design is displayed in the XML based on the planOption selection for Dental Master product plan
 * <p>
 * Test script template
 * <p>
 * Please refer this test script while creating other test scripts
 * 
 * @author AF12450
 * @since 09/18/2017
 *
 */
public class ValidateDentalMPPlanDesign_TS extends CoreSuperHelper{

	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int maxWaitTime = 450;
	static String strDownloadPath = "";
	public static void main(String[] args) {

		try {
			MANUAL_TC_EXECUTION_EFFORT = "00:20:00";
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {

					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					String strTCID=getCellValue("Test_Case_ID");
					String strPlanVersionID = "";
					String strProxyID = "";
					if(strRunFlag.equalsIgnoreCase("YES"))
					{
						logExtentReport(strTCName);
						strDownloadPath = getReportPathFolder();
						String strDentalNetwork = getCellValue("DentalNetwork");
						String strDentalPlanType = getCellValue("DentalPlanType");
						String strPediatricDentalType=getCellValue("PediatricDentalType");
						String strAdultDentalType=getCellValue("AdultDentalType");
						String strDentalOON=getCellValue("DentalOON");
						String strPlanDesignText = getCellValue("PlanDesignText");
						String strPlanDesignValue = getCellValue("PlanDesignValue");
						String strExpectedChoiceText="";
						String strExpectedChoiceValue="";
						String strExpectedDentalPlanType="";
						String strExpectedPediatricDental="";
						String strExpectedAdultDental="";
						String strExpectedDentalOON="";	
						boolean strResult=false;

						if(getWebDriver()==null)
						{
							seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad(2,360);
						}
						waitForPageLoad(2,360);
						CreatePlanPage.get().createPlan(true,maxWaitTime);
						strPlanVersionID = getCellValue("PlanVersionID");
						strProxyID = getCellValue("PlanProxyID");
						waitForPageLoad(5, maxWaitTime);						
						strExpectedDentalPlanType=PlanSetupPage.get().setDentalPlanType(strDentalPlanType);

						strExpectedPediatricDental=PlanSetupPage.get().setPediatricDental(strPediatricDentalType);

						strExpectedAdultDental=PlanSetupPage.get().setAdultDental(strAdultDentalType);

						strExpectedDentalOON=PlanSetupPage.get().setDentalOON(strDentalOON);
						strExpectedChoiceText=PlanSetupPage.get().setDentalNetwork(strDentalNetwork);
						strExpectedChoiceValue=strExpectedChoiceText.replace(" ", "");					
						waitForPageLoad(5, maxWaitTime);
						seClick(PlanHeaderPage.get().save, "Save Plan");
						waitForPageLoad(5, maxWaitTime);
						PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, maxWaitTime);
						if(RESULT_STATUS)
						{
							DownloadXML(strProxyID, strTestRegion, strDownloadPath);
						}
						else
						{
							RESULT_STATUS = false;
							log(FAIL, "Validate Plan Design in XML", "Plan not moved to pending audit", true);
						}
                        strResult=PlanXMLParser.validatePlanDesign(strDownloadPath+strTestRegion+"_"+strProxyID+".xml",strPlanDesignValue,strPlanDesignText);
						
                        strResult=PlanXMLParser.validatePlanOptionType(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", "Plan Type", strExpectedDentalPlanType);
							
                        strResult=PlanXMLParser.validatePlanOptionType(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", "Pediatric Dental", strExpectedPediatricDental);
						
                        strResult=PlanXMLParser.validatePlanOptionType(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", "Adult Dental", strExpectedAdultDental);
						
                        strResult=PlanXMLParser.validatePlanOptionType(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", "Out of Network Setup", strExpectedDentalOON);
						
                        strResult=PlanXMLParser.validateAccumulatorType(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", "Dental Network", "Dental Network", strExpectedChoiceText, strExpectedChoiceValue, "Choice");
						RESULT_STATUS = strResult;
                        log(strResult?PASS:FAIL,strTCID,strTCName);
						
					}

				} catch (Exception e) {
					RESULT_STATUS = false;
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					setResult("STATUS", RESULT_STATUS);
					if (getWebDriver() != null) {
						seCloseBrowser();
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			if (getWebDriver() != null) {
				seCloseBrowser();
			}
			endTestScript();
		}
	}
}
