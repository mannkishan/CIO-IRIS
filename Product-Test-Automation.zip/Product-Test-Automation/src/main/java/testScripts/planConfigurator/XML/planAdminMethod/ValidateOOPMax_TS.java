package testScripts.planConfigurator.XML.planAdminMethod;

import java.util.HashMap;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;
import utility.PCUtils;
import utility.PlanXMLParser;

public class ValidateOOPMax_TS extends CoreSuperHelper{

	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime = 1000;
	static String strDownloadPath = "";
	static String strProxyID = "";
	public static void main(String[] args) {

		try {
			MANUAL_TC_EXECUTION_EFFORT="00:15:00";
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					String strTCID=getCellValue("Test_Case_ID");
					if(strRunFlag.equalsIgnoreCase("YES"))
					{
						logExtentReport(strTCName);
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
						LoginPage.get().loginApplication(struserProfile);
						waitForPageLoad();

						CreatePlanPage.get().createPlan(true,intMaxWaitTime);
						String strPlanVersionID = getCellValue("PlanVersionID");
						strProxyID = getCellValue("PlanProxyID");
						strDownloadPath=getReportPathFolder();

						String strOptionsTab=getCellValue("OptionsTab");
						String strAccumulatorType=getCellValue("AccumulatorType");
						String strAccumBasisValue=getCellValue("AccumBasisValue");
						String strCrossAccumRuleValue=getCellValue("CrossAccumRuleValue");
						String strAccum=getCellValue("AccumName");
						String strDedType=getCellValue("DeductibleType");
						String strCopayAppliesToOOP=getCellValue("CopayAppliesToOOP");
						String strDedAppliesToOOP=getCellValue("DedAppliesToOOP");	
						String strCopayValue=getCellValue("CopayValue");
						String strCoinsuranceAppliesToOOP=getCellValue("CoinsuranceAppliesToOOP");
						String strCoinsuranceINNValue=getCellValue("CoinsuranceINNValue");
						String strCoinsuranceOONValue=getCellValue("CoinsuranceOONValue");
						String strDedINNValue=getCellValue("DeductibleINNValue");
						String strDedOONValue=getCellValue("DeductibleOONValue");
						String strINNValue=getCellValue("InNetworkTier1");
						String strOONValue=getCellValue("OutNetworkTier1");
						String strPlanType=getCellValue("ProductFamily");
						PlanLevelBenefitsPage.get().updatePlanTierSetUp(intMaxWaitTime, strINNValue, strOONValue);
						PlanLevelBenefitsPage.get().updateOOPMaxDetails(intMaxWaitTime, strAccumBasisValue,strCrossAccumRuleValue,strPlanType);
						PlanLevelBenefitsPage.get().updateDeductibleMax(intMaxWaitTime, strDedAppliesToOOP, strDedType,strDedINNValue,strDedOONValue,strPlanType,false);
						PlanLevelBenefitsPage.get().updateCoinsuranceMax(intMaxWaitTime, strCoinsuranceAppliesToOOP, strCoinsuranceINNValue,strCoinsuranceOONValue,strPlanType);
						PCUtils.get().updateCopayOOPMax(strOptionsTab, strAccumulatorType, intMaxWaitTime, strAccum, strCopayAppliesToOOP,strCopayValue);								
						waitForPageLoad(2,intMaxWaitTime);
						seClick(PlanOptionsPage.get().saveButton, "saveButton");
						waitForPageLoad(2,intMaxWaitTime);
						PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, intMaxWaitTime);
						waitForPageLoad(intMaxWaitTime);
						if(RESULT_STATUS)
						{
							DownloadXML(strProxyID, strTestRegion, strDownloadPath);
						}
						else
						{
							log(FAIL, "Validate Plan Design in XML", "Plan not moved to pending audit", true);
						}
						String applyToXrefAccum=PlanXMLParser.getOOPValue(strDownloadPath+strTestRegion+"_"+strProxyID+".xml",strAccumulatorType,strAccum);
						if(strCopayAppliesToOOP.equalsIgnoreCase("Yes"))
						{								
							if(applyToXrefAccum.equalsIgnoreCase("true"))
							{
								log(PASS,"Validate if applyToXrefAccum text is displayed as expected value in xml","Verifying if applyToXrefAccum value is "+applyToXrefAccum);
							}
							else
							{
								log(FAIL,"Validate if applyToXrefAccum text is displayed as expected value  in xml","Verifying if applyToXrefAccum value is "+applyToXrefAccum);
							}
						}
						else
						{
							if(applyToXrefAccum.equalsIgnoreCase("false"))
							{
								log(PASS,"Validate if applyToXrefAccum text is displayed as expected value in xml","Verifying if applyToXrefAccum value is "+applyToXrefAccum);
							}
							else
							{
								log(FAIL,"Validate if applyToXrefAccum text is displayed as expected value in xml","Verifying if applyToXrefAccum value is "+applyToXrefAccum);
							}
						}

						String strBenefitHierarchy=getCellValue("BenefitHierarchy");
						String strSituationGroupText=getCellValue("SituationGroup");
						String strSituationType=getCellValue("SituationType");
						String strCalChoiceType=getCellValue("CalculationChoiceType");
						String strAdminMethodType=getCellValue("AdminMethodType");
						String strAdminMethodValue=getCellValue("AdminMethodValue");
						HashMap<String,String> copayMax=PlanXMLParser.getAdminMethodData(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", strBenefitHierarchy, strSituationGroupText, strSituationType, strCalChoiceType, strAdminMethodType);
						String adminMethodType_actualtext=copayMax.get("Admin Method Type text");
						String adminMethodData_actualvalue=copayMax.get("Admin Method Data value"); 
						if(adminMethodType_actualtext.equalsIgnoreCase(strAdminMethodType) && adminMethodData_actualvalue.equalsIgnoreCase(strAdminMethodValue))
						{
							RESULT_STATUS=true;
							log(PASS,"Validate  "+strDedType+" OOP Max admin method type text in XML","Actual Text "+adminMethodType_actualtext+ "is equal to expected text" +strAdminMethodType);
							log(PASS, "Validate  "+strDedType+" OOP Max Value in XML", "Actual value "+adminMethodData_actualvalue+" is equal to Expected value "+strAdminMethodValue);
						}
						else
						{
							RESULT_STATUS=false;
							log(FAIL,"Validate "+strDedType+" OOP Max admin method type text in XML","Actual Text "+adminMethodType_actualtext+ "is equal to expected text" +strAdminMethodType);
							log(FAIL, "Validate "+strDedType+" OOP Max Value in XML", "Actual value "+adminMethodData_actualvalue+" is equal to Expected value "+strAdminMethodValue);
						}
						log(RESULT_STATUS?PASS:FAIL,strTCID,strTCName);
						seCloseBrowser();
					}
				} catch (Exception e) {
					RESULT_STATUS = false;
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
				finally {
					endTestScript();
					if(getWebDriver()!=null){
						seCloseBrowser();
					}
					setResult("STATUS", RESULT_STATUS);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			if(getWebDriver()!=null){
				seCloseBrowser();
		}
		}
	}		
}
