package testScripts.planConfigurator.XML.planAdminMethod;

import java.util.HashMap;


import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;

public class ValidateIndividualDeductible_TS extends CoreSuperHelper
{	
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime = 1000;
	static String strDownloadPath = "";
	static String strProxyID = "";
	public static void main(String[] args) {

		try {
			MANUAL_TC_EXECUTION_EFFORT="00:15:00";
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {					
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					String strTCID=getCellValue("Test_Case_ID");
					if(strRunFlag.equalsIgnoreCase("YES"))
					{
						logExtentReport(strTCName);
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
						LoginPage.get().loginApplication(struserProfile);
						waitForPageLoad(5,intMaxWaitTime);
						CreatePlanPage.get().createPlan(true,intMaxWaitTime);
						String strPlanVersionID = getCellValue("PlanVersionID");
						strProxyID = getCellValue("PlanProxyID");
						strDownloadPath=getReportPathFolder();													
						String strOptionsTab=getCellValue("OptionsTab");
						String strAccumulatorType=getCellValue("AccumulatorType");
						String strDedType=getCellValue("DeductibleType");
						String strAccum=getCellValue("AccumName");
						String strDedApplies=getCellValue("DedApplies");										
						String strDedINNValue=getCellValue("DeductibleINNValue");
						String strDedOONValue=getCellValue("DeductibleOONValue");
						String strINNValue=getCellValue("InNetworkTier1");
						String strOONValue=getCellValue("OutNetworkTier1");
						String strPlanType=getCellValue("ProductFamily");
						String strDedValue = "";
						PlanLevelBenefitsPage.get().updatePlanTierSetUp(intMaxWaitTime, strINNValue, strOONValue);
						PlanLevelBenefitsPage.get().updateDeductibleMax(intMaxWaitTime, strDedApplies, strDedType, strDedINNValue, strDedOONValue, strPlanType, true);						
						PlanOptionsPage.get().clickAtObject(PlanOptionsPage.get().optionsTab(strOptionsTab));
						waitForPageLoad(5, intMaxWaitTime);
						boolean booPaidAtPlanLevel = (PlanOptionsPage.get().checkboxPaidAsPlanLevel(strAccumulatorType, strAccum)).isSelected();
						if(!booPaidAtPlanLevel)
						{
							strDedValue = seGetDropDownValue(PlanOptionsPage.get().applyDeductibleList(strAccum));
						}
						if((strDedValue.equalsIgnoreCase("Yes"))||(booPaidAtPlanLevel))
						{
							log(PASS, "Validate Deductible applied to Plan", "Deductible is applied to required plan "+strOptionsTab, true);
						}
						else{
							log(FAIL, "Validate Deductible applied to Plan", "Deductible is not applied to required plan "+strOptionsTab, true);
						}

						waitForPageLoad(2,intMaxWaitTime);
						seClick(PlanOptionsPage.get().saveButton, "saveButton");
						waitForPageLoad(2,intMaxWaitTime);
						PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, intMaxWaitTime);
						waitForPageLoad(intMaxWaitTime);
						if(RESULT_STATUS)
						{
							DownloadXML(strProxyID, strTestRegion, strDownloadPath);
						}
						else
						{
							log(FAIL, "Validate Plan Design in XML", "Plan not moved to pending audit", true);
						}

						String strBenefitHierarchy=getCellValue("BenefitHierarchy");
						String strSituationGroupText=getCellValue("SituationGroup");
						String strSituationType=getCellValue("SituationType");
						String strCalChoiceType=getCellValue("CalculationChoiceType");
						String strAdminMethodType=getCellValue("AdminMethodType");
						String strExpAdminMethodValue=getCellValue("AdminMethodValue");
						HashMap<String, String> adminMethodData = PlanXMLParser.getAdminMethodData(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", strBenefitHierarchy, strSituationGroupText,strSituationType,strCalChoiceType, strAdminMethodType);
						String adminMethodType = adminMethodData.get("Admin Method Type text").toString().trim();
						String actAdminMethodValue = adminMethodData.get("Admin Method Data value").toString().trim();
						if(adminMethodType.equalsIgnoreCase(strAdminMethodType) && actAdminMethodValue.equalsIgnoreCase(strExpAdminMethodValue))
						{
							RESULT_STATUS=true;
							log(PASS,"Validate Individual deductible admin method type text in XML","Actual Text "+adminMethodType+ "is equal to expected text" +strAdminMethodType);
							log(PASS, "Validate Individual deductible Value in XML", "Actual value "+actAdminMethodValue+" is equal to Expected value "+strExpAdminMethodValue);
						}
						else
						{
							RESULT_STATUS=false;
							log(FAIL,"Validate Individual deductible admin method type text in XML","Actual Text "+adminMethodType+ "is equal to expected text" +strAdminMethodType);
							log(FAIL, "Validate Individual deductible Value in XML", "Actual value "+actAdminMethodValue+" is equal to Expected value "+strExpAdminMethodValue);
						}
						log(RESULT_STATUS?PASS:FAIL,strTCID,strTCName);
						seCloseBrowser();
					}
				} catch (Exception e) {
					RESULT_STATUS = false;
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
				finally {
					endTestScript();
					if(getWebDriver()!=null){
						seCloseBrowser();
					}
					setResult("STATUS", RESULT_STATUS);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {	
			if(getWebDriver()!=null){
				seCloseBrowser();
			}
		}
	}

}

