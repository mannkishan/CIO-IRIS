package testScripts.planConfigurator.XML.planOptions;

import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.MasterProductAndLegacyPlanOptionsXMLPage;
import utility.CoreSuperHelper;
/**
 * Manual test case: Verify that the Accumulator values are available in XML file or not for Legacy Plan 
 * @author AF16391
 * @since 09/20/2017
 *
 */
public class ValidateLegacyPlanOptionsXML_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strTestEnvironment = EnvHelper.getValue("test.environment");

	public static void main(String[] args) {
		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				String strXMLFileName = "";
				String strFileFeed = "";
				String strLegacyPlanID = getCellValue("LegacyPlanID");
				logExtentReport("Legacy Plan Options XML Validation");
				if (!strLegacyPlanID.equalsIgnoreCase("")) {
					if (MasterProductAndLegacyPlanOptionsXMLPage.get().seFileDownloadXML(strLegacyPlanID,
							strTestEnvironment, getReportPathFolder())) {
						strXMLFileName = getReportPathFolder() + strTestEnvironment + "_" + getCellValue("LegacyPlanID")
								+ ".xml";
						strFileFeed = getCellValue("LegacyExcelPath");
						MasterProductAndLegacyPlanOptionsXMLPage.get().seReadTabContents(strFileFeed, strXMLFileName);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
