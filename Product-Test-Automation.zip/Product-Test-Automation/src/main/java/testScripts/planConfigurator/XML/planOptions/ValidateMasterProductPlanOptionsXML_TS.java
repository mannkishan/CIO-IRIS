package testScripts.planConfigurator.XML.planOptions;

import java.io.File;

import org.apache.poi.util.SystemOutLogger;

import com.anthem.selenium.utility.EnvHelper;
import com.wellpoint.cssd.spider.DownloadFinalizeXML;

import page.planConfigurator.MasterProductAndLegacyPlanOptionsXMLPage;
import utility.CoreSuperHelper;
/**
 * Manual test case: Verify that the Accumulator values are available in XML file or not  for Master Product Plan
 * @author AF16391
 * @since 09/21/2017
 *
 */
public class ValidateMasterProductPlanOptionsXML_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strTestEnvironment = EnvHelper.getValue("test.environment");

	public static void main(String[] args) {
		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				String strXMLFileName = "";
				String strFileFeed = "";
				String strMasterProductPlanID = getCellValue("MasterProductPlanID");
				logExtentReport("Master Product Plan Options XML Validation");
				if (!strMasterProductPlanID.equalsIgnoreCase("")) {
					if (MasterProductAndLegacyPlanOptionsXMLPage.get().seFileDownloadXML(strMasterProductPlanID,
							strTestEnvironment, getReportPathFolder())) {
						strXMLFileName = getReportPathFolder() + strTestEnvironment + "_"
								+ getCellValue("MasterProductPlanID") + ".xml";
						strFileFeed = getCellValue("MP_File_path");
						MasterProductAndLegacyPlanOptionsXMLPage.get().seReadTabContents(strFileFeed, strXMLFileName);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
