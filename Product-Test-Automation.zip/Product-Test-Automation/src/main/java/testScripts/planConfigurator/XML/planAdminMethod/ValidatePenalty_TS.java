package testScripts.planConfigurator.XML.planAdminMethod;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import org.openqa.selenium.JavascriptExecutor;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import page.planConfigurator.TemplatePlanSetUpPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;


/**
 * Manual test case: Verify that correct value is represented for Penalty Admin method in the Plan XML 
 * <p>
 * Test script template
 * <p>
 * 
 * 
 * @author AF16535
 * 
 *
 */

public class ValidatePenalty_TS extends CoreSuperHelper {
	
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime = 360;
	static String strDownloadPath = "";
	public static void main(String[] args) {
		
		try {
			MANUAL_TC_EXECUTION_EFFORT="00:15:00";
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					String strPlanVersionID = "";
					String strProxyID = "";
					if(strRunFlag.equalsIgnoreCase("YES"))
					{
						logExtentReport(strTCName);
						strDownloadPath = getReportPathFolder();
						String strIsPenaltyEnabled = getCellValue("IsPenaltyEnabled");
						String strAdminMethodValue = getCellValue("AdminMethodValue");
						String strAdminMethodID = getCellValue("AdminMethodID");
						String strExaminerActionText = getCellValue("ExaminerActionText");
						String strExceptionValue = getCellValue("ExceptionValue");
						strPlanVersionID = getCellValue("PlanVersionID");
						strProxyID = getCellValue("PlanProxyID");
						String strInNetworkInstPercnt=getCellValue("InNetworkInstPercnt");
						String strInNetworkInstDollar=getCellValue("InNetworkInstDollar");
						String strOutNetworkInstPercnt=getCellValue("OutNetworkInstPercnt");
						String strOutNetworkInstDollar=getCellValue("OutNetworkInstDollar");
						String strInNetworkProfPercnt=getCellValue("InNetworkProfPercnt");
						String strInNetworkProfDollar=getCellValue("InNetworkProfDollar");
						String strOutNetworkProfPercnt=getCellValue("OutNetworkProfPercnt");
						String strOutNetworkProfDollar=getCellValue("OutNetworkProfDollar");
						String strUMPenaltyRule = getCellValue("UMPenaltyRule");
						if(getWebDriver()==null)
						{
							seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad(intMaxWaitTime);
						}
						waitForPageLoad(2,360);
						CreatePlanPage.get().createPlan(true,intMaxWaitTime);
						strPlanVersionID = getCellValue("PlanVersionID");
						strProxyID = getCellValue("PlanProxyID");
						waitForPageLoad(5, intMaxWaitTime);
						 PlanOptionsPage.clickTab("Plan Setup", "Plan Administration", intMaxWaitTime);
						 waitForPageLoad(2,intMaxWaitTime);
						 if(strIsPenaltyEnabled.equalsIgnoreCase("Yes"))
						 {
						 seSelectText(TemplatePlanSetUpPage.get().UMRulePenaltyPlanDesign, strUMPenaltyRule, "Select "+strUMPenaltyRule+" for UM Rule Penalty Design");
						 }
						 waitForPageLoad(4,intMaxWaitTime);
						 PlanOptionsPage.clickTab("Plan Level Benefits", "Penalties", intMaxWaitTime);
						 waitForPageLoad(2,intMaxWaitTime);
						 PlanLevelBenefitsPage.get().enablePenalty(strIsPenaltyEnabled);
						 waitForPageLoad(2, intMaxWaitTime);
						 if(strIsPenaltyEnabled.equalsIgnoreCase("Yes"))
						 {
							 sePCSelectText(PlanLevelBenefitsPage.get().InNetworkInstPercnt, "In Network Institutional Pre Authorization", strInNetworkInstPercnt, intMaxWaitTime);
								waitForPageLoad(intMaxWaitTime);
							sePCSelectText(PlanLevelBenefitsPage.get().InNetworkInstDollar, "In Network Institutional Pre Authorization Indv Max", strInNetworkInstDollar, intMaxWaitTime);
								waitForPageLoad(intMaxWaitTime);
							sePCSelectText(PlanLevelBenefitsPage.get().OutOfNetworkInstPercent, "Out of Network Institutional Pre Authorization Penalty Percent", strOutNetworkInstPercnt, intMaxWaitTime);
								waitForPageLoad(intMaxWaitTime);
							sePCSelectText(PlanLevelBenefitsPage.get().OutOfNetworkInstDollar, "Out of Network Institutional Pre Authorization Penalty Dollar", strOutNetworkInstDollar, intMaxWaitTime);
								waitForPageLoad(intMaxWaitTime);
							sePCSelectText(PlanLevelBenefitsPage.get().InNetworkProfPercnt, "In Network Professional Pre Authorization Penalty Percent", strInNetworkProfPercnt, intMaxWaitTime);
								waitForPageLoad(intMaxWaitTime);
							sePCSelectText(PlanLevelBenefitsPage.get().InNetworkProfDollar, "In Network Professional Pre Authorization Penalty Dollar", strInNetworkProfDollar, intMaxWaitTime);
								waitForPageLoad(intMaxWaitTime);
							sePCSelectText(PlanLevelBenefitsPage.get().OutOfNetworkProfPercent, "Out of Network Professional Pre Authorization Penalty Percent", strOutNetworkProfPercnt, intMaxWaitTime);
								waitForPageLoad(intMaxWaitTime);
							sePCSelectText(PlanLevelBenefitsPage.get().OutOfNetworkProfDollar, "Out of Network Professional Pre Authorization Penalty Dollar", strOutNetworkProfDollar, intMaxWaitTime);
								waitForPageLoad(intMaxWaitTime);
						 }
						 
						 seClick(PlanHeaderPage.get().save, "Save Plan");
						waitForPageLoad(2, intMaxWaitTime);
						PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, intMaxWaitTime);
						RESULT_STATUS= true;
						if(RESULT_STATUS)
						{
							DownloadXML(strProxyID, strTestRegion, strDownloadPath);
							String xmlPath = strDownloadPath + strTestRegion + "_" + strPlanVersionID + ".xml";
							validatePenaltyAdminMethod(xmlPath, strAdminMethodValue,strExaminerActionText, strExceptionValue);
							PlanXMLParser.validateAdminMethodID("Penalty",strAdminMethodID, xmlPath);
						
						}
						else
						{
							log(FAIL, "Validate Plan Admin method in XML", "Plan not moved to pending audit", true);
						} 
						
							
					}
					}
				
						catch (Exception e) {
							e.printStackTrace();
							log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
						}
				finally {
					if(getWebDriver() != null)
					{
						seCloseBrowser();
					}
				}
			}
		}
				
		catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
		
		
		

}
	
	public static void validatePenaltyAdminMethod(String strXMLPath, String strAdminMethodValue, String strExaminerActionCode,String strExceptionValue) throws Exception
	{
		try
		{
			File file = new File(strXMLPath);
			System.out.println(file.exists());
			SAXReader reader = new SAXReader();
			org.dom4j.Document document = reader.read(file);
			List<Node> nodes = document.selectNodes("//adminMethodList/AdminMethodData/adminMethodType[@text='Penalty']");
			System.out.println(nodes.size());
			if(nodes.size()>0)
			{
			for (Node node : nodes) {
				node = node.getParent();
				String adminMethodTypeText = ((Element) (node.selectSingleNode("value"))).getText();
				
				if(!adminMethodTypeText.equalsIgnoreCase(strAdminMethodValue))
				{
					String strSituationType = "";
					String strBenefit = "";
					String strExaminationActionText = "";
					while(!node.getName().equalsIgnoreCase("benefitTypeCoverage"))
					{
						node = node.getParent();
						System.out.println(node.getName());
						
						if(node.getName().equalsIgnoreCase("calculationSituation"))
						{
							strSituationType = ((Element) (node.selectSingleNode("situationType"))).attributeValue("text");
						}
						else if (node.getName().equalsIgnoreCase("benefitTypeCoverage"))
						{
						strBenefit = ((Element) (node.selectSingleNode("benefitLevel"))).attributeValue("text");
						}
						else if (node.getName().equalsIgnoreCase("calculation"))
						{
							Node dataNode = node.selectSingleNode("data");
							if(dataNode!=null)
							{
								Node examinerAction = dataNode.selectSingleNode("examinerActions");
								if(examinerAction != null)
								{
									if(examinerAction.selectSingleNode("examinerAction")!= null)
									{
									Node examinerActionCode = examinerAction.selectSingleNode("examinerAction").selectSingleNode("examinerActionCode");
									 strExaminationActionText = ((Element) examinerActionCode).attributeValue("text");
									}
								}
							}
						
						}
						
					}
					if(strExaminationActionText.equalsIgnoreCase(strExaminerActionCode))
					{
						if(adminMethodTypeText.equalsIgnoreCase(strExceptionValue))
						{
							RESULT_STATUS = true;
							log(PASS, "Validate admin method value for Penalty","Admin method value is as expected \""+strAdminMethodValue+"\" for \"situation type\" :"
									+ "\""+strSituationType+"\" for \"benefit\" : \""+strBenefit+"\" with an actual  value of \""+adminMethodTypeText+"\""+"with an examiner action text"+strExaminationActionText );
						}
						else
						{
							RESULT_STATUS = false;
							log(FAIL, "Validate admin method ID for Penalty","Admin method value is not as expected \""+strAdminMethodValue+"\" for \"situation type\" :"
									+ "\""+strSituationType+"\" for \"benefit\" : \""+strBenefit+"\" with an actual  value of \""+adminMethodTypeText+"\"" );
						}
					
					}
					else
					{
						RESULT_STATUS = false;
						log(FAIL, "Validate admin method ID for Penalty","Admin method value is not as expected \""+strAdminMethodValue+"\" for \"situation type\" :"
								+ "\""+strSituationType+"\" for \"benefit\" : \""+strBenefit+"\" with an actual  value of \""+adminMethodTypeText+"\"" );
					}
				}


			}
			if(RESULT_STATUS)
			{
				log(PASS, "Validate admin method ID for Penalty","All the benefits have the admin method ID as expected" );
			}
			}
			else {
				log(FAIL, "Validate admin method ID for Penalty","Not able to find the admin method in the XML" );
			}
			

		}
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Exception Occured in validate Penalty Admin Method"+e.getLocalizedMessage());
		}
	}
}

