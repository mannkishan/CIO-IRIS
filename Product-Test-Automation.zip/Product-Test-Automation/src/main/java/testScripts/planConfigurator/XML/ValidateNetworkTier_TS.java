package testScripts.planConfigurator.XML;

import java.io.File;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.ChangeReportPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.EditPlanInfo;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;
import utility.WebTableWithHeader;

public class ValidateNetworkTier_TS extends CoreSuperHelper {

	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	static String strDownloadPath = "";
	static String strTestRegion = EnvHelper.getValue("test.environment");
	public static void main(String[] args) {
		try {
			MANUAL_TC_EXECUTION_EFFORT = "00:05:00";
			String strRunFlag ="";
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					strRunFlag = getCellValue("Run_Flag");
					if(strRunFlag.equalsIgnoreCase("YES")) {
						strDownloadPath = getReportPathFolder();
						String strTestCaseName = getCellValue("TCName");
						String strPlanVersionID = "";
						String strProxyID = "";
						String strTier = "";
						String strState = "";
						String strProdcutFamily = "";
						int intMaxWaitTime=450;
						logExtentReport(strTestCaseName);
						if(getWebDriver()==null){
							seOpenBrowser(BrowserConstants.Chrome, strbaseURL,strDownloadPath);
							LoginPage.get().loginApplication(struserProfile);
						}
						CreatePlanPage.get().createPlan(true,intMaxWaitTime);
						strPlanVersionID = getCellValue("PlanVersionID");
						strProxyID = getCellValue("PlanProxyID");
						PlanOptionsPage.clickTab("Plan Setup", "Plan Tier Setup", intMaxWaitTime);
						sePCSelectText(PlanLevelBenefitsPage.get().inNetTier1Network, "In Network Tier 1", "New Hampshire", intMaxWaitTime);
						sePCSelectText(PlanLevelBenefitsPage.get().inNetTier2Network, "In Network Tier 2", "Pathway PPO", intMaxWaitTime);
						seClick(PlanHeaderPage.get().save, "Save Plan");
						waitForPageLoad(5, intMaxWaitTime);
						PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, intMaxWaitTime);
						if(RESULT_STATUS){
							strState = seGetElementValue(PlanHeaderPage.get().planState);
							waitForPageLoad(5, intMaxWaitTime);
							PlanOptionsPage.clickTab("Plan Setup", "Plan Tier Setup", intMaxWaitTime);
							//strTier = seGetElementValue(PlanSetupPage.get().planTier);
							FindPlanPage.get().findPlan(strPlanVersionID, "Pending Audit");
							WebElement planInfo=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div/table/tbody/tr[1]/td[12]/i"));
							seClick(planInfo,"Plan Info Option");
							waitForPageLoad();			
							Actions actions = new Actions(getWebDriver());
							actions.moveToElement(PlanHeaderPage.get().valueType("Product Family")).build().perform();;
							waitForPageLoad();
							strProdcutFamily=seGetElementValue(PlanHeaderPage.get().valueType("Product Family"));
							seClick(PlanHeaderPage.get().closebutton,"Close button");
							DownloadXML(strProxyID, strTestRegion, strDownloadPath);
							PlanXMLParser.validateState(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", strState);
							PlanXMLParser.validateProductFamily(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", strProdcutFamily);
							PlanXMLParser.validatePlanOptionType(strDownloadPath+strTestRegion+"_"+strProxyID+".xml", "Plan Tier Setup", strTier);

						}
						waitForPageLoad();


					}
				} catch (Exception e) {
					e.printStackTrace();
					RESULT_STATUS = false;
				}
				finally {
					setResult("STATUS", RESULT_STATUS);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null){
				seCloseBrowser();
			}
			endTestScript();
		}
	}
	
}

