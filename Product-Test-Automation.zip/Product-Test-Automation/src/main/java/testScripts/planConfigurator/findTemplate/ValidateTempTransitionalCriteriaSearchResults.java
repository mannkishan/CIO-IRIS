package testScripts.planConfigurator.findTemplate;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import utility.CoreSuperHelper;

public class ValidateTempTransitionalCriteriaSearchResults extends CoreSuperHelper {
	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	public static void main(String[] args) {
		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					if(strRunFlag.equalsIgnoreCase("YES")) {
						String strTestCaseID = getCellValue("Test_Case_ID");
						String strCreateFormDate = getCellValue("Createfrom");
						String strCreateToDate = getCellValue("CreateThrough");
						logExtentReport(getCellValue("TCName"));
						if(getWebDriver()==null){
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
						LoginPage.get().loginApplication(struserProfile);
						}
						waitForPageLoad(300);
						seClick(HomePage.get().find, "Find link");
						waitForPageLoad(300);
						seClick(HomePage.get().findTemplate, "Find Template link");
						waitForPageLoad(300);
						
						if(strTestCaseID.equalsIgnoreCase("Created From")){
							seSetText(FindTemplatePage.get().createFrom, strCreateFormDate, "Create From");
							seClick(FindTemplatePage.get().templateName, "templateName");
							waitForPageLoad();
							seSetText(FindTemplatePage.get().createThrough, strCreateToDate, "Create Through");
							seClick(FindTemplatePage.get().templateName, "templateName");
							waitForPageLoad();
							FindTemplatePage.get().validateTransCriteriaSearchResults(strCreateFormDate, strCreateToDate,strTestCaseID);
						}
						else if(strTestCaseID.equalsIgnoreCase("Modified From")){
							seSetText(FindTemplatePage.get().modifiedFrom, strCreateFormDate, "Modified From");
							seClick(FindTemplatePage.get().templateName, "templateName");
							waitForPageLoad();
							seSetText(FindTemplatePage.get().modifiedThrough, strCreateToDate, "Modified Through");
							seClick(FindTemplatePage.get().templateName, "templateName");
							waitForPageLoad();
							FindTemplatePage.get().validateTransCriteriaSearchResults(strCreateFormDate, strCreateToDate,strTestCaseID);
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					RESULT_STATUS=false;
					}
				finally {
					setResult("STATUS", RESULT_STATUS);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			} finally {
				if(getWebDriver()!=null){
					seCloseBrowser();
					}
				endTestScript();
				}
}

}
