package testScripts.planConfigurator.findTemplate;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;


import utility.CoreSuperHelper;

public class ValidateTempBaseCriteriaSearchResults_TS extends CoreSuperHelper {
	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	public static void main(String[] args) {
		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					if(strRunFlag.equalsIgnoreCase("YES")) {
						String strTestCaseID = getCellValue("Test_Case_ID");
						String strTemplateName = getCellValue("TemplateName");
						String strTemplateDescription = getCellValue("TemplateDescription");
						String strTemplateVersionId = getCellValue("TemplateVersionId");
						String strProxyTemplateID = getCellValue("TemplateID");
						String strEffDate = getCellValue("EffDate");
						String actualSearchValue="";
						logExtentReport(getCellValue("TCName"));
						if(getWebDriver()==null){
							seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
							LoginPage.get().loginApplication(struserProfile);
						}
						waitForPageLoad(2,360);
						seClick(HomePage.get().find, "Find link");
						waitForPageLoad(300);
						seClick(HomePage.get().findTemplate, "Find Template link");
						waitForPageLoad(2,360);

						switch (strTestCaseID) {
						case "Find Template with Base Criteria Template Name":
							actualSearchValue=FindTemplatePage.get().validateBaseCriteriaSearch(strTemplateName, "Template Name");
							RESULT_STATUS = actualSearchValue.equalsIgnoreCase(strTemplateName) ? true: false;
							log(strTemplateName.contains(actualSearchValue) ? PASS:FAIL  , "Verify Template Name","Expected  Template Name: " + strTemplateName + " Actual Template Name: "+ actualSearchValue, true);
							break;
						case "Find Template with Base Criteria Template Description":
							actualSearchValue=FindTemplatePage.get().validateBaseCriteriaSearch(strTemplateDescription,"Template Description");
							RESULT_STATUS = actualSearchValue.equalsIgnoreCase(strTemplateName) ? true: false;
							log(actualSearchValue.contains(strTemplateDescription) ? PASS:FAIL , "Verify Template Description","Expected  TemplateDescription: " + strTemplateDescription + " Actual TemplateDescription: "+ actualSearchValue, true);
							break;
						case "Find Template with Base Criteria Template Version Id":
							actualSearchValue=FindTemplatePage.get().validateBaseCriteriaSearch(strTemplateVersionId, "Template Version Id");
							RESULT_STATUS = actualSearchValue.equalsIgnoreCase(strTemplateName) ? true: false;
							log(actualSearchValue.equalsIgnoreCase(strTemplateVersionId) ? PASS:FAIL , "Verify Template VersionID","Expected  TemplateVersionID: " + strTemplateVersionId + " Actual TemplateVersionID: "+ actualSearchValue, true);
							break;
						case "Find Template with Base Criteria Proxy Template Id":
							actualSearchValue=FindTemplatePage.get().validateBaseCriteriaSearch(strProxyTemplateID, "Proxy Template ID");
							RESULT_STATUS = actualSearchValue.equalsIgnoreCase(strTemplateName) ? true: false;
							log(actualSearchValue.equalsIgnoreCase(strProxyTemplateID) ? PASS:FAIL , "Verify Template Proxy ID","Expected  Template ProxyID: " + strProxyTemplateID + " Actual TemplateProxyID: "+ actualSearchValue, true);
							break;
						case "Find Template with Base Criteria Effective Date":
							actualSearchValue=FindTemplatePage.get().validateBaseCriteriaSearch(strEffDate, "Effective Date");
							RESULT_STATUS = actualSearchValue.equalsIgnoreCase(strTemplateName) ? true: false;
							log(actualSearchValue.equalsIgnoreCase(strEffDate) ? PASS:FAIL , "Verify Effective From Date","Expected  Effective From: " + strEffDate + " Actual effectiveFrom: "+ actualSearchValue, true);
							break;

						default:
							break;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					RESULT_STATUS = false;
				}
				finally {
					setResult("STATUS", RESULT_STATUS);

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null){
				seCloseBrowser();
			}
			endTestScript();
		}
	}
}
