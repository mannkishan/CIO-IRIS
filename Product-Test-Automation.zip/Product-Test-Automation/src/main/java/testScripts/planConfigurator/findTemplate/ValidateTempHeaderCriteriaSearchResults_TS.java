package testScripts.planConfigurator.findTemplate;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.LoginPage;
import utility.CoreSuperHelper;

public class ValidateTempHeaderCriteriaSearchResults_TS extends CoreSuperHelper {
	


	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strHeaderCriteria="";	
	static String strValueType="";
	static String strHeaderName="";

	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strTestCaseID = getCellValue("Test_Case_ID");
					String strTestCaseDescription=getCellValue("TCName");
					String strRunFlag = getCellValue("Run_Flag");
					if(strRunFlag.equalsIgnoreCase("YES")) {
						logExtentReport(getCellValue("TCName"));
						strHeaderCriteria=getCellValue("HeaderCriteria");
						strValueType=getCellValue("ValueType");
						strHeaderName=getCellValue("HeaderName");
						boolean strResult=false;
						if(getWebDriver()==null)
						{
							seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
							waitForPageLoad();
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad(300);					
						}
						if(!strTestCaseID.equals(null))
						{
							strResult=FindTemplatePage.get().verifySearchUsingHeaderCriteria(strHeaderCriteria,strValueType);
							RESULT_STATUS = strResult;
							log(strResult?PASS:FAIL,strTestCaseID,strTestCaseDescription);							
						}
						else
						{
							log(FAIL,"Data need to be verified","Data need to be verified");
						}
						setResult("STATUS", RESULT_STATUS);
					}
				} catch (Exception e) {
					e.printStackTrace();
					RESULT_STATUS = false;
				}
				finally {
					setResult("STATUS", RESULT_STATUS);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null)
			{
				seCloseBrowser();
			}
			endTestScript();

		}
	}




}
