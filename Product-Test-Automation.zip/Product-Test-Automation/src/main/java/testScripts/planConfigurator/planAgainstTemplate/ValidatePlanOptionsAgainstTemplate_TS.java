package testScripts.planConfigurator.planAgainstTemplate;


import org.openqa.selenium.By;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanAgainstTemplatePage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;

public class ValidatePlanOptionsAgainstTemplate_TS extends CoreSuperHelper
{
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	
	public static void main(String[] args) {
		try {MANUAL_TC_EXECUTION_EFFORT="00:45:00";
			initiateTestScript();

					for (iROW = 1; iROW <= getRowCount(); iROW++) {

						try {
							
							logExtentReport("Test Script/ Functionality Descrtiption");

							seOpenBrowser(BrowserConstants.Chrome, strBaseURL);					
							LoginPage.get().loginApplication(strUserProfile);
							waitForPageLoad(60);													
                            String strOptionTab="Benefit Options";
                            String strBenefit="Antidiabetics";
						    CreatePlanPage.get().createPlan(true, 85);
						    seWaitForClickableWebElement(PlanOptionsPage.get().saveButton, 12);
							seClick(PlanOptionsPage.get().saveButton, "save button");
							waitForPageLoad();
							String strTemplateId=driver.findElement(By.xpath("//span[@class and text()='Template Version ID: ']/../span[2]")).getText();
							seWaitForClickableWebElement(FindPlanPage.get().clickPlanLevelBenefit, 22);	
							PlanAgainstTemplatePage.get().seValidatePlanAndTemplate(strBenefit,strOptionTab,strTemplateId,getCellValue("PlanVersionID"));
							
						} catch (Exception e) {
							e.printStackTrace();
							log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
						} finally {
							seClick(HomePage.get().find, "Find");
							seClick(HomePage.get().findPlan, "Find Plan");
							waitForPageLoad(45);
							seSetText(page.planConfigurator.FindPlanPage.get().planVersionID, getCellValue("PlanVersionID"), "text in plan version id textbox");
		                    seWaitForClickableWebElement(page.planConfigurator.FindPlanPage.get().planSearch, 12);		                    
							seClick(page.planConfigurator.FindPlanPage.get().planSearch, "Search plan");
							waitForPageLoad(45);
							seWaitForClickableWebElement(page.planConfigurator.FindPlanPage.get().selectSearchedPlan, 12);
							seClick(page.planConfigurator.FindPlanPage.get().selectSearchedPlan, " search result");
							waitForPageLoad(45);
							waitForPageLoad();
							seWaitForClickableWebElement(PlanAgainstTemplatePage.get().Delete, 12);
							seClick(PlanAgainstTemplatePage.get().Delete, "Delete Plan");
							seWaitForClickableWebElement(PlanAgainstTemplatePage.get().DeleteConfirmation, 12);
							seClick(PlanAgainstTemplatePage.get().DeleteConfirmation,"Confirm delete");
							waitForPageLoad();
							log(PASS, "Plan deleted successfully", getCellValue("PlanVersionID"));
							//seCloseBrowser();
						}
					}
					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
				} finally {
					endTestScript();
				}

			}	
							
							
						}

