package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import utility.CoreSuperHelper;

public class ValidateFindTemplateSavedSearchCriteria_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
    static String userProfile = EnvHelper.getValue("user.profile");
    public static void main(String[] args) {
                  try {
                        initiateTestScript();

                        for (iROW = 1; iROW <= getRowCount(); iROW++) {
                               try {
                                      logExtentReport("save the search criteria and check the saved search criteria For Template");
                                    
              						String strPlanVersionId = getCellValue("PlanVersionId");
              						String strProxyPlanID = getCellValue("ProxyPlanID");
              						String strEffFromDate = getCellValue("EffectiveFrom");
              						String strEffToDate = getCellValue("EffectiveThrough");
              						String strModifyFromDate = getCellValue("ModifyFrom");
              						String strModifyToDate = getCellValue("ModifyThrough");
              						String strPlanName = getCellValue("PlanName");
              						String strPlanDecription = getCellValue("PlanDecription");
              						String strHeaderType = getCellValue("HeaderType");
              						String strHeaderValue = getCellValue("HeaderValue");
              						String strHeaderCriteriaType = getCellValue("HeaderCriteriaType");
              						String strHeaderCriteriaValue = getCellValue("HeaderCriteriaValue");
              						String strName = getCellValue("Name");
              						seOpenBrowser(BrowserConstants.Chrome, baseURL);
                                      LoginPage.get().loginApplication(userProfile);
                                      waitForPageLoad();
                                      seClick(HomePage.get().find, "Find");
                                      seClick(BenefitRetainsInProductionPage.get().template, "Find Template");
                                      waitForPageLoad();
                                      waitForPageLoad();
                       seClick(FindPlanPage.get().planVersionID,"Plan Version Id");
						seSetText(FindPlanPage.get().planVersionID, strPlanVersionId, "Plan Version Id");
						seClick(FindPlanPage.get().planProxyId,"Proxy Plan ID");
						seSetText(FindPlanPage.get().planProxyId, strProxyPlanID, "Proxy Plan ID");
						
						seClick(FindPlanPage.get().effectiveFrom,"Effective From Date");
						seSetText(FindPlanPage.get().effectiveFrom, strEffFromDate, "Effective Date");
						seInputKeys(FindPlanPage.get().effectiveFrom, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						seClick(BenefitRetainsInProductionPage.get().modifiedFrom,"Modified From Date");
						seSetText(BenefitRetainsInProductionPage.get().modifiedFrom, strModifyFromDate, "Modified From Date");
						seInputKeys(BenefitRetainsInProductionPage.get().modifiedFrom, KeyConstants.ENTER, " ");
						
              			seClick(FindPlanPage.get().planName,"Plan Name");
						seSetText(FindPlanPage.get().planName, strPlanName, "Plan Name");
						seClick(BenefitRetainsInProductionPage.get().planDescription,"Plan Description");
						seSetText(BenefitRetainsInProductionPage.get().planDescription, strPlanDecription, "Plan Description");
						//Header Criteria
						seClick(FindPlanPage.get().headerCriteria,"Header criteria");
						seWaitForPageLoad();
						seClick(FindPlanPage.get().headerCriteriaType,"Header criteria type");
						seWaitForPageLoad();
						seSetText(BenefitRetainsInProductionPage.get().headerValueEnter, strHeaderType, "Header Type");
						seInputKeys(BenefitRetainsInProductionPage.get().headerValueEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						FindPlanPage.get().valueType(strHeaderValue);
						waitForPageLoad(360);
						seClick(BenefitRetainsInProductionPage.get().saveSearchCriteria,"save search criteria ");
                        seWaitForPageLoad();
                        seClick(BenefitRetainsInProductionPage.get().saveSearchName,"save search criteria ");
                        seSetText(BenefitRetainsInProductionPage.get().saveSearchName,strName,"saved search Name");
                        seWaitForPageLoad();
                        seClick(BenefitRetainsInProductionPage.get().saveSearchYes, "Yes");
                        seWaitForPageLoad();
                        seCloseBrowser();
    					seOpenBrowser(BrowserConstants.Chrome, baseURL);
                        LoginPage.get().loginApplication(userProfile);
    					waitForPageLoad();
    					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",HomePage.get().find);
    					seClick(BenefitRetainsInProductionPage.get().template, "Find Template");
                        seWaitForPageLoad();
                        seWaitForPageLoad();
                        WebElement objClick = getWebDriver().findElement(By.xpath("//*[@id=\"findPlanSearch\"]/div[1]/span[1]/span[1]/span/span[2]"));
                       waitForPageLoad();
                       waitForPageLoad();
                        seWaitForPageLoad();
                         objClick.click();
                         waitForPageLoad();
                        seSetText(BenefitRetainsInProductionPage.get().savedSearchEnter,strName,"saved search Name");
                        seInputKeys(BenefitRetainsInProductionPage.get().savedSearchEnter, KeyConstants.ENTER, " ");
                       waitForPageLoad();
                       waitForPageLoad();
                       String strPlanVersionIdText = seGetElementTextBoxValue(FindPlanPage.get().planVersionID);
                       String strProxyPlanIDText = seGetElementTextBoxValue(FindPlanPage.get().planProxyId);
                       String strEffFromDateText = seGetElementTextBoxValue(FindPlanPage.get().effectiveFrom);
                       String strEffToDateText = seGetElementTextBoxValue(BenefitRetainsInProductionPage.get().effectiveThrough);
                       String strModifyFromDateText = seGetElementTextBoxValue(BenefitRetainsInProductionPage.get().modifiedFrom);
                       String strModifyToDateText = seGetElementTextBoxValue(BenefitRetainsInProductionPage.get().modifiedThrough);
                       String strPlanNameText = seGetElementTextBoxValue(FindPlanPage.get().planName);
                       String strPlanDecriptionText = seGetElementTextBoxValue(BenefitRetainsInProductionPage.get().planDescription);
                       String strHeaderTypeText = seGetText(BenefitRetainsInProductionPage.get().headerTypeText);
                       String strHeaderValueText = seGetText(BenefitRetainsInProductionPage.get().headerValueText);
                       String strHeaderCriteriaText = seGetText(BenefitRetainsInProductionPage.get().headerCriteriaType);
                       String strHeaderCriteriaValueText = seGetText(BenefitRetainsInProductionPage.get().headerCriteriaValue);
                       waitForPageLoad();
                       BenefitRetainsInProductionPage.get();
					BenefitRetainsInProductionPage.seStringCompare(strPlanVersionId, strPlanVersionIdText);
					BenefitRetainsInProductionPage.get();
					BenefitRetainsInProductionPage.seStringCompare(strProxyPlanID, strProxyPlanIDText);
					BenefitRetainsInProductionPage.get();
					BenefitRetainsInProductionPage.seStringCompare(strEffFromDate, strEffFromDateText);
					BenefitRetainsInProductionPage.get();
					BenefitRetainsInProductionPage.seStringCompare(strEffToDate, strEffToDateText);
					BenefitRetainsInProductionPage.get();
					BenefitRetainsInProductionPage.seStringCompare(strModifyFromDate, strModifyFromDateText);
					BenefitRetainsInProductionPage.get();
					BenefitRetainsInProductionPage.seStringCompare(strModifyToDate, strModifyToDateText);
					BenefitRetainsInProductionPage.get();
					BenefitRetainsInProductionPage.seStringCompare(strPlanName, strPlanNameText);
					BenefitRetainsInProductionPage.get();
					BenefitRetainsInProductionPage.seStringCompare(strPlanDecription, strPlanDecriptionText);
					BenefitRetainsInProductionPage.get();
					BenefitRetainsInProductionPage.seStringCompare(strHeaderType, strHeaderTypeText);
					BenefitRetainsInProductionPage.get();
					BenefitRetainsInProductionPage.seStringCompare(strHeaderValue, strHeaderValueText);
					 /*
                       seCompareStrings(strPlanVersionId, strPlanVersionIdText, "=", "Comparison between saved criteria and populated criteria values"); waitForPageLoad();
                       seCompareStrings(strProxyPlanID , strProxyPlanIDText, "=", "Comparison between saved criteria and populated criteria values"); waitForPageLoad();
                       seCompareStrings(strEffFromDate , strEffFromDateText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strEffToDate , strEffToDateText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strModifyFromDate , strModifyFromDateText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strModifyToDate , strModifyToDateText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strPlanName , strPlanNameText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strPlanDecription , strPlanDecriptionText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strHeaderType , strHeaderTypeText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strHeaderValue , strHeaderValueText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strHeaderCriteriaType , strHeaderCriteriaText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strHeaderCriteriaValue , strHeaderCriteriaValueText, "=", "Comparison between saved criteria and populated criteria values");
                       System.out.println("test complete");*/
				} catch (Exception e) {
                    e.printStackTrace();
                    log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
             }
             finally {
           	  seCloseBrowser();
             }
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null){
				//seCloseBrowser();
			}
			endTestScript();
		}
	}
}