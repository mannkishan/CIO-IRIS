package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanAgainstTemplatePage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanSetupPage;
import utility.CoreSuperHelper;

public class VerifyAccVisibleInPlanOption_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	
	
	public static void main(String[] args) {
		try {MANUAL_TC_EXECUTION_EFFORT="00:10:00"; 
			initiateTestScript();
			
			for (iROW = 1; iROW <=getRowCount(); iROW++) {

				try {
					logExtentReport("Test Script/ Functionality Descrtiption");				
					seOpenBrowser(BrowserConstants.Chrome, baseURL);					
					LoginPage.get().loginApplication(userProfile);
					waitForPageLoad(60);				
					String strBenefit=getCellValue("Benefit");
					String strOptionTab=getCellValue("Option");
					String strPlanID=getCellValue("PlanID");
                    String strAction=getCellValue("Action");


					seClick(HomePage.get().find, "Find");
					seClick(HomePage.get().findPlan, "Find Plan");
					waitForPageLoad(45);
					seSetText(page.planConfigurator.FindPlanPage.get().planVersionID, strPlanID, "text in plan version id textbox");
                    seWaitForClickableWebElement(page.planConfigurator.FindPlanPage.get().planSearch, 12);
					seClick(page.planConfigurator.FindPlanPage.get().planSearch, "Search plan");
					waitForPageLoad(45);
					seWaitForClickableWebElement(page.planConfigurator.FindPlanPage.get().selectSearchedPlan, 12);
					seClick(page.planConfigurator.FindPlanPage.get().selectSearchedPlan, " search result");
					waitForPageLoad(45);					
				
					if(strAction.equalsIgnoreCase("copy")){
					seWaitForClickableWebElement(driver.findElement(By.xpath("//a[text()='Copy'][1]")), 12);
					seClick(driver.findElement(By.xpath("//a[text()='Copy'][1]")), "copy button");
					waitForPageLoad(30);
					seWaitForClickableWebElement(CreatePlanPage.get().createPlan, 22);
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", CreatePlanPage.get().createPlan);
					waitForPageLoad(45);
					waitForPageLoad(45);
					}
					else{
						seWaitForClickableWebElement(PlanSetupPage.get().editPlan, 12);
						seClick(PlanSetupPage.get().editPlan, "edit");
						waitForPageLoad();
						seClick(PlanSetupPage.get().savePlan, "edit save");
						waitForPageLoad(45);
					}
					seClick(PlanHeaderPage.get().save, "Save button");
					waitForPageLoad(45);
				    PlanAgainstTemplatePage.get().seCheckAccumulatorVisibility(strOptionTab, strPlanID, strBenefit);
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					waitForPageLoad();
					seWaitForClickableWebElement(PlanAgainstTemplatePage.get().Delete, 12);
					seClick(PlanAgainstTemplatePage.get().Delete, "Delete Plan");
					seWaitForClickableWebElement(PlanAgainstTemplatePage.get().DeleteConfirmation, 12);
					seClick(PlanAgainstTemplatePage.get().DeleteConfirmation,"Confirm delete");
				seCloseBrowser();
				}}
			
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	
	}
}	