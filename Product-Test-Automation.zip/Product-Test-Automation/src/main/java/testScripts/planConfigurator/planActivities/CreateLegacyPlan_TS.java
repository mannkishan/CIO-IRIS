package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreateLegacyPlanPage;
import page.planConfigurator.CreatePlanLegacyHeaderPage;
//import page.planConfigurator.CreatePlanL;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;
/**
 * Manual test case: Create Legacy Plan :
 * This Test script creates a Legacy Plan and moves the Plan to Production status. 
 * @author AF47903
 * @since 10-October-2017
 *
 */

public class CreateLegacyPlan_TS extends CoreSuperHelper {
	
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");

	public static void main(String[] args) {

		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("Create Legacy Plan");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
                    LoginPage.get().loginApplication(strUserProfile);
					seWaitForElementLoad(CreatePlanPage.get().homepage);
					waitForPageLoad();
                    CreateLegacyPlanPage.seCreatePlan(false, 10);
                    waitForPageLoad();
					CreateLegacyPlanPage.seCreateLegacyPlan();
                    seClick(PlanHeaderPage.get().save, "Save button");
					String strPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
					waitForPageLoad();
					String strPlanProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
					waitForPageLoad();
					setCellValue("LegacyPlanID", strPlanVersionID);
					setCellValue("LegacyProxyID", strPlanProxyID);
					seWaitForClickableWebElement(PlanHeaderPage.get().requestAudit,1);
					seClick(PlanHeaderPage.get().requestAudit, "request Audit button");
					waitForPageLoad();
					PlanTransitionPage.get().updateReasonCode("Other");
					seClick(PlanTransitionPage.get().requestAudit, "Request Audit button");
					waitForPageLoad();
					try{
						seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 360);
					    }
					catch(TimeoutException e){
			            seClick(PlanHeaderPage.get().close, "Close button");
			            }
					seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
					waitForPageLoad();
					seClick(PlanHeaderPage.get().userLogout, "Logout");
					waitForPageLoad(20,10); 
			        seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
					LoginPage.get().loginApplication(strUserProfileApprover);
					waitForPageLoad();
					String strLegacy = getCellValue("LegacyPlanID");
					seClick(HomePage.get().find, "Find");
                    seClick(HomePage.get().findPlan, "Find Plan");
					seSetText(FindPlanPage.get().planVersionID,strLegacy, "Set text in plan version id");
					waitForPageLoad();
					seClick(FindPlanPage.get().planSearch, "Search");
					waitForPageLoad();
					WebElement objSearch = FindPlanPage.get().selectSearchedPlan;
                    ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objSearch);
					Boolean blnPlanStatusPendingAudit= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
					if(blnPlanStatusPendingAudit==true){
							log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");
						}
					else { 
							new TimeoutException("Plan is not in Pending Audit status");
						}	
						seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 36);
						seClick(PlanHeaderPage.get().approveAudit, "Approve Audit");
						waitForPageLoad(30);
						seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ENTER);
						seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, 10);
						seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
						seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeText, 1);
						seSetText(PlanTransitionPage.get().planTransitionReasonCodeText, "Approved", "as " + "Approved");
						seClick(PlanTransitionPage.get().approved, "approved reason code");
						seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
						waitForPageLoad();
						seClick(PlanHeaderPage.get().moveToTestPHPage, "Move to test button");
						waitForPageLoad();
						seClick(PlanTransitionPage.get().moveToTest, "Move to test ");
						waitForPageLoad();
						seClick(PlanHeaderPage.get().approveTestForFinalize, "Approve test button");
						waitForPageLoad();
						seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "");
						seClick(PlanTransitionPage.get().approved,"approved");
						seClick(PlanTransitionPage.get().approvedTest, "approve test");
						waitForPageLoad();
						seClick(PlanHeaderPage.get().finalize, "Finalize button");
						waitForPageLoad();
						seClick(PlanTransitionPage.get().finalizeButtoninPT, "");
						waitForPageLoad();
						try{
			        		seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 300);
			        		}
						
						catch(TimeoutException e){
				            seClick(PlanHeaderPage.get().close, "Close button");
							waitForPageLoad();

				            }
				       seClick(FindPlanPage.get().clickSearchedPlan,"Plan");
						waitForPageLoad();
						Boolean blnPlanStatusProduction= PlanHeaderPage.get().seVerifyPlanStatus("Production");
					    if(blnPlanStatusProduction==true){
			                  	log(PASS, "plan takes correct time to load","plan is in Production status,RESULT=PASS");
			                             }
			            else { 
			            	new TimeoutException("Plan is not in Production status");
			                  }	  
					     seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
					     seClick(PlanHeaderPage.get().userLogout, "Logout");
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}finally{
					seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}

}
