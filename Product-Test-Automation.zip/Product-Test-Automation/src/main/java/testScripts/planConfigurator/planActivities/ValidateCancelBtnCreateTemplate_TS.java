package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.Keys;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import utility.CoreSuperHelper;

//Validate Cancel button on Create template screen
public class ValidateCancelBtnCreateTemplate_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("Validate the Cancel Button in Create Plan Page");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);

					LoginPage.get().loginApplication(userProfile);
					seWaitForElementLoad(CreatePlanPage.get().homepage);
					Boolean boolean1 = seIsElementDisplayed(CreatePlanPage.get().homepage,
							"Home page");
					seClick(HomePage.get().create, "Create Option  Clicked");
					seClick(CreatePlanPage.get().findTemplate, "Template Option clicked");
					seWaitForElementLoad(CreatePlanPage.get().enterEffectiveDate);
					String strDate = getCellValue("EffectiveDate");
					seClick(CreatePlanPage.get().enterEffectiveDate, "");
					seSetText(CreatePlanPage.get().enterEffectiveDate, strDate, "Effective Date  entered");
					CreatePlanPage.get().enterEffectiveDate.sendKeys(Keys.ENTER);

					// ***********************************************************************************************************************************

					// template name
					seWaitForClickableWebElement(CreatePlanPage.get().templateName, 0);
					seClick(CreatePlanPage.get().templateName, "TemplateName");
					seClick(CreatePlanPage.get().templateName, "Enter Name");
					String strtempid = getCellValue("Temp");
					seSetText(CreatePlanPage.get().templateName, strtempid, "Template Name Text");

					
					// State
					seClick(CreatePlanPage.get().templateState, "State");
					String strstate = getCellValue("State");
					seSetText(CreatePlanPage.get().templateState, strstate, "Set State as New York");
					seClick(CreatePlanPage.get().templateStateText, "Enter State");

					// Market segment
					seWaitForClickableWebElement(CreatePlanPage.get().templateMarketSegment, 0);
					seClick(CreatePlanPage.get().templateMarketSegment, "Template Market Segment");
					String strms = getCellValue("Marketsegment");
					seSetText(CreatePlanPage.get().templateMarketSegment, strms,
							"Set templateMarketSegment as Individual");
					seClick(CreatePlanPage.get().templateMSText, "Enter templateMSText");

					// LOB
					seWaitForClickableWebElement(CreatePlanPage.get().templateLob, 0);
					seClick(CreatePlanPage.get().templateLob, "LOB");
					seClick(CreatePlanPage.get().templateLobInput, "LOB input");
					String strlob = getCellValue("lob");
					seSetText(CreatePlanPage.get().templateLobInput, strlob, "Set text ");
					seClick(CreatePlanPage.get().templateLobText, "Enter Lob Input");

					// Product Family
					seWaitForClickableWebElement(CreatePlanPage.get().templateProductFmly, 0);
					seClick(CreatePlanPage.get().templateProductFmly, "Product Family");
					String strpdctfmly = getCellValue("Productfmly");
					seSetText(CreatePlanPage.get().templateProductFmly, strpdctfmly, "Prodcut Family Input");
					seClick(CreatePlanPage.get().templateProductfmlyinput, "Prodcut Family");

					// Network Tier
					seWaitForClickableWebElement(CreatePlanPage.get().templateNetwkTier, 0);
					seClick(CreatePlanPage.get().templateNetwkTier, "Network Tier");
					seClick(CreatePlanPage.get().templateNetwkInput, "Network Tier Input");
					String strntwrktier = getCellValue("Networktier");
					seSetText(CreatePlanPage.get().templateNetwkInput, strntwrktier, "Set text ");
					seClick(CreatePlanPage.get().templateNetwrkText, "Network Tier Enter");

					// cdhp
					seWaitForClickableWebElement(CreatePlanPage.get().templateCDHPInput, 0);
					seClick(CreatePlanPage.get().templateCDHPInput, "CDHP");
					String strcdhp = getCellValue("cdhp");
					seSetText(CreatePlanPage.get().templateCDHPInput, strcdhp, "CDHP input");
					// seClick(CreatePlanPage.get().templateCDHPText, "Set text

					// CDHP");
					seInputKeys(CreatePlanPage.get().templateCDHPInput, KeyConstants.ENTER, "Enter Key is Pressed");
					seClick(CreatePlanPage.get().cancelButton, "Cancel Button");
					seWaitForElementLoad(CreatePlanPage.get().popup);
					seClick(CreatePlanPage.get().popup, "Capture popup");
					seClick(CreatePlanPage.get().yesToCancel, "'Yes' to cancel");
					seWaitForElementLoad(CreatePlanPage.get().homepage);
					Boolean boolean2 = seIsElementDisplayed(CreatePlanPage.get().homepage,
							"Home Page");
					CreatePlanPage.get().strcomparebool(boolean1, boolean2);

				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}