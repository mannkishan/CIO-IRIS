package testScripts.planConfigurator.planActivities;

import org.apache.bcel.generic.Select;
import org.openqa.selenium.By;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreateLegacyPlanPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.CreatePlanPharmacyPage;
//import page.planConfigurator.EditPlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;

/*
"Validate on the Plan Transition: Request Audit Information screen Reason Codes with LOB of Vision will be as follows:
o Change Request
o Release Change
o Error Correction
o Other"
*/
public class PlanTransitionRequestAuditVision_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("PC2.0 Critical Scenarios Automation");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);
					waitForPageLoad();
					seWaitForElementLoad(CreatePlanPage.get().homepage);
					waitForPageLoad();
                    CreateLegacyPlanPage.seCreatePlan(false, 10);
                    waitForPageLoad();
					CreateLegacyPlanPage.seCreateLegacyPlan();
                    seClick(PlanHeaderPage.get().save, "Save button");
                    waitForPageLoad();
					String strPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
					waitForPageLoad();
					String strPlanProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
					waitForPageLoad();
					setCellValue("LegacyPlanID", strPlanVersionID);
					setCellValue("LegacyProxyID", strPlanProxyID);
					
					seClick(PlanSetupPage.get().checkValidation, "Check validation");
					waitForPageLoad();
					seClick(PlanSetupPage.get().validationMsg, "Validtaion Passed Display");
					waitForPageLoad();
					seIsElementDisplayed(PlanSetupPage.get().validationMsg,"Check if 'Validation Passed' green band is displayed in UI");
					waitForPageLoad();
					seWaitForClickableWebElement(PlanHeaderPage.get().requestAudit,1);
					seClick(PlanHeaderPage.get().requestAudit, "request Audit button");
					waitForPageLoad();
					
					
					//Verify Reason Codes with LOB of VISION will be as follows: Change Request ,Release Change, Error Correction, Other,  
				    String strReasonCode = seGetText(getWebDriver().findElement(By.xpath("//div[@name='reasonCodeGroup']/label"))).replaceAll("[,*]", "");
				    
				    String strFirstValue = getCellValue("FirstValue");
					PlanTransitionPage.get().seCheckDropDown(PlanTransitionPage.get().reasonCodeDropDown, strReasonCode, strFirstValue);
					String strSecondValue = getCellValue("SecondValue");
					PlanTransitionPage.get().seCheckDropDown(PlanTransitionPage.get().reasonCodeDropDown, strReasonCode, strSecondValue);
					String strThirdValue = getCellValue("ThirdValue");
					PlanTransitionPage.get().seCheckDropDown(PlanTransitionPage.get().reasonCodeDropDown, strReasonCode, strThirdValue);
					String strFourthValue = getCellValue("FourthValue");
					PlanTransitionPage.get().seCheckDropDown(PlanTransitionPage.get().reasonCodeDropDown, strReasonCode, strFourthValue);
					
					seCloseBrowser();
					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					 //seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
