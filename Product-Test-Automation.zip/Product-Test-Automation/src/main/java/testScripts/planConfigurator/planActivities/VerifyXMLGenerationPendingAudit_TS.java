package testScripts.planConfigurator.planActivities;

import org.apache.bcel.generic.Select;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.CreateLegacyPlanPage;
import page.planConfigurator.CreatePlanPage;
//import page.planConfigurator.EditPlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MasterProductAndLegacyPlanOptionsXMLPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;

//Validate once a plan processing has been completed successfully, the Plan XML is generated.
//Validate once Plan XML has been generated the plan version status will be updated from �Plan Processing in Progress� to �Pending Audit�. 

public class VerifyXMLGenerationPendingAudit_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("PC2.0 Critical Scenarios Automation");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
					LoginPage.get().loginApplication(strUserProfile);
					waitForPageLoad();
					seWaitForElementLoad(CreatePlanPage.get().homepage);
					waitForPageLoad();
					
                    CreateLegacyPlanPage.seCreatePlan(false, 10);
                    waitForPageLoad();
					CreateLegacyPlanPage.seCreateLegacyPlan();
                    seClick(PlanHeaderPage.get().save, "Save button");
					String strPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
					waitForPageLoad();
					String strPlanProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
					waitForPageLoad();
					setCellValue("LegacyPlanID", strPlanVersionID);
					setCellValue("LegacyProxyID", strPlanProxyID);
					
					seWaitForClickableWebElement(PlanHeaderPage.get().requestAudit,1);
					seClick(PlanHeaderPage.get().requestAudit, "request Audit button");
					waitForPageLoad();
					
					PlanTransitionPage.get().updateReasonCode("Other");
					seClick(PlanTransitionPage.get().requestAudit, "Request Audit button");
					waitForPageLoad();
					
					PlanTransitionPage.get().seDebugButton();
					//Verify once a plan processing has been completed successfully, the Plan XML will have been generated
					
					String strPlanId = getCellValue("LegacyPlanID").trim();
					waitForPageLoad(30);
                    String strUser= getCellValue("UserID");
                    waitForPageLoad();
					MasterProductAndLegacyPlanOptionsXMLPage.get().seFileDownloadXMLFromUI(strPlanId,strUser);
					waitForPageLoad();
					//Verify once Plan XML has been generated the plan version status will be updated from �Plan Processing in Progress� to �Pending Audit�
					
					try{
						seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 360);
					    }
					catch(TimeoutException e){
			            seClick(PlanHeaderPage.get().close, "Close button");
			            }
					seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
					waitForPageLoad();
					seClick(PlanHeaderPage.get().userLogout, "Logout");
					waitForPageLoad(20,10); 
			        seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
			        LoginPage.get().loginApplication(strUserProfile);
					waitForPageLoad();
					
					seClick(HomePage.get().find, "Find");
                    seClick(HomePage.get().findPlan, "Find Plan");
					seSetText(FindPlanPage.get().planVersionID,strPlanVersionID, "Set text in plan version id");
					waitForPageLoad();
					seClick(FindPlanPage.get().planSearch, "Search");
					waitForPageLoad();
					WebElement objSearch = FindPlanPage.get().selectSearchedPlan;
                    ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objSearch);
					Boolean blnPlanStatusPendingAudit= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
					if(blnPlanStatusPendingAudit==true){
							log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");
						}
					else { 
							new TimeoutException("Plan is not in Pending Audit status");
						}	
					seCloseBrowser();
					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					 //seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
