package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.CreateTemplatePage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import utility.CoreSuperHelper;

public class ValidateSortingAndFilteringInSearchedPlans_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
    static String userProfile = EnvHelper.getValue("user.profile");
    public static void main(String[] args) {
                  try {
                	  MANUAL_TC_EXECUTION_EFFORT="00:45:00";
                        initiateTestScript();

                        for (iROW = 1; iROW <= getRowCount(); iROW++) {
                               try {
                                      logExtentReport("save the search criteria and check the saved search criteria");
                                    
              						
              						String strHeaderType = getCellValue("HeaderType");
              						String strHeaderValue = getCellValue("HeaderValue");
              						String strPlanOptionArea = getCellValue("PlanOptionArea");
              						
                                      seOpenBrowser(BrowserConstants.Chrome, baseURL);
                                      LoginPage.get().loginApplication(userProfile);
                                      waitForPageLoad();
                                      seClick(HomePage.get().find, "Find");
                                      seClick(HomePage.get().findPlan, "Find Plan");
                                      waitForPageLoad();
                                      waitForPageLoad();
                      
						//Header Criteria
						seClick(FindPlanPage.get().headerCriteria,"Header criteria");
						seWaitForPageLoad();
						seClick(FindTemplatePage.get().headerCriteriaType,"Header criteria type");
	                       waitForPageLoad();
	                      BenefitRetainsInProductionPage.get().seHeaderScrollDropdown();
	                      FindPlanPage.get().valueType(strHeaderValue);
						waitForPageLoad(360);
						seClick(FindPlanPage.get().planSearch, "Search");
                        waitForPageLoad();
						BenefitRetainsInProductionPage.get().seFilter("Status", "Draft");
                       seClick(BenefitRetainsInProductionPage.get().rowlabel("Version ID"),"Sorting column wise");
                        String strAsc = BenefitRetainsInProductionPage.get().rowlabel("Version ID").getAttribute("aria-sort");
                        if(strAsc =="descending")
                        {log(PASS,"Validated that after entering the search criteria, the user selects search: The table is sorted by the values in :"+strAsc,"RESULT=PASS");}
                     else if(strAsc =="ascending")
                        {log(PASS,"Validated that after entering the search criteria, the user selects search: The table is sorted by the values in :"+strAsc,"RESULT=PASS");}
                  
                        BenefitRetainsInProductionPage.get().seComparePlan();
                        
				} catch (Exception e) {
                    e.printStackTrace();
                    log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
             }
             finally {
           	 // seCloseBrowser();
             }
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null){
				//seCloseBrowser();
			}
			endTestScript();
		}
	}
}