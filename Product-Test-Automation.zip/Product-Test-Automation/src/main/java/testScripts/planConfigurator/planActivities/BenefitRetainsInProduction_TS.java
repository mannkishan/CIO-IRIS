package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.BenefitsPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.HomePageTabsPage;
import page.planConfigurator.LoginPage;
import utility.CoreSuperHelper;
/**
 * Manual test case: Edit a plan in production status and check whether the Benefits retains
 * <p>
 * Test script template
 * <p>
 * Please refer this test script while creating other test scripts
 * 
 * @author AF48638
 * @since 10-October-2017
 *
 */ 

public class BenefitRetainsInProduction_TS extends CoreSuperHelper{
       static String baseURL = EnvHelper.getValue("pc.url");
       static String userProfile = EnvHelper.getValue("user.profile");
       public static void main(String[] args) {
                     try {
                           initiateTestScript();

                           for (iROW = 1; iROW <= getRowCount(); iROW++) {
                                  try {
                                         logExtentReport("Edit a plan in production status and check whether the Benefits retains");
                                         seOpenBrowser(BrowserConstants.Chrome, baseURL);
                                         LoginPage.get().loginApplication(userProfile);
                                         waitForPageLoad();
                                         seClick(HomePage.get().find, "Find");
                                         seClick(HomePage.get().findPlan, "Find Plan");
                                         waitForPageLoad();
                                         String planid = getCellValue("Plan_ID");
                                         seSetText(FindPlanPage.get().planVersionID, planid, "Set text in plan version id");
                                         seClick(FindPlanPage.get().planSearch, "Search");
                                         waitForPageLoad();
                                         seClick(BenefitRetainsInProductionPage.get().searchedPlanClick, " Searched plan");
                                         waitForPageLoad();
                                         for(int i=0;i<16;i++)
                                         {
                                         seClick(BenefitRetainsInProductionPage.get().scrollDownButton, " Scroll down button");
                                         }
                                         waitForPageLoad();
                                         seClick(BenefitRetainsInProductionPage.get().benefitsTab, " benefits tab");
                                         waitForPageLoad();
                                         seClick(BenefitRetainsInProductionPage.get().searchBar, " Benefits search bar");
                                         /*Benefit values before edit*/
                                         seSetText(BenefitRetainsInProductionPage.get().searchBar, "urgent care center", "Benefits search bar");
                                         seInputKeys(BenefitRetainsInProductionPage.get().searchBar, KeyConstants.ENTER, " ");
                                         waitForPageLoad();
                                         seClick(BenefitRetainsInProductionPage.get().tierIcon, " tier1 icon");
                                         waitForPageLoad();
                                         String strdeductible1BeforeEdit=BenefitRetainsInProductionPage.get().deductible1BeforeEdit.getText();
                                         String strdeductible2BeforeEdit=BenefitRetainsInProductionPage.get().deductible2BeforeEdit.getText();
                                         String strcoInsuranceBeforeEdit=BenefitRetainsInProductionPage.get().coInsuranceBeforeEdit.getText();
                                         
                                         /*editing the benefits in production*/
                                         seWaitForClickableWebElement(BenefitRetainsInProductionPage.get().editButton, 12);
                                         seClick(BenefitRetainsInProductionPage.get().editButton, " edit");
                                         waitForPageLoad();
                                         seClick(BenefitRetainsInProductionPage.get().saveButton, " save");
                                         waitForPageLoad();
                                         waitForPageLoad();
                                         BenefitsPage.get().wbscrollDownBenefits(); 
                                        
                                         /*Benefit values after edit*/
                                         seClick(BenefitRetainsInProductionPage.get().benefitsTab, " benefits tab");
                                         waitForPageLoad();
                                         seClick(BenefitRetainsInProductionPage.get().searchBar, " Benefits search bar");
                                         seSetText(BenefitRetainsInProductionPage.get().searchBar, "urgent care center", "Benefits search bar");
                                         seInputKeys(BenefitRetainsInProductionPage.get().searchBar, KeyConstants.ENTER, " ");
                                         waitForPageLoad();
                                         seClick(BenefitRetainsInProductionPage.get().tierIcon, "the tier1 icon");
                                         waitForPageLoad();
                                         String strdeductible1AfterEdit=seGetText(BenefitRetainsInProductionPage.get().deductible1AfterEdit);
                                         String strdeductible2AfterEdit=seGetText(BenefitRetainsInProductionPage.get().deductible2AfterEdit);
                                         String strcoInsuranceValueAfterEdit=seGetText(BenefitRetainsInProductionPage.get().coInsuranceAfterEdit);
                                         String strcoInsuranceTag=seGetText(BenefitRetainsInProductionPage.get().coInsuranceTag);
                                         String strcoInsuranceAfterEdit=strcoInsuranceValueAfterEdit+"\n"+strcoInsuranceTag;

                                      
                                         seCompareStrings(strdeductible1BeforeEdit, strdeductible1AfterEdit, "=", "Comparison between 'In Network Deductible'before edit and 'In Network Deductible' after edit in Benefits tab");
                                         seCompareStrings(strdeductible2BeforeEdit, strdeductible2AfterEdit, "=", "Comparison between 'In Network Family Deductible' before edit and 'In Network Family Deductible' after edit in Benefits tab");
                                         seCompareStrings(strcoInsuranceBeforeEdit, strcoInsuranceAfterEdit, "=", "Comparison between 'Coinsurance' before edit and 'Coinsurance' after edit in Benefits tab");
                                         
                                         waitForPageLoad();
                                         seClick(BenefitRetainsInProductionPage.get().deleteButton, "delete");
                                         waitForPageLoad();
                                         seClick(BenefitRetainsInProductionPage.get().yesButton, "yes");
                                         waitForPageLoad();
                                         seClick(BenefitRetainsInProductionPage.get().userNameIcon, "username in the top right corner");
                                         seClick(BenefitRetainsInProductionPage.get().logoutIcon, "logout");
                                         
                                         
                                  } catch (Exception e) {
                                         e.printStackTrace();
                                         log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
                                  }
                                  finally {
                                	  seCloseBrowser();
                                  }
                           }

                     } catch (Exception e) {
                           e.printStackTrace();
                           log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
                     } finally {
                           endTestScript();
                     }
              }
      
}

