package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.Keys;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitsPage;
import page.planConfigurator.ExamVisitsBenefitsPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.OfficeExamPCPPage;
import page.planConfigurator.OfficeExamSpecPage;
import page.planConfigurator.PCPSPCBreakoutSetupPage;
import utility.CoreSuperHelper;
/**
 * Manual test case: Verify that if PCP SPC Breakout in Plan Setup is selected and [Office Exams Primary Care Physician] and [Office Exams] in Plan Options is selected then the values are displayed in Benefits     
 * @author AF16391
 * @since 08/18/2017
 *
 */
public class VerifyPCPSPCBreakoutInPlanOptions_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {

		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("PCP SPC Breakout Setup Page");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
					LoginPage.get().loginApplication(strUserProfile);
					seWaitForClickableWebElement(HomePage.get().find, 10);
					String strPlanID = getCellValue("Plan_ID");
					String strGivenPCPValue = getCellValue("officeExamINNCostSharesAmount");
					String strGivenSPCValue = getCellValue("officeExamSpecilaistINNSpcCopay");
					seClick(HomePage.get().find, "Find");
					seClick(HomePage.get().findPlan, "Find Plan");
					seSetText(FindPlanPage.get().planVersionID, strPlanID, "Enter Plan ID");
					waitForPageLoad(30);
					seClick(FindPlanPage.get().planSearch, "Search Plan");
					seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().openClickedPlan, 10);
					seClick(PCPSPCBreakoutSetupPage.get().openClickedPlan, "Search");
					seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().pageSetup, 30);
					seClick(PCPSPCBreakoutSetupPage.get().pageSetup, "Page Setup");
					seClick(PCPSPCBreakoutSetupPage.get().pcpSPCSetup, "PCP SPC Setup");
					seClick(PCPSPCBreakoutSetupPage.get().scrollDown, "Scroll Down");
					seClick(PCPSPCBreakoutSetupPage.get().planOptions, "Plan Options");

					// Office Exam PCP Tab inside Plan Options starts here
					seClick(OfficeExamPCPPage.get().officeExamBenefitSpecificCostShares,
							"Office Exam PCP Benefit Specific Cost Shares");
					seWaitForClickableWebElement(OfficeExamPCPPage.get().officeExamApplyDeductible, 15);

					// Enter Yes/No for Office Exam Apply Deductible
					seClick(OfficeExamPCPPage.get().officeExamApplyDeductible, "Office Exam PCP Apply Deductible");
					seSetText(OfficeExamPCPPage.get().officeExamApplyDeductibleSearchBar,
							getCellValue("officeExamApplyDeductible"), "Office Exam PCP Apply Deductible Search Bar");
					OfficeExamPCPPage.get().officeExamApplyDeductibleSearchBar.sendKeys(Keys.ENTER);

					// Enter Value for Office Exam INN Cost Shares Amount
					seClick(OfficeExamPCPPage.get().officeExamINNCostSharesAmount,
							"Office Exam INN Cost Shares Search Bar");
					seSetText(OfficeExamPCPPage.get().officeExamINNCostSharesAmountSearchBar, strGivenPCPValue,
							"Office Exam INN Cost Shares Search Bar Search Bar");
					OfficeExamPCPPage.get().officeExamINNCostSharesAmountSearchBar.sendKeys(Keys.ENTER);

					// Enter value for In Network Exam Visit Copay Limit
					seWaitForClickableWebElement(OfficeExamPCPPage.get().officeExamINNExamVisitCopayLimit, 15);
					seClick(OfficeExamPCPPage.get().officeExamINNExamVisitCopayLimit,
							"Office Exam PCP In Network Exam Visit Copay Limit");
					seSetText(OfficeExamPCPPage.get().officeExamINNExamVisitCopayLimitSearchBar,
							getCellValue("officeExamINNExamVisitCopayLimit"),
							"In Network Exam Visit Copay Limit Search Bar");
					OfficeExamPCPPage.get().officeExamINNExamVisitCopayLimitSearchBar.sendKeys(Keys.ENTER);
					seClick(OfficeExamPCPPage.get().officeExamOONCostSharesBenefitSpecificCostShares,
							"Office Exam PCP OON Cost Shares Benefit Specific Cost Shares ");

					// Clicked on Office Exam OON Cost Shares Apply Deductible
					seClick(OfficeExamPCPPage.get().officeExamOONCostSharesApplyDeductible,
							"Emergency Diagnosis at INN PCP");
					seSetText(OfficeExamPCPPage.get().officeExamOONCostSharesApplyDeductibleSearchBar,
							getCellValue("officeExamOONCostSharesApplyDeductible"),
							"Office Exam OON Cost Shares Apply Deductible Search Bar");
					OfficeExamPCPPage.get().officeExamOONCostSharesApplyDeductibleSearchBar.sendKeys(Keys.ENTER);

					// Office Exam OON Cost Shares OON Exam Visit Copay Search
					// Bar
					seClick(OfficeExamPCPPage.get().officeExamOONCostSharesOutOfNetworkExamVisitCopay,
							"Office Exam OON Cost Shares OON Exam Visit Copay");
					seSetText(OfficeExamPCPPage.get().officeExamOONCostSharesOutOfNetworkExamVisitCopaySearchBar,
							getCellValue("officeExamOONCostSharesOutOfNetworkExamVisitCopay"),
							"Office Exam OON Cost Shares OON Exam Visit Copay Search Bar");
					OfficeExamPCPPage.get().officeExamOONCostSharesOutOfNetworkExamVisitCopaySearchBar
							.sendKeys(Keys.ENTER);
					// Office Exam PCP Tab inside Plan Options ends here

					// Office Exam Specialist inside Plan Options starts here
					seClick(OfficeExamSpecPage.get().officeExamSpecilaist, "Office Exam Specialist");
					seClick(OfficeExamSpecPage.get().officeExamSpecilaistINNBenSpecCostShares,
							"Office Exam Specialist  INN Benefit Specific Cost Shares ");

					// Selecting Yes/No from Office Exam Specialist Apply
					// Deductible
					seClick(OfficeExamSpecPage.get().officeExamSpecilaistApplyDeductible,
							"Office Exam Specilaist Apply Deductible");
					seSetText(OfficeExamSpecPage.get().officeExamSpecilaistApplyDeductibleSearchBar,
							getCellValue("officeExamSpecilaistApplyDeductible"),
							"Office Exam Specilaist Apply Deductible Search Bar");
					OfficeExamSpecPage.get().officeExamSpecilaistApplyDeductibleSearchBar.sendKeys(Keys.ENTER);

					// Selecting value for Office Exam Specilaist INN Specialist
					// Copay Specialist Copay
					seClick(OfficeExamSpecPage.get().officeExamSpecilaistINNSpcCopay,
							"Office Exam Specilaist INN Specialist Copay Specialist Copay");
					seSetText(OfficeExamSpecPage.get().officeExamSpecilaistINNSpcCopaySearchBar, strGivenSPCValue,
							"Office Exam Specilaist INN Specialist Copay Specialist Copay Search Bar");
					OfficeExamSpecPage.get().officeExamSpecilaistINNSpcCopaySearchBar.sendKeys(Keys.ENTER);

					// Selecting values for Non Routine Podiatric Dollar Limit
					seClick(OfficeExamSpecPage.get().officeExamSpecilaistNonRtnPdDlrLmt,
							"Non Routine Podiatric Dollar Limit");
					seSetText(OfficeExamSpecPage.get().officeExamSpecilaistNonRtnPdDlrLmtSearchBar,
							getCellValue("officeExamSpecilaistNonRtnPdDlrLmt"),
							"Non Routine Podiatric Dollar Limit Search Bar");
					OfficeExamSpecPage.get().officeExamSpecilaistNonRtnPdDlrLmtSearchBar.sendKeys(Keys.ENTER);

					// Benefits Tab starts here
					PCPSPCBreakoutSetupPage.get().benefitsScrollDownButton();
					seClick(ExamVisitsBenefitsPage.get().benefits, "Benefits Tab");
					seWaitForClickableWebElement(ExamVisitsBenefitsPage.get().benefitsSearch, 10);
					seClick(ExamVisitsBenefitsPage.get().benefitsSearch, "Benefit Search");
					seSetText(ExamVisitsBenefitsPage.get().benefitsSearch, "Exam Visit", "Exam Visit benefit name");
					seClick(ExamVisitsBenefitsPage.get().benefitsSearchButton, "Search");

					// Viewing values of Primary Care Physician
					// waitForPageLoad();
					seWaitForClickableWebElement(ExamVisitsBenefitsPage.get().physMedServ_ExmVst_HomeBy_PCP, 40);
					seClick(ExamVisitsBenefitsPage.get().physMedServ_ExmVst_HomeBy_PCP,
							"Situation Type Primary Care Physician");
					waitForPageLoad(30, 10);
					String strPCPValueCheck = seGetText(
							ExamVisitsBenefitsPage.get().physMedServ_ExmVst_HomeBy_PCPValue);					
					boolean blnPCPStaus = PCPSPCBreakoutSetupPage.get().validateValue(strGivenPCPValue,
							strPCPValueCheck);
					PCPSPCBreakoutSetupPage.get().checkPCPSPCStatus(blnPCPStaus, strGivenPCPValue, strPCPValueCheck);

					// Viewing values of Specialist
					waitForPageLoad(20, 10);
					seWaitForClickableWebElement(ExamVisitsBenefitsPage.get().physMedServ_ExmVst_HomeBy_SPC, 40);
					seClick(ExamVisitsBenefitsPage.get().physMedServ_ExmVst_HomeBy_SPC, "Situation Type Specialist");
					waitForPageLoad(20, 10);
					String strSPCValueCheck = seGetText(
							ExamVisitsBenefitsPage.get().physMedServ_ExmVst_HomeBy_SPCValue);					
					boolean blnSPCStatus = PCPSPCBreakoutSetupPage.get().validateValue(strGivenSPCValue,
							strSPCValueCheck);
					PCPSPCBreakoutSetupPage.get().checkPCPSPCStatus(blnSPCStatus, strGivenSPCValue, strSPCValueCheck);
					// Benefits Tab ends here

					// Logout Button
					seClick(PCPSPCBreakoutSetupPage.get().logoutDropDown, "Logout Drop Down ");
					seClick(PCPSPCBreakoutSetupPage.get().logout, "Logout");
					seCloseBrowser();
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			seCloseBrowser();
			endTestScript();
		}
	}

}
