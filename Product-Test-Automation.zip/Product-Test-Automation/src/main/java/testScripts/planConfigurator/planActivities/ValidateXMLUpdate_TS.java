package testScripts.planConfigurator.planActivities;

import java.io.File;
import java.util.List;

import org.apache.bcel.generic.Select;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.CreateLegacyPlanPage;
import page.planConfigurator.CreatePlanLegacyHeaderPage;
import page.planConfigurator.CreatePlanPage;
//import page.planConfigurator.EditPlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MasterProductAndLegacyPlanOptionsXMLPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;

//Validate that original plan XML that was generated on initial �Request Audit� will be discarded and new replacement plan XML will be created. 

public class ValidateXMLUpdate_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					//CREATE PLAN
					logExtentReport("Validate original plan XML generated on initial �Request Audit� will be discarded and new replacement plan XML will be created.");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
                    LoginPage.get().loginApplication(strUserProfile);
					seWaitForElementLoad(CreatePlanPage.get().homepage);
					waitForPageLoad();
                    CreateLegacyPlanPage.seCreatePlan(false, 10);
                    waitForPageLoad();
					CreateLegacyPlanPage.seCreateLegacyPlan();
					waitForPageLoad();
                    seClick(PlanHeaderPage.get().save, "Save button");
                    waitForPageLoad(100);
                    
					//GET PLAN ID FROM UI AND SET IT IN EXCEL SHEET
					String strPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
					waitForPageLoad();
					String strPlanProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
					waitForPageLoad();
					setCellValue("LegacyPlanID", strPlanVersionID);
					setCellValue("LegacyProxyID", strPlanProxyID);
					waitForPageLoad();
					
					//REQUEST AUDIT AND ANOTHER USER APPROVER LOGIN , CHECK PLAN STATUS = "Pending Audit"
					PlanTransitionPage.get().seRequestAudit();
                    waitForPageLoad(20,10); 
                   
                    //approver login
                    seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
					LoginPage.get().loginApplication(strUserProfileApprover);
					waitForPageLoad();
					PlanTransitionPage.get().seApproverLogin();
					
					//download and parse xml
					//get the text of accumulator and its field value
					PlanTransitionPage.get().deductible.click();
					waitForPageLoad();
					String strBenefit = PlanTransitionPage.get().deductibleText.getText();
					waitForPageLoad();
					System.out.println(strBenefit);
					String strAccumName = PlanTransitionPage.get().deductibleAccumulator.getText();
					waitForPageLoad();
					System.out.println(strAccumName);
					String strIndMax = PlanTransitionPage.get().deductibleAccumulatorValue.getText().replaceAll("[$,]", "");
					waitForPageLoad();
					String strIndvidualMax = strIndMax+".0";
					System.out.println(strIndvidualMax);
					
					//download xml
					PlanTransitionPage.get().seDebugButton();
					
					//Check xml downloaded and checking the accumulator value
					System.out.println("going to download xml");
					String strPlanId = getCellValue("LegacyPlanID").trim();
					waitForPageLoad();
					String strUserId = getCellValue("UserID");
					waitForPageLoad();
					MasterProductAndLegacyPlanOptionsXMLPage.get().seFileDownloadXMLFromUI(strPlanId,strUserId);
					waitForPageLoad(100);
					System.out.println("going to parse xml");
					MasterProductAndLegacyPlanOptionsXMLPage.get().seAccumulatorValidation(strBenefit,strAccumName,strIndvidualMax);
					waitForPageLoad(100);
					
					//reject audit with reason code and checking plan status = rejected audit
					PlanTransitionPage.get().seRejectAudit();
					//edit plan
					PlanTransitionPage.get().seDeductibleValue();
					
					//save and get Plan ID from UI and Set in Excel Sheet
					seClick(PlanOptionsPage.get().saveButton, "Save");
					waitForPageLoad(100);
					String strNewPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
					waitForPageLoad();
					setCellValue("NewLegacyPlanID", strNewPlanVersionID);
					
					//move plan to Pending Audit status
					PlanTransitionPage.get().seRequestAudit();
					waitForPageLoad(20,10); 
			        seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
					LoginPage.get().loginApplication(strUserProfileApprover);
					waitForPageLoad();
					PlanTransitionPage.get().seApproverLoginNew();
					
					//get the text of accumulator
					PlanTransitionPage.get().deductible.click();
					waitForPageLoad();
					String strNewBenefit = PlanTransitionPage.get().deductibleText.getText();
					waitForPageLoad();
					System.out.println(strBenefit);
					String strNewAccumName = PlanTransitionPage.get().deductibleAccumulator.getText();
					waitForPageLoad();
					System.out.println(strAccumName);
					// replaceAll("[$,]", ""))
					String strNewIndMax = PlanTransitionPage.get().deductibleAccumulatorValue.getText().replaceAll("[$,]", "");
					waitForPageLoad();
					String strNewIndvidualMax = strNewIndMax+".0";
					System.out.println(strNewIndvidualMax);
					
					//download xml
					PlanTransitionPage.get().seDebugButton();
					
					//Dwonload XML
					String strNewPlanId = getCellValue("NewLegacyPlanID").trim();
					waitForPageLoad();
					MasterProductAndLegacyPlanOptionsXMLPage.get().seFileDownloadXMLFromUINew(strNewPlanId,strUserId);
					waitForPageLoad();
					MasterProductAndLegacyPlanOptionsXMLPage.get().seAccumulatorValidation(strNewBenefit,strNewAccumName,strNewIndvidualMax);
					waitForPageLoad();
					
					// take first ded value, second ded value and compare  strIndvidualMax  strNewIndvidualMax
					PlanTransitionPage.seCompareAccumulator(strIndvidualMax, strNewIndvidualMax);
					
					
					
					seCloseBrowser();
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} 
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
