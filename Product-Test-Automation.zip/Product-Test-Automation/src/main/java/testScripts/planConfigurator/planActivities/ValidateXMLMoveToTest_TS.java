package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;

import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.CreateLegacyPlanPage;
import page.planConfigurator.CreatePlanPage;
//import page.planConfigurator.EditPlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MasterProductAndLegacyPlanOptionsXMLPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;

//Validate that User can select �Move to Test� to trigger system process of pushing Plan XML 

public class ValidateXMLMoveToTest_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					
					logExtentReport("Validate that User can select �Move to Test� to trigger system process of pushing Plan XML");
                    seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
                    LoginPage.get().loginApplication(strUserProfile);
                    seWaitForElementLoad(CreatePlanPage.get().homepage);
                    waitForPageLoad();
                    CreateLegacyPlanPage.seCreatePlan(false, 10);
                    waitForPageLoad();
                    CreateLegacyPlanPage.seCreateLegacyPlan();
                    seClick(PlanHeaderPage.get().save, "Save button");
                    waitForPageLoad();
                    String strPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
                    waitForPageLoad();
                    String strPlanProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
                    waitForPageLoad();
                    setCellValue("LegacyPlanID", strPlanVersionID);
                    setCellValue("LegacyProxyID", strPlanProxyID);
                    seWaitForClickableWebElement(PlanHeaderPage.get().requestAudit,1);
                    seClick(PlanHeaderPage.get().requestAudit, "request Audit button");
                    waitForPageLoad();
                    PlanTransitionPage.get().updateReasonCode("Other");
                    seClick(PlanTransitionPage.get().requestAudit, "Request Audit button");
                    waitForPageLoad();
                    try{
                           seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 360);
                        }
                    catch(TimeoutException e){
                   seClick(PlanHeaderPage.get().close, "Close button");
                   }
                    seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
                    waitForPageLoad();
                    seClick(PlanHeaderPage.get().userLogout, "Logout");
                    waitForPageLoad(20,10); 
                    seCloseBrowser();
                    seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
                    LoginPage.get().loginApplication(strUserProfileApprover);
                    waitForPageLoad();
                    String strLegacy = getCellValue("LegacyPlanID");
                    seClick(HomePage.get().find, "Find");
                    seClick(HomePage.get().findPlan, "Find Plan");
                    seSetText(FindPlanPage.get().planVersionID,strLegacy, "Set text in plan version id");
                    waitForPageLoad();
                    seClick(FindPlanPage.get().planSearch, "Search");
                    waitForPageLoad();
                    WebElement objSearch = FindPlanPage.get().selectSearchedPlan;
                    ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objSearch);
                    waitForPageLoad();
                    seClick(PlanHeaderPage.get().approveAudit, "Approve Audit");
                           waitForPageLoad(30);
                           seWaitForElementLoad(BenefitRetainsInProductionPage.get().planTransitionPage);
                           waitForPageLoad(30);
                           seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
                           PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
                           PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
                           PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ENTER);
                           waitForPageLoad();
                           seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, 10);
                           seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
                           seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeText, 1);
                           waitForPageLoad();
                           seSetText(PlanTransitionPage.get().planTransitionReasonCodeText, "Approved", "as " + "Approved");
                           seClick(PlanTransitionPage.get().approved, "approved reason code");
                           seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
                           waitForPageLoad(45);
                           
                           //Check if plan is in "Approve Audit"
                           Boolean blnPlanStatusApproveAudit= PlanHeaderPage.get().seVerifyPlanStatus("Approved Audit");
       						if(blnPlanStatusApproveAudit==true){
       							log(PASS, "plan takes correct time to load","plan is in Approve Audit status,RESULT=PASS");
       						}
       						else { 
       							new TimeoutException("Plan is not in Approve Audit status");
       						}	
       						System.out.println("Plan in Approve audit");
                           // Validate if 'Delete','Move to Test','Copy','Close' is enabled
       						Boolean blnDelete = seIsElementEnabled(PlanTransitionPage.get().delete,"'Delete' Button is Enabled");
       						String strDelete = seGetText(PlanTransitionPage.get().delete);
       						PlanTransitionPage.get().seButtonAvailability(blnDelete, strDelete);
       						System.out.println("delete");
                            
       						Boolean blnMoveToTest = seIsElementEnabled(PlanTransitionPage.get().moveToTestButton,"'MoveToTest' Button is Enabled");
       						String strMoveToTest = seGetText(PlanTransitionPage.get().moveToTestButton);
       						PlanTransitionPage.get().seButtonAvailability(blnMoveToTest, strMoveToTest);
       						System.out.println("move o test");
       						
       						Boolean blnCopy = seIsElementEnabled(PlanTransitionPage.get().copy,"'Copy'Button is Enabled");
       						String strCopy = seGetText(PlanTransitionPage.get().copy);
       						PlanTransitionPage.get().seButtonAvailability(blnCopy, strCopy);
       						System.out.println("copy");
       						
       						Boolean blnClose = seIsElementEnabled(PlanTransitionPage.get().close,"'Close'Button is Enabled");
       						String strClose = seGetText(PlanTransitionPage.get().close);
       						PlanTransitionPage.get().seButtonAvailability(blnClose, strClose);
       						System.out.println("close");
                           
                           waitForPageLoad(20);
                           seClick(PlanTransitionPage.get().moveToTestButton, "Move to test button");
                           waitForPageLoad();
                           seClick(PlanTransitionPage.get().moveToTest, "Move to test ");
                           waitForPageLoad(45);
                           
                           //0259580139
                           PlanTransitionPage.get().seDebugButton();
                           waitForPageLoad();
                           String strPlanId = getCellValue("LegacyPlanID").trim();
                           waitForPageLoad(30);
                           String strUser= getCellValue("UserID");
                           waitForPageLoad();
                           MasterProductAndLegacyPlanOptionsXMLPage.get().seFileDownloadXMLFromUI(strPlanId,strUser);
       					   waitForPageLoad();
				
					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					 seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
