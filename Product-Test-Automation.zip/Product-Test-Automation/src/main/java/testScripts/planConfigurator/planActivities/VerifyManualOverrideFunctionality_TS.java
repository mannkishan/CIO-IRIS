package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.BenefitsPage;
import page.planConfigurator.CreateLegacyPlanPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HomePage;
import page.planConfigurator.HomePageTabsPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;
/**
 * Manual test case: Do a Manual override and check whether the manual override Indicator is displayed
 * <p>
 * Test script template
 * <p>
 * Please refer this test script while creating other test scripts
 * 
 * @author AF48638
 * @since 10-October-2017
 *
 */ 

public class VerifyManualOverrideFunctionality_TS extends CoreSuperHelper{
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) { 
				try {
					logExtentReport("Verify whether Manual Override Changes are highlighted");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL, "testscripts");
					LoginPage.get().loginApplication(strUserProfile);
					waitForPageLoad();
					boolean blnIsMasterPlan = true;
					int intMaxWaitTime = 45;
					String strEffectiveDate = getCellValue("MP_EffectiveDate");
					String strProductModel = "";
					if (blnIsMasterPlan) {
						strProductModel = "Master Product";
					}
					String strTemplateVersionID = getCellValue("TemplateVersionID");
					String strApprovalStatus = getCellValue("MP_ApprovalStatus");
					String strCustomizationLevel = getCellValue("MP_CustomizationLevel");
					String strState = getCellValue("MP_State");
					String strMarketSegment = getCellValue("MP_MarketSegment");
					String strMarketUnit = getCellValue("MP_MarketUnit");
					String strProductFamily = getCellValue("MP_ProductFamily");
					String strProductName = getCellValue("MP_ProductName");
					String strCDHPType = getCellValue("MP_CDHP");
					String strBenefitPeriod = getCellValue("MP_BenefitPeriod");
					String strFundingArrangement = getCellValue("MP_FundingArrangement");
					String strBusinessUnit = getCellValue("MP_BusinessUnit");
					String strLineOfBusiness = getCellValue("MP_LOB");
					String strCoinsuranceValue = getCellValue("CoinsuranceValue");
					waitForPageLoad(intMaxWaitTime);
					seClick(HomePage.get().create, "Create");
					seClick(HomePage.get().plan, "Plan");
					waitForPageLoad(4, intMaxWaitTime);
					seSetText(CreatePlanPage.get().enterEffectiveDate, strEffectiveDate, "Effective date");
					CreatePlanPage.get().enterEffectiveDate.sendKeys(Keys.TAB);
					waitForPageLoad(intMaxWaitTime);
					seSelectText(CreatePlanPage.get().selectProductModelData, strProductModel, "Product Model",
							intMaxWaitTime);
					seSelectText(CreatePlanPage.get().customizationLevel, strCustomizationLevel, "Customization Level",
							intMaxWaitTime);
					seSelectText(CreatePlanPage.get().state, strState, "State", intMaxWaitTime);
					seSelectText(CreatePlanPage.get().marketSegment, strMarketSegment, "Market Segment", intMaxWaitTime);
					seSelectText(CreatePlanPage.get().marketUnit, strMarketUnit, "Market Unit", intMaxWaitTime);
					seSelectText(CreatePlanPage.get().lob, strLineOfBusiness, "Line of Business", intMaxWaitTime);
					seSelectText(CreatePlanPage.get().productName, strProductName, "Product Name", intMaxWaitTime);
					seSelectText(CreatePlanPage.get().productFamily, strProductFamily, "Product Family", intMaxWaitTime);
					seSelectText(CreatePlanPage.get().cdhType, strCDHPType, "Consumer Driven Health Plan", intMaxWaitTime);
					seSelectText(CreatePlanPage.get().benefitPeriod, strBenefitPeriod, "Benefit Period", intMaxWaitTime);
					seSelectText(CreatePlanPage.get().fundingArrangement, strFundingArrangement, "Funding Arrangement",
							intMaxWaitTime);
					seSelectText(CreatePlanPage.get().businessUnit, strBusinessUnit, "Business Unit", intMaxWaitTime);
					if (blnIsMasterPlan) {
						seClick(CreatePlanPage.get().selectTemplate, "Select Template");
						waitForPageLoad(4, intMaxWaitTime);
						seSwitchFrame(FindTemplatePage.get().findTemplateFrame);
						seWaitForClickableWebElement(FindTemplatePage.get().searchCriteria, 60);
						seClick(FindTemplatePage.get().searchCriteria, "Search Criteria");
						seWaitForClickableWebElement(FindTemplatePage.get().versionId, 120);
						seSetText(FindTemplatePage.get().versionId, strTemplateVersionID, "Template Version ID");
						seClick(FindTemplatePage.get().searchButton, "Search Criteria");
						waitForPageLoad(intMaxWaitTime);
						FindTemplatePage.get().selectTemplate(strTemplateVersionID);
					}
					waitForPageLoad(intMaxWaitTime);
					getWebDriver().switchTo().defaultContent();
					waitForPageLoad(intMaxWaitTime);
					seClick(CreatePlanPage.get().createPlan, "Create Plan");
					waitForPageLoad(5, intMaxWaitTime);
					waitForPageLoad(5, intMaxWaitTime);
					String planVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];					
					waitForPageLoad(5, intMaxWaitTime);
					String planProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
					setCellValue("MasterProductPlanID", planVersionID);
					setCellValue("MP_PlanProxyID", planProxyID);
					seClick(PlanHeaderPage.get().save, "Save button");
					waitForPageLoad(45);
					BenefitRetainsInProductionPage.get();
					BenefitRetainsInProductionPage.seBenefitsTab();
                     waitForPageLoad();
                     seClick(BenefitRetainsInProductionPage.get().benefitsTab, " benefits tab");
                     waitForPageLoad();
                     seClick(BenefitRetainsInProductionPage.get().searchBar, " Benefits search bar");
                     seWaitForPageLoad();
                     seSetText(BenefitRetainsInProductionPage.get().searchBar, "urgent care center", "Benefits search bar");
                     seInputKeys(BenefitRetainsInProductionPage.get().searchBar, KeyConstants.ENTER, " ");
                     waitForPageLoad();
                     seClick(BenefitRetainsInProductionPage.get().tierIcon, " tier1 icon");
                     waitForPageLoad(45);
                     seClick(BenefitRetainsInProductionPage.get().preAuthorizationButton, "Pre-Authorization");
                     waitForPageLoad(45);
                     seClick(BenefitRetainsInProductionPage.get().autoAdjudicationButton, "Auto-Adjudication");
                     seWaitForPageLoad(60);
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().appliesCheckBox, "Applies Check Box");
                     seClick(BenefitRetainsInProductionPage.get().appliesCheckBox, "Applies Check Box");
                     waitForPageLoad(60);
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().OOPButton, "OOP Choice");
                     seClick(BenefitRetainsInProductionPage.get().OOPButton, "OOP");
                     waitForPageLoad(60);
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().dropdownBox, "coinsurance");
                     seClick(BenefitRetainsInProductionPage.get().dropdownBox, "coinsurance");
                     waitForPageLoad(60);
                     seSetText(BenefitRetainsInProductionPage.get().copayDropdownValueEnter, strCoinsuranceValue, "coinsurance");
                     BenefitRetainsInProductionPage.get().copayDropdownValueEnter.sendKeys(Keys.TAB);
                     seWaitForPageLoad(60);  
                     
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().outOfNetworkTierIcon, "Out of network");
                     seClick(BenefitRetainsInProductionPage.get().outOfNetworkTierIcon, "Out of network");
                     waitForPageLoad(60);
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().outOfnetworkNotCovered, "Calculation choice");
                     seClick(BenefitRetainsInProductionPage.get().outOfnetworkNotCovered, "Calculation choice");
                     waitForPageLoad(60);
                  	 seIsElementDisplayed(BenefitRetainsInProductionPage.get().preAuthorizationButtonWrapper, "pre AuthorizationButtonWrapper");
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().autoAdjudicationButtonWrapper, "auto AdjudicationButtonWrapper");
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().appliesCheckBoxWrapper, "Applies check box Wrapper");
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().OOPButtonWrapper, "OOP Button Wrapper");
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().dropdownBoxWrapper, "coinsurance Dropdown Box Wrapper");
                    // seIsElementDisplayed(BenefitRetainsInProductionPage.get().copayDropdownBoxWrapper, "copay Dropdown Box Wrapper");
                    // seIsElementDisplayed(BenefitRetainsInProductionPage.get().coinsuranceDropdownBoxWrapper, "coinsurance Dropdown Box Wrapper");
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().outOfnetworkNotCoveredWrapper, "calculation choice Wrapper");
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().benefitsTreeIndicator, "benefits Tree Indicator");
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().restoreButton, "Restore Button");
                     seWaitForPageLoad();
                     seClick(BenefitRetainsInProductionPage.get().restoreButton, "Restore Button");
                     seWaitForPageLoad();
                     seClick(BenefitRetainsInProductionPage.get().restoreNoButton, "No");
                     seWaitForPageLoad();
                     seWaitForPageLoad();
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().benefitsTreeIndicator, "benefits Tree Indicator");


                     
					seWaitForClickableWebElement(PlanHeaderPage.get().requestAudit, 12);
					seClick(PlanHeaderPage.get().requestAudit, "request Audit button");
					waitForPageLoad();
					
					PlanTransitionPage.get().updateReasonCode("Other");
					seClick(PlanTransitionPage.get().requestAudit, "Request Audit button");
					waitForPageLoad();
					try {
						seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 360);
					}
					catch (TimeoutException e) {
						seClick(PlanHeaderPage.get().close, "Close button");
						waitForPageLoad();
					}
					seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
					waitForPageLoad();
					seClick(PlanHeaderPage.get().userLogout, "Logout");
					waitForPageLoad();
					seCloseBrowser();
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
					LoginPage.get().loginApplication(strUserProfileApprover);
					waitForPageLoad();
					FindPlanPage.seSearchPlanByPlanVersionID(getCellValue("MasterProductPlanID"));
					waitForPageLoad();
					Boolean blnAuditStatus = PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
					if (blnAuditStatus == true) {
						log(PASS, "plan takes correct time to load", "plan is in Pending Audit status,RESULT=PASS");
					} else {
						throw new TimeoutException("Plan is not in Pending Audit status");
					}
					seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 36);
					seClick(PlanHeaderPage.get().approveAudit, "Approve Audit");
					waitForPageLoad(45);
					seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
					PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
					PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
					PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ENTER);
					seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, 10);
					seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
					seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeText, 1);
					seSetText(PlanTransitionPage.get().planTransitionReasonCodeText, "Approved", "as " + "Approved");
					seClick(PlanTransitionPage.get().approved, "approved reason code");
					seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
					waitForPageLoad(45);
					seWaitForClickableWebElement(PlanHeaderPage.get().moveToTestPHPage, 12);
					seClick(PlanHeaderPage.get().moveToTestPHPage, "Move to test button");
					waitForPageLoad();
					seClick(PlanTransitionPage.get().moveToTest, "Move to test ");
					waitForPageLoad(45);
					seWaitForClickableWebElement(PlanHeaderPage.get().approveTestForFinalize, 12);
					seClick(PlanHeaderPage.get().approveTestForFinalize, "Approve test button");
					waitForPageLoad();
					seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "test approval");
					seClick(PlanTransitionPage.get().approved, "approved");
					seClick(PlanTransitionPage.get().approvedTest, "approve test");
					waitForPageLoad(45);
					seWaitForClickableWebElement(PlanHeaderPage.get().finalize, 12);
					seClick(PlanHeaderPage.get().finalize, "Finalize button");
					waitForPageLoad();
					seClick(PlanTransitionPage.get().finalizeButtoninPT, "finalize");
					waitForPageLoad();
					try {
						seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 300);
					}
					catch (TimeoutException e) {
						seClick(PlanHeaderPage.get().close, "Close button");
						waitForPageLoad();
					}
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",
							FindPlanPage.get().selectSearchedPlan);
					waitForPageLoad(45);
					Boolean blnFinalStatus = PlanHeaderPage.get().seVerifyPlanStatus("Production");
					if (blnFinalStatus == true) {
						log(PASS, "plan takes correct time to load", "plan is in Production status,RESULT=PASS");
					} else {
						throw new TimeoutException("Plan is not in Production status");
					}
					waitForPageLoad();
					seWaitForClickableWebElement(BenefitRetainsInProductionPage.get().editButton, 12);
                    seClick(BenefitRetainsInProductionPage.get().editButton, " edit");
                    waitForPageLoad();
                    seClick(BenefitRetainsInProductionPage.get().saveButton, " save");
                    waitForPageLoad();
                    waitForPageLoad();
                    BenefitRetainsInProductionPage.get();
					BenefitRetainsInProductionPage.seBenefitsTab();
                     waitForPageLoad();
                     seClick(BenefitRetainsInProductionPage.get().benefitsTab, " benefits tab");
                     waitForPageLoad();
                     seClick(BenefitRetainsInProductionPage.get().searchBar, " Benefits search bar");
                     /*Benefit values before edit*/
                    seSetText(BenefitRetainsInProductionPage.get().searchBar, "urgent care center", "Benefits search bar");
                     seInputKeys(BenefitRetainsInProductionPage.get().searchBar, KeyConstants.ENTER, " ");
                     waitForPageLoad();
                     seClick(BenefitRetainsInProductionPage.get().tierIcon, " tier1 icon");
                     waitForPageLoad(45);
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().outOfNetworkTierIcon, "Out of network");
                     seClick(BenefitRetainsInProductionPage.get().outOfNetworkTierIcon, "Out of network");
                     waitForPageLoad(60);
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().preAuthorizationButtonWrapper, "pre AuthorizationButtonWrapper");
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().autoAdjudicationButtonWrapper, "auto AdjudicationButtonWrapper");
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().appliesCheckBoxWrapper, "Applies check box Wrapper");
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().OOPButtonWrapper, "OOP Button Wrapper");
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().dropdownBoxWrapper, "coinsurance Dropdown Box Wrapper");
                    // seIsElementDisplayed(BenefitRetainsInProductionPage.get().copayDropdownBoxWrapper, "copay Dropdown Box Wrapper");
                    // seIsElementDisplayed(BenefitRetainsInProductionPage.get().coinsuranceDropdownBoxWrapper, "coinsurance Dropdown Box Wrapper");
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().outOfnetworkNotCoveredWrapper, "calculation choice Wrapper");
                     seIsElementDisplayed(BenefitRetainsInProductionPage.get().benefitsTreeIndicator, "benefits Tree Indicator");
					seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
					seClick(PlanHeaderPage.get().userLogout, "Logout");  
					     	
                                  } catch (Exception e) {
                                         e.printStackTrace();
                                         log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
                                  }
                                  finally {
                                	 seCloseBrowser();
                                  }
                           }

                     } catch (Exception e) {
                           e.printStackTrace();
                           log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
                     } finally {
                           endTestScript();
                     }
              }
      
}

