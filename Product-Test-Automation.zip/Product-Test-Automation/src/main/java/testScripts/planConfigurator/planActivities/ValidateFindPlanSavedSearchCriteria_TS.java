package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import utility.CoreSuperHelper;

public class ValidateFindPlanSavedSearchCriteria_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
    static String userProfile = EnvHelper.getValue("user.profile");
    public static void main(String[] args) {
                  try {
                        initiateTestScript();

                        for (iROW = 1; iROW <= getRowCount(); iROW++) {
                               try {
                                      logExtentReport("save the search criteria and check the saved search criteria");
                                    
              						String strPlanVersionId = getCellValue("PlanVersionId");
              						String strProxyPlanID = getCellValue("ProxyPlanID");
              						String strEffFromDate = getCellValue("EffectiveFrom");
              						String strEffToDate = getCellValue("EffectiveThrough");
              						String strModifyFromDate = getCellValue("ModifyFrom");
              						String strModifyToDate = getCellValue("ModifyThrough");
              						String strPlanName = getCellValue("PlanName");
              						String strPlanDecription = getCellValue("PlanDecription");
              						String strRepositoryId = getCellValue("RepositoryId");
              						String strHeaderType = getCellValue("HeaderType");
              						String strHeaderValue = getCellValue("HeaderValue");
              						String strPlanOptionArea = getCellValue("PlanOptionArea");
              						String strPlanOptionType = getCellValue("PlanOptionType");
              						String strPlanOptionName = getCellValue("PlanOptionName");
              						String strAccumType = getCellValue("AccumulatorType");
              						String strAccumName = getCellValue("AccumulatorName");
              						String strAccumValue = getCellValue("AccumulatorValue");
              						String strBenefit = getCellValue("Benefit");
              						String strSituationGroup = getCellValue("SituationGroup");
              						String strSituationType = getCellValue("SituationType");
                                      seOpenBrowser(BrowserConstants.Chrome, baseURL);
                                      LoginPage.get().loginApplication(userProfile);
                                      waitForPageLoad();
                                      seClick(HomePage.get().find, "Find");
                                      seClick(HomePage.get().findPlan, "Find Plan");
                                      waitForPageLoad();
                                      waitForPageLoad();
                       seClick(FindPlanPage.get().planVersionID,"Plan Version Id");
						seSetText(FindPlanPage.get().planVersionID, strPlanVersionId, "Plan Version Id");
						seClick(FindPlanPage.get().planProxyId,"Proxy Plan ID");
						seSetText(FindPlanPage.get().planProxyId, strProxyPlanID, "Proxy Plan ID");
						
						seClick(FindPlanPage.get().effectiveFrom,"Effective From Date");
						seSetText(FindPlanPage.get().effectiveFrom, strEffFromDate, "Effective Date");
						seInputKeys(FindPlanPage.get().effectiveFrom, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						seClick(BenefitRetainsInProductionPage.get().modifiedFrom,"Modified From Date");
						seSetText(BenefitRetainsInProductionPage.get().modifiedFrom, strModifyFromDate, "Modified From Date");
						seInputKeys(BenefitRetainsInProductionPage.get().modifiedFrom, KeyConstants.ENTER, " ");
						
              			seClick(FindPlanPage.get().planName,"Plan Name");
						seSetText(FindPlanPage.get().planName, strPlanName, "Plan Name");
						seClick(BenefitRetainsInProductionPage.get().planDescription,"Plan Description");
						seSetText(BenefitRetainsInProductionPage.get().planDescription, strPlanDecription, "Plan Description");
						seClick(BenefitRetainsInProductionPage.get().repositoryId,"Repository Id");
						seSetText(BenefitRetainsInProductionPage.get().repositoryId, strRepositoryId, "Repository Id");
						//Header Criteria
						seClick(FindPlanPage.get().headerCriteria,"Header criteria");
						seWaitForPageLoad();
						seClick(FindPlanPage.get().headerCriteriaType,"Header criteria type");
						seWaitForPageLoad();
						seSetText(BenefitRetainsInProductionPage.get().headerValueEnter, strHeaderType, "Header Type");
						seInputKeys(BenefitRetainsInProductionPage.get().headerValueEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						FindPlanPage.get().valueType(strHeaderValue);
						waitForPageLoad(360);
						//Option Criteria
						seClick(FindPlanPage.get().optionCriteria, "optionCriteria");
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().planOptionArea, "Plan Option Area");
						seClick(FindPlanPage.get().planOptionAreaValue(strPlanOptionArea),"PlanOptionArea "+strPlanOptionArea);
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().planOptionType, "Plan Option Type");
						seClick(FindPlanPage.get().planOptionTypeValue(strPlanOptionType),"PlanOptionType "+strPlanOptionType);
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().planOptionName, "Plan Option Name");
						seClick(BenefitRetainsInProductionPage.get().planOptionNameEnter, "Plan Option Name");
						seSetText(BenefitRetainsInProductionPage.get().planOptionNameEnter, strPlanOptionName, "Plan Option Name");
						seInputKeys(BenefitRetainsInProductionPage.get().planOptionNameEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						//Accumulator Criteria
						seClick(FindPlanPage.get().accumulatorCriteria, "Accumulatory Criteria");
						seClick(FindPlanPage.get().accumType,"Accumulator Type");
						seClick(BenefitRetainsInProductionPage.get().accumTypeEnter,"Accumulator Type");
						seSetText(BenefitRetainsInProductionPage.get().accumTypeEnter, strAccumType, "Accumulator Type");
						seInputKeys(BenefitRetainsInProductionPage.get().accumTypeEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						seClick(BenefitRetainsInProductionPage.get().accumulatorName,"Accumulator Name");
						seClick(BenefitRetainsInProductionPage.get().accumNameEnter,"Accumulator Name");
						seSetText(BenefitRetainsInProductionPage.get().accumNameEnter, strAccumName, "Accumulator Name");
						seInputKeys(BenefitRetainsInProductionPage.get().accumNameEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						seClick(BenefitRetainsInProductionPage.get().accumulatorValue,"Accumulator Value");
						seSetText(BenefitRetainsInProductionPage.get().accumulatorValue, strAccumValue, "Accumulator Value");
						seWaitForPageLoad();
						//Benefit Criteria
						seClick(FindPlanPage.get().benefitCriteria, "Benefit Criteria");
						waitForPageLoad(300);
						FindPlanPage.get().selectTheBenefit(strBenefit);
						waitForPageLoad(300);
						FindPlanPage.get().situationGroup(strSituationGroup);
						waitForPageLoad(300);
						
						seClick(BenefitRetainsInProductionPage.get().benefitSituationType, "Situation Type");
						seClick(BenefitRetainsInProductionPage.get().benefitSituationTypeEnter, "Situation Type");
						seSetText(BenefitRetainsInProductionPage.get().benefitSituationTypeEnter, strSituationType, "Situation Type");
						seInputKeys(BenefitRetainsInProductionPage.get().benefitSituationTypeEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						seClick(BenefitRetainsInProductionPage.get().exclude,"Exclude");
						seWaitForPageLoad();
                        seClick(BenefitRetainsInProductionPage.get().saveSearchCriteria,"save search criteria ");
                        seWaitForPageLoad();
                        seClick(BenefitRetainsInProductionPage.get().saveSearchName,"save search criteria ");
                        seSetText(BenefitRetainsInProductionPage.get().saveSearchName,"sample","saved search Name");
                        seWaitForPageLoad();
                        seClick(BenefitRetainsInProductionPage.get().saveSearchYes, "Yes");
                        seWaitForPageLoad();
                        seCloseBrowser();
    					seOpenBrowser(BrowserConstants.Chrome, baseURL);
                        LoginPage.get().loginApplication(userProfile);
    					waitForPageLoad();
    					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",HomePage.get().find);
    					seClick(HomePage.get().findPlan, "Find Plan");
                        seWaitForPageLoad();
                        seWaitForPageLoad();
                        WebElement objClick = getWebDriver().findElement(By.xpath("//*[@id=\"findPlanSearch\"]/div[1]/span[1]/span[1]/span/span[2]"));
                       waitForPageLoad();
                       waitForPageLoad();
                        seWaitForPageLoad();
                         objClick.click();
                         waitForPageLoad();
                        seSetText(BenefitRetainsInProductionPage.get().savedSearchEnter,"sample","saved search Name");
                        seInputKeys(BenefitRetainsInProductionPage.get().savedSearchEnter, KeyConstants.ENTER, " ");
                       waitForPageLoad();
                       waitForPageLoad();
                       String strPlanVersionIdText = seGetElementTextBoxValue(FindPlanPage.get().planVersionID);
                       String strProxyPlanIDText = seGetElementTextBoxValue(FindPlanPage.get().planProxyId);
                       String strEffFromDateText = seGetElementTextBoxValue(FindPlanPage.get().effectiveFrom);
                       String strEffToDateText = seGetElementTextBoxValue(BenefitRetainsInProductionPage.get().effectiveThrough);
                       String strModifyFromDateText = seGetElementTextBoxValue(BenefitRetainsInProductionPage.get().modifiedFrom);
                       String strModifyToDateText = seGetElementTextBoxValue(BenefitRetainsInProductionPage.get().modifiedThrough);
                       String strPlanNameText = seGetElementTextBoxValue(FindPlanPage.get().planName);
                       String strPlanDecriptionText = seGetElementTextBoxValue(BenefitRetainsInProductionPage.get().planDescription);
                       String strRepositoryIdText = seGetElementTextBoxValue(BenefitRetainsInProductionPage.get().repositoryId);
                       String strHeaderTypeText = seGetText(BenefitRetainsInProductionPage.get().headerTypeText);
                       System.out.println(strHeaderTypeText);
                       String strHeaderValueText = seGetText(BenefitRetainsInProductionPage.get().headerValueText);
                       System.out.println(strHeaderValueText);
                       String strPlanOptionAreaText = seGetText(FindPlanPage.get().planOptionArea);
                       String strPlanOptionTypeText = seGetText(FindPlanPage.get().planOptionType);
                       String strPlanOptionNameText = seGetText(FindPlanPage.get().planOptionName);
                       String strAccumTypeText = seGetText(FindPlanPage.get().accumType);
                       String strAccumNameText = seGetText(BenefitRetainsInProductionPage.get().accumName);
                       String strAccumValueText = seGetElementTextBoxValue(BenefitRetainsInProductionPage.get().dollarLimit);
                       String strBenefitText = seGetText(BenefitRetainsInProductionPage.get().benefitName);
                       String strSituationGroupText = seGetText(BenefitRetainsInProductionPage.get().situationGroup);
                       String strSituationTypeText = seGetText(BenefitRetainsInProductionPage.get().situationType);
                       seCompareStrings(strPlanVersionId, strPlanVersionIdText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strProxyPlanID , strProxyPlanIDText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strEffFromDate , strEffFromDateText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strEffToDate , strEffToDateText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strModifyFromDate , strModifyFromDateText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strModifyToDate , strModifyToDateText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strPlanName , strPlanNameText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strPlanDecription , strPlanDecriptionText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strRepositoryId , strRepositoryIdText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strHeaderType , strHeaderTypeText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strHeaderValue , strHeaderValueText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strPlanOptionArea , strPlanOptionAreaText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strPlanOptionType , strPlanOptionTypeText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strPlanOptionName , strPlanOptionNameText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strAccumType , strAccumTypeText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strAccumName , strAccumNameText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strAccumValue , strAccumValueText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strBenefit , strBenefitText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strSituationGroup , strSituationGroupText, "=", "Comparison between saved criteria and populated criteria values");
                       seCompareStrings(strSituationType, strSituationTypeText, "=", "Comparison between saved criteria and populated criteria values");
                        
				} catch (Exception e) {
                    e.printStackTrace();
                    log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
             }
             finally {
           	  seCloseBrowser();
             }
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null){
				//seCloseBrowser();
			}
			endTestScript();
		}
	}
}