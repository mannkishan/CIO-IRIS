package testScripts.planConfigurator.planActivities;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.BenefitsPage;
//import page.planConfigurator.EditPlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;

//Validate service codes are displayed under Benefits Tab
public class ValidateServiceCode_TS extends CoreSuperHelper{
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	public static void main(String[] args) {
			try {
				initiateTestScript();

				for (iROW = 1; iROW <= getRowCount(); iROW++) {
					try {
						logExtentReport("Validate the Service code for Benefits");
						seOpenBrowser(BrowserConstants.Chrome, baseURL);
						LoginPage.get().loginApplication(userProfile);
						waitForPageLoad();
						
                        seClick(HomePage.get().find, "Find");
						
						seClick(HomePage.get().findPlan, "Find Plan");
                        String planid = getCellValue("PlanID");
						
						seSetText(FindPlanPage.get().planVersionID, planid, "Set text in plan version id");
						waitForPageLoad();
						
						seClick(FindPlanPage.get().planSearch, "Search");
						waitForPageLoad();
						
						
						seClick(PlanOptionsPage.get().clickSearchedPlan, "Click the plan from Search Result");
						waitForPageLoad();
						waitForPageLoad();
						
						
						BenefitsPage.get().wbscrollDownBenefits(); 

						
						waitForPageLoad();
						seClick(BenefitsPage.get().benefitTab, "Benefits Tab");
						waitForPageLoad();
						seClick(BenefitRetainsInProductionPage.get().searchBar, " Benefits search bar");
						
						waitForPageLoad();
						String strbenefit = getCellValue("Benefit");
						seSetText(BenefitsPage.get().searchBenefit, strbenefit, "Filter Urgent care");
						
                        seInputKeys(BenefitRetainsInProductionPage.get().searchBar, KeyConstants.ENTER, " ");
                        waitForPageLoad();
						
						seClick(PlanOptionsPage.get().clickViewServiceCode, "View Service Code box is clicked");
						waitForPageLoad();
						
						
						
						seClick(PlanOptionsPage.get().serviceCodePopup, "Service Code popup");
						waitForPageLoad();
						seIsElementDisplayed(PlanOptionsPage.get().serviceCodePopup, "if 'View Service Code' is clicked then 'Service Code popup' ");
						
						
                        String strservicecodeExp = getCellValue("ServiceCode");
						
						
						
						String strservicecodeAct = seGetText(PlanOptionsPage.get().getServiceCode);
						waitForPageLoad();
						
						//compate exp and act service code
						 String strservicecodedescExp = getCellValue("Description");
						
						String strservicecodedescAct= seGetText(PlanOptionsPage.get().getServiceCodeDescription);
						waitForPageLoad();
					
						PlanOptionsPage.get().strcompareservicecode(strservicecodeExp,strservicecodeAct);
						waitForPageLoad();
						PlanOptionsPage.get().strcompareservicecodedescription(strservicecodedescExp,strservicecodedescAct);
						
					} catch (Exception e) {
						e.printStackTrace();
						log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
					}
					finally {
						seCloseBrowser();
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
				log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
			} finally {
				endTestScript();
			}
		}
}
