package testScripts.planConfigurator.planActivities;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.DentalAccumAndBenefitsPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PCPSPCBreakoutSetupPage;
import page.planConfigurator.VisionAccumAndBenefitsPage;
import utility.CoreSuperHelper;

public class EditAndVerifyDentalAccumAndBenefits_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("Dental Benefits");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
					LoginPage.get().loginApplication(strUserProfile);
					seWaitForClickableWebElement(HomePage.get().find, 10);
					String strPlanID = getCellValue("Plan_Version_ID");
					seClick(HomePage.get().find, "Find");
					seClick(HomePage.get().findPlan, "Find Plan");
					seSetText(FindPlanPage.get().planVersionID, strPlanID, "Enter Plan ID");
					seWaitForClickableWebElement(FindPlanPage.get().planSearch, 30);
					seClick(FindPlanPage.get().planSearch, "Search Plan");
					seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().openClickedPlan, 10);
					seClick(PCPSPCBreakoutSetupPage.get().openClickedPlan, "Search");
					waitForPageLoad();
					seClick(BenefitRetainsInProductionPage.get().editButton, "Edit Button");
					waitForPageLoad(30, 10);
					seClick(BenefitRetainsInProductionPage.get().saveButton, "Save");
					waitForPageLoad();
					
					DentalAccumAndBenefitsPage.get().seIsDentalPlanOptionsVisible();
					DentalAccumAndBenefitsPage.get().seIsDentalBenefitOptionsVisible();
					

				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occurred for the iteration", e.getLocalizedMessage());
				} finally {
					BenefitRetainsInProductionPage.get();
					BenefitRetainsInProductionPage.seTearDown();
					//seCloseBrowser();
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occurred for the script execution", e.getLocalizedMessage());
		} finally {
			//seCloseBrowser();
			endTestScript();
		}

	}

}
