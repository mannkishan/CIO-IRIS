package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.AllergySerumBenefitOptionPage;
import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PCPSPCBreakoutSetupPage;
import utility.CoreSuperHelper;
/**
 * Manual test case: Verify that the Accumulator Group Types and Accumulator names are available for the Benefit Allergy Serum  
 * @author AF16391
 * @since 08/21/2017
 *
 */
public class VerifyAllergySerumAccumVisibleInBenefitOptionsPage_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {

					logExtentReport("Allergy Serum Accumulator Visisbility");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
					LoginPage.get().loginApplication(strUserProfile);
					seWaitForClickableWebElement(HomePage.get().find, 10);
					String strPlanID = getCellValue("Plan_ID");
					seClick(HomePage.get().find, "Find");
					seClick(HomePage.get().findPlan, "Find Plan");
					seSetText(FindPlanPage.get().planVersionID, strPlanID, "Enter Plan ID");
					seWaitForClickableWebElement(FindPlanPage.get().planSearch, 30);
					seClick(FindPlanPage.get().planSearch, "Search Plan");
					seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().openClickedPlan, 10);
					seClick(PCPSPCBreakoutSetupPage.get().openClickedPlan, "Search");
					waitForPageLoad(30, 30);
					seClick(BenefitRetainsInProductionPage.get().editButton, " edit");
					waitForPageLoad();
					seClick(BenefitRetainsInProductionPage.get().saveButton, " save");
					waitForPageLoad(30, 30);
					seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().scrollDown, 20);
					seClick(PCPSPCBreakoutSetupPage.get().scrollDown, "Scroll Down");
					seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().scrollDown, 20);
					seClick(PCPSPCBreakoutSetupPage.get().scrollDown, "Scroll Down");
					waitForPageLoad(10, 10);
					seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().benefitOptions, 50);
					seClick(PCPSPCBreakoutSetupPage.get().benefitOptions, "Benefit Options");
					waitForPageLoad(30, 10);
					seWaitForClickableWebElement(AllergySerumBenefitOptionPage.get().allergySerum, 30);
					seClick(AllergySerumBenefitOptionPage.get().allergySerum, "Allergy Serum");
					if (AllergySerumBenefitOptionPage.get().seCheckIsElementNotSelected(
							AllergySerumBenefitOptionPage.get().allergySerumCoveredINNOON,
							"Covered In Network Out of Network")) {
						seWaitForClickableWebElement(AllergySerumBenefitOptionPage.get().allergySerumCoveredINNOON, 30);
						seClick(AllergySerumBenefitOptionPage.get().allergySerumCoveredINNOON,
								"Covered In Network Out of Network");
						seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().savePage, 30);
						seClick(PCPSPCBreakoutSetupPage.get().savePage, "Save");
						seWaitForClickableWebElement(AllergySerumBenefitOptionPage.get().allergySerum, 30);
						seClick(AllergySerumBenefitOptionPage.get().allergySerum, "Allergy Serum");

						/* Covered In Network Out of Network starts here */
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage.get().allergySerumCoveredINNOONName,
								getCellValue("CoveredINNOON"));

						/* In Network Cost Shares Facility */
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage.get().allergySerumCoveredINNOONINNCostSharesFacilityName,
								getCellValue("CoveredINNOONINCostSharesFac"));
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage
										.get().allergySerumCoveredINNOONINNCostSharesFacilityPaidPlnLvlName,
								getCellValue("CoveredINNOONPaidAsPlnLvl"));
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage
										.get().allergySerumCoveredINNOONINNCostSharesFacilityBenSpecCoShareName,
								getCellValue("CoveredINNOONBenSpecCostShr"));

						/* Out of Network Cost Shares Facility */
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage.get().allergySerumCoveredINNOONOONCostSharesFacilityName,
								getCellValue("CoveredINNOONOONCostSharesFac"));
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage
										.get().allergySerumCoveredINNOONINNCostSharesFacilityPaidPlnLvlName,
								getCellValue("CoveredINNOONOONCostSharesFacPaidAsPlnLvl"));
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage
										.get().allergySerumCoveredINNOONINNCostSharesFacilityBenSpecCoShareName,
								getCellValue("CoveredINNOONOONCostSharesFacBenSpecCostShares"));

						/* In Network Cost Shares Professional */
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage.get().allergySerumCoveredINNOONINNCostSharesProfName,
								getCellValue("INNOONINNCostSharesProfName"));
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage
										.get().allergySerumCoveredINNOONINNCostSharesProfPaidPlnLvlName,
								getCellValue("INNOONINNCostSharesProfPaidPlnLvlName"));
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage
										.get().allergySerumCoveredINNOONINNCostSharesProfFolwOffcAdminName,
								getCellValue("INNOONINNCostSharesProfFolwOffcAdminName"));
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage
										.get().allergySerumCoveredINNOONINNCostSharesProfBenSpecCoShareName,
								getCellValue("INNOONINNCostSharesProfBenSpecCoShareName"));

						/* Out of Network Cost Shares Professional */
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage.get().allergySerumCoveredINNOONOONCostSharesProfName,
								getCellValue("INNOONOONCostSharesProfName"));
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage
										.get().allergySerumCoveredINNOONOONCostSharesProfPaidPlnLvlName,
								getCellValue("INNOONOONCostSharesProfPaidPlnLvlName"));
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage
										.get().allergySerumCoveredINNOONOONCostSharesProfBenSpecCoShareName,
								getCellValue("INNOONOONCostSharesProfBenSpecCoShareName"));
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage
										.get().allergySerumCoveredINNOONOONCostSharesProfNotCoveredName,
								getCellValue("INNOONOONCostSharesProfNotCoveredName"));
						/* Covered In Network Out of Network ends here */

					} else {
						seWaitForClickableWebElement(AllergySerumBenefitOptionPage.get().allergySerumCoveredINNOnly,
								30);
						seClick(AllergySerumBenefitOptionPage.get().allergySerumCoveredINNOnly,
								"Covered In Network Only");
						seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().savePage, 30);
						seClick(PCPSPCBreakoutSetupPage.get().savePage, "Save");
						seWaitForClickableWebElement(AllergySerumBenefitOptionPage.get().allergySerum, 30);
						seClick(AllergySerumBenefitOptionPage.get().allergySerum, "Allergy Serum");

						/* Covered In Network Only starts here */
						/* In Network Cost Shares Facility */
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage.get().allergySerumINNOnlyINCostSharesFacName,
								getCellValue("INNOnlyINCostSharesFacName"));
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage.get().allergySerumINNOnlyINCostSharesFacPaidPlnLvlName,
								getCellValue("INNOnlyINCostSharesFacPaidPlnLvlName"));
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage
										.get().allergySerumINNOnlyINCostSharesFacBenSpecCoShareName,
								getCellValue("INNOnlyINCostSharesFacBenSpecCoShareName"));

						/* In Network Cost Shares Professional */
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage.get().allergySerumINNOnlyINCostSharesProfName,
								getCellValue("INNOnlyINCostSharesProfName"));
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage.get().allergySerumINNOnlyINCostSharesProfPaidPlnLvlName,
								getCellValue("INNOnlyINCostSharesProfPaidPlnLvlName"));
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage
										.get().allergySerumINNOnlyINCostSharesProfFolwOffcAdminName,
								getCellValue("INNOnlyINCostSharesProfFolwOffcAdminName"));
						AllergySerumBenefitOptionPage.seIsAccumulatorNameVisible(
								AllergySerumBenefitOptionPage
										.get().allergySerumINNOnlyINCostSharesProfBenSpecCoShareName,
								getCellValue("INNOnlyINCostSharesProfBenSpecCoShareName"));
						/* Covered In Network Only ends here */
					}

					seClick(BenefitRetainsInProductionPage.get().deleteButton, "Deleting the Plan");
					waitForPageLoad();
					seClick(BenefitRetainsInProductionPage.get().yesButton, "Selected Yes");
					waitForPageLoad();

					seCloseBrowser();
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			seCloseBrowser();
			endTestScript();
		}

	}

}
