package testScripts.planConfigurator.planActivities;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

//import page.planConfigurator.EditPlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import utility.CoreSuperHelper;

//Validate service codes are displayed under Benefits Tab
public class ValidateSavenCheckValidation_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("Validate the Service code for Benefits");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);
					waitForPageLoad();

					seClick(HomePage.get().find, "Find");

					seClick(HomePage.get().findPlan, "Find Plan");
					String planid = getCellValue("PlanID");

					seSetText(FindPlanPage.get().planVersionID, planid, "Set text in plan version id");
					waitForPageLoad();
					seClick(FindPlanPage.get().planSearch, "Search");
					waitForPageLoad();
					seClick(PlanOptionsPage.get().clickSearchedPlan, "Searched Plan");
					waitForPageLoad();
					seClick(PlanSetupPage.get().checkValidation, "Check validation");
					waitForPageLoad();
					seClick(PlanSetupPage.get().validationMsg, "Validtaion Passed Display");
					waitForPageLoad();
					seIsElementDisplayed(PlanSetupPage.get().validationMsg,
							"'Validation Passed' green band");
					waitForPageLoad();
					seClick(PlanSetupPage.get().innTier1Network, "In Network Tier1 Network");
					
					seClick(PlanSetupPage.get().innTier1Networkinput, "In Network Tier1 Network Input");
					
					seClick(PlanSetupPage.get().innTier1NetworkEnter, "In Network Tier1 Network Enter");

					
					seClick(PlanOptionsPage.get().saveButton, "Save");
					waitForPageLoad(100);
					
					seWaitForClickableWebElement(PlanSetupPage.get().checkValidation, 10);
					seClick(PlanSetupPage.get().checkValidation, "Check validation");
					waitForPageLoad(10);
					

					seClick(PlanSetupPage.get().errorMessage, "Error message display");
					waitForPageLoad();
					seIsElementDisplayed(PlanSetupPage.get().errorMessage,
							"Due to error message 'red band'");
					waitForPageLoad();

					seClick(PlanSetupPage.get().innTier1Network, "In Network Tier1 Network");
					
					seClick(PlanSetupPage.get().innTier1Networkinput, "In Network Tier1 Network Input");
					
					seClick(PlanSetupPage.get().innTier1NetworkEPO, "In Network Tier1 Network Enter");

					waitForPageLoad();
					seClick(PlanOptionsPage.get().saveButton, "Save");
					waitForPageLoad();
					seClick(PlanSetupPage.get().checkValidation, "Check validation");
					waitForPageLoad();

					
					seClick(PlanSetupPage.get().validationMsg, "Validtaion Passed Diplay");
					waitForPageLoad();
					seIsElementDisplayed(PlanSetupPage.get().validationMsg,
							"'Validation Passed' green band");
					waitForPageLoad();
					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					 seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
