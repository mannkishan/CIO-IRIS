package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.CreateLegacyPlanPage;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PCPSPCBreakoutSetupPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;
/**
 * Manual test case: Create Legacy Plan :
 * This Test script checks When the user selects �Approve� audit, the system will redirect user to a Plan Transition screen entitled �Approve Audit Information� and the plan status is updated to "Approved Audit"
 
 * @author AF48638
 * @since 10-October-2017
 *
 */

public class VerifyApproveAuditFunctionality_TS extends CoreSuperHelper {
	
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");

	public static void main(String[] args) {

		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("verify approved audit functionality");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
                    LoginPage.get().loginApplication(strUserProfile);
					seWaitForElementLoad(CreatePlanPage.get().homepage);
					waitForPageLoad();
                    CreateLegacyPlanPage.seCreatePlan(false, 10);
                    waitForPageLoad();
					CreateLegacyPlanPage.seCreateLegacyPlan();
                    seClick(PlanHeaderPage.get().save, "Save button");
                    seWaitForPageLoad(60);
                    String strPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
					waitForPageLoad();
					String strPlanProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
					waitForPageLoad();
					setCellValue("LegacyPlanID", strPlanVersionID);
					setCellValue("LegacyProxyID", strPlanProxyID);
					seWaitForClickableWebElement(PlanHeaderPage.get().requestAudit,1);
					seClick(PlanHeaderPage.get().requestAudit, "request Audit button");
					waitForPageLoad();
					PlanTransitionPage.get().updateReasonCode("Other");
					seClick(PlanTransitionPage.get().requestAudit, "Request Audit button");
					waitForPageLoad();
					try{
						seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 360);
					    }
					catch(TimeoutException e){
			            seClick(PlanHeaderPage.get().close, "Close button");
			            }
					seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
					waitForPageLoad();
					seClick(PlanHeaderPage.get().userLogout, "Logout");
					waitForPageLoad(20,10); 
					seCloseBrowser();
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
					LoginPage.get().loginApplication(strUserProfileApprover);
					waitForPageLoad();
					String strLegacy = getCellValue("LegacyPlanID");
					seClick(HomePage.get().find, "Find");
                    seClick(HomePage.get().findPlan, "Find Plan");
					seSetText(FindPlanPage.get().planVersionID,strLegacy, "Set text in plan version id");
					waitForPageLoad();
					seClick(FindPlanPage.get().planSearch, "Search");
					waitForPageLoad();
					WebElement objSearch = FindPlanPage.get().selectSearchedPlan;
                    ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objSearch);
					
					 Boolean blnStatusPendingAudit= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
					 
					 if(blnStatusPendingAudit==true){
							log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");
						}
						else { 
							throw new TimeoutException("Plan is not in Pending Audit status");
						}	
					
					 seClick(PlanHeaderPage.get().approveAudit, "Approve Audit");
						waitForPageLoad(30);
						seWaitForElementLoad(BenefitRetainsInProductionPage.get().planTransitionPage);
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().planTransitionPage,
								"Plan Transition page");
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().approveAuditInformation,
								"Approve Audit Information");

						seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ENTER);
						
						seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, 10);
						seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
						seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeText, 1);
						
						seSetText(PlanTransitionPage.get().planTransitionReasonCodeText, "Approved", "as " + "Approved");
						seClick(PlanTransitionPage.get().approved, "approved reason code");
						seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
						waitForPageLoad(45);
						
						Boolean blnstatusApprovedAudit=PlanHeaderPage.get().seVerifyPlanStatus("Approved Audit");
						
						if(blnstatusApprovedAudit==true){
							log(PASS, "plan takes correct time to load","plan is in Approved Audit status,RESULT=PASS");
						}
						else { 
							throw new TimeoutException("Plan is not in Approved Audit status");
							  }	
						seIsElementDisplayed(PlanHeaderPage.get().moveToTestPHPage, "Move to test Button ");
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().deleteButton, "Delete Button ");
						seIsElementDisplayed(PCPSPCBreakoutSetupPage.get().copyButton, "Copy Button ");
						seIsElementDisplayed(PlanHeaderPage.get().close, "close Button ");
						
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}finally{
					seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}

}
