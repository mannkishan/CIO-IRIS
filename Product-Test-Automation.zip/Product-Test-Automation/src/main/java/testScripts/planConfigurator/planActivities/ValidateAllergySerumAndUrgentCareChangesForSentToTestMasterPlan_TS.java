package testScripts.planConfigurator.planActivities;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.AllergySerumBenefitOptionPage;
import page.planConfigurator.BenefitsPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.UrgentCarePlanOptionPage;
import utility.CoreSuperHelper;

/**
 * This script Rejects a 'Sent to Test' Master Plan and creates another plan through 'Edit' option.  
 * The Urgent Care and Allergy Serum accumulator values are then updated and 'Request Audit' is done.
 * The values updated are now verified in respective tabs and also in Benefits tab. 
 * @author AF13762
 * */
public class ValidateAllergySerumAndUrgentCareChangesForSentToTestMasterPlan_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strNewPlanVersionId;
	
	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strPlanVersionId = getCellValue("Plan_Version_ID");
					String strUrgentCareApplyDeductible = getCellValue("UC_ApplyDeductible");
					String strUrgentCareCoinsurance = getCellValue("UC_CoInsurancePerc");
					String strUrgentCareCopayAmount = getCellValue("UC_CoPayAmt");
					String strAllergySerumApplyDeductible = getCellValue("AS_ApplyDeductible");
					String strAllergySerumCoinsurance = getCellValue("AS_CoInsurancePerc");
					
					if (getCellValue("Run_Flag").equalsIgnoreCase("YES")) {
						logExtentReport("Verify Allergy Serum and Urgent Care changes for Sent to Test Master Plan");
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
						LoginPage.get().loginApplication(strUserProfile);
						FindPlanPage.get().seNavigateToSearchPlanPage();
						FindPlanPage.get().seSearchByPlanVersionID(strPlanVersionId);
						FindPlanPage.get().seOpenFirstPlanFromFindPlanResults();
						PlanHeaderPage.get().seRejectTest();
						PlanHeaderPage.get().seEditPlan();
						strNewPlanVersionId = (seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1]).trim();
						UrgentCarePlanOptionPage.get().seUpdateUrgentCare(strUrgentCareApplyDeductible, strUrgentCareCoinsurance, strUrgentCareCopayAmount);
						AllergySerumBenefitOptionPage.get().seUpdateAllergySerum(strAllergySerumApplyDeductible, strAllergySerumCoinsurance);
						PlanHeaderPage.get().requestAuditPlan(strNewPlanVersionId, 60);
						UrgentCarePlanOptionPage.get().seVerifyUrgentCareValues(strUrgentCareApplyDeductible, strUrgentCareCoinsurance, strUrgentCareCopayAmount);
						AllergySerumBenefitOptionPage.get().seVerifyAllergySerumValues(strAllergySerumApplyDeductible, strAllergySerumCoinsurance);
						BenefitsPage.get().seVerifyUrgentCareValuesInBenefits(strUrgentCareCopayAmount, strUrgentCareCoinsurance);
						BenefitsPage.get().seVerifyAllergySerumValuesInBenefits(strAllergySerumCoinsurance);
						PlanHeaderPage.get().seClosePlan();
						setResult("STATUS", RESULT_STATUS);
					}
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					seCloseBrowser();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}

	}
	
}