package testScripts.planConfigurator.planActivities;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.BenefitsPage;
//import page.planConfigurator.EditPlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;

//Validate when making a change to the numeric values for coinsurance /deductible/limits
//saving, they are retained on the plan and in the benefits	

public class VerifyUpdateDedCoinsuLimit_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("Update Coinsurance and Detectible limit in Benefits Tab, Save, check the edits have been updated ");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);

					waitForPageLoad();
					seClick(HomePage.get().find, "Find");

					seClick(HomePage.get().findPlan, "Find Plan");
					waitForPageLoad();
					String planid = getCellValue("PlanID");

					seSetText(FindPlanPage.get().planVersionID, planid, "Set text in plan version id");
					waitForPageLoad();

					seClick(FindPlanPage.get().planSearch, "Search");

					waitForPageLoad();
					seClick(PlanOptionsPage.get().planSearchSelect, "Filtered Plan");
					
					waitForPageLoad();
					// ----------------------------------------------------------------------------------------------

					// @PlanLevelBenefitsPage
					waitForPageLoad();
					seClick(PlanLevelBenefitsPage.get().planLevelBenefits, "PlanLevel benefits");
					waitForPageLoad();
					seClick(PlanLevelBenefitsPage.get().deductibleTab, "Deductible Tab");
					String strinnIndvalueExp = seGetText(PlanLevelBenefitsPage.get().innindDedfield);
					waitForPageLoad(100);

					String strinnFamvalueExp = seGetText(PlanLevelBenefitsPage.get().innFamDedfield);
					waitForPageLoad(100);

					// *********************************************************************************************************************

					for (int j = 1; j <= 2; j++) {
						seClick(BenefitsPage.get().firstScroll, "Scroll down");

					}

					// @PlanOptionsPage
					seClick(PlanOptionsPage.get().planOptions, "Plan Options");

					waitForPageLoad();

					seClick(PlanOptionsPage.get().urgentCare, "Urgent care");

					waitForPageLoad(200);
					seClick(BenefitsPage.get().MainScrollDown, "Main Scroll Down");

					seClick(PlanOptionsPage.get().benefitSpecificINNRadioBtn, "Benefit Specific Cost Shares");

					waitForPageLoad();
					BenefitsPage.get().scroll();
					seClick(PlanOptionsPage.get().applyDeductible, "Apply Deductible");

					waitForPageLoad();

					seClick(PlanOptionsPage.get().applyDeductibleText, "Input Field Apply Deductible");
					String strapplyded = getCellValue("Applyded");
					seSetText(PlanOptionsPage.get().applyDeductibleText, strapplyded, "Input value Apply deductible");

					seClick(PlanOptionsPage.get().applyDeductibleYes, "Select value Apply Deductible");
					waitForPageLoad();
					// ----------------------------------------------------------------------------------------------------
					BenefitsPage.get().scroll();

					seClick(PlanOptionsPage.get().innUrgentCare, "INNUrgentCare Facility");
					seClick(PlanOptionsPage.get().innUrgentCareText, "Input Field INNUrgentCare Facility");
					String strinnurgentcare = getCellValue("innUrgentcare");
					seSetText(PlanOptionsPage.get().innUrgentCareText, strinnurgentcare,
							"Set percentage in INNUrgentCare Facility");

					seClick(PlanOptionsPage.get().collapseInputField, "Input value ");
					String strinputpercentage = seGetText(PlanOptionsPage.get().percentageInputField);

					seClick(PlanOptionsPage.get().innUrgCareFacCopay, "Input Field INNUrgCareFacCopay");
					String strinnurgentcarecopay = getCellValue("innUrgentcareCopay");
					seSetText(PlanOptionsPage.get().innUrgCareFacCopayAmount, strinnurgentcarecopay,
							"Enter In Network Urgent care Facility Copay Amount");
					waitForPageLoad(100);

					seClick(PlanOptionsPage.get().innUrgCareFacCopayEnter, "Input Field INNUrgCareFacCopay");
					waitForPageLoad();
					String strinputamountexp = seGetText(PlanOptionsPage.get().innUrgCareFacCopayText);
					waitForPageLoad();

					seClick(PlanOptionsPage.get().saveButton, "Save Button to save the changes made");
					// **************************************************************************************************

					waitForPageLoad(200);
					waitForPageLoad(200);

					BenefitsPage.get().wbscrollDownBenefits(); 


					// @Benefits Tab
					waitForPageLoad();
					seClick(BenefitsPage.get().benefitTab, "Benefits Tab");
					waitForPageLoad();
					seClick(BenefitRetainsInProductionPage.get().searchBar, " Benefits search bar");

					waitForPageLoad();
					String strbenefit = getCellValue("Benefit");
					seSetText(BenefitsPage.get().searchBenefit, strbenefit, "Filter Urgent care");
					seInputKeys(BenefitRetainsInProductionPage.get().searchBar, KeyConstants.ENTER, " ");
                    waitForPageLoad();
                    
                    seClick(BenefitRetainsInProductionPage.get().tierIcon, " tier1 icon");
					
					BenefitsPage.get().scroll();
					// ----------------------------------------------------------------------------------------

					// check copayment is $2500

					String strcopaymentAct = seGetText(BenefitsPage.get().copaymentText);

					waitForPageLoad();

					waitForPageLoad();
					seCompareStrings(strinputamountexp, strcopaymentAct, "=", "Comparison between 'Copayment' in Plan Level Benefits tab and Benefits tab");
					waitForPageLoad();

					// ----------------------------------------------------------------------------------------

					// Checking deductible

					String strinnIndvalueAct = seGetText(BenefitsPage.get().innDedFirst);
					waitForPageLoad();

					String strinnFamvalueAct = seGetText(BenefitsPage.get().innDedSecond);
					waitForPageLoad();
					seCompareStrings(strinnIndvalueExp, strinnIndvalueAct, "=", "Comparison between 'In Network Deductible' in Plan Level Benefits tab and Benefits tab");
					waitForPageLoad();
					seCompareStrings(strinnFamvalueExp, strinnFamvalueAct, "=", "Comparison between 'In Network Family Deductible' in Plan Level Benefits tab and Benefits tab");
					// --------------------------------------------------------------------------------------------
					// cheking coinsurance
					String strcoinsurance = seGetText(BenefitsPage.get().innUrgCareFacCoinsurTextBenefit);
					waitForPageLoad();
					
					seCompareStrings(strinputpercentage, strcoinsurance, "=", "Comparison between 'In Network Urgent Care Facility Coinsurance' in Plan Level Benefits tab and Benefits tab");
					waitForPageLoad();
					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} 
					 finally { 
						 seCloseBrowser(); 
						 }
					 

			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}

		/*
		 * public static void scrollToBottom(WebElement benefitType, String
		 * str){ boolean flag = false; while((flag==false &&
		 * !EditPlanPage.get().benefitTab.isDisplayed()) ||
		 * seIsElementDisplayed(benefitType, benefitType +
		 * " Element is displayed to Click")) {
		 * seClick(EditPlanPage.get().firstScroll, "To Scroll down the pane"); }
		 * 
		 * if (seClick(benefitType, str)) flag = true;
		 * 
		 * if(flag==false){ log(ERROR, "No Such " + benefitType +
		 * " button exists to click"); } }
		 */
	}
}