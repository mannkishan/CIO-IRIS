package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.groupConfigurator.LoginPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanSetupPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;

public class ValidateLifeCycleOfPlanByUpdatingCoinsurance_TS extends CoreSuperHelper {

	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static String userProfileApprover = EnvHelper.getValue("user.profile.approver");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					
				logExtentReport("Test Script/ Functionality Descrtiption");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);
					waitForPageLoad();
					
					FindPlanPage.seSearchByPlanProxyID(getCellValue("Plan_ID"));
					waitForPageLoad();
					
					Boolean status=PlanHeaderPage.get().seVerifyPlanStatus("Production");
					
				
					if(status==true){
						log(PASS, "plan takes correct time to load","plan is in Production status,RESULT=PASS");
					}
					else { 
						throw new TimeoutException("Plan is not in Production status");
						  }	
					
					seClick(PlanSetupPage.get().editPlan, "edit");
					waitForPageLoad();
					
					seClick(PlanSetupPage.get().savePlan, "edit save");
					waitForPageLoad(45);
					seWaitForClickableWebElement(FindPlanPage.get().clickPlanLevelBenefit, 22);
					seClick(FindPlanPage.get().clickPlanLevelBenefit,"plan level benefit");
					waitForPageLoad();
					String strCoin=getCellValue("Coinsurance_Value");
					PlanLevelBenefitsPage.updateCoinsuranceValue(strCoin);
					waitForPageLoad();
					
					seClick(PlanHeaderPage.get().save, "Save button");
					waitForPageLoad(45);
					seWaitForClickableWebElement(PlanHeaderPage.get().requestAudit, 5);
					seClick(PlanHeaderPage.get().requestAudit, "request Audit");
					waitForPageLoad();
					
					PlanTransitionPage.get().updateReasonCode("Other");
					seClick(PlanTransitionPage.get().requestAudit, "Request Audit button");
					waitForPageLoad();

					
					try{seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 360);				
					    }
					
					catch(TimeoutException e){
			            seClick(PlanHeaderPage.get().close, "Close button");
			            waitForPageLoad();
			            }
					
				    seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
					waitForPageLoad();
					
					seClick(PlanHeaderPage.get().userLogout, "Logout");
					waitForPageLoad(); 
					
					seCloseBrowser();
			       
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
                    LoginPage.get().loginApplication(userProfileApprover);
					waitForPageLoad();
					
					FindPlanPage.seSearchByPlanProxyID(getCellValue("Plan_ID"));
					waitForPageLoad(45);
					
					 Boolean auditStatus= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
					 
					 if(auditStatus==true){
							log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");
						}
						else { 
							throw new TimeoutException("Plan is not in Pending Audit status");
						}	
							
                        seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 10);
					    seClick(PlanHeaderPage.get().approveAudit, "Approve Audit");
						waitForPageLoad(30);
						
						seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ENTER);
						
						seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, 10);
						seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
						seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeText, 1);
						
						seSetText(PlanTransitionPage.get().planTransitionReasonCodeText, "Approved", "as " + "Approved");
						seClick(PlanTransitionPage.get().approved, "approved reason code");
						seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
						waitForPageLoad(45);
						seWaitForClickableWebElement(PlanHeaderPage.get().moveToTestPHPage, 12);
						seClick(PlanHeaderPage.get().moveToTestPHPage, "Move to test button");
						waitForPageLoad();
						seClick(PlanTransitionPage.get().moveToTest, "Move to test ");
						waitForPageLoad(45);
						seWaitForClickableWebElement(PlanHeaderPage.get().approveTestForFinalize, 12);
						seClick(PlanHeaderPage.get().approveTestForFinalize, "Approve test button");
						waitForPageLoad();
						
						seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "reason code");
						seClick(PlanTransitionPage.get().approved,"approved");
						seClick(PlanTransitionPage.get().approvedTest, "approve test");
						waitForPageLoad(45);
						seWaitForClickableWebElement(PlanHeaderPage.get().finalize, 12);
						seClick(PlanHeaderPage.get().finalize, "Finalize");
						waitForPageLoad();
						
						seClick(PlanTransitionPage.get().finalizeButtoninPT, "finalize");
						waitForPageLoad();
						
                    	try{
                    		seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 300);
                    		}
						
						catch(TimeoutException e){
				            seClick(PlanHeaderPage.get().close, "Close button");
							waitForPageLoad();
 
				            }
						
        				((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);
						waitForPageLoad(45);
						
                        Boolean finalStatus= PlanHeaderPage.get().seVerifyPlanStatus("Production");
					 
                        if(finalStatus==true){
	                          	log(PASS, "plan takes correct time to load","plan is in Production status,RESULT=PASS");
	                                     }
	                    else { 
	                    	throw new TimeoutException("Plan is not in Production status");
	                          }	

                         waitForPageLoad();
					     seClick(FindPlanPage.get().clickPlanLevelBenefit,"plan level benefit");
					     waitForPageLoad();
					     
					    String strCoinsuranceValue =seGetText(PlanSetupPage.get().getCoinsValue);
						log(strCoinsuranceValue.equalsIgnoreCase(strCoin+"%") ? PASS : FAIL,"Verify coinsurance value", "coinsurance value  is " + getCellValue("Coinsurance_Value")+ "Actual value is " + strCoinsuranceValue,	true); 
					

					     seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
					     seClick(PlanHeaderPage.get().userLogout, "Logout");


				}
                  catch(TimeoutException e){
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());

				}
				catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
				
				finally{
					seCloseBrowser();
				}
			
		}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}

	}
