package testScripts.planConfigurator.planActivities;

import java.io.File;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import com.anthem.selenium.utility.ExtentReportsUtility;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import utility.CoreSuperHelper;

public class CreateMasterPlan_TS extends CoreSuperHelper{
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	public static void main(String[] args) {
			try {
				initiateTestScript();

				for (iROW = 1; iROW <= getRowCount(); iROW++) {
					try {
						logExtentReport("Create a Master Plan");
//						seOpenBrowser(BrowserConstants.Chrome, baseURL);
//						LoginPage.get().loginApplication(userProfile);
//						waitForPageLoad();
////						createPlan(true);
//						seClick(HomePage.get().find, "Find");
//						seClick(HomePage.get().findPlan, "Find Plan");
//						waitForPageLoad();
//						seSetText(FindPlanPage.get().planVersionID, "1555090404", "Set text in plan version id");
//						seClick(FindPlanPage.get().planSearch, "Search");
//						waitForPageLoad();
						//FindPlanPage.get().selectPlanFromResults("1555090404");
						
						
					} catch (Exception e) {
						e.printStackTrace();
						log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
					}
					finally {
//						seCloseBrowser();
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
				log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
			} finally {
				endTestScript();
			}
		}
}
