package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

//import page.planConfigurator.EditPlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import utility.CoreSuperHelper;
//Verify when in the process of configuring a plan, prior to requesting an Audit,
//a message is displayed when clicking the 'Check Validation' button, and required fields have not been populated
//Verify when clicking 'Check Validation' and required fields are missing, 
//each warning message includes a link that will navigate directly to the field referenced in the message
public class ValidateSavenCheckValidationNavigation_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("Validate the Save and check Validation, Navigation");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);
					waitForPageLoad();

					seClick(HomePage.get().find, "Find");

					seClick(HomePage.get().findPlan, "Find Plan");
					String planid = getCellValue("PlanID");

					seSetText(FindPlanPage.get().planVersionID, planid, "Set text in plan version id");
					waitForPageLoad();
					seClick(FindPlanPage.get().planSearch, "Search");
					waitForPageLoad();
					seClick(PlanOptionsPage.get().clickSearchedPlan, "Searched Plan");
					waitForPageLoad();
					seClick(PlanSetupPage.get().checkValidation, "Check validation");
					waitForPageLoad(10);
					seIsElementDisplayed(PlanSetupPage.get().errorDisplay,"Due to error message 'red band'");
					waitForPageLoad();
                
					//Validating that an error message is displayed if a required fields have not been populated
					
					String strFirstErrorValueExpected ="{Product Definition Error} (Accumulator) In Network Pediatric Vision Coinsurance, percentage is required field" ;
					PlanSetupPage.get().seCheckErrorMessage(strFirstErrorValueExpected);
					waitForPageLoad();
					String strSecondErrorValueExpected ="{Product Definition Error} (Accumulator) Out of Network Pediatric Vision Coinsurance, percentage is required field" ;
					PlanSetupPage.get().seCheckErrorMessage(strSecondErrorValueExpected);
					
					//Verify that each warning message includes a link that will navigate directly to the field referenced in the message
					waitForPageLoad();
					PlanSetupPage.get().seCheckErrorMessageLink(strFirstErrorValueExpected, strSecondErrorValueExpected);
					
					
				
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					 seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
