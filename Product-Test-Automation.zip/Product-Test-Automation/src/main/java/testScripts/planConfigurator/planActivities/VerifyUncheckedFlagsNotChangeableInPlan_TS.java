package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.JavascriptExecutor;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreateVisionMasterProductTemplate;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.CreateTemplatePage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PCPSPCBreakoutSetupPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.TemplateCreation;
import page.planConfigurator.UncheckedFlagAttributeVisiblePage;
import utility.CoreSuperHelper;

public class VerifyUncheckedFlagsNotChangeableInPlan_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
			try {
					//MPRO-1944
					//[Verify template configurations will control which levels of the Plan (Plan Option Areas, Types, Name, Accumulator Groups, Accumulators, and Accumulator attributes) are changeable when configuring a Plan]
					//MPRO-2404 && MPRO-3146
					//[Verify that the Visibility and Changeability flags will exist for each benefit attribute on the benefit details screen with the exception of Accumulator Reference]
					//MPRO-1945
					//[Verify If the changeable checkbox is deselected at the Plan Option Type level, none of the associated (child) attributes/accumulators will be changeable on the Plan even though the changeable checkboxes are still checked in the Template.]
					logExtentReport("Test Script/ Functionality Description");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL, "testscripts");
					LoginPage.get().loginApplication(strUserProfile);
					waitForPageLoad(65);									
					CreateVisionMasterProductTemplate.get().seCreateVisionTemplate();					
					UncheckedFlagAttributeVisiblePage.get().seUncheckTemplateLevelBenefitsVision();					
					UncheckedFlagAttributeVisiblePage.get().seVisionAttributesVisibleNotChangeable();
					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occurred for the iteration", e.getLocalizedMessage());
				} finally {
					 seCloseBrowser();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occurred for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}

	}
}
