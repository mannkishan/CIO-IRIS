package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.AllergySerumBenefitOptionPage;
import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PCPSPCBreakoutSetupPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanTransitionPage;
import page.planConfigurator.UrgentCarePlanOptionPage;
import utility.CoreSuperHelper;
/**
 * Manual test case: Verify when an existing plan in Production status is copied the plan should successfully create a new version of the plan in draft status and finalize through the new flow.

 * <p>
 * Test script template
 * <p>
 * Please refer this test script while creating other test scripts
 * 
 * @author AF48638
 * @since 10-October-2017
 *
 */
public class CopyCreateProductionPlan_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {

					logExtentReport("Copy create a production plan");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
					LoginPage.get().loginApplication(strUserProfile);
					seWaitForClickableWebElement(HomePage.get().find, 10);
					String strPlanID = getCellValue("Plan_ID");
					seClick(HomePage.get().find, "Find");
					seClick(HomePage.get().findPlan, "Find Plan");					
					seSetText(FindPlanPage.get().planVersionID, strPlanID, "Enter Plan ID");									
					seWaitForClickableWebElement(FindPlanPage.get().planSearch, 30);
					seClick(FindPlanPage.get().planSearch, "Search Plan");
					seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().openClickedPlan, 10);
					seClick(PCPSPCBreakoutSetupPage.get().openClickedPlan, "Search");
					waitForPageLoad(30,10);
					Boolean blnstatus=PlanHeaderPage.get().seVerifyPlanStatus("Production");
					
					if(blnstatus==true){
						log(PASS, "plan takes correct time to load","plan is in Production status,RESULT=PASS");
					}
					else { 
						throw new TimeoutException("Plan is not in Production status");
						  }	
					/*Copying a MP plan*/
					seClick(PCPSPCBreakoutSetupPage.get().copyButton, "copy button");
					waitForPageLoad(30,10);
					seClick(PCPSPCBreakoutSetupPage.get().createButton, "create button");
					waitForPageLoad(45,20);
					String strPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
					seWaitForPageLoad();
					setCellValue("LegacyPlanID", strPlanVersionID);
					Boolean blnstatusDraft=PlanHeaderPage.get().seVerifyPlanStatus("Draft");
					if(blnstatusDraft==true){
						log(PASS, "plan takes correct time to load","plan is in Draft status,RESULT=PASS");
					}
					else { 
						throw new TimeoutException("Plan is not in Draft status");
					}
					seClick(FindPlanPage.get().clickPlanLevelBenefit,"plan level benefit");
					String strCoin=getCellValue("Coinsurance_Value");
					PlanLevelBenefitsPage.updateCoinsuranceValue(strCoin);
					waitForPageLoad();
					seClick(PlanHeaderPage.get().save, "Save button");
					waitForPageLoad(45);
					seClick(PlanHeaderPage.get().requestAudit, "request Audit");
					waitForPageLoad();
					
					PlanTransitionPage.get().updateReasonCode("Other");
					seClick(PlanTransitionPage.get().requestAudit, "Request Audit button");
					waitForPageLoad();

					
					try{seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 360);
					    }
					
					catch(TimeoutException e){
			            seClick(PlanHeaderPage.get().close, "Close button");
			            }
					
				    seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
					waitForPageLoad();
					
					seClick(PlanHeaderPage.get().userLogout, "Logout");
					waitForPageLoad(); 
					
					seCloseBrowser();
			       
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
                    LoginPage.get().loginApplication(strUserProfileApprover);
					waitForPageLoad();
					
					seClick(HomePage.get().find, "Find");
                    seClick(HomePage.get().findPlan, "Find Plan");
                    waitForPageLoad();
                    String strplanIdInDraft = getCellValue("LegacyPlanID");
                    seSetText(FindPlanPage.get().planVersionID, strplanIdInDraft, "Set text in plan version id");
                    seClick(FindPlanPage.get().planSearch, "Search");
                    waitForPageLoad();
                    seClick(BenefitRetainsInProductionPage.get().searchedPlanClick, " Searched plan");
                    waitForPageLoad();
                    Boolean blnauditStatus= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
					 
					 if(blnauditStatus==true){
							log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");
						}
						else { 
							throw new TimeoutException("Plan is not in Pending Audit status");
						}	
					seClick(PlanHeaderPage.get().approveAudit, "Approve Audit");
						waitForPageLoad(30);
						
						seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ENTER);
						
						seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, 10);
						seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
						seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeText, 1);
						
						seSetText(PlanTransitionPage.get().planTransitionReasonCodeText, "Approved", "as " + "Approved");
						seClick(PlanTransitionPage.get().approved, "approved reason code");
						seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
						waitForPageLoad(45);
						seClick(PlanHeaderPage.get().moveToTestPHPage, "Move to test button");
						waitForPageLoad();
						seClick(PlanTransitionPage.get().moveToTest, "Move to test ");
						waitForPageLoad(45);
						seClick(PlanHeaderPage.get().approveTestForFinalize, "Approve test button");
						waitForPageLoad();
						
						seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "reason code");
						seClick(PlanTransitionPage.get().approved,"approved");
						seClick(PlanTransitionPage.get().approvedTest, "approve test");
						waitForPageLoad(45);
						seClick(PlanHeaderPage.get().finalize, "Finalize");
						waitForPageLoad();
						
						seClick(PlanTransitionPage.get().finalizeButtoninPT, "finalize");
						waitForPageLoad();
						
                    	try{
                    		seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 300);
                    		}
						
						catch(TimeoutException e){
				            seClick(PlanHeaderPage.get().close, "Close button");
							waitForPageLoad();
 
				            }
						
        				((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);
						waitForPageLoad(45);
						
                        Boolean blnfinalStatus= PlanHeaderPage.get().seVerifyPlanStatus("Production");
					 
                        if(blnfinalStatus==true){
	                          	log(PASS, "plan takes correct time to load","plan is in Production status,RESULT=PASS");
	                                     }
	                    else { 
	                    	throw new TimeoutException("Plan is not in Production status");
	                          }	

					
							
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
				finally {
					
					seCloseBrowser();
                }

			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			seCloseBrowser();
			endTestScript();
		}

	}
	
}
