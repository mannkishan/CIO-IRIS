package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.WebElement;


import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PCPSPCBreakoutSetupPage;
import page.planConfigurator.UrgentCarePlanOptionPage;
import utility.CoreSuperHelper;

/**
 * Manual test case: Verify that the Accumulator Group Types and Accumulator names are available for the Benefit Urgent Care  
 * @author AF16391
 * @since 08/28/2017
 *
 */
public class VerifyUrgentCareAccumVisibleInPlanOptionsPage_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {

					logExtentReport("Urgent Care Accumulator Visibility");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
					LoginPage.get().loginApplication(strUserProfile);
					seWaitForClickableWebElement(HomePage.get().find, 10);
					String strPlanID = getCellValue("Plan_ID");
					seClick(HomePage.get().find, "Find");
					seClick(HomePage.get().findPlan, "Find Plan");					
					seSetText(FindPlanPage.get().planVersionID, strPlanID, "Enter Plan ID");
					seWaitForClickableWebElement(FindPlanPage.get().planSearch, 30);
					seClick(FindPlanPage.get().planSearch, "Search Plan");
					seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().openClickedPlan, 10);
					seClick(PCPSPCBreakoutSetupPage.get().openClickedPlan, "Search");					
					waitForPageLoad();
					seClick(BenefitRetainsInProductionPage.get().editButton,"Edit Button");
					waitForPageLoad(30,10);
					seClick(BenefitRetainsInProductionPage.get().saveButton, "Save");
                    waitForPageLoad();
					seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().scrollDown, 20);
					seClick(PCPSPCBreakoutSetupPage.get().scrollDown, "Scroll Down");
					seClick(PCPSPCBreakoutSetupPage.get().scrollDown, "Scroll Down");					
					waitForPageLoad();
					seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().planOptions, 50);
					seClick(PCPSPCBreakoutSetupPage.get().planOptions, "Plan Options");
					waitForPageLoad(30,10);					
					seWaitForClickableWebElement(UrgentCarePlanOptionPage.get().urgentCare, 30);
					seClick(UrgentCarePlanOptionPage.get().urgentCare,"Urgent Care");	
					UrgentCarePlanOptionPage.get().seUrgentCareVerifyAccumulator();
					seClick(BenefitRetainsInProductionPage.get().deleteButton,"Deleting the Plan");
					waitForPageLoad(30,10);
					seClick(BenefitRetainsInProductionPage.get().yesButton,"Selected Yes");					
					seCloseBrowser();
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			seCloseBrowser();
			endTestScript();
		}

	}
	
}