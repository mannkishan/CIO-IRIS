package testScripts.planConfigurator.planActivities;



import org.openqa.selenium.By;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import utility.CoreSuperHelper;

public class ValidateFindPlanSearchCriteriaFunctionality_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
    static String userProfile = EnvHelper.getValue("user.profile");
    public static void main(String[] args) {
                  try {
                	  MANUAL_TC_EXECUTION_EFFORT = "00:45:00";  
                	  initiateTestScript();

                        for (iROW = 1; iROW <= getRowCount(); iROW++) {
                               try {
                                      logExtentReport("save the search criteria and check the saved search criteria");
                                    
              						
              						String strHeaderType = getCellValue("HeaderType");
              						String strHeaderValue = getCellValue("HeaderValue");
              						String strPlanOptionArea = getCellValue("PlanOptionArea");
              						String strPlanOptionType = getCellValue("PlanOptionType");
              						String strPlanOptionName = getCellValue("PlanOptionName");
              						String strAccumType = getCellValue("AccumulatorType");
              						String strAccumName = getCellValue("AccumulatorName");
              						String strAccumValue = getCellValue("AccumulatorValue");
              						String strBenefit = getCellValue("Benefit");
              						String strSituationGroup = getCellValue("SituationGroup");
              						String strSituationType = getCellValue("SituationType");
              						String strHeaderNewValue = getCellValue("HeaderNewValue");
              						String strAccumTypeNew = getCellValue("AccumTypeNew");
              						String strAccumValueNew = getCellValue("AccumValueNew");
                                      seOpenBrowser(BrowserConstants.Chrome, baseURL);
                                      LoginPage.get().loginApplication(userProfile);
                                      waitForPageLoad();
                                      seClick(HomePage.get().find, "Find");
                                      seClick(HomePage.get().findPlan, "Find Plan");
                                      waitForPageLoad();
                                      waitForPageLoad();
                                      seIsElementDisplayed(BenefitRetainsInProductionPage.get().base, "Base criteria");
                                      seIsElementDisplayed(BenefitRetainsInProductionPage.get().header, "header criteria");
                                      seIsElementDisplayed(BenefitRetainsInProductionPage.get().option, "option criteria");
                                      seIsElementDisplayed(BenefitRetainsInProductionPage.get().accumulator, "accumulator criteria");
                                      seIsElementDisplayed(BenefitRetainsInProductionPage.get().benefit, "benefit criteria");
                                      seClick(FindPlanPage.get().optionCriteria, "optionCriteria");
                						waitForPageLoad(2,360);
                						seClick(FindPlanPage.get().planOptionArea, "Plan Option Area");
                                       seIsElementDisplayed(BenefitRetainsInProductionPage.get().mandate, "Mandate Criteria");
                                      seIsElementDisplayed(BenefitRetainsInProductionPage.get().medicalPolicy, "Medical Policy Criteria");
                                      seIsElementDisplayed(BenefitRetainsInProductionPage.get().umRules, "UM Rules criteria");
                                       
						//Header Criteria
						seClick(FindPlanPage.get().headerCriteria,"Header criteria");
						seWaitForPageLoad();
						seClick(FindPlanPage.get().headerCriteriaType,"Header criteria type");
						seWaitForPageLoad();
						seSetText(BenefitRetainsInProductionPage.get().headerValueEnter, strHeaderType, "Header Type");
						seInputKeys(BenefitRetainsInProductionPage.get().headerValueEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						FindPlanPage.get().valueType(strHeaderValue);
						waitForPageLoad(360);
						//Option Criteria
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().planOptionArea, "Plan Option Area");
						seClick(FindPlanPage.get().planOptionAreaValue(strPlanOptionArea),"PlanOptionArea "+strPlanOptionArea);
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().planOptionType, "Plan Option Type");
						seClick(FindPlanPage.get().planOptionTypeValue(strPlanOptionType),"PlanOptionType "+strPlanOptionType);
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().planOptionName, "Plan Option Name");
						seClick(BenefitRetainsInProductionPage.get().planOptionNameEnter, "Plan Option Name");
						seSetText(BenefitRetainsInProductionPage.get().planOptionNameEnter, strPlanOptionName, "Plan Option Name");
						seInputKeys(BenefitRetainsInProductionPage.get().planOptionNameEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						//Accumulator Criteria
						seClick(FindPlanPage.get().accumulatorCriteria, "Accumulatory Criteria");
						seClick(FindPlanPage.get().accumType,"Accumulator Type");
						seClick(BenefitRetainsInProductionPage.get().accumTypeEnter,"Accumulator Type");
						seSetText(BenefitRetainsInProductionPage.get().accumTypeEnter, strAccumType, "Accumulator Type");
						seInputKeys(BenefitRetainsInProductionPage.get().accumTypeEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad(360);
						seWaitForPageLoad(360);
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().accumulatorName, "accum name");
						seClick(BenefitRetainsInProductionPage.get().accumulatorName,"Accumulator Name");
						seClick(BenefitRetainsInProductionPage.get().accumNameEnter,"Accumulator Name");
						seSetText(BenefitRetainsInProductionPage.get().accumNameEnter, strAccumName, "Accumulator Name");
						seInputKeys(BenefitRetainsInProductionPage.get().accumNameEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						seClick(BenefitRetainsInProductionPage.get().accumulatorValue,"Accumulator Value");
						seSetText(BenefitRetainsInProductionPage.get().accumulatorValue, strAccumValue, "Accumulator Value");
						seWaitForPageLoad();
						//Benefit Criteria
						seClick(FindPlanPage.get().benefitCriteria, "Benefit Criteria");
						waitForPageLoad(300);
						FindPlanPage.get().selectTheBenefit(strBenefit);
						waitForPageLoad(300);
						FindPlanPage.get().situationGroup(strSituationGroup);
						waitForPageLoad(300);
						
						seClick(BenefitRetainsInProductionPage.get().benefitSituationType, "Situation Type");
						seClick(BenefitRetainsInProductionPage.get().benefitSituationTypeEnter, "Situation Type");
						seSetText(BenefitRetainsInProductionPage.get().benefitSituationTypeEnter, strSituationType, "Situation Type");
						seInputKeys(BenefitRetainsInProductionPage.get().benefitSituationTypeEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						seClick(BenefitRetainsInProductionPage.get().exclude,"Exclude");
						seWaitForPageLoad();
						
						seClick(BenefitRetainsInProductionPage.get().cancelHeader,"Cancel Header Criteria");
						seWaitForPageLoad();
						waitForPageLoad(360);
						seIsElementDisplayed(FindPlanPage.get().headerCriteriaType,"Header criteria type");
						seClick(FindPlanPage.get().headerCriteriaType,"Header criteria type");
						seWaitForPageLoad();
						seSetText(BenefitRetainsInProductionPage.get().headerValueEnter, strHeaderType, "Header Type");
						seInputKeys(BenefitRetainsInProductionPage.get().headerValueEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						FindPlanPage.get().valueType(strHeaderNewValue);
						waitForPageLoad(360);
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().warningMessage, "Warning Message Indicating the removed Option,Accumulator, Benefit Criteria");
						BenefitRetainsInProductionPage.get().seCheckDropdownEmpty();
						seWaitForPageLoad();
						
						seClick(FindPlanPage.get().accumType,"Accumulator Type");
						seClick(BenefitRetainsInProductionPage.get().accumTypeEnter,"Accumulator Type");
						seSetText(BenefitRetainsInProductionPage.get().accumTypeEnter, strAccumTypeNew, "Accumulator Type");
						seClick(driver.findElement(By.xpath("((//*[@class='badge single-criteria planOption-single-criteria ']/following::span[@class='select2-results'])[1]/ul/li/span)[1]")), "dropdown choice");
						seWaitForPageLoad(360);
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().accumulatorName, "accum name");
						seClick(BenefitRetainsInProductionPage.get().accumulatorName,"Accumulator Name");
						
						seClick(driver.findElement(By.xpath("((//*[@class='badge single-criteria planOption-single-criteria ']/following::span[@class='select2-results'])[1]/ul/li/span)[55]")), "dropdown choice");
						seWaitForPageLoad();
						
						seClick(BenefitRetainsInProductionPage.get().accumulatorChoiceValue,"Accumulator Value");
						seSetText(BenefitRetainsInProductionPage.get().accumulatorChoiceValueEnter, strAccumValueNew, "Accumulator Value");
						seInputKeys(BenefitRetainsInProductionPage.get().accumulatorChoiceValueEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						seClick(FindPlanPage.get().planSearch, "Search");
                        waitForPageLoad();
                       
				} catch (Exception e) {
                    e.printStackTrace();
                    log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
             }
             finally {
           	  seCloseBrowser();
             }
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null){
			seCloseBrowser();
			}
			endTestScript();
		}
	}
}