package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.AllergySerumBenefitOptionPage;
import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.CreateTemplatePage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PCPSPCBreakoutSetupPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanTransitionPage;
import page.planConfigurator.UrgentCarePlanOptionPage;
import utility.CoreSuperHelper;
/**
 * Manual test case: Copy MP plan created from exisitng template go thru life cycle
 * <p>
 * Test script template
 * <p>
 * Please refer this test script while creating other test scripts
 * 
 * 
 * 
 *
 */
//User Creates a new plan by copying an existing plan.Verify that, 
//The system will validate the new plan against the current version of the template associated with the plan
// plan : 1525320416   Template : 1444540624
public class CopyMPAndVerifyTemplateExisiting_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	
	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {

					logExtentReport("Copy a MP plan and verify Same Template Exist");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
					LoginPage.get().loginApplication(strUserProfile);
					
					//find a Master  plan in Production status
					seWaitForClickableWebElement(HomePage.get().find, 10);
					String strPlanID = getCellValue("Plan_ID");
					seClick(HomePage.get().find, "Find");
					seClick(HomePage.get().findPlan, "Find Plan");					
					seSetText(FindPlanPage.get().planVersionID, strPlanID, "Enter Plan ID");									
					seWaitForClickableWebElement(FindPlanPage.get().planSearch, 30);
					seClick(FindPlanPage.get().planSearch, "Search Plan");
					seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().openClickedPlan, 10);
					seClick(PCPSPCBreakoutSetupPage.get().openClickedPlan, "Search");
					waitForPageLoad(30,10);
					System.out.println("searched plan needed");
				
					
					
					//get current template id from UI
					String strTemplateVersionIDold = seGetElementValue(PlanHeaderPage.get().templateVersionID);
                    waitForPageLoad();
                    setCellValue("TemplateIDold", strTemplateVersionIDold);
                    System.out.println("got old template id");
                    
                   
                    //get plan id from UI
                    String strPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
					waitForPageLoad();
					String strPlanProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
					waitForPageLoad();
					setCellValue("MasterPlanID", strPlanVersionID);
					setCellValue("MasterProxyID", strPlanProxyID);
					
					//search for the template trTemplateVersionIDold
					
					seClick(HomePage.get().find, "Find");waitForPageLoad();
					seClick(HomePage.get().findTemplate, "Find Template");waitForPageLoad();
					seSetText(PlanTransitionPage.get().inputTemplate,strTemplateVersionIDold, "Enter Plan ID");waitForPageLoad();									
					seWaitForClickableWebElement(FindPlanPage.get().planSearch, 30);waitForPageLoad();
					seClick(FindPlanPage.get().planSearch, "Search Plan");waitForPageLoad();
					System.out.println("searched need to click");
					seWaitForClickableWebElement(PlanHeaderPage.get().searchTemplates, 10);waitForPageLoad();
					//seClick(PlanHeaderPage.get().searchTemplate, "Search");
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",PlanHeaderPage.get().searchTemplates);
					System.out.println("click sucess");
					waitForPageLoad(30,10);
					
				  //edit the searched template
					seWaitForClickableWebElement(PlanHeaderPage.get().editTemplate, 30);//seClick(PlanHeaderPage.get().editTemplate, "Edit");
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",PlanHeaderPage.get().editTemplate);
					waitForPageLoad(10);
					seWaitForClickableWebElement(PlanHeaderPage.get().headerSave, 30);seClick(PlanHeaderPage.get().headerSave, "Save");
					waitForPageLoad(100);
					
					PlanHeaderPage.get().seEditTemplate();
					waitForPageLoad();
					
					//Save the template
					seClick(PlanTransitionPage.get().saveTemplate, "Save");
					waitForPageLoad(100);
					
					//get new template version ID
					String strTemplateVersionIDnewExtract = seGetElementValue(PlanHeaderPage.get().templateVersion).split(":")[1];
					String strTemplateVersionIDnew = strTemplateVersionIDnewExtract.trim();
                    waitForPageLoad();
                    setCellValue("TemplateIDnew", strTemplateVersionIDnew);
                    System.out.println("got new template id"+strTemplateVersionIDnew);
					
					//Move template to production and Close Template
                    waitForPageLoad(100);
					PlanHeaderPage.get().seMoveToProductionTemplate();waitForPageLoad();
					waitForPageLoad();
                    seClick(PlanTransitionPage.get().closeTemplate, "close");
                    waitForPageLoad();
					
					
					//find plan strPlanVersionID.trim()
					seWaitForClickableWebElement(HomePage.get().find, 10);
					seClick(HomePage.get().find, "Find");
					seClick(HomePage.get().findPlan, "Find Plan");	waitForPageLoad();				
					seSetText(FindPlanPage.get().planVersionID, strPlanVersionID.trim(), "Enter Plan ID");									
					seWaitForClickableWebElement(FindPlanPage.get().planSearch, 30);
					seClick(FindPlanPage.get().planSearch, "Search Plan");
					waitForPageLoad();
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",CreateTemplatePage.get().selectPlan);
					//seClick(PlanOptionsPage.get().clickSearchedPlan, "Searched Plan");
					
					
					waitForPageLoad(30,10);
					System.out.println("searched plan needed");waitForPageLoad();
				   
					//Copying n existing MP plan
					seClick(PlanTransitionPage.get().copy, "copy button");
					waitForPageLoad(30,10);
					seClick(PCPSPCBreakoutSetupPage.get().createButton, "create button");
					waitForPageLoad(45,20);
					
					
					//get the updated Template version ID:
					String strTemplateVersionIDnewFromUI = seGetElementValue(PlanHeaderPage.get().templateVersionID);
                    waitForPageLoad();
                    System.out.println(strTemplateVersionIDnewFromUI);
                   //when the template gets edited the version id changes so should check if that reflects in the plan aswell.
                   //The system will validate the new plan against the current version of the template associated with the plan
                    //remove this also 
                    //String strTemplateVersionIDnew = "1734050610";
                    seCompareStrings(strTemplateVersionIDnew, strTemplateVersionIDnewFromUI, "=", "Verified, the system validates the new plan against the current version of the template associated with the plan");
					waitForPageLoad();
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
								
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
				finally {
					/*BenefitRetainsInProductionPage.get();
					BenefitRetainsInProductionPage.seTearDown();*/
					//seCloseBrowser();
                }

			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			//seCloseBrowser();
			endTestScript();
		}

	}
	
}
