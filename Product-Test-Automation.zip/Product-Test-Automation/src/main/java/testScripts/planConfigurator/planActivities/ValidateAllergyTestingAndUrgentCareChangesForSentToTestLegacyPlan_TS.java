package testScripts.planConfigurator.planActivities;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.AllergyTestingBenefitOptionPage;
import page.planConfigurator.BenefitsPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.UrgentCarePlanOptionPage;
import utility.CoreSuperHelper;

/**
 * This script Rejects a 'Sent to Test' Legacy Plan and creates another plan through 'Edit' option.  
 * The Urgent Care Facility and Allergy Testing accumulator values are then updated and 'Request Audit' is done.
 * The values updated are now verified in respective tabs and also in Benefits tab. 
 * @author AF13762
 * */
public class ValidateAllergyTestingAndUrgentCareChangesForSentToTestLegacyPlan_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strNewPlanVersionId;
	
	public static void main(String[] args) {

		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strPlanVersionId = getCellValue("Plan_Version_ID");
					String strUrgentCareCopayAmount = getCellValue("UC_CoPayAmt");
					String strAllergyTestingDeductible = getCellValue("AT_ApplyDeductible");
					String strAllergyTestingCoinsurance = getCellValue("AT_CoInsurancePerc");
					String strAllergyTestingBenefitPeriod = getCellValue("AT_BenefitPeriod");
					
					if (getCellValue("Run_Flag").equalsIgnoreCase("YES")) {
						logExtentReport("Verify Allergy Testing and Urgent Care Facility changes for Sent to Test Legacy Plan");
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
						LoginPage.get().loginApplication(strUserProfile);
						FindPlanPage.get().seNavigateToSearchPlanPage();
						FindPlanPage.get().seSearchByPlanVersionID(strPlanVersionId);
						FindPlanPage.get().seOpenFirstPlanFromFindPlanResults();
						PlanHeaderPage.get().seRejectTest();
						PlanHeaderPage.get().seEditPlan();
						strNewPlanVersionId = (seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1]).trim();
						UrgentCarePlanOptionPage.get().seUpdateUrgentCareFacility(strUrgentCareCopayAmount);
						AllergyTestingBenefitOptionPage.get().seUpdateAllergyTesting(strAllergyTestingDeductible, strAllergyTestingCoinsurance, strAllergyTestingBenefitPeriod);
						PlanHeaderPage.get().requestAuditPlan(strNewPlanVersionId, 60);
						UrgentCarePlanOptionPage.get().seVerifyUrgentCareFacilityValues(strUrgentCareCopayAmount);
						AllergyTestingBenefitOptionPage.get().seVerifyAllergyTestingValues(strAllergyTestingDeductible, strAllergyTestingCoinsurance);
						BenefitsPage.get().seVerifyUrgentCareFacilityValuesInBenefits(strUrgentCareCopayAmount);
						BenefitsPage.get().seVerifyAllergyTestingValuesInBenefits(strAllergyTestingCoinsurance);
						PlanHeaderPage.get().seClosePlan();
						setResult("STATUS", RESULT_STATUS);
					}
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					seCloseBrowser();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}

	}
}
