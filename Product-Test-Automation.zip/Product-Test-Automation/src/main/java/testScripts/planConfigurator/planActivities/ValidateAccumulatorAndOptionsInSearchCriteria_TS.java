package testScripts.planConfigurator.planActivities;



import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import utility.CoreSuperHelper;

public class ValidateAccumulatorAndOptionsInSearchCriteria_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
    static String userProfile = EnvHelper.getValue("user.profile");
    public static void main(String[] args) {
                  try {
                	  MANUAL_TC_EXECUTION_EFFORT = "00:45:00";  
                	  initiateTestScript();

                        for (iROW = 1; iROW <= getRowCount(); iROW++) {
                               try {
                                      logExtentReport("save the search criteria and check the saved search criteria");
                                    
              						
              						String strHeaderType = getCellValue("HeaderType");
              						String strHeaderValue = getCellValue("HeaderValue");
              						String strPlanOptionArea = getCellValue("PlanOptionArea");
              						String strPlanOptionType = getCellValue("PlanOptionType");
              						String strPlanOptionName = getCellValue("PlanOptionName");
              						String strAccumType = getCellValue("AccumulatorType");
              						String strAccumName = getCellValue("AccumulatorName");
              						
              						String strHeaderNewValue = getCellValue("HeaderNewValue");
              						String strPlanOptionAreaNew = getCellValue("PlanOptionAreaNew");
              						String strPlanOptionTypeNew = getCellValue("PlanOptionTypeNew");
              						String strPlanOptionNameNew = getCellValue("PlanOptionNameNew");
              						String strAccumTypeNew = getCellValue("AccumTypeNew");
              						String strAccumValueNew = getCellValue("AccumValueNew");
                                      seOpenBrowser(BrowserConstants.Chrome, baseURL);
                                      LoginPage.get().loginApplication(userProfile);
                                      waitForPageLoad();
                                      
                                      seClick(HomePage.get().find, "Find");
                                      seClick(HomePage.get().findPlan, "Find Plan");
                                      waitForPageLoad();
                                      waitForPageLoad();
                                      
						//Header Criteria
						seClick(FindPlanPage.get().headerCriteria,"Header criteria");
						seWaitForPageLoad();
						seClick(FindPlanPage.get().headerCriteriaType,"Header criteria type");
						seWaitForPageLoad();
						seSetText(BenefitRetainsInProductionPage.get().headerValueEnter, strHeaderType, "Header Type");
						seInputKeys(BenefitRetainsInProductionPage.get().headerValueEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						//FindPlanPage.get().valueType(strHeaderValue);
						//waitForPageLoad(360);
						//Option Criteria
						seClick(FindPlanPage.get().optionCriteria, "optionCriteria");
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().planOptionArea, "Plan Option Area");
						seClick(FindPlanPage.get().planOptionAreaValue(strPlanOptionArea),"PlanOptionArea "+strPlanOptionArea);
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().planOptionType, "Plan Option Type");
						String strOptionTypeForDental = seGetText(BenefitRetainsInProductionPage.get().planSetupTypesForDental);
						seClick(FindPlanPage.get().planOptionTypeValue(strPlanOptionType),"PlanOptionType "+strPlanOptionType);
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().planOptionName, "Plan Option Name");
						String strOptionNameForDental = seGetText(BenefitRetainsInProductionPage.get().planSetupNameForDental);
						seClick(BenefitRetainsInProductionPage.get().planOptionNameEnter, "Plan Option Name");
						seSetText(BenefitRetainsInProductionPage.get().planOptionNameEnter, strPlanOptionName, "Plan Option Name");
						seInputKeys(BenefitRetainsInProductionPage.get().planOptionNameEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						seClick(FindPlanPage.get().accumulatorCriteria, "Accumulatory Criteria");
						seClick(FindPlanPage.get().accumType,"Accumulator Type");
						seClick(BenefitRetainsInProductionPage.get().accumTypeEnter,"Accumulator Type");
						seSetText(BenefitRetainsInProductionPage.get().accumTypeEnter, strAccumType, "Accumulator Type");
						seInputKeys(BenefitRetainsInProductionPage.get().accumTypeEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad(360);
						seWaitForPageLoad(360);
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().accumulatorName, "accum name");
						seIsElementEnabled(BenefitRetainsInProductionPage.get().accumName, "accum name");
						String strname=seGetText(BenefitRetainsInProductionPage.get().accumName);
						System.out.println(strname);
						seClick(BenefitRetainsInProductionPage.get().accumulatorName,"Accumulator Name");
						String strAccumNameForDental = seGetText(BenefitRetainsInProductionPage.get().planSetupTypesForDental);
						
						seClick(BenefitRetainsInProductionPage.get().accumNameEnter,"Accumulator Name");
						seSetText(BenefitRetainsInProductionPage.get().accumNameEnter, strAccumName, "Accumulator Name");
						seInputKeys(BenefitRetainsInProductionPage.get().accumNameEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						
						seClick(BenefitRetainsInProductionPage.get().cancelHeader,"Cancel Header Criteria");
						seWaitForPageLoad();
						waitForPageLoad(360);
						seIsElementDisplayed(FindPlanPage.get().headerCriteriaType,"Header criteria type");
						seClick(FindPlanPage.get().headerCriteriaType,"Header criteria type");
						seWaitForPageLoad();
						seSetText(BenefitRetainsInProductionPage.get().headerValueEnter, strHeaderType, "Header Type");
						seInputKeys(BenefitRetainsInProductionPage.get().headerValueEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						FindPlanPage.get().valueType(strHeaderNewValue);
						waitForPageLoad(360);
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().warningMessage, "Warning Message Indicating the removed Option,Accumulator, Benefit Criteria");
						waitForPageLoad(2,360);
						seClick(BenefitRetainsInProductionPage.get().deleteOptionCriteria, "delete");
						seWaitForPageLoad();
						seClick(FindPlanPage.get().planOptionArea, "Plan Option Area");
						//String strAccumNameForMedical = seGetText(BenefitRetainsInProductionPage.get().planSetupTypesForDental);
						seClick(FindPlanPage.get().planOptionAreaValue("Plan Setup"),"PlanOptionArea "+"Plan Setup");
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().planOptionType, "Plan Option Type");
						String strOptionTypeForMedical = seGetText(BenefitRetainsInProductionPage.get().planSetupTypesForDental);
						
	                	seClick(FindPlanPage.get().planOptionTypeValue(strPlanOptionTypeNew),"PlanOptionType "+strPlanOptionTypeNew);
						waitForPageLoad(2,360);
						seClick(FindPlanPage.get().planOptionName, "Plan Option Name");
						String strOptionNameForMedical = seGetText(BenefitRetainsInProductionPage.get().planSetupTypesForDental);
						seClick(BenefitRetainsInProductionPage.get().planOptionNameEnter, "Plan Option Name");
						seSetText(BenefitRetainsInProductionPage.get().planOptionNameEnter, strPlanOptionNameNew, "Plan Option Name");
						seInputKeys(BenefitRetainsInProductionPage.get().planOptionNameEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						//Accumulator Criteria
						//seClick(FindPlanPage.get().accumulatorCriteria, "Accumulator Criteria");
						seClick(FindPlanPage.get().accumType,"Accumulator Type");
						seClick(BenefitRetainsInProductionPage.get().accumTypeEnter,"Accumulator Type");
						seSetText(BenefitRetainsInProductionPage.get().accumTypeEnter, strAccumTypeNew, "Accumulator Type");
						seInputKeys(BenefitRetainsInProductionPage.get().accumTypeEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad(360);
						seWaitForPageLoad(360);
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().accumulatorName, "accum name");
						seClick(BenefitRetainsInProductionPage.get().accumulatorName,"Accumulator Name");
						String strAccumulatorNameForMedical = seGetText(BenefitRetainsInProductionPage.get().planSetupTypesForDental);
						
						seClick(BenefitRetainsInProductionPage.get().accumNameEnter,"Accumulator Name");
						seSetText(BenefitRetainsInProductionPage.get().accumNameEnter, strAccumValueNew, "Accumulator Name");
						seInputKeys(BenefitRetainsInProductionPage.get().accumNameEnter, KeyConstants.ENTER, " ");
						seWaitForPageLoad();
						BenefitRetainsInProductionPage.get().seFieldValueCompare(strOptionTypeForDental,strOptionTypeForMedical);
						BenefitRetainsInProductionPage.get().seFieldValueCompare(strOptionNameForDental,strOptionNameForMedical);
						
						BenefitRetainsInProductionPage.get().seFieldValueCompare(strAccumNameForDental,strAccumulatorNameForMedical);
						
                       
				} catch (Exception e) {
                    e.printStackTrace();
                    log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
             }
             finally {
           	  seCloseBrowser();
             }
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null){
			seCloseBrowser();
			}
			endTestScript();
		}
	}
}