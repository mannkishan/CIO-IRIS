package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import com.thoughtworks.selenium.webdriven.commands.GetTitle;

import page.groupConfigurator.LoginPage;
import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.CreateLegacyPlanPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.PCPSPCBreakoutSetupPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanSetupPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;
/**
 * Manual test case: Create Legacy Plan :
 * This Test script checks the Functionallities of Test Passed status plan
 
 * @author AF48638
 * @since 10-October-2017
 *
 */
public class VerifyTestPassedFunctionality_TS extends CoreSuperHelper {

	
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");

	public static void main(String[] args) {

		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("verify functionality of Test passed status plan");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
                    LoginPage.get().loginApplication(strUserProfile);
					seWaitForElementLoad(CreatePlanPage.get().homepage);
					waitForPageLoad();
                    CreateLegacyPlanPage.seCreatePlan(false, 10);
                    waitForPageLoad();
					CreateLegacyPlanPage.seCreateLegacyPlan();
                    seClick(PlanHeaderPage.get().save, "Save button");
                    waitForPageLoad();
                    String strPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
					waitForPageLoad();
					String strPlanProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
					waitForPageLoad();
					setCellValue("LegacyPlanID", strPlanVersionID);
					setCellValue("LegacyProxyID", strPlanProxyID);
					seWaitForClickableWebElement(PlanHeaderPage.get().requestAudit,1);
					seClick(PlanHeaderPage.get().requestAudit, "request Audit button");
					waitForPageLoad();
					PlanTransitionPage.get().updateReasonCode("Other");
					seClick(PlanTransitionPage.get().requestAudit, "Request Audit button");
					waitForPageLoad();
					try{
						seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 360);
					    }
					catch(TimeoutException e){
			            seClick(PlanHeaderPage.get().close, "Close button");
			            }
					seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
					waitForPageLoad();
					seClick(PlanHeaderPage.get().userLogout, "Logout");
					waitForPageLoad(20,10); 
					seCloseBrowser();
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
					LoginPage.get().loginApplication(strUserProfileApprover);
					waitForPageLoad();
					String strLegacy = getCellValue("LegacyPlanID");
					seClick(HomePage.get().find, "Find");
                    seClick(HomePage.get().findPlan, "Find Plan");
					seSetText(FindPlanPage.get().planVersionID,strLegacy, "Set text in plan version id");
					waitForPageLoad();
					seClick(FindPlanPage.get().planSearch, "Search");
					waitForPageLoad();
					WebElement objSearch = FindPlanPage.get().selectSearchedPlan;
                    ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objSearch);
                    waitForPageLoad();
					seClick(PlanHeaderPage.get().approveAudit, "Approve Audit");
						waitForPageLoad(30);
						seWaitForElementLoad(BenefitRetainsInProductionPage.get().planTransitionPage);
						waitForPageLoad(30);
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().planTransitionPage,
								"Plan Transition page");
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().approveAuditInformation,
								"Approve Audit Information");
						seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ENTER);
						waitForPageLoad();
						seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, 10);
						seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
						seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeText, 1);
						waitForPageLoad();
						seSetText(PlanTransitionPage.get().planTransitionReasonCodeText, "Approved", "as " + "Approved");
						seClick(PlanTransitionPage.get().approved, "approved reason code");
						seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
						waitForPageLoad(45);
						
						Boolean blnstatusApprovedAudit=PlanHeaderPage.get().seVerifyPlanStatus("Approved Audit");
						
						if(blnstatusApprovedAudit==true){
							log(PASS, "plan takes correct time to load","plan is in Approved Audit status,RESULT=PASS");
						}
						else { 
							throw new TimeoutException("Plan is not in Approved Audit status");
							  }	
						seClick(PlanHeaderPage.get().moveToTestPHPage, "Move to test button");
						waitForPageLoad();
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().planTransitionPage,
								"Plan Transition page");
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().approveAuditInformation,
								"Move to Test Information");
						seClick(PlanTransitionPage.get().moveToTest, "Move to test ");
						waitForPageLoad(45);
						
						Boolean blnstatusSentToTest=PlanHeaderPage.get().seVerifyPlanStatus("Sent To Test");
						
						if(blnstatusSentToTest==true){
							log(PASS, "plan takes correct time to load","plan is in Sent To Test status,RESULT=PASS");
						}
						else { 
							throw new TimeoutException("Plan is not in Sent To Test status");
							  }	
						
						seClick(PlanHeaderPage.get().approveTestForFinalize, "Approve test button");
						waitForPageLoad();
						
						seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "reason code");
						seClick(PlanTransitionPage.get().approved,"approved");
						seClick(PlanTransitionPage.get().approvedTest, "approve test");
						
						waitForPageLoad(45);
						Boolean blnstatusTestpassed=PlanHeaderPage.get().seVerifyPlanStatus("Test Passed");
						if(blnstatusTestpassed==true){
							log(PASS, "plan takes correct time to load","plan is in Test Passed status,RESULT=PASS");
						}
						else { 
							throw new TimeoutException("Plan is not in Test Passed status");
							  }	
						
						seClick(PlanHeaderPage.get().finalize, "Finalize");
						waitForPageLoad();
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().planTransitionPage,
								"Plan Transition page");
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().approveAuditInformation,
								"finalization Information");
						waitForPageLoad();
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().effectiveDate,
								"Effective date");
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().reasoncode,
								"Reason code");
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().comments,
								"Comments");
						seClick(PlanTransitionPage.get().finalizeButtoninPT, "finalize");
						waitForPageLoad();
						Boolean blnstatusPendingFinalization=PlanHeaderPage.get().seVerifyPlanStatus("Pending Finalization");
						if(blnstatusPendingFinalization==true){
							log(PASS, "plan takes correct time to load","plan is in Pending Finalization status,RESULT=PASS");
						}
						else { 
							throw new TimeoutException("Plan is not in Pending Finalization status");
							  }	
                    	try{
                    		seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 300);
                    		}
						
						catch(TimeoutException e){
				            seClick(PlanHeaderPage.get().close, "Close button");
							waitForPageLoad();
 
				            }
						
        				((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);
						waitForPageLoad(45);
						
                        Boolean blnfinalStatus= PlanHeaderPage.get().seVerifyPlanStatus("Production");
					 
                        if(blnfinalStatus==true){
	                          	log(PASS, "plan takes correct time to load","plan is in Production status,RESULT=PASS");
	                                     }
	                    else { 
	                    	throw new TimeoutException("Plan is not in Production status");
	                          }	

                         waitForPageLoad();
					     
					     seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
					     seClick(PlanHeaderPage.get().userLogout, "Logout");
						

				}
                  catch(TimeoutException e){
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());

				}
				catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
				
				finally{
					seCloseBrowser();
				}
			
		}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}

	}
