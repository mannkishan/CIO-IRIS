package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.RecheckPOTCheckboxPage;
import utility.CoreSuperHelper;

public class VerfiyChangeableCheckboxRecheckedInPOT_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");

	public static void main(String[] args) {
		try {
			//MPRO-1946
			//Verify if the changeable checkbox is rechecked at the Plan Option Type level in template, the associated attributes to that POT will be changeable in the plan
			initiateTestScript();
			
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
			try {
					RecheckPOTCheckboxPage.get().seRecheckPOT(getCellValue("TemplateVersionID"));
			} catch (Exception e) {
				e.printStackTrace();
				log(ERROR, "Exception has occurred for the iteration", e.getLocalizedMessage());
			} finally {
				 //seCloseBrowser();
			}
		}
	} catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occurred for the script execution", e.getLocalizedMessage());
	} finally {
		endTestScript();
	}

}
}
