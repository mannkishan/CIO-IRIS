package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.CreateLegacyPlanPage;
import page.planConfigurator.CreatePlanPage;
//import page.planConfigurator.EditPlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MasterProductAndLegacyPlanOptionsXMLPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;

//Validate that on clicking the "Reject Audit", the plan status is updated to "Rejected Audit" 

public class ValidateRejectAudit_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("Create Legacy Plan");
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
                    LoginPage.get().loginApplication(strUserProfile);
					seWaitForElementLoad(CreatePlanPage.get().homepage);
					waitForPageLoad();
                    CreateLegacyPlanPage.seCreatePlan(false, 10);
                    waitForPageLoad();
					CreateLegacyPlanPage.seCreateLegacyPlan();
                    seClick(PlanHeaderPage.get().save, "Save button");
                    waitForPageLoad();
					String strPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
					waitForPageLoad();
					String strPlanProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
					waitForPageLoad();
					setCellValue("LegacyPlanID", strPlanVersionID);
					setCellValue("LegacyProxyID", strPlanProxyID);
					seWaitForClickableWebElement(PlanHeaderPage.get().requestAudit,1);
					seClick(PlanHeaderPage.get().requestAudit, "request Audit button");
					waitForPageLoad();
					PlanTransitionPage.get().updateReasonCode("Other");
					seClick(PlanTransitionPage.get().requestAudit, "Request Audit button");
					waitForPageLoad();
					try{
						seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 360);
					    }
					catch(TimeoutException e){
			            seClick(PlanHeaderPage.get().close, "Close button");
			            }
					waitForPageLoad();
					
                    ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",PlanHeaderPage.get().userNameHeader);
                    waitForPageLoad();
                    
                    ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",PlanHeaderPage.get().userLogout);
                   
                   
					waitForPageLoad(20,10); 
			        seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
					LoginPage.get().loginApplication(strUserProfileApprover);
					waitForPageLoad();
					String strLegacy = getCellValue("LegacyPlanID");
					seClick(HomePage.get().find, "Find");
                    seClick(HomePage.get().findPlan, "Find Plan");
					seSetText(FindPlanPage.get().planVersionID,strLegacy, "Set text in plan version id");
					waitForPageLoad();
					seClick(FindPlanPage.get().planSearch, "Search");
					waitForPageLoad();
					WebElement objSearch = FindPlanPage.get().selectSearchedPlan;
                    ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objSearch);
					Boolean blnPlanStatusPendingAudit= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
					if(blnPlanStatusPendingAudit==true){
							log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");
						}
					else { 
							new TimeoutException("Plan is not in Pending Audit status");
						}	
					waitForPageLoad();
					
					seWaitForClickableWebElement(PlanHeaderPage.get().rejectAudit, 36);
					seClick(PlanHeaderPage.get().rejectAudit, "Reject Audit");
					waitForPageLoad(30);
					//Availability of reason code Field
					Boolean blnReasonCodeAvailability = seIsElementDisplayed(PlanTransitionPage.get().reasonCodeAvailable,"If in 'Reject Audit Information screen', 'ReasonCode'");
					String strReasonCodeAvailable = seGetText(PlanTransitionPage.get().reasonCodeAvailable).replaceAll("[,*]", "");
					PlanTransitionPage.get().seAvailabilityCheck(blnReasonCodeAvailability, strReasonCodeAvailable);
				
					PlanHeaderPage.get().seReasonCode();
					seWaitForClickableWebElement(PlanTransitionPage.get().txtWorkflowComment, 60);
					seSetText(PlanTransitionPage.get().txtWorkflowComment, "Test Reject", "Comment");
					seClick(PlanTransitionPage.get().btnRejectedTest, "Rejected Test");
					Boolean blnPlanStatusRejectedAudit= PlanHeaderPage.get().seVerifyPlanStatus("Rejected Audit");
					if(blnPlanStatusRejectedAudit==true){
							log(PASS, "Plan Status is updated to Rejected Audit,RESULT=PASS");
						}
					else { 
							new TimeoutException("Plan is not in Rejected Audit status");
						}	
					waitForPageLoad();
				
					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					 seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
