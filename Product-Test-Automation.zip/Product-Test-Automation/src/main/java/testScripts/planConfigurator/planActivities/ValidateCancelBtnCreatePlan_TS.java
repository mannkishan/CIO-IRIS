package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.Keys;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitsPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import utility.CoreSuperHelper;

//Validate Cancel button on Create plan screen
public class ValidateCancelBtnCreatePlan_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("Validate the Cancel Button in Create Plan Page");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);

					LoginPage.get().loginApplication(userProfile);
					seWaitForElementLoad(CreatePlanPage.get().homepage);
					Boolean boolean1 = seIsElementDisplayed(CreatePlanPage.get().homepage,
							"Home page");
					CreatePlanPage.get().cancelPlan(true,10);
					
					waitForPageLoad();
					seWaitForClickableWebElement(CreatePlanPage.get().popup, 0);
					seClick(CreatePlanPage.get().popup, "capture popup");

					seClick(CreatePlanPage.get().yesToCancel, "'Yes' to cancel");
					Boolean boolean2 = seIsElementDisplayed(CreatePlanPage.get().homepage,
							"Home page");
					CreatePlanPage.get().strcomparebool(boolean1, boolean2);
					
			        

				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					seCloseBrowser(); 
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}

}