package testScripts.planConfigurator.planActivities;

import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.AllergySerumBenefitOptionPage;
import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.CreatePlanLegacyHeaderPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PCPSPCBreakoutSetupPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;
/**
 * Manual test case: Verify that the Accumulator Group Types and Accumulator names are available for the Benefit Allergy Serum  
 * @author AF16391
 * @since 08/21/2017
 *
 */
public class VerifyAccumulatorsForRejectedAuditPlans_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	
	public static void main(String[] args) {
		try {
            initiateTestScript();

            for (iROW = 1; iROW <= getRowCount(); iROW++) {
                   try {
                          logExtentReport("Edit a plan in production status and check whether the Benefits retains");
                          seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
                          LoginPage.get().loginApplication(strUserProfile);
                          waitForPageLoad();
                          seClick(HomePage.get().find, "Find");
                          seClick(HomePage.get().findPlan, "Find Plan");
                          waitForPageLoad();
                          String planid = getCellValue("Plan_ID");
                          String strApplyDeductibleValue = getCellValue("ApplyDeductibleValue");
                          String strExamVisitCopayValue = getCellValue("ExamVisitCopayValue");
                          String strExamVisitCopayLimitValue = getCellValue("ExamVisitCopayLimitValue");
                          String strApplyDeductibleOONValue = getCellValue("ApplyDeductibleOONValue");
                          String strExamVisitCopayOONValue = getCellValue("ExamVisitCopayOONValue");
                          String strCoInsuranceOONValue = getCellValue("CoInsuranceOONValue");
                          String strEmergencyDiagnosisPaidAtINNLevelOffice = getCellValue("emergencyDiagnosisPaidAtINNLevelOffice");
                          
                          seSetText(FindPlanPage.get().planVersionID, planid, "Set text in plan version id");
                          seClick(FindPlanPage.get().planSearch, "Search");
                          waitForPageLoad();
                          seClick(BenefitRetainsInProductionPage.get().searchedPlanClick, " Searched plan");
                          waitForPageLoad();
					Boolean blnPlanStatusRejectedAudit= PlanHeaderPage.get().seVerifyPlanStatus("Rejected Audit");
					if(blnPlanStatusRejectedAudit==true){
							log(PASS, "Plan Status is updated to Rejected Audit,RESULT=PASS");
						}
					else { 
							new TimeoutException("Plan is not in Rejected Audit status");
						}	
					seWaitForPageLoad();
					seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().scrollDown, 20);
					seClick(PCPSPCBreakoutSetupPage.get().scrollDown, "Scroll Down");
					seClick(PCPSPCBreakoutSetupPage.get().scrollDown, "Scroll Down");					
					waitForPageLoad();
					seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().planOptions, 50);
					seClick(PCPSPCBreakoutSetupPage.get().planOptions, "Plan Options");
					waitForPageLoad(30,10);	
					/*In Network office exams */
					seClick(BenefitRetainsInProductionPage.get().benefitSpecificCostShares, "Benefit specific Cost Shares");
					seWaitForPageLoad();
					seIsElementDisplayed(BenefitRetainsInProductionPage.get().applyDeductible,"Apply Deductible");
					seIsElementDisplayed(BenefitRetainsInProductionPage.get().examVisitCopay,"In Network Exam Visit Copay");
					seIsElementDisplayed(BenefitRetainsInProductionPage.get().examVisitCopayLimit,"In Network Exam Visit Copay Limit");
					
					seClick(BenefitRetainsInProductionPage.get().applyDeductibleValue, "Apply Deductible");
					seWaitForPageLoad();
					seSetText(BenefitRetainsInProductionPage.get().applyDeductibleValueEnter, strApplyDeductibleValue, "Apply Deductible");
                    BenefitRetainsInProductionPage.get().applyDeductibleValueEnter.sendKeys(Keys.TAB);
                    seWaitForPageLoad();
                    
                    seClick(BenefitRetainsInProductionPage.get().examVisitCopayValue,"In Network Exam Visit Copay");
                    waitForPageLoad();
                    seSetText(BenefitRetainsInProductionPage.get().examVisitCopayValueEnter, strExamVisitCopayValue, "In Network Exam Visit Copay");
                    BenefitRetainsInProductionPage.get().examVisitCopayValueEnter.sendKeys(Keys.TAB);
                    seWaitForPageLoad();
                    
                    seClick(BenefitRetainsInProductionPage.get().examVisitCopayLimitValue, "In Network Exam Visit Copay Limit");
                    seWaitForPageLoad();
                    seSetText(BenefitRetainsInProductionPage.get().examVisitCopayLimitValueEnter, strExamVisitCopayLimitValue, "In Network Exam Visit Copay Limit");
                    BenefitRetainsInProductionPage.get().examVisitCopayLimitValueEnter.sendKeys(Keys.TAB);
                    seWaitForPageLoad();
                    
                    /*Out of network office Exams */
                    seClick(BenefitRetainsInProductionPage.get().benefitSpecificCostSharesOON, "Benefit specific Cost Shares");
                    seWaitForPageLoad();
                    seIsElementDisplayed(BenefitRetainsInProductionPage.get().applyDeductibleOON,"Apply Deductible");
					seIsElementDisplayed(BenefitRetainsInProductionPage.get().examVisitCopayOON,"Out of Network Exam Visit Copay");
					seIsElementDisplayed(BenefitRetainsInProductionPage.get().emergencyDiagnosisPaidAtINNLevelOffice,"Emergency Diagnosis Paid At In Network Level Office ");
					seIsElementDisplayed(BenefitRetainsInProductionPage.get().coInsuranceOON,"Out of Network Exam Coinsurance");
					
					seClick(BenefitRetainsInProductionPage.get().applyDeductibleOONValue,"Apply Deductible");
                    waitForPageLoad();
                    seSetText(BenefitRetainsInProductionPage.get().applyDeductibleOONValueEnter, strApplyDeductibleOONValue, "Apply Deductible");
                    BenefitRetainsInProductionPage.get().applyDeductibleOONValueEnter.sendKeys(Keys.TAB);
                    seWaitForPageLoad();
                    
                    seClick(BenefitRetainsInProductionPage.get().examVisitCopayOONValue,"Out of Network Exam Visit Copay");
                    waitForPageLoad();
                    seSetText(BenefitRetainsInProductionPage.get().examVisitCopayOONValueEnter, strExamVisitCopayOONValue, "Out of Network Exam Visit Copay");
                    BenefitRetainsInProductionPage.get().examVisitCopayOONValueEnter.sendKeys(Keys.TAB);
                    seWaitForPageLoad();
                    
                    seClick(BenefitRetainsInProductionPage.get().emergencyDiagnosisPaidAtINNLevelOfficeValue,"Emergency Diagnosis Paid At In Network Level Office");
                    waitForPageLoad();
                    seSetText(BenefitRetainsInProductionPage.get().emergencyDiagnosisPaidAtINNLevelOfficeEnter, strEmergencyDiagnosisPaidAtINNLevelOffice, "Emergency Diagnosis Paid At In Network Level Office");
                    BenefitRetainsInProductionPage.get().emergencyDiagnosisPaidAtINNLevelOfficeEnter.sendKeys(Keys.TAB);
                    seWaitForPageLoad();
                    
                    seClick(BenefitRetainsInProductionPage.get().coInsuranceOONValue,"Out of Network Exam Coinsurance");
                    waitForPageLoad();
                    seSetText(BenefitRetainsInProductionPage.get().coInsuranceOONValueEnter, strCoInsuranceOONValue, "Out of Network Exam Coinsurance");
                    BenefitRetainsInProductionPage.get().coInsuranceOONValueEnter.sendKeys(Keys.TAB);
                    seWaitForPageLoad();
                    
                    
                    seClick(PlanOptionsPage.get().saveButton, "Save");
					waitForPageLoad();
					seWaitForClickableWebElement(PlanHeaderPage.get().requestAudit,1);
					seClick(PlanHeaderPage.get().requestAudit, "request Audit button");
					waitForPageLoad();
					PlanTransitionPage.get().updateReasonCode("Other");
					seClick(PlanTransitionPage.get().requestAudit, "Request Audit button");
					waitForPageLoad();
					try{
						seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 360);
					    }
					catch(TimeoutException e){
			            seClick(PlanHeaderPage.get().close, "Close button");
			            }
					seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
					waitForPageLoad();
					seClick(PlanHeaderPage.get().userLogout, "Logout");
					waitForPageLoad(20,10); 
					seCloseBrowser();
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
                    LoginPage.get().loginApplication(strUserProfileApprover);
					waitForPageLoad();
					
					FindPlanPage.seSearchByPlanProxyID(getCellValue("Plan_ID"));
					waitForPageLoad(45);
					
					 Boolean auditStatus= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
					 
					 if(auditStatus==true){
							log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");
						}
						else { 
							throw new TimeoutException("Plan is not in Pending Audit status");
						}	
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			//seCloseBrowser();
			endTestScript();
		}

	}

}
