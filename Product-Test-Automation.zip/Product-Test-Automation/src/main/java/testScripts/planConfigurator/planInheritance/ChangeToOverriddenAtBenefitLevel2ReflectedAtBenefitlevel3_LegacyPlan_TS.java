package testScripts.planConfigurator.planInheritance;

import org.openqa.selenium.Keys;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;

import page.planConfigurator.CreateLegacyPlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.LoginPage;
import page.planInheritance.PlanInheritancePage;
import utility.CoreSuperHelper;

public class ChangeToOverriddenAtBenefitLevel2ReflectedAtBenefitlevel3_LegacyPlan_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {
		              
        try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try { 
					 String strRunFlag = getCellValue("Run_Flag");
					 String strTCName = getCellValue("TCName");
					 String strTCID = getCellValue("TC_ID");
					 logExtentReport("ChangeToOverriddenAtBenefitLevel2ReflectedAtBenefitlevel3_LegacyPlan_TS");
					 if(strRunFlag.equalsIgnoreCase("YES")) {
						    String[] strLevel2CopayValue = getCellValue("Level2CopayValues").split(",");
						 	seOpenBrowser(BrowserConstants.Chrome, baseURL);
						 	LoginPage.get().loginApplication(userProfile);
						 	CreateLegacyPlanPage.seCreatePlan(false,intMaxWaitTime);   
							waitForPageLoad(300);
							FindPlanPage.get().benefit();
							waitForPageLoad(360);
							// Overridden Level 2 value
							seClick(PlanInheritancePage.get().selectAntidiabetics, "Select Level 2 Benefit Antidiabetics");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectParentInpatientPlaceofService, "Select Formulary Tier 1");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectBenefitCopayRetail, "Select benefit Copay");
							seSetText(PlanInheritancePage.get().textHFCParentcoinsurance, strLevel2CopayValue[0]);
							PlanInheritancePage.get().textHFCParentcoinsurance.sendKeys(Keys.ENTER);
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectSave, "Save Button");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectAntidiabeticsAmylinAnalogs, "Select Level 3 Benefit Antidiabetics Amylin Analogs");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectParentInpatientPlaceofService, "Select Formulary Tier 1");
							waitForPageLoad(360);
							boolean Copayvalue =PlanInheritancePage.get().coinsuranceValue(strLevel2CopayValue[0]);
							if(Copayvalue){
								RESULT_STATUS = true;
								log(PASS, "Verify level 3 benefit inherited value from Level 2", "level 3 benefit inherited value from Level 2",true);
							}else
							{
								RESULT_STATUS = false;
								log(FAIL, "level 3 benefit not inherited value from Level 2", "level 3 benefit not inherited value from Level 2",true);
							}
							// Overridden Level 2 value again
							seClick(PlanInheritancePage.get().selectAntidiabetics, "Select Level 2 Benefit Antidiabetics");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectParentInpatientPlaceofService, "Select Formulary Tier 1");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectBenefitCopayRetail, "Select benefit Copay");
							seSetText(PlanInheritancePage.get().textHFCParentcoinsurance, strLevel2CopayValue[1]);
							PlanInheritancePage.get().textHFCParentcoinsurance.sendKeys(Keys.ENTER);
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectSave, "Save Button");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectAntidiabeticsAmylinAnalogs, "Select Level 3 Benefit Antidiabetics Amylin Analogs");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectParentInpatientPlaceofService, "Select Formulary Tier 1");
							waitForPageLoad(360);
							//verify inherited value
							boolean OverriddenCopayvalue =PlanInheritancePage.get().coinsuranceValue(strLevel2CopayValue[1]);
							if(OverriddenCopayvalue){
								RESULT_STATUS = true;
								log(PASS, "Verify level 3 benefit inherited overridden value from Level 2", "level 3 benefit inherited overridden value from Level 2",true);
							}else
							{
								RESULT_STATUS = false;
								log(FAIL, "level 3 benefit not inherited overridden value from Level 2", "level 3 benefit not inherited overridden value from Level 2",true);
							}
							log(RESULT_STATUS?PASS:FAIL, strTCID,strTCName);
						 }									
				}	
				catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					 setResult("STATUS", RESULT_STATUS);
					 seCloseBrowser();
				}
			}
        }
        catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
        
