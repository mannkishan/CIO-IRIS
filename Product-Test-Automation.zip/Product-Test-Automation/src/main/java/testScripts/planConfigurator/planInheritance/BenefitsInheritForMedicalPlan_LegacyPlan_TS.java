package testScripts.planConfigurator.planInheritance;

import org.openqa.selenium.Keys;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;

import page.planConfigurator.CreateLegacyPlanPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.LoginPage;
import page.planInheritance.PlanInheritancePage;
import utility.CoreSuperHelper;

public class BenefitsInheritForMedicalPlan_LegacyPlan_TS extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {
		              
        try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try { 
					 String strRunFlag = getCellValue("Run_Flag");
					 logExtentReport("BenefitsInheritForMedicalPlan_LegacyPlan_TS");
					 if(strRunFlag.equalsIgnoreCase("YES")) {
						    String strPlanLevelCopayValue = getCellValue("PlanlevelCopayValues");
						    String strPlanLevelCoinsuValue = getCellValue("PlanlevelCoinsValues");
						 	seOpenBrowser(BrowserConstants.Chrome, baseURL);
						 	LoginPage.get().loginApplication(userProfile);
							//CreatePlanPage.get().createLegacyPlan(false,intMaxWaitTime);
						 	CreateLegacyPlanPage.seCreatePlan(false,intMaxWaitTime);
							waitForPageLoad(300);
							FindPlanPage.get().benefit();
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectParentBenefitHFC, "Select Parent Benefit Hospital / Facility Care");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectParentInpatientPlaceofService, "Select Inpatient Place of Service");
							seClick(PlanInheritancePage.get().HFCParentcopayment, "HFC Parent copayment");
							seSetText(PlanInheritancePage.get().textHFCParentcopayment, strPlanLevelCopayValue);
							PlanInheritancePage.get().textHFCParentcopayment.sendKeys(Keys.ENTER);
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().HFCParentcoinsurance, "HFC Parent Coinsurance");
							seSetText(PlanInheritancePage.get().textHFCParentcoinsurance, strPlanLevelCoinsuValue);
							PlanInheritancePage.get().textHFCParentcoinsurance.sendKeys(Keys.ENTER);
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectSave, "Save Button");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectChildBenefitBariatric, "Select Child Benefit Bariatric");
							seClick(PlanInheritancePage.get().selectChildInpatientPlaceofService, "Select Inpatient Place of Service");
							boolean Copayvalue =PlanInheritancePage.get().copaymentValue(strPlanLevelCopayValue);
							if(Copayvalue){
								log(PASS, "Verify Coipayment inherited value from Plan Level", "Expected Coipayment inherited value from Plan Level");
							}else
							{
								log(FAIL, "Coipayment not inherited value from Plan Level", "Coipayment not inherited value from Plan Level");
							}
							
							boolean Coinsvalue =PlanInheritancePage.get().coinsuranceValue(strPlanLevelCoinsuValue);
							if(Coinsvalue){
								log(PASS, "Verify Coinsurance inherited value from Plan Level", "Expected Coinsurance inherited value from Plan Level");
							}else
							{
								log(FAIL, "Coinsurance not inherited value from Plan Level", "Coinsurance not inherited value from Plan Level");
							}	
						 }									
				}
				
				catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					 seCloseBrowser();
				}
}
        }
        catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
        