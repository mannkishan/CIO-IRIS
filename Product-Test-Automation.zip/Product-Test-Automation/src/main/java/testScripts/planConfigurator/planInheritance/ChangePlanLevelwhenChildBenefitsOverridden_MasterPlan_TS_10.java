package testScripts.planConfigurator.planInheritance;

import org.openqa.selenium.Keys;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.LoginPage;
import page.planInheritance.PlanInheritancePage;
import utility.CoreSuperHelper;

public class ChangePlanLevelwhenChildBenefitsOverridden_MasterPlan_TS_10 extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {
		              
        try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try { 
					 String strRunFlag = getCellValue("Run_Flag");
					 String strTCName = getCellValue("TCName");
					 String strTCID = getCellValue("TC_ID");
					 logExtentReport("ChangePlanLevelwhenChildBenefitsOverridden_MasterPlan_TS_10");
					 if(strRunFlag.equalsIgnoreCase("YES")) {
						   // String strPlanLevelCopayValue = getCellValue("PlanlevelCopayValues");
						    String strSetPlanLevelCoinsuValue = getCellValue("SetPlanlevelCoinsValues");
						    String strSetChildLevelCoinsuValue = getCellValue("SetChildlevelCoinsValue");
						 	seOpenBrowser(BrowserConstants.Chrome, baseURL);
						 	LoginPage.get().loginApplication(userProfile);
							CreatePlanPage.get().createPlan(true,intMaxWaitTime); 
							waitForPageLoad(300);
							PlanInheritancePage.get().planLevelbenefit();
							waitForPageLoad(360);
							String inNetworkCoinsValue = seGetElementValue(PlanInheritancePage.get().InNetworkCoinsValue);
				   			setCellValue("PlanlevelCoinsValues", inNetworkCoinsValue);
				   		    String strPlanLevelCoinsuValue = getCellValue("PlanlevelCoinsValues");
				   			FindPlanPage.get().benefit();
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectParentBenefitHFC, "Select Parent Benefit Hospital / Facility Care");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectParentInpatientPlaceofService, "Select Inpatient Place of Service");
							waitForPageLoad(360);
							boolean ParentCoinsvalue =PlanInheritancePage.get().coinsuranceValue(strPlanLevelCoinsuValue);
							if(ParentCoinsvalue){
								RESULT_STATUS = true;
								log(PASS, "Verify Parent level benefit Coinsurance inherited value from Plan Level", "Expected Parent level benefit Coinsurance inherited value from Plan Level",true);
							}else
							{
								RESULT_STATUS = false;
								log(FAIL, "Parent level benefit Coinsurance not inherited value from Plan Level", "Parent level benefit Coinsurance not inherited value from Plan Level",true);
							}
							seClick(PlanInheritancePage.get().selectChildBenefitBariatric, "Select Child Benefit Bariatric");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectChildInpatientPlaceofService, "Select Tire 1");
							waitForPageLoad(360);
							boolean ChildCoinsvalue =PlanInheritancePage.get().coinsuranceValue(strPlanLevelCoinsuValue);
							if(ChildCoinsvalue){
								RESULT_STATUS = true;
								log(PASS, "Verify Child level benefit Coinsurance inherited value from Plan Level", "Expected Child level benefit Coinsurance inherited value from Plan Level",true);
							}else
							{
								RESULT_STATUS = false;
								log(FAIL, "Child level benefit Coinsurance not inherited value from Plan Level", "Child level benefit Coinsurance not inherited value from Plan Level",true);
							}
							// Override the child level benefit
							seClick(PlanInheritancePage.get().childcoinsurance, "Child Coinsurance");
							seSetText(PlanInheritancePage.get().textHFCParentcoinsurance, strSetChildLevelCoinsuValue);
							PlanInheritancePage.get().textHFCParentcoinsurance.sendKeys(Keys.ENTER);
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectSave, "Save Button");
							waitForPageLoad(360);
							PlanInheritancePage.get().planLevelbenefit();
							waitForPageLoad(360);
							//Change the plan level 
							seClick(PlanInheritancePage.get().childcoinsurance, "Select Plan Level Coinsurance");
							seSetText(PlanInheritancePage.get().textHFCParentcoinsurance, strSetPlanLevelCoinsuValue);
							PlanInheritancePage.get().textHFCParentcoinsurance.sendKeys(Keys.ENTER);
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectSave, "Save Button");
							waitForPageLoad(360);
							FindPlanPage.get().benefit();
							waitForPageLoad(360);
							//Verify the overridden child benefit
							seClick(PlanInheritancePage.get().selectChildBenefitBariatric, "Select Child Benefit Bariatric");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectChildInpatientPlaceofService, "Select Tire 1");
							String inNetworkCoinsChildValue = seGetElementValue(PlanInheritancePage.get().InNetworkCoinsuranceValue);
							//verify inherited value
							if(!inNetworkCoinsChildValue.equals(strPlanLevelCoinsuValue))
							{
								RESULT_STATUS = true;
								log(PASS, "Verify Overridden Benefit will not inherited the Plan Level change", "Expected Overridden Benefit not inherited the Plan Level change",true);
							}else
							{
								RESULT_STATUS = false;
								log(FAIL, "Overridden Benefit inherited the Plan Level change", "Overridden Benefit inherited the Plan Level change",true);
							}
							log(RESULT_STATUS?PASS:FAIL, strTCID,strTCName);
						 }									
				}
				
				catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					 setResult("STATUS", RESULT_STATUS);
					 seCloseBrowser();
				}
}
        }
        catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
        
