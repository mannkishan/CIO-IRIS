package testScripts.planConfigurator.planInheritance;

import org.openqa.selenium.Keys;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;

import page.planConfigurator.ChangeReportPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.LoginPage;
import page.planInheritance.PlanInheritancePage;
import utility.CoreSuperHelper;

public class BenefitsInheritForDentalPlan_MasterPlan_TS_15 extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {
		              
        try {
        	MANUAL_TC_EXECUTION_EFFORT ="00:30:00";
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try { 
					 String strRunFlag = getCellValue("Run_Flag");
					 String strTCName = getCellValue("TCName");
				     String strTCID = getCellValue("TC_ID");
					 logExtentReport("BenefitsInheritForDentalPlan_MasterPlan_TS_15");
					 if(strRunFlag.equalsIgnoreCase("YES")) {
						    String strPlanLevelCopayValue = getCellValue("PlanlevelCopayValues");
						    String strPlanLevelCoinsuValue = getCellValue("PlanlevelCoinsValues");
						    String strAccumNameCopay = getCellValue("AccumNameCopay");
						    String strAccumNameCoins = getCellValue("AccumNameCoins");
						    String strparentbenefit = getCellValue("ParentBenefit");
						    String strchildbenefit = getCellValue("ChildBenefit");
						    String strTier = getCellValue("Tier");
						 	seOpenBrowser(BrowserConstants.Chrome, baseURL);
						 	LoginPage.get().loginApplication(userProfile);
							CreatePlanPage.get().createPlan(true,intMaxWaitTime); 
							waitForPageLoad(300);
							FindPlanPage.get().benefit();
							waitForPageLoad(360);
							seSetText(FindTemplatePage.get().benefitsSearchField, strparentbenefit, "Setting benefit value in search field");
							waitForPageLoad(600); 
							seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
							waitForPageLoad(600); 
							seClick(ChangeReportPage.get().situationType(strTier), "click on Tier1");
							waitForPageLoad(360); 
							seClick(PlanInheritancePage.get().selectDropdown2(strAccumNameCopay), "Select Parent Filling Copay");
							waitForPageLoad();
							seSetText(PlanInheritancePage.get().textParentFillingCopayment, strPlanLevelCopayValue);
							PlanInheritancePage.get().textParentFillingCopayment.sendKeys(Keys.ENTER);
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectDropdown2(strAccumNameCoins), "Select Parent Filling Coinsurance");
							waitForPageLoad();
							seSetText(PlanInheritancePage.get().textParentFillingCoinsurance, strPlanLevelCoinsuValue);
							PlanInheritancePage.get().textParentFillingCoinsurance.sendKeys(Keys.ENTER);
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectSave, "Save Button");
							waitForPageLoad(360);
							seSetText(FindTemplatePage.get().benefitsSearchField, strchildbenefit, "Setting benefit value in search field");
							waitForPageLoad(360); 
							seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
							waitForPageLoad(600); 
							seClick(ChangeReportPage.get().situationType(strTier), "click on Tier1");
							waitForPageLoad(360);
							//verify inherited value
							boolean Copayvalue =PlanInheritancePage.get().copaymentValue(strPlanLevelCopayValue);
							if(Copayvalue){
								RESULT_STATUS = true;
								log(PASS, "Verify Copayment inherited value from Plan Level", "Expected Copayment inherited value from Plan Level",true);
							}else
							{
								RESULT_STATUS = false;
								log(FAIL, "Copayment not inherited value from Plan Level", "Copayment not inherited value from Plan Level",true);
							}
							
							boolean Coinsvalue =PlanInheritancePage.get().coinsuranceValue(strPlanLevelCoinsuValue);
							if(Coinsvalue){
								RESULT_STATUS = true;
								log(PASS, "Verify Coinsurance inherited value from Plan Level", "Expected Coinsurance inherited value from Plan Level",true);
							}else
							{
								RESULT_STATUS = false;
								log(FAIL, "Coinsurance not inherited value from Plan Level", "Coinsurance not inherited value from Plan Level",true);
							}	
							//log(RESULT_STATUS?PASS:FAIL, strTCID,strTCName);
						 }									
				}
				
				catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					// setResult("STATUS", RESULT_STATUS);
					 seCloseBrowser();
				}
}
        }
        catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
        
