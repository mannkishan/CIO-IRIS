package testScripts.planConfigurator.planInheritance;

import org.openqa.selenium.Keys;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.LoginPage;
import page.planInheritance.PlanInheritancePage;
import utility.CoreSuperHelper;

public class BenefitsWithoutPMOverride_MasterPlan_TS_01 extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {
		              
        try {
        	MANUAL_TC_EXECUTION_EFFORT ="00:10:00";
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					 
					 String strRunFlag = getCellValue("Run_Flag");
					 String strTCName = getCellValue("TCName");
					 String strTCID = getCellValue("TC_ID");
					 logExtentReport("BenefitsWithoutPMOverride_MasterPlan_TS_01");
					 if(strRunFlag.equalsIgnoreCase("YES")) {
						    String strPlanLevelValue = getCellValue("Planlevelvalues");
						 	seOpenBrowser(BrowserConstants.Chrome, baseURL);
						 	LoginPage.get().loginApplication(userProfile);
							CreatePlanPage.get().createPlan(true,intMaxWaitTime); 
							waitForPageLoad(300);
							PlanInheritancePage.get().planLevelbenefit();
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().mailCoverage, " Mail Coverage ");
							seClick(PlanInheritancePage.get().formularyTier1MailCoinsurance, "Formulary Tier1 Mail Coinsurance");
							seSetText(PlanInheritancePage.get().textFormularyTier2MailCoinsurance, strPlanLevelValue);
							PlanInheritancePage.get().textFormularyTier2RetailCoinsurance.sendKeys(Keys.ENTER);
							seClick(PlanInheritancePage.get().selectSave, "Save Button");
							waitForPageLoad(600);
							FindPlanPage.get().benefit();
							waitForPageLoad(600);
							seClick(PlanInheritancePage.get().selectBenefit, "Select Benefit");
							waitForPageLoad(600);
							seClick(PlanInheritancePage.get().selectFirstRow, "Select Formulary Tier2 Retail");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectChildCoveredOverride, "Select covered");
							waitForPageLoad(360);
							//verify inherited value
							boolean value =PlanInheritancePage.get().coinsuranceValue(strPlanLevelValue);
							if(value){
								RESULT_STATUS = true;
								log(PASS, "Verify Coinsurance inherited value from Plan Level", "Expected Coinsurance inherited value from Plan Level",true);
							}else
							{
								RESULT_STATUS = false;
								log(FAIL, "Coinsurance not inherited value from Plan Level", "Coinsurance not inherited value from Plan Level",true);
							}	
							//log(RESULT_STATUS?PASS:FAIL, strTCID,strTCName);
						 }									
				}
				
				catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					// setResult("STATUS", RESULT_STATUS);
					 seCloseBrowser();
				}
}
        }
        catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
        
