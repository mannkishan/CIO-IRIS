package testScripts.planConfigurator.planInheritance;

import org.openqa.selenium.Keys;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.LoginPage;
import page.planInheritance.PlanInheritancePage;
import utility.CoreSuperHelper;

public class ChildBenefitsNotInherit_MasterPlan_TS_05 extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {
		              
        try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					 
					 String strRunFlag = getCellValue("Run_Flag");
					 String strTCName = getCellValue("TCName");
					 String strTCID = getCellValue("TC_ID");
					 logExtentReport("ChildBenefitsNotInherit_MasterPlan_TS");
					 if(strRunFlag.equalsIgnoreCase("YES")) {
						    String[] strPlanLevelValue = getCellValue("ParentlevelCoinsValues").split(",");
						 	seOpenBrowser(BrowserConstants.Chrome, baseURL);
						 	LoginPage.get().loginApplication(userProfile);
							CreatePlanPage.get().createPlan(true,intMaxWaitTime); 
							waitForPageLoad(300);
							FindPlanPage.get().benefit();
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectBenefit, "Select Benefit");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectFormularyTier1Mail, "Select Formulary Tier1 Mail");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectParentCoveredOverride,"Select Covered Override");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectParentBiologicalsCoinsurance, "Select Parent Filling Coinsurance");
							waitForPageLoad();
							seSetText(PlanInheritancePage.get().textParentBiologicalsCoinsurance, strPlanLevelValue[0]);
							PlanInheritancePage.get().textParentBiologicalsCoinsurance.sendKeys(Keys.ENTER);
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectSave, "Save Button");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectChildBenefitAllergens, "Select Child Benefit Allergens");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectFormularyTier1Retail, "Select Formulary Tier1 Retail");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectChildCoveredOverride,"Select Covered Override");
							waitForPageLoad(360);
							//verify inherited value
							boolean CoinsValue = PlanInheritancePage.get().coinsuranceValue(strPlanLevelValue[1]);
							if(CoinsValue){
								RESULT_STATUS = true;
								log(PASS, "Coinsurance not inherited value from Plan Level", "Coinsurance not inherited value from Plan Level",true);
							}else
							{
								RESULT_STATUS = false;
								log(FAIL, "Verify Coinsurance inherited value from Plan Level", "Expected Coinsurance inherited value from Plan Level",true);
							}	
							log(RESULT_STATUS?PASS:FAIL, strTCID,strTCName);
						 }									
				}
				
				catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					 setResult("STATUS", RESULT_STATUS);
					 seCloseBrowser();
				}
}
        }
        catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
        
