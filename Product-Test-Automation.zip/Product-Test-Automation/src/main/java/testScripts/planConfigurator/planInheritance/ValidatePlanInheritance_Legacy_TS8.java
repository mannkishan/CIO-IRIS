package testScripts.planConfigurator.planInheritance;


import org.openqa.selenium.Keys;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;

import page.planConfigurator.CreateLegacyPlanPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanInheritancePage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;

public class ValidatePlanInheritance_Legacy_TS8 extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile3 = EnvHelper.getValue("user.profile");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {

		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {

					
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");

					String strValue=getCellValue("Accumvalue");
					String strTier=getCellValue("Tier");
					String strTierName=getCellValue("TierName");

					String strSearchLevel1=getCellValue("SearchLevel1");
					String strSearchLevel2=getCellValue("SearchLevel2");
					String strCopayValue=getCellValue("copayvalue");
					String strSearchLevel3=getCellValue("SearchLevel3");
					String strAccumulatorName =getCellValue("AccumulatoName");



					if(strRunFlag.equalsIgnoreCase("YES")) {
						seOpenBrowser(BrowserConstants.Chrome, baseURL);
						LoginPage.get().loginApplication(userProfile3);
						logExtentReport(strTCName);	
						waitForPageLoad();
						CreateLegacyPlanPage.seCreatePlan(false, 10);

						waitForPageLoad();


						String strPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
						waitForPageLoad();
						String strPlanProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
						waitForPageLoad();
						setCellValue("LegacyPlanID", strPlanVersionID);
						setCellValue("LegacyProxyID", strPlanProxyID);
						waitForPageLoad();



						PlanOptionsPage.clickBenefit();
						waitForPageLoad(600);
						seSetText(FindTemplatePage.get().benefitsSearchField, strSearchLevel1, "Setting benefit value in search field");
						waitForPageLoad(600); 
						seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
						waitForPageLoad(600); 
						seClick(PlanOptionsPage.get().situationType(strTier, strTierName), "click on Tier1");
						waitForPageLoad(600);
						sePCSelectText(PlanInheritancePage.get().copay(strAccumulatorName), "copay", strValue, intMaxWaitTime);
						waitForPageLoad();
						seClick(PlanInheritancePage.get().clearButton,"clear button");
						waitForPageLoad(600);
						seSetText(FindTemplatePage.get().benefitsSearchField, strSearchLevel2, "Setting benefit value in search field");
						waitForPageLoad(600); 
						seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
						waitForPageLoad(600); 
						seClick(PlanOptionsPage.get().situationType(strTier, strTierName), "click on Tier1");
						waitForPageLoad(600);

						String level2Value=	seGetElementValue(PlanInheritancePage.get().AccumValue(strAccumulatorName));

						if(level2Value.equalsIgnoreCase(strCopayValue))
						{
							RESULT_STATUS=true;
							log(PASS,level2Value , "Benefits with PM Override should not inherit plan level accumulator changes");
						}
						else 
						{
							RESULT_STATUS=false;
							log(FAIL,level2Value , "Benefits with PM Override inherit plan level accumulator changes", true);
						}

					}
					seClick(PlanInheritancePage.get().clearButton,"clear button");
					waitForPageLoad(600);
					seSetText(FindTemplatePage.get().benefitsSearchField, strSearchLevel3, "Setting benefit value in search field");
					waitForPageLoad(600); 
					seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
					waitForPageLoad(600); 
					seClick(PlanOptionsPage.get().situationType(strTier, strTierName), "click on Tier1");
					waitForPageLoad(600);
					if(!PlanInheritancePage.get().radioButton.isSelected())
						seClick(PlanInheritancePage.get().radioButton, "radio button");
					waitForPageLoad(600);
					String level3Value=	seGetElementValue(PlanInheritancePage.get().AccumValue(strAccumulatorName));

					if(level3Value.equalsIgnoreCase(strValue))
					{
						RESULT_STATUS=true;
						log(PASS,level3Value , "level3 should inherit level1 value");
					}
					else 
					{
						RESULT_STATUS=false;
						log(FAIL,level3Value , "level3 should not inherit level1 value ", true);
					}
				}

				catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					setResult("STATUS", RESULT_STATUS); 
					seCloseBrowser();
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}



