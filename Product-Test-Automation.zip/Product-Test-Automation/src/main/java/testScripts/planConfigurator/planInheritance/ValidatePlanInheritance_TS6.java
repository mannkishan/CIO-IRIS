package testScripts.planConfigurator.planInheritance;


import org.openqa.selenium.Keys;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;

import page.planConfigurator.CreateLegacyPlanPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanInheritancePage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;

public class ValidatePlanInheritance_TS6 extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile3 = EnvHelper.getValue("user.profile");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {

		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {

					
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					String strValue=getCellValue("Accumvalue");
					String strTier=getCellValue("Tier");
					String strTierName=getCellValue("TierName");
					String strSearch1=getCellValue("Search1");
					String strSearch2=getCellValue("Search2");
					String childFeildValue="";
					String strPlanVersionID="";
					String strPlanProxyId="";
					String strAccumulatorName =getCellValue("AccumulatoName");
					if(strRunFlag.equalsIgnoreCase("YES")) {
						logExtentReport(strTCName);
						seOpenBrowser(BrowserConstants.Chrome, baseURL);
						LoginPage.get().loginApplication(userProfile3);
						logExtentReport(strTCName);	

						CreatePlanPage.get().createPlan(true,460);

						waitForPageLoad(600);

						strPlanVersionID =getCellValue("PlanVersionID");
						System.out.println(strPlanVersionID);
						waitForPageLoad(600);
						PlanOptionsPage.clickBenefit();
						waitForPageLoad(600);
						seSetText(FindTemplatePage.get().benefitsSearchField, strSearch1, "Setting benefit value in search field");
						waitForPageLoad(600); 
						seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
						waitForPageLoad(600); 
						seClick(PlanOptionsPage.get().situationType(strTier, strTierName), "click on Tier1");
						waitForPageLoad(600);
						if(!PlanInheritancePage.get().radioButton.isSelected())
							seClick(PlanInheritancePage.get().radioButton, "radio button");
						waitForPageLoad(600);
						sePCSelectText(PlanInheritancePage.get().copay(strAccumulatorName), "parentFeild",strValue, intMaxWaitTime);
						waitForPageLoad(600);
						seClick(PlanOptionsPage.get().saveButton, "Save");
						waitForPageLoad(600);
						seClick(PlanInheritancePage.get().clearButton,"clear button");
						waitForPageLoad(600);
						seSetText(FindTemplatePage.get().benefitsSearchField, strSearch2, "Setting benefit value in search field");
						waitForPageLoad(600); 
						seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
						waitForPageLoad(600); 
						seClick(PlanOptionsPage.get().situationType(strTier, strTierName), "click on Tier1");
						waitForPageLoad(600);
						if(!PlanInheritancePage.get().radioButton.isSelected())
							seClick(PlanInheritancePage.get().radioButton, "radio button");
						waitForPageLoad(600);
						childFeildValue=seGetText(PlanInheritancePage.get().benefitAccumValue(strAccumulatorName));

						if(childFeildValue.equalsIgnoreCase(strValue))
						{
							RESULT_STATUS=true;
							log(PASS,childFeildValue , "plan inheritance is working fine");
						}
						else 
						{
							RESULT_STATUS=false;
							log(FAIL,childFeildValue , "plan inheritance is not  working fine ", true);
						}


						seClick(PlanOptionsPage.get().saveButton, "Save");

						waitForPageLoad(600);
						//FindPlanPage.get().findPlan(strPlanVersionID);
						PlanHeaderPage.get().SeMoveToProductionPlan(strPlanVersionID, intMaxWaitTime);
						waitForPageLoad(600);
						PlanOptionsPage.clickBenefit();
						waitForPageLoad(600);

						seSetText(FindTemplatePage.get().benefitsSearchField, strSearch1, "Setting benefit value in search field");
						waitForPageLoad(600); 
						seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
						waitForPageLoad(600); 
						seClick(PlanOptionsPage.get().situationType(strTier, strTierName), "click on Tier1");
						waitForPageLoad(600);


						seClick(PlanInheritancePage.get().clearButton,"clear button");
						waitForPageLoad(600);
						seSetText(FindTemplatePage.get().benefitsSearchField,strSearch2, "Setting benefit value in search field");
						waitForPageLoad(600); 
						seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
						waitForPageLoad(600); 
						seClick(PlanOptionsPage.get().situationType(strTier, strTierName), "click on Tier1");
						waitForPageLoad(600);

						childFeildValue=seGetText(PlanInheritancePage.get().benefitAccumValueProduction(strAccumulatorName));

						if(childFeildValue.equalsIgnoreCase(strValue))
						{
							RESULT_STATUS=true;
							log(PASS,childFeildValue , "plan inheritance is working fine");
						}
						else 
						{
							RESULT_STATUS=false;
							log(FAIL,childFeildValue , "plan inheritance is not  working fine ", true);
						}


					}
				}

				catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					setResult("STATUS", RESULT_STATUS); 
					seCloseBrowser();
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}

