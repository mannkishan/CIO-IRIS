package testScripts.planConfigurator.planInheritance;

import org.openqa.selenium.Keys;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.LoginPage;
import page.planInheritance.PlanInheritancePage;
import utility.CoreSuperHelper;

public class BenefitsInheritForVisionPlan_MasterPlan_TS_16 extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {
		              
        try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try { 
					 String strRunFlag = getCellValue("Run_Flag");
					 String strTCName = getCellValue("TCName");
					 String strTCID = getCellValue("TC_ID");
					 logExtentReport("BenefitsInheritForVisionPlan_MasterPlan_TS_16");
					 if(strRunFlag.equalsIgnoreCase("YES")) {
						    String strPlanLevelCoinsuValue = getCellValue("PlanlevelCoinsValues");
						 	seOpenBrowser(BrowserConstants.Chrome, baseURL);
						 	LoginPage.get().loginApplication(userProfile);
						 	CreatePlanPage.get().createPlan(true,intMaxWaitTime);
							waitForPageLoad(300);
							FindPlanPage.get().benefit();
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectAntiReflectiveLenses, "Select Anti Reflective Lenses");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectAdultTire11, "Select Adult Tire1");
							waitForPageLoad();
							seClick(PlanInheritancePage.get().selectParentEyeglassesCoinsurance, "Select Parent Eyeglasses Coinsurance");
							seSetText(PlanInheritancePage.get().textParentVisionCoinsurance, strPlanLevelCoinsuValue);
							PlanInheritancePage.get().textParentVisionCoinsurance.sendKeys(Keys.ENTER);
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectSave, "Save Button");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectAntReflectiveCoating, "Select Child Benefit");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectAdultTire11, "Select Adult Tire1");
							waitForPageLoad(360);
							//verify inherited value
							boolean Coinsvalue =PlanInheritancePage.get().coinsuranceValue(strPlanLevelCoinsuValue);
							if(Coinsvalue){
								RESULT_STATUS = true;
								log(PASS, "Verify Coinsurance inherited value from Plan Level", "Expected Coinsurance inherited value from Plan Level",true);
							}else
							{
								RESULT_STATUS = false;
								log(FAIL, "Coinsurance not inherited value from Plan Level", "Coinsurance not inherited value from Plan Level",true);
							}	
							log(RESULT_STATUS?PASS:FAIL, strTCID,strTCName);
						 }									
				}
				
				catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					 setResult("STATUS", RESULT_STATUS);
					 seCloseBrowser();

				}
}
        }
        catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
        
