//package testScripts.planConfigurator.planInheritance;
//
//
//
//import com.anthem.crypt.EnvHelper;
//import com.anthem.selenium.constants.BrowserConstants;
//import page.planConfigurator.CreatePlanPage;
//import page.planConfigurator.FindTemplatePage;
//import page.planConfigurator.LoginPage;
//import page.planConfigurator.PlanInheritancePage;
//import page.planConfigurator.PlanOptionsPage;
//import utility.CoreSuperHelper;
//
//public class ValidatePlanInheritance_TS3 extends CoreSuperHelper {
//                static String baseURL = EnvHelper.getValue("pc.url");
//                static String userProfile3 = EnvHelper.getValue("user.profile");
//                static int intMaxWaitTime=450;
//
//                public static void main(String[] args) {
//
//                                try {
//                                	MANUAL_TC_EXECUTION_EFFORT="00:15:00";
//                                                initiateTestScript();
//
//                                                for (iROW = 1; iROW <= getRowCount(); iROW++) {
//                                                                try {
//
//                                                                				
//                                                                                String strRunFlag = getCellValue("Run_Flag");
//                                                                                String strTCName = getCellValue("TCName");
//                                                                                String strValue=getCellValue("Accumvalue");
//                                                                                String strTier=getCellValue("Tier");
//                                                                                String strTierName=getCellValue("TierName");
//                                                                                
//                                                                                String strOptionsTab = getCellValue("OptionsTab");
//                                                                                String strAccumulator1 = getCellValue("Accum1");
//                                                                                String strAccumulator2 = getCellValue("Accum2");
//                                                                                
//                                                                                String strMin = getCellValue("Min");
//                                                                                String strMax = getCellValue("Max");
//                                                                                String strPercentage = getCellValue("Percentage");
//                                                                                String strAmount = getCellValue("Amount");
//                                                                                
//                                                                                String strAccumulatorName = getCellValue("AccumulatorName");
//                                                                                if(strRunFlag.equalsIgnoreCase("YES")) {
//                                                                                                seOpenBrowser(BrowserConstants.Chrome, baseURL);
//                                                                                                LoginPage.get().loginApplication(userProfile3);
//                                                                                                logExtentReport(strTCName);   
//                                                                                                
//                                                                                                CreatePlanPage.get().createPlan(true,460);
//
//                                                                                                
//                                                                                                waitForPageLoad(600);
//                                                                                                PlanOptionsPage.clickTab(strOptionsTab, strAccumulator1, intMaxWaitTime);
//                                                                                                waitForPageLoad(600);
//                                                                                                seClick(PlanInheritancePage.get().retailcost,"Clicking on benefit search button");
//                                                                                                waitForPageLoad(600);
//                                                                                                seClick(PlanInheritancePage.get().mailcost,"Clicking on benefit search button");
//                                                                                                waitForPageLoad(600);
//                                                                                                
//                                                                                                PlanOptionsPage.clickTab(strOptionsTab, strAccumulator2, intMaxWaitTime);
//                                                                                                waitForPageLoad(600);
//                                                                                                seClick(PlanInheritancePage.get().retailcost2,"Clicking on benefit search button");
//                                                                                                waitForPageLoad(600);
//                                                                                                seClick(PlanInheritancePage.get().mailcost2,"Clicking on benefit search button");
//                                                                                                waitForPageLoad(600);
//                                                                                                
//                                                                                                
//                                                                                                PlanOptionsPage.clickBenefit();
//                                                                                                waitForPageLoad(600);
//                                                                                                seSetText(FindTemplatePage.get().benefitsSearchField, strAccumulator1, "Setting benefit value in search field");
//                                                                                                waitForPageLoad(600); 
//                                                                                                seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
//                                                                                                waitForPageLoad(600); 
//                                                                                                seClick(PlanOptionsPage.get().situationType(strTier, strTierName), "click on Tier1");
//                                                                                                waitForPageLoad(600);
//                                                                                                sePCSelectText(PlanInheritancePage.get().benefitAccumValue(strAccumulatorName), "parentFeild",strValue, intMaxWaitTime);
//                                                                                                if(!PlanInheritancePage.get().checkBox.isSelected())
//                                                                                                                seClick(PlanInheritancePage.get().checkBox, "check box");
//                                                                                                waitForPageLoad(600);                                                                                 
//                                                                                                sePCSelectText(PlanInheritancePage.get().benefitAccumValueType(strMin), "parentFeild",strValue, intMaxWaitTime);
//                                                                                                sePCSelectText(PlanInheritancePage.get().benefitAccumValueType(strMax), "parentFeild",strValue, intMaxWaitTime);
//                                                                                                sePCSelectText(PlanInheritancePage.get().benefitAccumValueType(strPercentage), "parentFeild",strValue, intMaxWaitTime);
//                                                                                                                                                                                
//                                                                                                                                                                                                seClick(PlanOptionsPage.get().saveButton, "Save");
//                                                                                                waitForPageLoad(600);
//
//                                                                                                PlanOptionsPage.clickBenefit();
//                                                                                                waitForPageLoad(600);
//                                                                                                seSetText(FindTemplatePage.get().benefitsSearchField, strAccumulator2, "Setting benefit value in search field");
//                                                                                                waitForPageLoad(600); 
//                                                                                                seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
//                                                                                                waitForPageLoad(600); 
//                                                                                                seClick(PlanOptionsPage.get().situationType(strTier, strTierName), "click on Tier1");
//                                                                                                waitForPageLoad(600);
//                                                                                                String MinValue=seGetElementValue(PlanInheritancePage.get().benefitAccumValueType(strMin));
//                                                                                                String MaxValue=seGetElementValue(PlanInheritancePage.get().benefitAccumValueType(strMax));
//                                                                                                String PercentageValue=seGetElementValue(PlanInheritancePage.get().benefitAccumValueType(strPercentage));
//                                                                                                String AccumulatorValue=seGetElementValue(PlanInheritancePage.get().benefitAccumValue(strAccumulatorName));
//                                                                                                
//                                                                                                if(MinValue.equalsIgnoreCase(strMin)&& MaxValue.equalsIgnoreCase(strMax) &&  PercentageValue.equalsIgnoreCase(strPercentage)&& AccumulatorValue.equalsIgnoreCase(strAmount) )
//                                                                                                {
//                                                                                                                RESULT_STATUS=true;
//                                                                                                                log(PASS, "child Benefit inherits the values from the parent except for Pre Auth and Deductible.");
//                                                                                                }
//                                                                                                else 
//                                                                                                {
//                                                                                                                RESULT_STATUS=false;
//                                                                                                                log(FAIL ,"only override override for copay and coinsurance,OOP","child Benefit do not inherits the values from the parent except for Pre Auth and Deductible.", true);
//                                                                                                }
//
//                                                                                }
//                                                                }
//
//                                                                catch (Exception e) {
//                                                                                e.printStackTrace();
//                                                                                log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
//                                                                } finally {
//                                                                                setResult("STATUS", RESULT_STATUS); 
//                                                                                
//                                                                }
//                                                }
//                                }
//                                catch (Exception e) {
//                                                e.printStackTrace();
//                                                log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
//                                } finally {
//                                                endTestScript();
//                                                seCloseBrowser();
//                                }
//                                
//                }
//}
