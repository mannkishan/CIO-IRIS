package testScripts.planConfigurator.planInheritance;

import org.openqa.selenium.Keys;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.LoginPage;
import page.planInheritance.PlanInheritancePage;
import utility.CoreSuperHelper;

public class BenefitsInheritForMedicalPlan_MasterPlan_TS_14 extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {
		              
        try {
        	MANUAL_TC_EXECUTION_EFFORT ="00:10:00";
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try { 
					 String strRunFlag = getCellValue("Run_Flag");
					 String strTCName = getCellValue("TCName");
					 String strTCID = getCellValue("TC_ID");
					 logExtentReport("BenefitsInheritForMedicalPlan_MasterPlan_TS_14");
					 if(strRunFlag.equalsIgnoreCase("YES")) {
						    String strPlanLevelCopayValue = getCellValue("PlanlevelCopayValues");
						    String strPlanLevelCoinsuValue = getCellValue("PlanlevelCoinsValues");
						 	seOpenBrowser(BrowserConstants.Chrome, baseURL);
						 	LoginPage.get().loginApplication(userProfile);
							CreatePlanPage.get().createPlan(true,intMaxWaitTime); 
							waitForPageLoad(300);
							FindPlanPage.get().benefit();
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectParentBenefitHFC, "Select Parent Benefit Hospital / Facility Care");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectParentInpatientPlaceofService, "Select Inpatient Place of Service");
							seClick(PlanInheritancePage.get().HFCParentcopayment, "HFC Parent copayment");
							seSetText(PlanInheritancePage.get().textHFCParentcopayment, strPlanLevelCopayValue);
							PlanInheritancePage.get().textHFCParentcopayment.sendKeys(Keys.ENTER);
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().HFCParentcoinsurance, "HFC Parent Coinsurance");
							seSetText(PlanInheritancePage.get().textHFCParentcoinsurance, strPlanLevelCoinsuValue);
							PlanInheritancePage.get().textHFCParentcoinsurance.sendKeys(Keys.ENTER);
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectSave, "Save Button");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectChildBenefitBariatric, "Select Child Benefit Bariatric");
							seClick(PlanInheritancePage.get().selectChildInpatientPlaceofService, "Select Inpatient Place of Service");
							//verify inherited value
							boolean Copayvalue =PlanInheritancePage.get().copaymentValue(strPlanLevelCopayValue);
							if(Copayvalue){
								RESULT_STATUS = true;
								log(PASS, "Verify Copayment inherited value from Plan Level", "Expected Copayment inherited value from Plan Level",true);
							}else
							{
								RESULT_STATUS = false;
								log(FAIL, "Copayment not inherited value from Plan Level", "Copayment not inherited value from Plan Level",true);
							}
							
							boolean Coinsvalue =PlanInheritancePage.get().coinsuranceValue(strPlanLevelCoinsuValue);
							if(Coinsvalue){
								RESULT_STATUS = true;
								log(PASS, "Verify Coinsurance inherited value from Plan Level", "Expected Coinsurance inherited value from Plan Level",true);
							}else
							{
								RESULT_STATUS = false;
								log(FAIL, "Coinsurance not inherited value from Plan Level", "Coinsurance not inherited value from Plan Level",true);
							}	
							log(RESULT_STATUS?PASS:FAIL, strTCID,strTCName);
						 }									
				}
				
				catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					 setResult("STATUS", RESULT_STATUS);
					 seCloseBrowser();
				}
}
        }
        catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
        
