package testScripts.planConfigurator.planInheritance;


import javax.naming.spi.DirStateFactory.Result;

import org.openqa.selenium.Keys;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;

import page.planConfigurator.CreateLegacyPlanPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanInheritancePage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;

public class ValidatePlanInheritance_TS8 extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile3 = EnvHelper.getValue("user.profile");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {

		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {

					
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					String strSearch1=getCellValue("Search1");
					String strSearch2=getCellValue("Search2");
					String strSearch3=getCellValue("Search3");                                        
					String strAccumulatorName =getCellValue("AccumulatoName");
					String strAccumMaxValue=getCellValue("AccumulatorMaxValue");
					String strTier=getCellValue("Tier");
					String strTierName=getCellValue("TierName");
					String strCoinValue=getCellValue("CoinValue");

					if(strRunFlag.equalsIgnoreCase("YES")) {
						logExtentReport(strTCName);	
						seOpenBrowser(BrowserConstants.Chrome, baseURL);
						LoginPage.get().loginApplication(userProfile3);
						CreatePlanPage.get().createPlan(true,460);
						waitForPageLoad(600);
						PlanOptionsPage.clickBenefit();
						waitForPageLoad(600);
						seSetText(FindTemplatePage.get().benefitsSearchField, strSearch1, "Setting benefit value in search field");
						waitForPageLoad(600); 
						seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
						waitForPageLoad(600); 
						seClick(PlanOptionsPage.get().situationType(strTier, strTierName), "click on Tier1");
						waitForPageLoad(600);
						sePCSelectText(PlanInheritancePage.get().benefitAccumValue(strAccumulatorName), "parentFeild",strAccumMaxValue, intMaxWaitTime);
						waitForPageLoad(600);
						seClick(PlanInheritancePage.get().clearButton,"clear button");
						waitForPageLoad(600);
						seSetText(FindTemplatePage.get().benefitsSearchField, strSearch2, "Setting benefit value in search field");
						waitForPageLoad(600); 
						seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
						waitForPageLoad(600); 
						seClick(PlanOptionsPage.get().situationType(strTier, strTierName), "click on Tier1");
						waitForPageLoad(600);
						String level2Value=seGetElementValue(PlanInheritancePage.get().benefitAccumValue(strAccumulatorName));

						if(level2Value.equalsIgnoreCase(strCoinValue))
						{
							RESULT_STATUS=true;
							log(PASS,level2Value , "Benefits with PM Override should not inherit plan level accumulator changes");
						}
						else 
						{
							RESULT_STATUS=false;
							log(FAIL,level2Value , "Benefits with PM Override inherit plan level accumulator changes", true);
						}

						waitForPageLoad(600);	
						seClick(PlanInheritancePage.get().clearButton,"clear button");
						waitForPageLoad(600);							
					seSetText(FindTemplatePage.get().benefitsSearchField, strSearch3, "Setting benefit value in search field");
					waitForPageLoad(600); 
					seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
					waitForPageLoad(600); 
					seClick(PlanOptionsPage.get().situationType(strTier, strTierName), "click on Tier1");
					waitForPageLoad(600);
					String level3Value=seGetElementValue(PlanInheritancePage.get().benefitAccumValue(strAccumulatorName));
					if(strAccumMaxValue.equalsIgnoreCase(level3Value))
					{
						RESULT_STATUS=true;
						log(PASS,level3Value , "level3 should inherit level1 value");
					}
					else 
					{
						RESULT_STATUS=false;
						log(FAIL,level3Value , "level3 should not inherit level1 value ", true);
					}
				}
				}

				catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					setResult("STATUS", RESULT_STATUS); 
					//seCloseBrowser();
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
			seCloseBrowser();
		}
	}
}

