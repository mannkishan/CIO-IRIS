package testScripts.planConfigurator.planInheritance;

import org.openqa.selenium.Keys;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;

import page.planConfigurator.CreateLegacyPlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.LoginPage;
import page.planInheritance.PlanInheritancePage;
import utility.CoreSuperHelper;

public class BenefitsWithoutPMOverride_LegacyPlan_TS_01 extends CoreSuperHelper {
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {
		              
        try {
        	MANUAL_TC_EXECUTION_EFFORT ="00:10:00";
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					 
					 String strRunFlag = getCellValue("Run_Flag");
					 String strTCName = getCellValue("TCName");
					 String strTCID = getCellValue("TC_ID");
					 logExtentReport("BenefitsWithoutPMOverride_LegacyPlan_TS_01");
					 if(strRunFlag.equalsIgnoreCase("YES")) {
						    String strPlanLevelValue = getCellValue("PlanlevelCopayValues");
						 	seOpenBrowser(BrowserConstants.Chrome, baseURL);
						 	LoginPage.get().loginApplication(userProfile);
							//CreatePlanPage.get().createLegacyPlan(false,intMaxWaitTime); 
						 	CreateLegacyPlanPage.seCreatePlan(false,intMaxWaitTime);
							waitForPageLoad(300);
							seClick(PlanInheritancePage.get().level1NetworkCoverage, "Clicked on level 1 Network Coverage");
							seClick(PlanInheritancePage.get().formularyTier2RetailCoinsurance, "Formulary Tier2 Retail Coinsurance");
							seSetText(PlanInheritancePage.get().textFormularyTier2RetailCoinsurance, strPlanLevelValue);
							PlanInheritancePage.get().textFormularyTier2RetailCoinsurance.sendKeys(Keys.ENTER);
							seClick(PlanInheritancePage.get().selectSave, "Save Button");
							waitForPageLoad(360);
							FindPlanPage.get().benefit();
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectBenefit, "Select Benefit");
							waitForPageLoad(360);
							seClick(PlanInheritancePage.get().selectFormularyTier2Retail, "Select Formulary Tier2 Retail");
							waitForPageLoad(360);
							//verify inherited value
							boolean value =PlanInheritancePage.get().coinsuranceValue(strPlanLevelValue);
							if(value){
								RESULT_STATUS = true;
								log(PASS, "Verify Coinsurance inherited value from Plan Level", "Expected Coinsurance inherited value from Plan Level",true);
							}else
							{
								RESULT_STATUS = false;
								log(FAIL, "Coinsurance not inherited value from Plan Level", "Coinsurance not inherited value from Plan Level",true);
							}	
							//log(RESULT_STATUS?PASS:FAIL, strTCID,strTCName);
						 }									
				}
				
				catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					// setResult("STATUS", RESULT_STATUS);
					 seCloseBrowser();
				}
}
        }
        catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
        
