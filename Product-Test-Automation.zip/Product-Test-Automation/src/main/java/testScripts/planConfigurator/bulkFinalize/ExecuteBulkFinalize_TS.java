package testScripts.planConfigurator.bulkFinalize;


import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BulkFinalizeFindPlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HistoryPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.ImpactReviewPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import utility.CoreSuperHelper;
import utility.ExcelUtility;
import utility.PCUtils;
import utility.PlanXMLParser;

/**
 * Manual test case: <Validate Bulk Finalize>
 * @author AF19349
 * @since 02-Nov-2017
 */
public class ExecuteBulkFinalize_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static String strDownloadPath = "";
	static int intMaxWaitTime = 300;

	public static void main(String[] args) {

		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("Bulk Finalize");
					strDownloadPath = getReportPathFolder();
					String strRunFlag = getCellValue("Run_Flag");
					String included = getCellValue("Include");
					String excluded = getCellValue("Exclude");
					String strSchedDay1 = getCellValue("ScheduleDay1");
					boolean strScheduleDay1=Boolean.parseBoolean(strSchedDay1);
					String strScheduleDay2 = getCellValue("ScheduleDay2");
					boolean isScheduleDay2Exc = Boolean.parseBoolean(strScheduleDay2);
					boolean isIncluded= Boolean.parseBoolean(included);					
					boolean isExcluded= Boolean.parseBoolean(excluded);
					String strReportID = getCellValue("ReportID");
					String strImpactReportPath= getCellValue("ImpactReportPath");
					String strSchedPlanVersionID = getCellValue("SchedulePlanVersionID");
					String status = getCellValue("Status");
					String strEffectiveDate = getCellValue("EffectiveDate");
					String strdownloadPath=getReportPathFolder();	
					String strreportFolder = "";
					String strupdateid = "";
					String strupdatereportFolder = "";
					String strPlanVersionID1 = "";
					String strPlanVersionID2 = "";
					boolean isPlan1Finalized = false;
					boolean isPlan2Finalized = false;
					String strPlanProxyID1 = "";
					String strPlanProxyID2 = "";
					if(strRunFlag.equalsIgnoreCase("YES")) {
					if(getWebDriver()==null)
					{
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL,strDownloadPath);
						LoginPage.get().loginApplication(strUserProfile);
						waitForPageLoad(2,intMaxWaitTime);
					}

					if(!isScheduleDay2Exc)
					{
						waitForPageLoad(360);
						seClick(HomePage.get().massUpdate,"Mass Update link");
						seWaitForElementLoad(HomePage.get().createNew);
						seClick(HomePage.get().createNew,"Create New");
						seWaitForClickableWebElement(HomePage.get().bulkFinalize,120);
						seClick(HomePage.get().bulkFinalize,"Bulk Finalize");

						seSetText(BulkFinalizeFindPlanPage.get().effectiveDate, strEffectiveDate, "Setting text value in effective date text field");
						BulkFinalizeFindPlanPage.get().effectiveDate.sendKeys("{ENTER}");
						waitForPageLoad(intMaxWaitTime);
						sePCSelectText(BulkFinalizeFindPlanPage.get().headerValue, "Status", status, intMaxWaitTime);
						waitForPageLoad(intMaxWaitTime);
						seClick(FindPlanPage.get().optionCriteria, "optionCriteria");
						BulkFinalizeFindPlanPage.get().validateOptionCrteriaBulkFinalize(isIncluded, isExcluded);
						String strVID = BulkFinalizeFindPlanPage.get().clickBulkFinalizeCheckBox(strScheduleDay1);
						if(strScheduleDay1)
						{
							setCellValue("SchedulePlanVersionID", strVID);
						}
						else {
							if(strVID.contains(":")){						
								strPlanVersionID1= strVID.split(":")[0];
								strPlanVersionID2= strVID.split(":")[1];
							}
							else
							{
								strPlanVersionID1=strVID;
							}								
						}						
						waitForPageLoad(intMaxWaitTime);
						seClick(true,BulkFinalizeFindPlanPage.get().bulkFinalizeButton, "Bulk Finalize");
						waitForPageLoad(intMaxWaitTime);
						seSetText(BulkFinalizeFindPlanPage.get().commentBulkFinalize, "Comment");
						waitForPageLoad(20);
						seClick(true,BulkFinalizeFindPlanPage.get().submitBulkFinalizeButton, "submit");


						if(strScheduleDay1){
							String strscheduleDate=getCellValue("ScheduleDate");
							String strTime=getCellValue("ScheduleTime");
							String strid =BulkFinalizeFindPlanPage.get().schedulebulkFinalize(strscheduleDate,strTime);
							setCellValue("ReportID", strid);
							strreportFolder = strdownloadPath+"Bulk Finalize - "+strid+" - Impact Report.xlsx";
							setCellValue("ImpactReportPath", strreportFolder);
						}
						else{
							waitForPageLoad(intMaxWaitTime);
							String strid = PCUtils.downloadImpactReviewReport();
							strreportFolder = strdownloadPath+"Bulk Finalize - "+strid+" - Impact Report.xlsx";
							seSetText(ImpactReviewPage.get().id,strid,"ID Field");
							seClick(ImpactReviewPage.get().execute,"Execute button");
							waitForPageLoad(intMaxWaitTime);
							strupdateid=HistoryPage.get().downloadUpdateReport(strid);
							strupdatereportFolder = strdownloadPath+"Bulk Finalize - "+strupdateid+" - Update Report.xlsx";	
							ExcelUtility.get().validateUpateReportForBulkFinalize(strPlanVersionID1,strupdatereportFolder);
							isPlan1Finalized = BulkFinalizeFindPlanPage.get().verifyPlanStatus(strPlanVersionID1);
							strPlanProxyID1 = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1].trim();
							waitForPageLoad(intMaxWaitTime);
							//Validate XML
							if(isPlan1Finalized)
							{
								DownloadXML(strPlanProxyID1, strTestRegion, strDownloadPath);	
								PlanXMLParser.validatePlanStatus(strDownloadPath+strTestRegion+"_"+strPlanProxyID1+".xml");
							}
							else
							{
								log(FAIL, "Validate Plan status in XML", "Plan "+strPlanVersionID1+" not moved to pending finalization or Production", true);
							}
							if(!strPlanVersionID2.equalsIgnoreCase(""))
							{
								ExcelUtility.get().validateUpateReportForBulkFinalize(strPlanVersionID2,strupdatereportFolder);
								isPlan2Finalized = BulkFinalizeFindPlanPage.get().verifyPlanStatus(strPlanVersionID2);
								strPlanProxyID2 = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1].trim();
								waitForPageLoad(intMaxWaitTime);
								//Validate XML
								if(isPlan2Finalized)
								{
									DownloadXML(strPlanProxyID2, strTestRegion, strDownloadPath);	
									PlanXMLParser.validatePlanStatus(strDownloadPath+strTestRegion+"_"+strPlanProxyID2+".xml");
								}
								else
								{
									log(FAIL, "Validate Plan status in XML", "Plan "+strPlanVersionID2+" not moved to pending finalization or Production", true);
								}
							}
						}	
					}
					else
					{
						waitForPageLoad(intMaxWaitTime);
						seClick(HomePage.get().massUpdate,"Mass Update link");
						waitForPageLoad(intMaxWaitTime);						
						seClick(HomePage.get().historyLnk,"History link");
						waitForPageLoad(intMaxWaitTime);
						strupdateid=HistoryPage.get().downloadUpdateReport(strReportID);
						strupdatereportFolder = strdownloadPath+"Bulk Finalize - "+strupdateid+" - Update Report.xlsx";	
						ExcelUtility.get().validateUpateReportForBulkFinalize(strSchedPlanVersionID,strupdatereportFolder);
						isPlan1Finalized = BulkFinalizeFindPlanPage.get().verifyPlanStatus(strSchedPlanVersionID);
						String planProxyID1 = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1].trim();
						//Validate XML
						if(isPlan1Finalized)
						{
							DownloadXML(planProxyID1, strTestRegion, strDownloadPath);	
							PlanXMLParser.validatePlanStatus(strDownloadPath+strTestRegion+"_"+planProxyID1+".xml");
						}
						else
						{
							log(FAIL, "Validate Plan status in XML", "Plan "+strPlanVersionID1+" not moved to pending finalization or Production", true);
						}
					}
					}
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			seCloseBrowser();
			endTestScript();
		}
	}

}
