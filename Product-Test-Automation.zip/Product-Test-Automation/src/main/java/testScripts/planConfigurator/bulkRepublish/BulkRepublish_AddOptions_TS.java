package testScripts.planConfigurator.bulkRepublish;


import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitsPage;
import page.planConfigurator.EditTemplateInformationPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HistoryPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.ImpactReviewPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MassUpdatePage;
import page.planConfigurator.PlanBenefitOptionsPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import page.planConfigurator.TemplateBenefitOptionPage;
import page.planConfigurator.TemplateBenefitPage;
import page.planConfigurator.TemplateHeaderPage;
import page.planConfigurator.TemplatePlanOptionPage;
import page.planConfigurator.TemplatePlanSetUpPage;
import utility.CoreSuperHelper;
import utility.ExcelUtility;
import utility.PCUtils;

public class BulkRepublish_AddOptions_TS extends CoreSuperHelper{
	
	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	static String strdownloadPath = "";
	static String strtemplateVersionID = "";
	static String strAddOrRemovePlanOption = "";
	static String strPlanOption = "";
	static String strAddOrRemoveBenefitOption = "";
	static String strBenefitOption = "";
	static String strAddOrRemoveBenefit = "";
	static String strBenefit = "";
	static String strBenefitFrondEndName = "";
	static String strPlanID1 = "";
	static String strPlanID2 = "";
	static String strPlanID3 = "";
	static String straddOrRemoveSituationType = "";
	static String strSituationTypeServiceCode= "";
	static String strUpdateUMRule = "";
	static boolean booEditPlanOptionFlag = false;
	static String strTemplateName = "";
	static String strupdatereportFolder = "";
	static String notUpdatedUMRule = "";
	static String strreportFolder  = "";
	static boolean booupdateUMRuleFlag = false;
	static boolean addOrRemovePlanOptionStatus = false;
	static boolean addOrRemoveBenefitOptionStatus = false;
	static boolean addOrRemoveBenefit = false;
	static boolean addOrRemoveSituationType = false;
	static boolean booEditPlanOptionStatus = false;
	static String strExistingApplyDeducticle = "";
	static String strUpdatedApplyDeducticle = "";
	static String  currentUMRule = "";
	static String priorUMRule= "";
	
	public static void main(String[] args) {

		try {
			MANUAL_TC_EXECUTION_EFFORT = "00:17:00";
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strTestCaseID = getCellValue("Test_Case_ID");
					String strRunFlag = getCellValue("Run_Flag");
					String strUpdatePlanID1 = "";
					String strUpdatePlanID2 = "";
					
					if(strRunFlag.equalsIgnoreCase("YES")) {
						logExtentReport(getCellValue("TCName"));
						if(strTestCaseID.equalsIgnoreCase("Create Test Data for Add Options"))
						{
							loadTestDataVariables();
						}
						else if(!strTestCaseID.equalsIgnoreCase("Validate Changes in Not Republished Plans"))
						{
							strUpdatePlanID1 = ExcelUtility.get().getNewPlanID(strupdatereportFolder, strPlanID1);
		                       strUpdatePlanID2 = ExcelUtility.get().getNewPlanID(strupdatereportFolder, strPlanID2); 
		                       
						}
						strdownloadPath=getReportPathFolder();	
						String strEffectiveDate=getCellValue("EffectiveDate");
						 String strupdateid = "";
						
						switch (strTestCaseID) {
						case "Create Test Data for Add Options":
							// Creation of test data for bulk republish add options 
							seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad(300);
							System.out.println(HomePage.get().find.isEnabled());
							FindTemplatePage.findTemplate(strtemplateVersionID);
							waitForPageLoad(300);
							seClick(TemplateHeaderPage.get().edit, "Edit Button ");
							waitForPageLoad(300);					
							seClick(EditTemplateInformationPage.get().save, "Save Button ");
							waitForPageLoad(360);
							strtemplateVersionID = TemplateHeaderPage.get().getTemplateVersionID().trim();
							for(iROW=2;iROW<=getRowCount(); iROW++)
							{
							String strTCName = getCellValue("Test_Case_ID");
							String updateFlag = getCellValue("Run_Flag");
							if(updateFlag.equalsIgnoreCase("YES"))
							{
							switch (strTCName) {
							case "Validate Update UM Rule":
								log(INFO, "Updating UM Rule","Update UM Rule for Bulk Republish process");
									seWaitForClickableWebElement(TemplatePlanSetUpPage.get().planAdministration,60);
									seClick(TemplatePlanSetUpPage.get().planAdministration, "Plan Administration");
									waitForPageLoad(360);
									 priorUMRule=	seGetDropDownValue(TemplatePlanSetUpPage.get().UMRulePenaltyPlanDesign);
									 currentUMRule = TemplatePlanSetUpPage.get().updateUMRule();
									 if(!currentUMRule.isEmpty())
									 {
										 booupdateUMRuleFlag = true;
									 }
								log(booupdateUMRuleFlag?PASS:FAIL, "Updating UM Rule Status","Update UM Rule for Bulk Republish process");
								break;
							case "Validate Add Plan Option":
								log(INFO, "Add a Plan Option","Add a Plan option for the bulk republish process");
								addOrRemovePlanOptionStatus= TemplatePlanOptionPage.get().addOrRemovePlanOption("ADD",strPlanOption);
								log(addOrRemovePlanOptionStatus?PASS:FAIL, "Add a Plan Option","Add a Plan option for the bulk republish process");
								break;
							case "Validate Add  Benefit Option":
								log(INFO, "Add a Benefit Option");
								addOrRemoveBenefitOptionStatus=TemplateBenefitOptionPage.get().addOrRemoveBenefitOption("ADD");
								log(addOrRemoveBenefitOptionStatus?PASS:FAIL, "Add a Benefit Option");
								break;
							case "Validate Add Benefit":
								log(INFO, "Add a Benefit ");
								addOrRemoveBenefit= TemplateBenefitPage.get().addOrRemoveBenefit(strBenefitFrondEndName	, "ADD");
								log(addOrRemoveBenefit?PASS:FAIL, "Add a Benefit", "Create test data for Bulk republish process for Add a benefit");
								break;
							case "Validate Add Situation":
								log(INFO, "Add a Situation type ");
								addOrRemoveSituationType= TemplateBenefitPage.get().addOrRemoveSituationType("ADD");
								log(addOrRemoveSituationType?PASS:FAIL, "Add a Situation type ");
								break;
							default:
								break;
							}
							waitForPageLoad(360);
							}
							}
							iROW = 1;
							
							seClick(FindTemplatePage.get().save, "Click Save Button ");
							waitForPageLoad(360);	
							log(INFO, "Moving Template to Production");
							waitForPageLoad(300);	
							FindTemplatePage.requestAuditTemplate(strtemplateVersionID);
							seCloseBrowser();
							//Logging with another approver
							seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
							LoginPage.get().loginApplication(strauditApprover);
							waitForPageLoad();
							FindTemplatePage.findTemplate(strtemplateVersionID);						
							FindTemplatePage.approveAuditTemplate();
							setCellValue("TemplateVersionID", strtemplateVersionID);
							seCloseBrowser();
							log(INFO, "Bulk Republish Process Started","Bulk Republish Process");
							seOpenBrowser(BrowserConstants.Chrome, strbaseURL,strdownloadPath);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad();
							String strplanID=MassUpdatePage.bulkRepublish(strTemplateName,strEffectiveDate,"Medical");
							String[] strplanId=strplanID.split(":");
							strPlanID1=strplanId[0];
							strPlanID2=strplanId[1];
							strPlanID3=strplanId[2];
							String strid = PCUtils.downloadImpactReviewReport();
							 strreportFolder = strdownloadPath+"Bulk Republish - "+strid+" - Impact Report.xlsx";
							seSetText(ImpactReviewPage.get().id,strid,"ID Field");
	                        seClick(ImpactReviewPage.get().execute,"Execute button");
	                       strupdateid=HistoryPage.get().downloadUpdateReport(strid);
	                       strupdatereportFolder = strdownloadPath+"Bulk Republish - "+strupdateid+" - Update Report.xlsx";
	                       seCloseBrowser();
							break;
//							 Creation of test data for bulk republish process completes here
						case "Validate Update UM Rule":
							 if(booupdateUMRuleFlag)
		                        {
		                        	log(INFO, "Validate Update UM Rule","Started Validation Update UM Rule Current UM RUle: "+currentUMRule+" Prior UM Rule: "+priorUMRule+ " in Impact Analysis and Update Report");
		                        	ExcelUtility.get().validateUMRuleImpact(strPlanID1,strreportFolder,currentUMRule,priorUMRule);
		                    		ExcelUtility.get().validateUMRuleImpact(strPlanID2,strreportFolder,currentUMRule,priorUMRule);
		                    		ExcelUtility.get().validateUMRuleChangeUpdateReport(strPlanID1, strupdatereportFolder, currentUMRule, priorUMRule);
		                    		ExcelUtility.get().validateUMRuleChangeUpdateReport(strPlanID2, strupdatereportFolder, currentUMRule, priorUMRule);
		                    		log(INFO, "Completed Validation Update UM Rule in Impact Analysis and Update Report","");
		                        }
		                        else
		                        {
		                        	 RESULT_STATUS = false;
		                        	log(FAIL, "Verify Bulk republish process for Update UM Rule","Updating UM Rule is failed");
		                        }
							break;
						case "Validate Add Benefit":
							   if(addOrRemoveBenefit)
		                        {
		                        	String strStepName = "Validate Add a Benefit  in update report";
		                        	log(INFO, "Validate Add Benefit", "Started Validation Add Benefit in Impact Analysis and Update Report");
		                        	ExcelUtility.get().validateBenefitChange(strPlanID1,strreportFolder,strBenefit, true);
		    						ExcelUtility.get().validateBenefitChange(strPlanID2,strreportFolder,strBenefit, true);
		    						ExcelUtility.get().validateUpateReportForAddOrRemove(strPlanID1,strupdatereportFolder,strBenefit,strStepName, true);
		    						ExcelUtility.get().validateUpateReportForAddOrRemove(strPlanID2,strupdatereportFolder,strBenefit,strStepName, true);
		                        	log(INFO, "Completed Validation Add Benefit in Impact Analysis and Update Report","");
		                        }
		                        else
		                        {
		                        	 RESULT_STATUS = false;
		                        	log(FAIL, "Verify Bulk republish process for Add Benefit","Add Benefit is failed as the data creation process is failed");
		                        }
							break;
						case "Validate Add Situation":
	                        if(addOrRemoveSituationType)
	                        {
	                        	log(INFO,"Validate Add Situation" ,"Started Validation Add Situation in Impact Analysis and Update Report");
	                        	ExcelUtility.get().validateSituationChange(strPlanID1, strreportFolder, strSituationTypeServiceCode, true);
	    						ExcelUtility.get().validateSituationChange(strPlanID2, strreportFolder, strSituationTypeServiceCode, true);
	                        	ExcelUtility.get().validateUpdateSituationTypeChange(strPlanID1,strupdatereportFolder,strSituationTypeServiceCode, true);
	                            ExcelUtility.get().validateUpdateSituationTypeChange(strPlanID2,strupdatereportFolder,strSituationTypeServiceCode, true);	
	                        	log(INFO, "Completed Validation Add Situation in Impact Analysis and Update Report","");
	                        }
	                        else
	                        {
	                        	 RESULT_STATUS = false;
	                        	log(FAIL, "Verify Bulk republish process for Add Situation","Add Situation is failed as the data creation process is failed");
	                        }
						default:
							break;
						}
		if(!strTestCaseID.equalsIgnoreCase("Create Test Data for Add Options"))
							{
						String[] strUpdatedPlans = {strUpdatePlanID1,strUpdatePlanID2};
						if(getWebDriver()==null)
						{
                        seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
                        waitForPageLoad();
                        LoginPage.get().loginApplication(struserProfile);
                        waitForPageLoad();
						}
						if(!strTestCaseID.equalsIgnoreCase("Validate Changes in Not Republished Plans"))
						{
                        for(int intIndex = 0; intIndex<2; intIndex++)
                        {
                        	 if(!strUpdatedPlans[intIndex].isEmpty())
                             {
                        		boolean  booFoundPlan = FindPlanPage.get().findPlan(strUpdatedPlans[intIndex]);
                             	waitForPageLoad(360);
                             	switch (strTestCaseID) {
								case "Validate Update UM Rule":
									seClick(PlanSetupPage.get().planAdministration, "Plan Adminsitration");
	                             	waitForPageLoad(300);
	                             	String planUMRule = PlanSetupPage.get().umRulePenaltyPlanDesign.getText();
	                             	if(currentUMRule.equalsIgnoreCase(planUMRule))
	                             	{
	                             		 RESULT_STATUS = true;
	                             		log(PASS, "Validate UM Rule Change in the Plan with Plan id: "+strUpdatedPlans[intIndex], "Validation successful for UM Rule in the new plan");
	                             	}
	                             	else
	                             	{
	                             		 RESULT_STATUS = false;
	                             		log(FAIL, "Validate UM Rule Change in the Plan with Plan id: "+strUpdatedPlans[intIndex], 
	                             				"Validation failed for UM Rule in the new plan +Actual UM Rule value: "+planUMRule+" Expected UM Rule: "+currentUMRule);
	                             	}
									break;
								case "Validate Add Plan Option":
									PlanOptionsPage.get().verifyChangeInPlanOption(true, strPlanOption, strUpdatedPlans[intIndex], booFoundPlan);
									break;
								case "Validate Add  Benefit Option":
									PlanBenefitOptionsPage.get().verifyBeneiftOptionChangeInPlan(true	, strBenefitOption, 
	                             			strUpdatedPlans[intIndex],booFoundPlan);
									break;
								case "Validate Add Benefit":
									BenefitsPage.get().validateBenefitChangeinPlan(strUpdatedPlans[intIndex], "Urgent Care Advanced Imaging", "ADD");
								break;
								case "Validate Add Situation":
									BenefitsPage.get().validateSituationTypeChangeinPlan(strUpdatedPlans[intIndex], "Inpatient Place of Service", "ADD");
									break;
								default:
									break;
								}
                             }
                             else
                             {
                            	 RESULT_STATUS = false;
                             	log(FAIL, "Validate Bulk Republish Changes in the Plan","Validation failed, plan did not get republsihed: "+strUpdatedPlans[intIndex]);
                             }
                        }
						}
                        
                        if(strTestCaseID.equalsIgnoreCase("Validate Changes in Not Republished Plans"))
                        {
                        FindPlanPage.get().findPlan(strPlanID3);
                        waitForPageLoad(300);
						seWaitForClickableWebElement(TemplatePlanSetUpPage.get().planAdministration,60);
						seClick(TemplatePlanSetUpPage.get().planAdministration, "Plan Administration");
						currentUMRule=seGetElementValue(TemplatePlanSetUpPage.get().UMRulePenaltyPlanDesign);
						if(notUpdatedUMRule.equalsIgnoreCase(currentUMRule))
						{
							 RESULT_STATUS = true;
							log(PASS,"UM rule is not updated for the plan which is not republished",
									"UM rule is not updated for the plan",true);
						}
						else
						{
							 RESULT_STATUS = false;
							log(FAIL,"UM rule is updated for the plan which is not republished",
									"UM Rule is updated for the plan",true);
						}
							}
							}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				finally {
					setResult("STATUS", RESULT_STATUS);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null)
			{
			seCloseBrowser();
			}
			endTestScript();

		}
	}
	
	
	public static void loadTestDataVariables()
	{
		strtemplateVersionID = getCellValue("TemplateVersionID");
		strPlanOption = getCellValue("PlanOption");
		strBenefitOption = getCellValue("BenefitOption");
		strBenefit = getCellValue("Benefit");
		strBenefitFrondEndName = getCellValue("BenefitFrontEndName");
		strSituationTypeServiceCode= getCellValue("SituationServiceCode");
		strTemplateName = getCellValue("TemplateName");
		notUpdatedUMRule = getCellValue("NotChangedUMRule");
	}
	
	
	

	
	
	

}
