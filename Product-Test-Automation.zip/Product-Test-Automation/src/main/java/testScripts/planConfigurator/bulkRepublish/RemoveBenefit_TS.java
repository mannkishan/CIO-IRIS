package testScripts.planConfigurator.bulkRepublish;


import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitsPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HistoryPage;
import page.planConfigurator.ImpactReviewPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MassUpdatePage;
import page.planConfigurator.TemplateHeaderPage;
import utility.CoreSuperHelper;
import utility.ExcelUtility;
import utility.PCUtils;

public class RemoveBenefit_TS extends CoreSuperHelper{
	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	static String strdownloadPath = "";
	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					if(getCellValue("Run_Flag").equalsIgnoreCase("YES")) {
						getCellValue("Test_Case_ID");
						String strtemplateVersionID = getCellValue("TemplateVersionID");	
						String strTemplateName = getCellValue("TemplateName");
						String strAddRemoveFlag = getCellValue("AddRemoveFlag");
						strdownloadPath=getReportPathFolder();						
						String strEffectiveDate=getCellValue("EffectiveDate");
						logExtentReport("Validating impact analysis report");
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
						LoginPage.get().loginApplication(struserProfile);
						waitForPageLoad();
						FindTemplatePage.findTemplate(strtemplateVersionID);						
						String benefit=FindTemplatePage.editBenefits(strAddRemoveFlag);	
						strtemplateVersionID = TemplateHeaderPage.get().getTemplateVersionID().trim();
						FindTemplatePage.requestAuditTemplate(strtemplateVersionID);
						seCloseBrowser();
												
						//Logging with another user Credentials
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL,strdownloadPath);
						LoginPage.get().loginApplication(strauditApprover);
						waitForPageLoad();
						FindTemplatePage.findTemplate(strtemplateVersionID);						
						FindTemplatePage.approveAuditTemplate();
						setCellValue("TemplateVersionID", strtemplateVersionID);						
						String strplanID=MassUpdatePage.bulkRepublish(strTemplateName,strEffectiveDate);
						String[] strplanId=strplanID.split(":");
						String strplan1=strplanId[0];
						String strplan2=strplanId[1];						
						String strid = PCUtils.downloadImpactReviewReport();												
						String strreportFolder = strdownloadPath+"Bulk Republish - "+strid+" - Impact Report.xlsx";
						ExcelUtility.get().validateBenefitChange(strplan1,strreportFolder,benefit, false);
						ExcelUtility.get().validateBenefitChange(strplan2,strreportFolder,benefit, false);
						seSetText(ImpactReviewPage.get().id,strid,"Setting id value in id text field");
                        seClick(ImpactReviewPage.get().execute,"Clicking on execute button");
                        String strupdateid=HistoryPage.get().downloadUpdateReport(strid);
                        String strupdatereportFolder = strdownloadPath+"Bulk Republish - "+strupdateid+" - Update Report.xlsx";
                        String strUpdatePlanID1=ExcelUtility.get().validateUpdateBenefitChange(strplan1,strupdatereportFolder,benefit, false);
                        String strUpdatePlanID2=ExcelUtility.get().validateUpdateBenefitChange(strplan2,strupdatereportFolder,benefit, false);                        
                        if(!strUpdatePlanID1.isEmpty())
                        {
                        	FindPlanPage.get().findPlan(strUpdatePlanID1);
                        	BenefitsPage.get().validateBenefitChangeinPlan(strUpdatePlanID1, "Urgent Care Advanced Imaging", "REMOVE");
                        }
                        else
                        {
                        	log(FAIL, "Validate Benefit Change after Bulk Republish", "Plan "+strplan1+" is not republished");
                        }
                        if(!strUpdatePlanID2.isEmpty())
                        {
                        	FindPlanPage.get().findPlan(strUpdatePlanID2);
                        	BenefitsPage.get().validateBenefitChangeinPlan(strUpdatePlanID2, "Urgent Care Advanced Imaging", "REMOVE");
                        }
                        else
                        {
                        	log(FAIL, "Validate Benefit Change after Bulk Republish", "Plan "+strplan2+" is not republished");
                        }
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			seCloseBrowser();
			endTestScript();
			endExtentReport();

		}
	}





}


