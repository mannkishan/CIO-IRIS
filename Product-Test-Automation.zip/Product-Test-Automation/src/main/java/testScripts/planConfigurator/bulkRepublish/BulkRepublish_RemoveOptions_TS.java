package testScripts.planConfigurator.bulkRepublish;


import java.util.Hashtable;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.BenefitsPage;
import page.planConfigurator.EditTemplateInformationPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HistoryPage;
import page.planConfigurator.ImpactReviewPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MassUpdatePage;
import page.planConfigurator.PlanBenefitOptionsPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.TemplateBenefitOptionPage;
import page.planConfigurator.TemplateBenefitPage;
import page.planConfigurator.TemplateHeaderPage;
import page.planConfigurator.TemplatePlanOptionPage;
import page.planConfigurator.TemplatePlanSetUpPage;
import utility.CoreSuperHelper;
import utility.ExcelUtility;
import utility.PCUtils;

public class BulkRepublish_RemoveOptions_TS extends CoreSuperHelper{
	
	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	static String strdownloadPath = "";
	static String strtemplateVersionID = "";
	static String strAddOrRemovePlanOption = "";
	static String strPlanOption = "";
	static String strAddOrRemoveBenefitOption = "";
	static String strBenefitOption = "";
	static String strAddOrRemoveBenefit = "";
	static String strBenefit = "";
	static String strBenefitFrondEndName = "";
	static String strPlanID1 = "";
	static String strPlanID2 = "";
	static String strPlanID3 = "";
	static String straddOrRemoveSituationType = "";
	static String strSituationTypeServiceCode= "";
	static String strTemplateName = "";
	static String strupdatereportFolder = "";
	static String strreportFolder  = "";
	static boolean addOrRemovePlanOptionStatus = false;
	static boolean addOrRemoveBenefitOptionStatus = false;
	static boolean addOrRemoveBenefit = false;
	static boolean addOrRemoveSituationType = false;
	static boolean booEditPlanOptionFlag = false;
	static boolean booEditBenefitOption = false;
	static String strEditPlanOptionValue = "";
	static String strEditBenefitOptionValue = "";
	static Hashtable<String, String> editPlanOption ;
	static Hashtable<String, String> editBenefitOption ;
	
	
	public static void main(String[] args) {

		try {
			MANUAL_TC_EXECUTION_EFFORT = "00:17:00";
		
			initiateTestScript();
			String strTestCaseID = "";
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					strTestCaseID = getCellValue("Test_Case_ID");
					String strRunFlag = getCellValue("Run_Flag");
					String strUpdatePlanID1 = "";
					String strUpdatePlanID2 = "";
					if(strRunFlag.equalsIgnoreCase("YES")) {
						
						logExtentReport(getCellValue("TCName"));
						 if(strTestCaseID.equalsIgnoreCase("Create Test Data for Remove Options"))
							{
								loadTestDataVariables();
							}
							else
							{
									strUpdatePlanID1 = ExcelUtility.get().getNewPlanID(strupdatereportFolder, strPlanID1);
									strUpdatePlanID2 = ExcelUtility.get().getNewPlanID(strupdatereportFolder, strPlanID2); 
							}
						
						strdownloadPath=getReportPathFolder();	
						String strEffectiveDate=getCellValue("EffectiveDate");
						 String strupdateid = "";
						switch (strTestCaseID) {
						case "Create Test Data for Remove Options":
							// Creation of test data for bulk republish add options 
							seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad(300);
							FindTemplatePage.findTemplate(strtemplateVersionID);
							waitForPageLoad(300);
							seClick(TemplateHeaderPage.get().edit, "Edit Button ");
							waitForPageLoad(300);					
							seClick(EditTemplateInformationPage.get().save, "Save Button ");
							waitForPageLoad(360);
							strtemplateVersionID = TemplateHeaderPage.get().getTemplateVersionID().trim();
							for(iROW=2;iROW<=getRowCount(); iROW++)
							{
							String strTCName = getCellValue("Test_Case_ID");
							String updateFlag = getCellValue("Run_Flag");
							if(updateFlag.equalsIgnoreCase("YES"))
							{
							switch (strTCName) {
							case "Validate Remove Plan Option":
									log(INFO, "Remove a Plan Option","Remove a Plan option for the bulk republish process");
									addOrRemovePlanOptionStatus= TemplatePlanOptionPage.get().addOrRemovePlanOption("REMOVE",strPlanOption);
									log(addOrRemovePlanOptionStatus?PASS:FAIL, "Remove a Plan Option","Remove a Plan option for the bulk republish process");
								break;
							case "Validate Edit Benefit Option":
									log(INFO, "Edit a Benefit Option","Edit a Benefit option Cover for Pain Management only in Allergy Injection for the bulk republish process");
								editBenefitOption	 = TemplateBenefitOptionPage.get().editBenefitOption(strEditBenefitOptionValue);
								break;
							case "Validate Edit Plan Option":
									log(INFO, "Edit a Plan Option","Edit a Plan option for the bulk republish process");
									editPlanOption = TemplatePlanOptionPage.get().editPlanOption(strEditPlanOptionValue);
								break;
							case "Validate Remove  Benefit Option":
									log(INFO, "Remove a Benefit Option","Remove a Benefit option for the bulk republish process");
									addOrRemoveBenefitOptionStatus=TemplateBenefitOptionPage.get().addOrRemoveBenefitOption("REMOVE");
									log(addOrRemoveBenefitOptionStatus?PASS:FAIL, "Remove a Benefit Option","Remove a Benefit option for the bulk republish process");
								break;
							case "Validate Remove Benefit":
								log(INFO, "Remove a Benefit ","Remove a Benefit  for the bulk republish process");
								addOrRemoveBenefit= TemplateBenefitPage.get().addOrRemoveBenefit(strBenefitFrondEndName	, "REMOVE");
								log(addOrRemoveBenefit?PASS:FAIL, "Remove a Benefit","Remove a Benefit for the bulk republish process");
							break;
							case "Validate Remove Situation":
								log(INFO, "Remove a Situation type ","Remove a Situation type  for the bulk republish process");
								addOrRemoveSituationType= TemplateBenefitPage.get().addOrRemoveSituationType("REMOVE");
								log(addOrRemoveSituationType?PASS:FAIL, "Remove a Situation type ","Remove a Situation type  for the bulk republish process");
								break;
							default:
								break;
							}
							waitForPageLoad(360);
							}
							}
							iROW = 1;
							seClick(FindTemplatePage.get().save, "Click Save Button ");
							waitForPageLoad(360);	
							log(INFO, "Moving Template to Production","Move Template to Production");
							waitForPageLoad(300);	
							FindTemplatePage.requestAuditTemplate(strtemplateVersionID);
							seCloseBrowser();
							//Logging with another approver
							seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
							LoginPage.get().loginApplication(strauditApprover);
							waitForPageLoad();
							FindTemplatePage.findTemplate(strtemplateVersionID);						
							FindTemplatePage.approveAuditTemplate();
							setCellValue("TemplateVersionID", strtemplateVersionID);
							seCloseBrowser();
							log(INFO, "Bulk Republish Process Started","Bulk Republish Process");
							seOpenBrowser(BrowserConstants.Chrome, strbaseURL,strdownloadPath);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad(360);
							String strplanID=MassUpdatePage.bulkRepublish(strTemplateName,strEffectiveDate);
							String[] strplanId=strplanID.split(":");
							strPlanID1=strplanId[0];
							strPlanID2=strplanId[1];
							String strid = PCUtils.downloadImpactReviewReport();
							 strreportFolder = strdownloadPath+"Bulk Republish - "+strid+" - Impact Report.xlsx";
							seSetText(ImpactReviewPage.get().id,strid,"ID Field");
	                        seClick(ImpactReviewPage.get().execute,"Execute button");
	                       strupdateid=HistoryPage.get().downloadUpdateReport(strid);
	                       strupdatereportFolder = strdownloadPath+"Bulk Republish - "+strupdateid+" - Update Report.xlsx";
	                       seCloseBrowser();
							break;
						case "Validate Remove Benefit":
							   if(addOrRemoveBenefit)
		                        {
		                        	String strStepName = "Validate Remove a Benefit  in update report";
		                        	log(INFO, "Started Validation Add or Remove Benefit in Impact Analysis and Update Report","");
		                        	ExcelUtility.get().validateBenefitChange(strPlanID1,strreportFolder,strBenefit, false);
		    						ExcelUtility.get().validateBenefitChange(strPlanID2,strreportFolder,strBenefit, false);
		    						ExcelUtility.get().validateUpateReportForAddOrRemove(strPlanID1,strupdatereportFolder,strBenefit,strStepName, false);
		    						ExcelUtility.get().validateUpateReportForAddOrRemove(strPlanID2,strupdatereportFolder,strBenefit,strStepName, false);
		                        	log(INFO, "Completed Validation Remove Benefit in Impact Analysis and Update Report","");
		                        }
		                        else
		                        {
		                        	 RESULT_STATUS = false;
		                        	log(FAIL, "Verify Bulk republish process for Remove Benefit","Remove Benefit is failed as the data creation process is failed");
		                        }
							break;
						case "Validate Remove Situation":
	                        if(addOrRemoveSituationType)
	                        {
	                        	log(INFO, "Started Validation Remove Situation in Impact Analysis and Update Report","");
	                        	ExcelUtility.get().validateSituationChange(strPlanID1, strreportFolder, strSituationTypeServiceCode, false);
	    						ExcelUtility.get().validateSituationChange(strPlanID2, strreportFolder, strSituationTypeServiceCode, false);
	                        	ExcelUtility.get().validateUpdateSituationTypeChange(strPlanID1,strupdatereportFolder,strSituationTypeServiceCode, false);
	                            ExcelUtility.get().validateUpdateSituationTypeChange(strPlanID2,strupdatereportFolder,strSituationTypeServiceCode, false);	
	                        	log(INFO, "Completed Validation Remove Situation in Impact Analysis and Update Report","");
	                        }
	                        else
	                        {
	                        	 RESULT_STATUS = false;
	                        	log(FAIL, "Verify Bulk republish process for Remove Situation","Remove Situation is failed as the data creation process is failed");
	                        }
	                        break;
						case "Validate Edit Benefit Option":
							String editBenefitOptionStatus = editBenefitOption.get("Edit Benefit Option Status");
							String strBenefitOptionOldValue = editBenefitOption.get("Existing Value");
							String strBenefitOptionNewValue = editBenefitOption.get("Updated Value");
							String[] selectedPlans = {strPlanID1,strPlanID2};
							TemplateBenefitOptionPage.get().validateEditBenefitOption(selectedPlans,strreportFolder,strupdatereportFolder,
									strBenefitOptionOldValue, strBenefitOptionNewValue, editBenefitOptionStatus);
	                        break;
						case "Validate Edit Plan Option":
							String editPlanOptionStatus = editPlanOption.get("Edit Plan Option Status");
							String strPlanOptionOldValue = editPlanOption.get("Existing Apply Deductible");
							String strPlanOptionNewValue = editPlanOption.get("Updated Apply Deductible");
							String[] selectedBulkRepublishPlans = {strPlanID1,strPlanID2};
							TemplatePlanOptionPage.get().validateEditPlanOption(selectedBulkRepublishPlans,strreportFolder,strupdatereportFolder,
									strPlanOptionOldValue, strPlanOptionNewValue, editPlanOptionStatus);
	                        break;
	                        
						default:
							break;
						}
		if(!strTestCaseID.equalsIgnoreCase("Create Test Data for Remove Options") && !strTestCaseID.equalsIgnoreCase("Validate Edit Benefit Option")&& !strTestCaseID.equalsIgnoreCase("Validate Edit Plan Option"))
							{
						String[] strUpdatedPlans = {strUpdatePlanID1,strUpdatePlanID2};
						if(getWebDriver()==null)
						{
                        seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
                        waitForPageLoad();
                        LoginPage.get().loginApplication(struserProfile);
                        waitForPageLoad();
						}
                        for(int intIndex = 0; intIndex<2; intIndex++)
                        {
                        	 if(!strUpdatedPlans[intIndex].isEmpty())
                             {
                        		boolean  booFoundPlan = FindPlanPage.get().findPlan(strUpdatedPlans[intIndex]);
                             	waitForPageLoad(300);
                             	switch (strTestCaseID) {
								case "Validate Remove Plan Option":
									PlanOptionsPage.get().verifyChangeInPlanOption(false, strPlanOption, strUpdatedPlans[intIndex], booFoundPlan);
									break;
								case "Validate Remove  Benefit Option":
									PlanBenefitOptionsPage.get().verifyBeneiftOptionChangeInPlan(false	, strBenefitOption, 
	                             			strUpdatedPlans[intIndex],booFoundPlan);
									break;
								case "Validate Remove Benefit":
									BenefitsPage.get().validateBenefitChangeinPlan(strUpdatedPlans[intIndex], "Urgent Care Advanced Imaging", "REMOVE");
								break;
								case "Validate Remove Situation":
									BenefitsPage.get().validateSituationTypeChangeinPlan(strUpdatedPlans[intIndex], "Inpatient Place of Service", "REMOVE");
									break;
								default:
									break;
								}
                             }
                             else
                             {
                            	 RESULT_STATUS = false;
                             	log(FAIL, "Validate Bulk Republish Changes in the Plan","Validation failed, plan did not get republsihed: "+strUpdatedPlans[intIndex]);
                             }
                        }
                        
							}
					}
				} catch (Exception e) {
					 RESULT_STATUS = false;
					if(getWebDriver()!=null)
					{
					seCloseBrowser();
					}
					e.printStackTrace();
				}
				finally {
					 if(!strTestCaseID.equalsIgnoreCase("Create Test Data for Remove Options"))
					 {
					setResult("STATUS", RESULT_STATUS);
					 }
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null)
			{
			seCloseBrowser();
			}
			endTestScript();

		}
	}
	
	
	public static void loadTestDataVariables()
	{
		strtemplateVersionID = getCellValue("TemplateVersionID");
		strPlanOption = getCellValue("PlanOption");
		strBenefitOption = getCellValue("BenefitOption");
		strBenefit = getCellValue("Benefit");
		strBenefitFrondEndName = getCellValue("BenefitFrontEndName");
		strSituationTypeServiceCode= getCellValue("SituationServiceCode");
		strTemplateName = getCellValue("TemplateName");
		strEditPlanOptionValue= getCellValue("EditPlanOption");
		strEditBenefitOptionValue = getCellValue("EditBenefitOption");
	}
	
	
	

	
	
	

}
