package testScripts.planConfigurator.bulkRepublish;

import org.openqa.selenium.support.ui.ExpectedConditions;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MassUpdatePage;
import page.planConfigurator.TemplateHeaderPage;
import utility.CoreSuperHelper;
import utility.ExcelUtility;
import utility.PCUtils;

public class RemoveSituationType_TS extends CoreSuperHelper{
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover=EnvHelper.getValue("user.profile.approver");
    static String strPath=getReportPathFolder();
    
    public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					if(getCellValue("Run_Flag").equalsIgnoreCase("YES")) {
						getCellValue("Test_Case_ID");	
						
						String strtemplateVersionID = getCellValue("VersionId");
						String strEffectiveDate = getCellValue("EffectiveDate");
						String strTemplateName = getCellValue("TemplateName");
						strPath=getReportPathFolder();
						logExtentReport("Validating Update report");
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
						LoginPage.get().loginApplication(strUserProfile);
						waitForPageLoad();
						FindTemplatePage.findTemplate(strtemplateVersionID);
						waitForPageLoad(300);
						String situationType=FindTemplatePage.removeSituationType();
						String strServiceCode = "";
						strtemplateVersionID = TemplateHeaderPage.get().getTemplateVersionID().trim();
						FindTemplatePage.requestAuditTemplate(strtemplateVersionID);
						seCloseBrowser();
						
						//Logging with another user Credentials
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL,strPath);
						LoginPage.get().loginApplication(strUserProfileApprover);
						waitForPageLoad();
						FindTemplatePage.findTemplate(strtemplateVersionID);
						waitForPageLoad();
						FindTemplatePage.approveAuditTemplate();
						setCellValue("VersionId", strtemplateVersionID);
						seCloseBrowser();
						System.out.println(strtemplateVersionID);
						
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL,strPath);
						LoginPage.get().loginApplication(strUserProfile);
						waitForPageLoad();
						seWaitForWebElement(60,ExpectedConditions.elementToBeClickable(HomePage.get().massUpdate));
						String planID=MassUpdatePage.bulkRepublish(strTemplateName,strEffectiveDate);
						String[] planId=planID.split(":");
						String strPlan1=planId[0];
						String strPlan2=planId[1];	
						String strImpactID = PCUtils.downloadImpactReviewReport();
						String strImpactReportPath= strPath+"Bulk Republish - "+strImpactID+" - Impact Report.xlsx";
						ExcelUtility.get().validateSituationChange(strPlan1, strImpactReportPath, strServiceCode, true);
						ExcelUtility.get().validateSituationChange(strPlan2, strImpactReportPath, strServiceCode, true);
//						seCloseBrowser();
						
											
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		//	seCloseBrowser();
			endTestScript();
		//	endExtentReport();

		}
	}



}
