package testScripts.planConfigurator.bulkRepublish;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import page.planConfigurator.EditTemplateInformationPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HistoryPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.ImpactReviewPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MassUpdatePage;
import page.planConfigurator.PlanBenefitOptionsPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.TemplateBenefitOptionPage;
import page.planConfigurator.TemplateHeaderPage;
import utility.CoreSuperHelper;
import utility.ExcelUtility;
import utility.PCUtils;

public class AddOrRemoveBenefitOption_TS extends CoreSuperHelper {

	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover=EnvHelper.getValue("user.profile.approver");
	static String strPath=getReportPathFolder();

	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					if(getCellValue("Run_Flag").equalsIgnoreCase("YES")) {

						String strtemplateVersionID = getCellValue("VersionId");
						String strEffectiveDate = getCellValue("EffectiveDate");
						String strTemplateName = getCellValue("TemplateName");
						String benefitOption = getCellValue("BenefitOption");
						String strPlanID1 = getCellValue("PlanID1");
						String strPlanID2 = getCellValue("PlanID2");
						String modifiedFromDate = getCellValue("ModifiedFromDate"); 
						String modifiedThruDate = getCellValue("ModifiedThroughDate"); 
						String LOB = getCellValue("LOB");
						String strPlanOption = "/"+benefitOption;
						boolean booAddRemoveFlag=false;
						strPath=getReportPathFolder();

						//Login to Perform Request Audit
						logExtentReport("Validating Benefit Option Added or Removed");
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
						LoginPage.get().loginApplication(strUserProfile);
						waitForPageLoad();
						FindTemplatePage.findTemplate(strtemplateVersionID);
						seClick(TemplateHeaderPage.get().edit, "Click Edit Button ");
						waitForPageLoad(150);					
						seClick(EditTemplateInformationPage.get().save, "Click Save Button ");
						waitForPageLoad(150);
						((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",TemplateBenefitOptionPage.get().benefitOption);
						waitForPageLoad(50);
						seClick(TemplateBenefitOptionPage.get().acupuncture, benefitOption);
						waitForPageLoad(150);

						if(getCellValue("AddRemoveFlag").equalsIgnoreCase("ADD"))
						{
							booAddRemoveFlag = true;
							if(!TemplateBenefitOptionPage.get().checkBoxChangeable.isSelected())
							{
								seClick(TemplateBenefitOptionPage.get().checkBoxVisible, "Visible CheckBox");
								seClick(TemplateBenefitOptionPage.get().save, "Save");
							}
						}
						if(getCellValue("AddRemoveFlag").equalsIgnoreCase("REMOVE"))
						{
							booAddRemoveFlag = false;
							if(TemplateBenefitOptionPage.get().checkBoxChangeable.isSelected())
							{
								seClick(TemplateBenefitOptionPage.get().checkBoxVisible, "Visible CheckBox");
								seClick(TemplateBenefitOptionPage.get().save, "Save");
							}
						}
						waitForPageLoad(50);
						strtemplateVersionID = TemplateHeaderPage.get().getTemplateVersionID().trim();
						FindTemplatePage.requestAuditTemplate(strtemplateVersionID);
						seCloseBrowser();

						//Logging with another user Credentials to approve and finalize
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL,strPath);
						LoginPage.get().loginApplication(strUserProfileApprover);
						waitForPageLoad();
						FindTemplatePage.findTemplate(strtemplateVersionID);
						waitForPageLoad();
						FindTemplatePage.approveAuditTemplate();
						setCellValue("VersionId", strtemplateVersionID);
						seCloseBrowser();

						//Login to perform Bulk Republish
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL,strPath);
						LoginPage.get().loginApplication(strUserProfile);
						waitForPageLoad();
						seWaitForWebElement(60,ExpectedConditions.elementToBeClickable(HomePage.get().massUpdate));
						String planID=MassUpdatePage.bulkRepublish(strTemplateName,strPlanID1,strPlanID2,strEffectiveDate,modifiedFromDate,modifiedThruDate,LOB);
						//String planID=MassUpdatePage.bulkRepublish(strTemplateName,strEffectiveDate);
						String[] strplanId=planID.split(":");
						String strPlan1=strplanId[0];
						String strPlan2=strplanId[1];	
						String strImpactID = PCUtils.downloadImpactReviewReport();
						String strImpactReportPath= strPath+"Bulk Republish - "+strImpactID+" - Impact Report.xlsx";
						
						//Impact Report validation
						ExcelUtility.get().validateImpactBenefitOptionChange(strPlan1, strImpactReportPath, strPlanOption, booAddRemoveFlag);
						ExcelUtility.get().validateImpactBenefitOptionChange(strPlan2, strImpactReportPath, strPlanOption, booAddRemoveFlag);
						
						//Update Report Validation
						seSetText(ImpactReviewPage.get().id,strImpactID,"Setting id value in id text field");
						seClick(ImpactReviewPage.get().execute,"Clicking on execute button");
						waitForPageLoad(100);
						String strupdateid=HistoryPage.get().downloadUpdateReport(strImpactID);
						String strupdatereportFolder = strPath+"Bulk Republish - "+strupdateid+" - Update Report.xlsx";
						String strUpdatePlanID1= ExcelUtility.get().validateUpdateBenefitOptionChange(strPlan1,strupdatereportFolder,strPlanOption, booAddRemoveFlag);
						String strUpdatePlanID2= ExcelUtility.get().validateUpdateBenefitOptionChange(strPlan2,strupdatereportFolder,strPlanOption, booAddRemoveFlag);
						if(!strUpdatePlanID1.isEmpty())
						{
							boolean booFoundPlan = FindPlanPage.get().findPlan(strUpdatePlanID1);
							PlanBenefitOptionsPage.get().verifyBeneiftOptionChangeInPlan(booAddRemoveFlag, benefitOption, strUpdatePlanID1,booFoundPlan);
						}
						else
						{
							log(FAIL, "Validate Plan Option Change after Bulk Republish", "Plan "+strPlan1+" is not republished");
						}

						if(!strUpdatePlanID2.isEmpty())
						{
							boolean booFoundPlan = FindPlanPage.get().findPlan(strUpdatePlanID1);
							PlanBenefitOptionsPage.get().verifyBeneiftOptionChangeInPlan(booAddRemoveFlag, benefitOption, strUpdatePlanID2,booFoundPlan);
						}
						else
						{
							log(FAIL, "Validate Plan Option Change after Bulk Republish", "Plan is "+strPlan2+" not republished");
						}

					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//seCloseBrowser();
			endTestScript();
			//endExtentReport();
		}
	}
}
