package testScripts.planConfigurator.bulkRepublish;


import org.openqa.selenium.By;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.EditTemplateInformationPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HistoryPage;
import page.planConfigurator.ImpactReviewPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MassUpdatePage;
import page.planConfigurator.TemplateHeaderPage;
import page.planConfigurator.TemplatePlanSetUpPage;
import utility.CoreSuperHelper;
import utility.ExcelUtility;
import utility.PCUtils;

public class UpdateUMRule_TS extends CoreSuperHelper {

	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	static String strdownloadPath = "";
	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					logExtentReport("Test Script/ Functionality Descrtiption");
					String strtemplateVersionID = getCellValue("TemplateVersionID");
					String strTemplateName = getCellValue("TemplateName");
					strdownloadPath = getReportPathFolder();
					String strEffectiveDate = getCellValue("EffectiveDate");
					seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
					LoginPage.get().loginApplication(struserProfile);
					waitForPageLoad();
					FindTemplatePage.findTemplate(strtemplateVersionID);
					waitForPageLoad();
					seClick(TemplateHeaderPage.get().edit, "Click Edit Button ");
					waitForPageLoad();					
					seClick(EditTemplateInformationPage.get().save, "Click Save Button ");
					waitForPageLoad();
					strtemplateVersionID = TemplateHeaderPage.get().getTemplateVersionID().trim();
					seWaitForClickableWebElement(TemplatePlanSetUpPage.get().planAdministration,60);
					seClick(TemplatePlanSetUpPage.get().planAdministration, "Plan Administration");
					waitForPageLoad();
					String priorUMRule=	seGetDropDownValue(TemplatePlanSetUpPage.get().UMRulePenaltyPlanDesign);
					String currentUMRule = TemplatePlanSetUpPage.get().updateUMRule();
					waitForPageLoad();
					seClick(TemplateHeaderPage.get().save, "Template Save");
					waitForPageLoad();
					FindTemplatePage.requestAuditTemplate(strtemplateVersionID);
					seCloseBrowser();
//					
//                 	approve audit for the pending audit template
					seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
					LoginPage.get().loginApplication(strauditApprover);
					waitForPageLoad(300);
					FindTemplatePage.findTemplate(strtemplateVersionID);
					waitForPageLoad();
					FindTemplatePage.approveAuditTemplate();
					setCellValue("TemplateVersionID", strtemplateVersionID);
					seCloseBrowser();
					System.out.println(strtemplateVersionID);
					seOpenBrowser(BrowserConstants.Chrome, strbaseURL,strdownloadPath);
					LoginPage.get().loginApplication(struserProfile);
					waitForPageLoad();
					
									
					String strplanID=MassUpdatePage.bulkRepublish(strTemplateName,strEffectiveDate);
					String[] strplanId=strplanID.split(":");
					String strplan1=strplanId[0];
					String strplan2=strplanId[1];						
					String strid = PCUtils.downloadImpactReviewReport();						
					String strreportFolder = strdownloadPath+"Bulk Republish - "+strid+" - Impact Report.xlsx";
					ExcelUtility.get().validateUMRuleImpact(strplan1,strreportFolder,currentUMRule,priorUMRule);
					ExcelUtility.get().validateUMRuleImpact(strplan2,strreportFolder,currentUMRule,priorUMRule);
					seSetText(ImpactReviewPage.get().id,strid,"ID Field");
                    seClick(ImpactReviewPage.get().execute,"Execute button");
                    String strupdateid=HistoryPage.get().downloadUpdateReport(strid);
                    String strupdatereportFolder = strdownloadPath+"Bulk Republish - "+strupdateid+" - Update Report.xlsx";
					ExcelUtility.get().validateUMRuleChangeUpdateReport(strplan1, strupdatereportFolder, currentUMRule, priorUMRule);
					ExcelUtility.get().validateUMRuleChangeUpdateReport(strplan2, strupdatereportFolder, currentUMRule, priorUMRule);
					
					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}

	}

}
