package testScripts.planConfigurator.bulkRepublish;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.EditTemplateInformationPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HistoryPage;
import page.planConfigurator.ImpactReviewPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MassUpdatePage;
import page.planConfigurator.TemplateHeaderPage;
import page.planConfigurator.TemplatePlanSetUpPage;
import utility.CoreSuperHelper;
import utility.ExcelUtility;
import utility.PCUtils;

public class ValidateImpactReport_TS extends CoreSuperHelper{
	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	static String strdownloadPath = "";
	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					if(getCellValue("Run_Flag").equalsIgnoreCase("YES")) {
						logExtentReport("Test Script/ Functionality Descrtiption");
						String strtemplateVersionID = getCellValue("TemplateVersionID");
						System.out.println(strtemplateVersionID);
						String strTemplateName = getCellValue("TemplateName");
						String currentUMRule = "";					
						strdownloadPath = getReportPathFolder();
						String strEffectiveDate = getCellValue("EffectiveDate");
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
						LoginPage.get().loginApplication(struserProfile);
						waitForPageLoad();
						FindTemplatePage.findTemplate(strtemplateVersionID);
						waitForPageLoad();
						seClick(TemplateHeaderPage.get().edit, "Click Edit Button ");
						waitForPageLoad();					
						seClick(EditTemplateInformationPage.get().save, "Click Save Button ");
						waitForPageLoad(100);
						strtemplateVersionID = TemplateHeaderPage.get().getTemplateVersionID().trim();
						seWaitForClickableWebElement(TemplatePlanSetUpPage.get().planAdministration,60);
						seClick(TemplatePlanSetUpPage.get().planAdministration, "Plan Administration");
						waitForPageLoad();
						String priorUMRule=	seGetDropDownValue(TemplatePlanSetUpPage.get().UMRulePenaltyPlanDesign);
						currentUMRule = TemplatePlanSetUpPage.get().updateUMRule();
						waitForPageLoad();
						seClick(TemplateHeaderPage.get().save, "Template Save");
						waitForPageLoad();
						FindTemplatePage.requestAuditTemplate(strtemplateVersionID);
						seCloseBrowser();

						//approve audit for the pending audit template
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL,strdownloadPath);
						LoginPage.get().loginApplication(strauditApprover);
						waitForPageLoad(300);
						FindTemplatePage.findTemplate(strtemplateVersionID);
						waitForPageLoad();
						FindTemplatePage.approveAuditTemplate();
						setCellValue("TemplateVersionID", strtemplateVersionID);									
						String strplanID=MassUpdatePage.bulkRepublish(strTemplateName,strEffectiveDate,"Medical");
						String[] strplanId=strplanID.split(":");
						String strplan1=strplanId[0];
						String strplan2=strplanId[1];						
						String strplan3=strplanId[2];					
						String strid = PCUtils.downloadImpactReviewReport();						
						String strreportFolder = strdownloadPath+"Bulk Republish - "+strid+" - Impact Report.xlsx";
						ExcelUtility.get().validateUMRuleImpact(strplan1,strreportFolder,currentUMRule,priorUMRule);
						ExcelUtility.get().validateUMRuleImpact(strplan2,strreportFolder,currentUMRule,priorUMRule);
						seSetText(ImpactReviewPage.get().id,strid,"ID Field");
						seClick(ImpactReviewPage.get().execute,"Execute button");
						String strupdateid=HistoryPage.get().downloadUpdateReport(strid);
						String strupdatereportFolder = strdownloadPath+"Bulk Republish - "+strupdateid+" - Update Report.xlsx";
						ExcelUtility.get().validateUMRuleChangeUpdateReport(strplan1, strupdatereportFolder, currentUMRule, priorUMRule);
						ExcelUtility.get().validateUMRuleChangeUpdateReport(strplan2, strupdatereportFolder, currentUMRule, priorUMRule);
						FindPlanPage.get().findPlan(strplan3);
						seWaitForClickableWebElement(TemplatePlanSetUpPage.get().planAdministration,60);
						seClick(TemplatePlanSetUpPage.get().planAdministration, "Plan Administration");
						currentUMRule=seGetElementValue(TemplatePlanSetUpPage.get().UMRulePenaltyPlanDesign);
						if(priorUMRule.equalsIgnoreCase(currentUMRule))
						{
							log(PASS,"UM rule is not updated for the plan which is not republished",
									"UM rule is not updated for the plan which is not republished",true);
						}
						else
						{
							log(FAIL,"UM rule is updated for the plan which is not republished",
									"UM rule is updated for the plan which is not republished",true);
						}
						seCloseBrowser();
					}

				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}

	}

}
