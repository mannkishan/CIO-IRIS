package testScripts.planConfigurator.bulkRepublish;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.EditTemplateInformationPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HistoryPage;
import page.planConfigurator.ImpactReviewPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MassUpdatePage;
import page.planConfigurator.TemplateHeaderPage;
import page.planConfigurator.TemplatePlanOptionPage;
import utility.CoreSuperHelper;
import utility.ExcelUtility;
import utility.PCUtils;

public class EditPlanOption_TS extends CoreSuperHelper {
	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	static String strdownloadPath = "";
	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					if(getCellValue("Run_Flag").equalsIgnoreCase("YES")) {
						String strtemplateVersionID = getCellValue("TemplateVersionID");
						String strTemplateName = getCellValue("TemplateName");
						String strPlanOptionNewValue = getCellValue("PlanOptionValue");
						String strPlanBenefitFlag=getCellValue("PlanBenefitFlag");
						strdownloadPath=getReportPathFolder();						
						String strEffectiveDate=getCellValue("EffectiveDate");
						logExtentReport("Validating Edit PlanOPtion/BenefitOption Bulk Republish process");
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
						LoginPage.get().loginApplication(struserProfile);
						waitForPageLoad();
						FindTemplatePage.findTemplate(strtemplateVersionID);
						seClick(TemplateHeaderPage.get().edit, "Click Edit Button ");
						waitForPageLoad(300);	
						seClick(EditTemplateInformationPage.get().save, "Click Save Button ");
						waitForPageLoad(300);
						if(strPlanBenefitFlag.equalsIgnoreCase("PlanOption"))
//							strPlanOptionNewValue=TemplatePlanOptionPage.get().editPlanOption("Inpatient Facility");
						if(strPlanBenefitFlag.equalsIgnoreCase("BenefitOption"))
//							strPlanOptionNewValue=FindTemplatePage.editBenefitOption();
						strtemplateVersionID = TemplateHeaderPage.get().getTemplateVersionID().trim();
						FindTemplatePage.requestAuditTemplate(strtemplateVersionID);
						seCloseBrowser();
												
						//Logging with another user Credentials
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
						LoginPage.get().loginApplication(strauditApprover);
						waitForPageLoad();
						FindTemplatePage.findTemplate(strtemplateVersionID);						
						FindTemplatePage.approveAuditTemplate();
						setCellValue("TemplateVersionID", strtemplateVersionID);
						seCloseBrowser();
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL,strdownloadPath);
						LoginPage.get().loginApplication(struserProfile);
						waitForPageLoad();
						String strplanID=MassUpdatePage.bulkRepublish(strTemplateName,strEffectiveDate);
						String[] strplanId=strplanID.split(":");
						String strplan1=strplanId[0];
						String strplan2=strplanId[1];	
						
						String strid = PCUtils.downloadImpactReviewReport();
						String strreportFolder = strdownloadPath+"Bulk Republish - "+strid+" - Impact Report.xlsx";
						if(strPlanBenefitFlag.equalsIgnoreCase("PlanOption")){
//							ExcelUtility.get().validateImpactPlanChange(strplan1,strreportFolder,strPlanOptionNewValue);
//							ExcelUtility.get().validateImpactPlanChange(strplan2,strreportFolder,strPlanOptionNewValue);
						}
						if(strPlanBenefitFlag.equalsIgnoreCase("BenefitOption")){
//							ExcelUtility.get().validateImpactBenefitChange(strplan1,strreportFolder,strPlanOptionNewValue);
//							ExcelUtility.get().validateImpactBenefitChange(strplan2,strreportFolder,strPlanOptionNewValue);
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			seCloseBrowser();
			endTestScript();

		}
	}

}
