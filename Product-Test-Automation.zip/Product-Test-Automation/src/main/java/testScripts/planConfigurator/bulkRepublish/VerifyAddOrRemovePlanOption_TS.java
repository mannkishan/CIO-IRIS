package testScripts.planConfigurator.bulkRepublish;


import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.EditTemplateInformationPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HistoryPage;
import page.planConfigurator.ImpactReviewPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MassUpdatePage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.TemplateHeaderPage;
import page.planConfigurator.TemplatePlanOptionPage;
import utility.CoreSuperHelper;
import utility.ExcelUtility;
import utility.PCUtils;

public class VerifyAddOrRemovePlanOption_TS extends CoreSuperHelper{
	
	static String strbaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile= EnvHelper.getValue("user.profile");
	static String strauditApprover= EnvHelper.getValue("user.profile.approver");
	static String strdownloadPath = "";
	public static void main(String[] args) {

		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					if(getCellValue("Run_Flag").equalsIgnoreCase("YES")) {
						String strtemplateVersionID = getCellValue("TemplateVersionID");
						String strAddOrRemove = getCellValue("AddRemoveFlag");
						String strPlanOption = getCellValue("PlanOption");
						String strTemplateName = getCellValue("TemplateName");
						strdownloadPath=getReportPathFolder();						
						String strEffectiveDate=getCellValue("EffectiveDate");
						logExtentReport("Validating Bulk Republish Process after "+getCellValue("TCName"));
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
						LoginPage.get().loginApplication(struserProfile);
						waitForPageLoad();
						FindTemplatePage.findTemplate(strtemplateVersionID);
						waitForPageLoad();
						seClick(TemplateHeaderPage.get().edit, "Edit Button ");
						waitForPageLoad(300);					
						seClick(EditTemplateInformationPage.get().save, "Save Button ");
						waitForPageLoad(360);
						strtemplateVersionID = TemplateHeaderPage.get().getTemplateVersionID().trim();
						
						
						 TemplatePlanOptionPage.get().addOrRemovePlanOption(strAddOrRemove,strPlanOption);
						waitForPageLoad(300);	
						seClick(TemplateHeaderPage.get().save, "Save Button ");
						waitForPageLoad(300);	
						FindTemplatePage.requestAuditTemplate(strtemplateVersionID);
						seCloseBrowser();
						//Logging with another approver
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL);
						LoginPage.get().loginApplication(strauditApprover);
						waitForPageLoad();
						FindTemplatePage.findTemplate(strtemplateVersionID);						
						FindTemplatePage.approveAuditTemplate();
						setCellValue("TemplateVersionID", strtemplateVersionID);
						seCloseBrowser();
						
						seOpenBrowser(BrowserConstants.Chrome, strbaseURL,strdownloadPath);
						LoginPage.get().loginApplication(struserProfile);
						waitForPageLoad();
						String strplanID=MassUpdatePage.bulkRepublish(strTemplateName,strEffectiveDate);
						String[] strplanId=strplanID.split(":");
						String strplan1=strplanId[0];
						String strplan2=strplanId[1];	
						boolean booAddRemoveFlag = false;
						if(strAddOrRemove.equalsIgnoreCase("ADD"))
						{
							booAddRemoveFlag = true;
						}
						String strid = PCUtils.downloadImpactReviewReport();
						String strreportFolder = strdownloadPath+"Bulk Republish - "+strid+" - Impact Report.xlsx";
						ExcelUtility.get().validatePlanOptionImpactReport(strplan1,strreportFolder,strPlanOption, booAddRemoveFlag);
						ExcelUtility.get().validatePlanOptionImpactReport(strplan2,strreportFolder,strPlanOption, booAddRemoveFlag);
						seSetText(ImpactReviewPage.get().id,strid,"ID Field");
                        seClick(ImpactReviewPage.get().execute,"Execute button");
                        String strupdateid=HistoryPage.get().downloadUpdateReport(strid);
                        String strupdatereportFolder = strdownloadPath+"Bulk Republish - "+strupdateid+" - Update Report.xlsx";
                    String strUpdatePlanID1=   ExcelUtility.get().validatePlanOptionUpateReport(strplan1,strupdatereportFolder,strPlanOption, booAddRemoveFlag);
                    String strUpdatePlanID2= ExcelUtility.get().validatePlanOptionUpateReport(strplan2,strupdatereportFolder,strPlanOption, booAddRemoveFlag);	
                    
                    if(!strUpdatePlanID1.isEmpty())
                    {
                    	boolean booFoundPlan = FindPlanPage.get().findPlan(strUpdatePlanID1);
                    	PlanOptionsPage.get().verifyChangeInPlanOption(booAddRemoveFlag, strPlanOption, strUpdatePlanID1,booFoundPlan);
                    }
                    else
                    {
                    	log(FAIL, "Validate Plan Option Change after Bulk Republish", "Plan "+strplan1+" is not republished");
                    }
                    
                    if(!strUpdatePlanID2.isEmpty())
                    {
                    	boolean booFoundPlan = FindPlanPage.get().findPlan(strUpdatePlanID2);
                    	PlanOptionsPage.get().verifyChangeInPlanOption(booAddRemoveFlag, strPlanOption, strUpdatePlanID2,booFoundPlan);
                    }
                    else
                    {
                    	log(FAIL, "Validate Plan Option Change after Bulk Republish", "Plan is "+strplan1+" not republished");
                    }
						
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(getWebDriver()!=null)
			{
			seCloseBrowser();
			}
			endTestScript();

		}
	}
	
	
}
