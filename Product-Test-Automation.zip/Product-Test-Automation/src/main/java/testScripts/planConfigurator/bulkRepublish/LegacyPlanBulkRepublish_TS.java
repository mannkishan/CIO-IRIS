package testScripts.planConfigurator.bulkRepublish;


import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.HistoryPage;
import page.planConfigurator.ImpactReviewPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.MassUpdatePage;
import utility.CoreSuperHelper;
import utility.ExcelUtility;
import utility.PCUtils;

/*
'Revision History
'#############################################################################
'@rev.On	@rev.No		@rev.By				  @rev.Comments
'										
'#############################################################################
*/

/**
 * Manual test case: <Could provide manual test case reference here>
 * <p>
 * Test script template
 * <p>
 * Please refer this test script while creating other test scripts
 * 
 * @author TP&E
 * @since 14-July-2017
 *
 */
public class LegacyPlanBulkRepublish_TS extends CoreSuperHelper {
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {

		try {
			MANUAL_TC_EXECUTION_EFFORT = "00:10:00";
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					
					String strRunFlag = getCellValue("Run_Flag");
					if(strRunFlag.equalsIgnoreCase("YES"))
					{
						String strTCName = getCellValue("TCName");
						logExtentReport(strTCName);
						String strEffectiveDate = getCellValue("EffectiveDate");
						String strLOB = getCellValue("LOB");
						String strreportFolder= "";
						String strdownloadPath= getReportPathFolder();
						String strupdateid = "";
						String strupdatereportFolder= "";
					
					if(getWebDriver() == null)
					{
					seOpenBrowser(BrowserConstants.Chrome, strBaseURL, strdownloadPath);
					LoginPage.get().loginApplication(strUserProfile);
					}
					waitForPageLoad(360);
					String strplanID=MassUpdatePage.bulkRepublish("-",strEffectiveDate,strLOB);
					String[] strplanId=strplanID.split(":");
					String strPlanID1=strplanId[0];
					String strPlanID2=strplanId[1];
					
					String strid = PCUtils.downloadImpactReviewReport();
					 strreportFolder = strdownloadPath+"Bulk Republish - "+strid+" - Impact Report.xlsx";
					seSetText(ImpactReviewPage.get().id,strid,"ID Field");
                    seClick(ImpactReviewPage.get().execute,"Execute button");
                   strupdateid=HistoryPage.get().downloadUpdateReport(strid);
                   strupdatereportFolder = strdownloadPath+"Bulk Republish - "+strupdateid+" - Update Report.xlsx";
					
                   ExcelUtility.get().validateLegacyUpdateReport(strPlanID1, strupdatereportFolder);
                   
                   ExcelUtility.get().validateLegacyUpdateReport(strPlanID2, strupdatereportFolder);
					
					
					}
					
				} catch (Exception e) {
					e.printStackTrace();
					log(FAIL, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
				finally {
					setResult("STATUS", RESULT_STATUS);
					if(getWebDriver()!=null)
					{
						seCloseBrowser();
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
	
	

}
