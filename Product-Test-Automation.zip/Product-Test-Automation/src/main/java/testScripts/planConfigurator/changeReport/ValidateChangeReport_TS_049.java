package testScripts.planConfigurator.changeReport;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;
import page.planConfigurator.ChangeReportPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planInheritance.PlanInheritancePage;
import utility.CoreSuperHelper;

public class ValidateChangeReport_TS_049 extends CoreSuperHelper{
	
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static int intMaxTime=450;
	
	public static void main(String[] args) {
	 try {
			MANUAL_TC_EXECUTION_EFFORT ="00:30:00";
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
			try { 
				    String strPlanVersionID = getCellValue("planVersionID");
					String strRunFlag = getCellValue("Run_Flag");
					String strDownloadPath = getReportPathFolder();
					String strDownloadedSheet = "PlanComparisonReport";
					String strBenefitValue = getCellValue("Benefit");
					String strTier = getCellValue("SelectTire");
					String strAccumName = getCellValue("AccumName");
					String strHeaderValue = "Yes";
					String strHeaderCSName = "Cost Share Name";
					String strHeaderPercentPmOveride = "Percent PM Override";
					String strPlanStatus = getCellValue("Status");
					logExtentReport("ValidateChangeReport_TS_049");
					if(strRunFlag.equalsIgnoreCase("YES")) {
						
						 seOpenBrowser(BrowserConstants.Chrome, baseURL,strDownloadPath); 
						 LoginPage.get().loginApplication(userProfile); 
						 waitForPageLoad(300);
						 FindPlanPage.get().findPlan(strPlanVersionID);
						 waitForPageLoad(300);
						 Thread.sleep(5000);
						 ChangeReportPage.get().validatePlanStatus(strPlanStatus);
						 Thread.sleep(1000);
						 seClick(ChangeReportPage.get().edit, "Edit option");
						 waitForPageLoad(360);
						 seClick(ChangeReportPage.get().SaveBtn, "Save the plan");
						 waitForPageLoad(360);
						 strPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1].trim();
						 waitForPageLoad(360);
						 setCellValue("planVersionID",strPlanVersionID);
						 waitForPageLoad(500);
						 FindPlanPage.get().benefit();
						 waitForPageLoad(600);
						 seSetText(FindTemplatePage.get().benefitsSearchField, strBenefitValue, "Setting benefit value in search field");
						 waitForPageLoad(600); 
						 seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
						 waitForPageLoad(600); 
						 seClick(ChangeReportPage.get().situationType(strTier), "click on Tier1");
						 waitForPageLoad(360);
						 seClick(ChangeReportPage.get().selectOOP(strAccumName), "Select OOP");
						 waitForPageLoad(360);
						 seClick(PlanInheritancePage.get().selectSave, "Save Button");
						 waitForPageLoad(360);
						 ChangeReportPage.get().requestAuditPlan(strPlanVersionID,intMaxTime);
						 waitForPageLoad(360);
						 seClick(ChangeReportPage.get().historyOption, "History Option");
						 waitForPageLoad(360);
						 ChangeReportPage.get().excelButton();
						 waitForPageLoad(360);
					   //Verify the Flag is set to "Yes / No" for CS Modified 
						 String strchangereportFolder = strDownloadPath+"Plan What's Changed Report_"+strPlanVersionID+".xlsx";
						 utility.ExcelUtility.get().validateExcelData(strchangereportFolder,strDownloadedSheet,strHeaderCSName,strHeaderPercentPmOveride,strAccumName,strHeaderValue);
						 waitForPageLoad(360);
						 }									
			}
					
				catch (Exception e) {
						e.printStackTrace();
						log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
						 setResult("STATUS", RESULT_STATUS);
						 seCloseBrowser();
				}
	}
	        }
	        catch (Exception e) {
				e.printStackTrace();
				log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
			} finally {
				endTestScript();
			}
	}

}
