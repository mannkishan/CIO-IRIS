package testScripts.planConfigurator.changeReport;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;
import page.planConfigurator.ChangeReportPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanInheritancePage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;

public class PlanWhatsChangedReportDataStaging_051 extends CoreSuperHelper{
	
	static String strDownloadPath = "";
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
//	static String strPlanVersionID = getCellValue("PlanVersionID");
	static int intMaxWaitTime=600;
	
	public static void main(String[] args) {
		
		try
		{
			MANUAL_TC_EXECUTION_EFFORT ="00:30:00";
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					
					String strRunFlag = getCellValue("Run_Flag");
					if(strRunFlag.equalsIgnoreCase("YES")) {
						
						logExtentReport(getCellValue("TCName"));
						String strTestCaseID = getCellValue("Test_Case_ID");
						System.out.println(strTestCaseID);
						String strPlanLevel ="In Network Adult Oral Surgery Services Copay";
						String strPlanVersionID = getCellValue("PlanVersionID");
						String strPlanStatus = getCellValue("Status");
						String strOptionsTab2=getCellValue("OptionsTab2");
						String strOptionsTabValue2=getCellValue("OptionsTabValue2");
						String strAccumCopayValue = getCellValue("CopayValue");
						String strDownloadPath = getReportPathFolder();
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL,strDownloadPath);
						waitForPageLoad(360);	
						LoginPage.get().loginApplication(struserProfile);
						waitForPageLoad(360);					
						FindPlanPage.get().findPlan(strPlanVersionID);
						 waitForPageLoad(300);
						 Thread.sleep(5000);
//						 ChangeReportPage.get().validatePlanStatus(strPlanStatus);
//						 Thread.sleep(1000);
//						 seClick(ChangeReportPage.get().edit, "Edit option");
//						 waitForPageLoad(360);
//						 seClick(ChangeReportPage.get().SaveBtn, "Save the plan");
//						 waitForPageLoad(800);
//						 strPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1].trim();
//						 waitForPageLoad(360);
//						 setCellValue("PlanVersionID",strPlanVersionID);
//						 waitForPageLoad(500);
						 PlanOptionsPage.clickTab(strOptionsTab2, strOptionsTabValue2, intMaxWaitTime);
						 waitForPageLoad(intMaxWaitTime);
							seClick(PlanOptionsPage.get().PlanLevelType(strPlanLevel), "In Network In Patient Care Copay");
							waitForPageLoad(intMaxWaitTime);
//							seSetText(PlanOptionsPage.get().PlanLevelTextBox(strPlanLevel), strAccumCopayValue, "Update copay value ");
//							waitForPageLoad(intMaxWaitTime);
//							seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
//							waitForPageLoad(360);
//							seClick(PlanInheritancePage.get().selectSave, "Save Button");
//							waitForPageLoad(360);
//							 PlanHeaderPage.get().requestAuditPlan(strPlanVersionID,intMaxWaitTime);
//							 waitForPageLoad(360);
							seClick(PlanHeaderPage.get().close, "Close button");}
							waitForPageLoad(360);
				    		seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
				    		waitForPageLoad();
							seClick(PlanHeaderPage.get().userLogout, "Logout");
							waitForPageLoad();
							seCloseBrowser();
							seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
						    waitForPageLoad();
						    LoginPage.get().loginApplication(strUserProfileApprover);
						    waitForPageLoad();
						    String strPlanVersionID = getCellValue("PlanVersionID");
						    FindPlanPage.get().findPlan(strPlanVersionID);
						    waitForPageLoad();
						    seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 15);
						    seClick(PlanHeaderPage.get().approveAudit, "approve");
							seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "reason code");
							seClick(PlanTransitionPage.get().approved, "approved");
							seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
							waitForPageLoad(45);
							seClick(ChangeReportPage.get().historyOption, "History Option");
							 waitForPageLoad(360);
							 ChangeReportPage.get().excelButton();
							 waitForPageLoad(360);
							 if(ChangeReportPage.get().excelReportbtn.isDisplayed())
							 {
							 log(PASS, "Excel button is present","Excel report Validation",true);
							 seClick(ChangeReportPage.get().excelReportbtn,"Excel Report");
							 waitForPageLoad(360);
							 }
							 else
							 {
								 log(FAIL, "Excel button is not present", "Excel report Validation",true); 
							 }
					} 
				catch (Exception e) {
						e.printStackTrace();
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if(getWebDriver()!=null)
				{
					seCloseBrowser();
				}
				endTestScript();

			}
		
		}
						    
							
}
