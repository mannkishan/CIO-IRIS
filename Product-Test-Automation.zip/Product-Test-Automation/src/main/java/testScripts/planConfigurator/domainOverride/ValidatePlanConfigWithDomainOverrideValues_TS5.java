package testScripts.planConfigurator.domainOverride;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;

public class ValidatePlanConfigWithDomainOverrideValues_TS5 extends CoreSuperHelper {

	///TC14,15////
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime=450;
	public static void main(String[] args) {
		try {
			MANUAL_TC_EXECUTION_EFFORT="00:10:00";
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					String strPlanVersionID = getCellValue("PlanProxyID");
					if(strRunFlag.equalsIgnoreCase("YES")) {
						logExtentReport(strTCName);	
						seOpenBrowser(BrowserConstants.Chrome, baseURL);
						LoginPage.get().loginApplication(userProfile);
						String strSearch1=getCellValue("Search1");
						FindPlanPage.get().findPlan(strPlanVersionID);
						//PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, intMaxWaitTime);
						waitForPageLoad(600);
						seClick(PlanOptionsPage.get().copyButton, "copy");
						waitForPageLoad(600);
						seClick(CreatePlanPage.get().createPlan, "Create Plan");
						waitForPageLoad(600);
						PlanOptionsPage.clickBenefit();
						waitForPageLoad(600);
						seSetText(FindTemplatePage.get().benefitsSearchField, strSearch1, "Setting benefit value in search field");
						waitForPageLoad(600); 
						seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
						waitForPageLoad(600); 
						if(PlanOptionsPage.get().visualIndicator(strSearch1).isEnabled() && PlanOptionsPage.get().visualIndicatorTier.isEnabled()){
							RESULT_STATUS=true;
							log(PASS,strPlanVersionID,"visualIndicator is display on benefit screen",true);
						}
						else
						{
							RESULT_STATUS=false;
							log(FAIL,strPlanVersionID,"visualIndicator is display on benefit screen",true);
						}

					}
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					setResult("STATUS", RESULT_STATUS);
					seCloseBrowser();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();	

		}
	}
}
