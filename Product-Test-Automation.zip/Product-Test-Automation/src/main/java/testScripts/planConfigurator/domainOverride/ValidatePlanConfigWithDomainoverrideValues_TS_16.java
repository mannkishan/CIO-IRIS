package testScripts.planConfigurator.domainOverride;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;

import page.planConfigurator.BulkFinalizeFindPlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HistoryPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.ImpactReviewPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import testScripts.planConfigurator.bulkFinalize.ExecuteBulkFinalize_TS;
import utility.CoreSuperHelper;
import utility.ExcelUtility;
import utility.PCUtils;
import utility.WebTableWithHeader;

public class ValidatePlanConfigWithDomainoverrideValues_TS_16 extends CoreSuperHelper {

	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static String userProfile1 = EnvHelper.getValue("user.profile1");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static String strdownloadPath=getReportPathFolder();
	static int intMaxWaitTime=600;

	public static void main(String[] args) {

		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");					 				 
					if(strRunFlag.equalsIgnoreCase("YES")) {
						logExtentReport(strTCName);	
						seOpenBrowser(BrowserConstants.Chrome, baseURL,strdownloadPath);
						LoginPage.get().loginApplication(userProfile);																		
						String strPlanName = getCellValue("PlanName");
						String strPlanVersionID=getCellValue("PlanVersionId");
						String strScheduleDay2 = getCellValue("ScheduleDay2");
						boolean isScheduleDay2Exc = Boolean.parseBoolean(strScheduleDay2);
						String status = getCellValue("Status");
						String strEffectiveDate = getCellValue("EffectiveDate");
							
						String strSearch1=getCellValue("Search1");
						String strupdateid = "";
						String strupdatereportFolder = "";
						if(!isScheduleDay2Exc)
						{
							waitForPageLoad(360);
							seClick(HomePage.get().massUpdate,"Mass Update link");
							seWaitForElementLoad(HomePage.get().createNew);
							seClick(HomePage.get().createNew,"Create New");
							seWaitForClickableWebElement(HomePage.get().bulkFinalize,120);
							seClick(HomePage.get().bulkFinalize,"Bulk Finalize");
							seSetText(BulkFinalizeFindPlanPage.get().effectiveDate, strEffectiveDate, "Setting text value in effective date text field");
							BulkFinalizeFindPlanPage.get().effectiveDate.sendKeys("{ENTER}");
							waitForPageLoad(intMaxWaitTime);
							seSetText(BulkFinalizeFindPlanPage.get().PlanName, strPlanName, "Setting text value in effective date text field");				
							sePCSelectText(BulkFinalizeFindPlanPage.get().headerValue, "Status", status, intMaxWaitTime);
							waitForPageLoad(intMaxWaitTime);			
							seClick(BulkFinalizeFindPlanPage.get().searchButton, "Search button");
							waitForPageLoad(20,500);
							WebTableWithHeader searchResults = new WebTableWithHeader(FindPlanPage.get().searchResults, "Plan Search Results");
							seClick(true,BulkFinalizeFindPlanPage.get().checkBoxBulkFinalize(1), "CheckBox1");
							strPlanVersionID = searchResults.getCell(1, 3).getText().toString().trim();
							waitForPageLoad(intMaxWaitTime);
							seClick(true,BulkFinalizeFindPlanPage.get().bulkFinalizeButton, "Bulk Finalize");
							waitForPageLoad(intMaxWaitTime);
							seSetText(BulkFinalizeFindPlanPage.get().commentBulkFinalize, "Comment");
							waitForPageLoad(20);
							seClick(true,BulkFinalizeFindPlanPage.get().submitBulkFinalizeButton, "submit");
							waitForPageLoad(intMaxWaitTime);
							String strid = PCUtils.downloadImpactReviewReport();
							seSetText(ImpactReviewPage.get().id,strid,"ID Field");
							seClick(ImpactReviewPage.get().execute,"Execute button");
							waitForPageLoad(intMaxWaitTime);
							strupdateid=HistoryPage.get().downloadUpdateReport(strid);
							strupdatereportFolder = strdownloadPath+"Bulk Finalize - "+strupdateid+" - Update Report.xlsx";	
							ExcelUtility.get().validateUpateReportForBulkFinalize(strPlanVersionID,strupdatereportFolder);
							BulkFinalizeFindPlanPage.get().verifyPlanStatus(strPlanVersionID);
							waitForPageLoad(intMaxWaitTime);
						}
						FindPlanPage.get().findPlan(strPlanVersionID);	
						waitForPageLoad(intMaxWaitTime);
						PlanOptionsPage.clickBenefit();
						waitForPageLoad(600);
						seSetText(FindTemplatePage.get().benefitsSearchField, strSearch1, "Setting benefit value in search field");
						waitForPageLoad(600); 
						seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
						waitForPageLoad(600); 																
						if(PlanOptionsPage.get().visualIndicator(strSearch1).isEnabled() && PlanOptionsPage.get().visualIndicatorTier.isEnabled()){
							RESULT_STATUS=true;
							log(PASS,strPlanVersionID,"Validate that the Domain Override values and visual indicators are retained on the Plan versions which was Bulk Republished and Bulk finalized",true);
						}
						else
						{
							RESULT_STATUS=false;
							log(FAIL,strPlanVersionID,"Validate that the Domain Override values and visual indicators are not  retained on the Plan versions which was Bulk Republished and Bulk finalized",true);
						}					
					}					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					setResult("STATUS", RESULT_STATUS);
					seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();	

		}
	}
}



