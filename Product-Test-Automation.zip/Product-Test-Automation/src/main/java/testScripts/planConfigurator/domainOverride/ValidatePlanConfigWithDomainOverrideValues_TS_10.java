package testScripts.planConfigurator.domainOverride;

//import org.openqa.selenium.WebElement;

import com.anthem.crypt.EnvHelper;
//import com.anthem.selenium.SuperHelper;
import com.anthem.selenium.constants.BrowserConstants;
//import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;

import page.planConfigurator.BenefitsPage;
import page.planConfigurator.CreatePlanPage;
//import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;

public class ValidatePlanConfigWithDomainOverrideValues_TS_10 extends CoreSuperHelper {
	
	static String strDownloadPath = "";
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime=1000;
	public static void main(String[] args) {
        
        try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					
					 String strRunFlag = getCellValue("Run_Flag");
					 String strTCName = getCellValue("TCName");
					 String strPlanVersionID = "";
					 String strProxyID = "";
					 
					 if(strRunFlag.equalsIgnoreCase("YES")) {
						 
						logExtentReport(strTCName);
						String strDownloadPath = getReportPathFolder(); 
						String strOptionsTab1=getCellValue("OptionsTab1");
						String strOptionsTab2=getCellValue("OptionsTab2");
						String strOptionsTabValue1=getCellValue("OptionsTabValue1");
						String strOptionsTabValue2=getCellValue("OptionsTabValue2");
						String strOptionsTabValue3=getCellValue("OptionsTabValue3");
						String[] strAccumUnitValue=getCellValue("UnitLimitValue").split(",");
						System.out.println(strAccumUnitValue[0]);
						System.out.println(strAccumUnitValue[1]);
						String[] strAccumVisitValue=getCellValue("VisitLimitValue").split(",");
						String[] strAccumPenalityValue=getCellValue("PenaltyValue").split(",");
						String strOptionsTypeTextValue=getCellValue("OptionsTypeTextValue");
						String strAccumName = getCellValue("AccumName");
						String strAccumName1=getCellValue("AccumulatorName");
						
						if(getWebDriver()==null)
						{
							seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad(intMaxWaitTime);
						}
						
//						FindPlanPage.get().findPlan("1538280409");
						CreatePlanPage.get().createPlan(true,intMaxWaitTime); 
						strPlanVersionID = getCellValue("PlanVersionID");
						strProxyID = getCellValue("PlanProxyID");
						waitForPageLoad(5, intMaxWaitTime);
						
						///visit limit////
						
						PlanOptionsPage.clickTab(strOptionsTab2, strOptionsTabValue1, intMaxWaitTime);
						waitForPageLoad(intMaxWaitTime);
						seClick(PlanOptionsPage.get().accVisitLimit, "Acupuncture Visit Limit");
						waitForPageLoad(intMaxWaitTime);
						seSetText(PlanOptionsPage.get().accVisitLimitTextBox, strAccumVisitValue[0], "Update acupuncture value ");
						waitForPageLoad(intMaxWaitTime);
						seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
						waitForPageLoad(100);
						seClick(PlanOptionsPage.get().saveButton, "Save");
						waitForPageLoad(600);
											
						//unit limit///
						
						PlanOptionsPage.clickTab(strOptionsTab2, strOptionsTabValue2, intMaxWaitTime);
						waitForPageLoad(intMaxWaitTime);
						seClick(PlanOptionsPage.get().breastPumpLimit, "Breast Pump Limit");
						waitForPageLoad(intMaxWaitTime);
						seSetText(PlanOptionsPage.get().breastPumpLimitTextBox, strAccumUnitValue[0], "Update breast pump value ");
						waitForPageLoad(intMaxWaitTime);
						seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
						waitForPageLoad(100);
						seClick(PlanOptionsPage.get().saveButton, "Save");
						waitForPageLoad(600);
							
						///penalty///
						
						PlanOptionsPage.clickTab(strOptionsTab1, strOptionsTabValue3, intMaxWaitTime);
						waitForPageLoad(intMaxWaitTime);
						seClick(PlanLevelBenefitsPage.get().InNetworkInstDollar, "In Network institutional pre-auth penalty");
						waitForPageLoad(intMaxWaitTime);
						seSetText(PlanLevelBenefitsPage.get().InNetworkInstDollarTextBox, strAccumPenalityValue[0], "Update penalty value ");
						waitForPageLoad(intMaxWaitTime);
						seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
						waitForPageLoad(100);
						seClick(PlanOptionsPage.get().saveButton, "Save");
						waitForPageLoad(600);
						
							 //validate Unit value, Visit value and Penality in benefits screen///
							 
							 
								PlanOptionsPage.clickBenefit();
								waitForPageLoad(400);
								seSetText(FindTemplatePage.get().benefitsSearchField, "Hospital / Facility Care", "Setting benefit value in search field");
								waitForPageLoad(600); 
								seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
								waitForPageLoad(600); 
								seClick(PlanOptionsPage.get().situationType("Tier1", "Inpatient Place of Service"), "click on Tier1");
			                    String strPenaltyValue=seGetElementValue(PlanOptionsPage.get().PenaltyValueBenefit);
			                    String strPenaltyValue1=strPenaltyValue.substring(1);
			                    waitForPageLoad(10,intMaxWaitTime);
			                    seClick(FindTemplatePage.get().clearButton,"Clicking on clear button");
			                    waitForPageLoad(10,intMaxWaitTime);
			                    seSetText(FindTemplatePage.get().benefitsSearchField, "Acupuncture", "Setting benefit value in search field");
								waitForPageLoad(600); 
								seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
								waitForPageLoad(600); 
								seClick(PlanOptionsPage.get().situationType("Tier1", "Professional"), "click on Tier1");
								String strVisitValue=seGetElementValue(BenefitsPage.get().acupunctureValueBenefit);
			                    String strVisitValue1[]=strVisitValue.split(" ");
			                    String strVisitValue2=strVisitValue1[0];
			                    System.out.println(strVisitValue2);
			                    waitForPageLoad(10,intMaxWaitTime);
			                    seClick(FindTemplatePage.get().clearButton,"Clicking on clear button");
			                    waitForPageLoad(10,intMaxWaitTime);
			                    seSetText(FindTemplatePage.get().benefitsSearchField, "Breast Pump", "Setting benefit value in search field");
								waitForPageLoad(600); 
								seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
								waitForPageLoad(600); 
								seClick(PlanOptionsPage.get().situationType("Tier1", "Unless Otherwise Specified"), "click on Tier1");
								String strUnitValue=seGetElementValue(BenefitsPage.get().breastPumpBenefit);
								String strUnitValue1[]=strUnitValue.split(" ");
			                    String strUnitValue2=strUnitValue1[0];
			                    System.out.println(strUnitValue2);
			                    waitForPageLoad(10,intMaxWaitTime);
			                    

								if( strUnitValue2.equalsIgnoreCase(strAccumUnitValue[0]))
								{
									log(PASS,strUnitValue2,"unit value displays in benefit tab ",true);
								}
								else
								{
									log(FAIL,strUnitValue2,"unit value is not displayed in benefit tab ",true);
								}
								
								if(strVisitValue2.equalsIgnoreCase(strAccumVisitValue[0]))
								{
									log(PASS,strVisitValue2,"visit value displays in benefit tab ",true);
								}
								else
								{
									log(FAIL,strVisitValue2,"visit value is not displayed in benefit tab",true);
								}
								
								if(strPenaltyValue1.equalsIgnoreCase(strAccumPenalityValue[0]))
								{
									log(PASS,strPenaltyValue1,"penalty value displays in benefit tab ",true);
								}
								else
								{
									log(FAIL,strPenaltyValue1,"penalty value is not displayed in benefit tab",true);
								}
								
								
								PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, intMaxWaitTime);
								waitForPageLoad(intMaxWaitTime);
								if(RESULT_STATUS){
			                           DownloadXML(strProxyID, strTestRegion, strDownloadPath);
			                           waitForPageLoad(500);
			                    }
			                             
			                   String UnitValue= PlanXMLParser.getAccumulatorAmount(strDownloadPath+strTestRegion+"_"+strPlanVersionID+".xml",strOptionsTabValue2,strAccumName,"Unit");
			                    if(UnitValue.equalsIgnoreCase(strAccumUnitValue[1]))  
					              {
					                   										
					            	  log(PASS,strAccumUnitValue[1],"updated unit values are displayed on the XML",true);
									}
									else
									{
										log(FAIL,strAccumUnitValue[1],"updated unit values are not displayed on the XML",true);
									}
			                   
			                    
			                    String VisitValue=  PlanXMLParser.getAccumulatorAmount(strDownloadPath+strTestRegion+"_"+strPlanVersionID+".xml",strOptionsTabValue1,strOptionsTypeTextValue,"Unit");
			                    if(VisitValue.equalsIgnoreCase(strAccumVisitValue[1]))  
					              {
					                   										
					            	  log(PASS,strAccumVisitValue[1],"updated visit values are displayed on the XML",true);
									}
									else
									{
										log(FAIL,strAccumVisitValue[1],"updated visit values are not displayed on the XML",true);
									}
			                    
			                 String PenalityValue=PlanXMLParser.getAccumulatorAmount(strDownloadPath+strTestRegion+"_"+strPlanVersionID+".xml",strOptionsTabValue3,strAccumName1,"Penalty");
			                 if(PenalityValue.equalsIgnoreCase(strAccumPenalityValue[1]))  
				              {
				                   										
				            	  log(PASS,strAccumPenalityValue[1],"updated penalty values are displayed on the XML",true);
								}
								else
								{
									log(FAIL,strAccumPenalityValue[1],"updated penalty values are not displayed on the XML",true);
								}
			                
			                    seCloseBrowser();
								}
				
				
			} catch (Exception e) {
				e.printStackTrace();
				log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
			} 
		}

	} catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
	} finally {
		endTestScript();	

}
}

}

								
								
								
								
						
						
						
						

