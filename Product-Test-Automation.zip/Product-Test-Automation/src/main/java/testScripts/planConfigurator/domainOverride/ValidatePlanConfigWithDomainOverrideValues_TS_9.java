package testScripts.planConfigurator.domainOverride;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;

import page.planConfigurator.CreatePlanPage;
//import page.planConfigurator.FindPlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.FindTemplatePage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;


public class ValidatePlanConfigWithDomainOverrideValues_TS_9 extends CoreSuperHelper {

	
	static String strDownloadPath = "";
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String struserProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime=600;
	
	public static void main(String[] args) {
        
        try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
							
					 String strRunFlag = getCellValue("Run_Flag");
					 String strTCName = getCellValue("TCName");
					 String strPlanVersionID = "";
					 String strProxyID = "";
					
					 if(strRunFlag.equalsIgnoreCase("YES")) {
							
						logExtentReport(strTCName);
						strDownloadPath = getReportPathFolder();
						String strOptionsTab1=getCellValue("OptionsTab1");
						String strOptionsTab2=getCellValue("OptionsTab2");
						String strOptionsTabValue1=getCellValue("OptionsTabValue1");
						String strOptionsTabValue2=getCellValue("OptionsTabValue2");
						String strAccumName = getCellValue("AccumName");
						String[] strAccumDeductibleValue=getCellValue("DeductibleValue").split(",");
						String strAccumName1=getCellValue("AccumulatorName");
						//String strAccumOOPValue=getCellValue("OOPValue");
						String[] strAccumCopayValue = getCellValue("CopayValue").split(",");
						System.out.println(strAccumCopayValue[0]);
						System.out.println(strAccumCopayValue[1]);
						String strOptionsTypeTextValue=getCellValue("OptionsTypeTextValue");
						String strOOPCheckBoxValue=getCellValue("OOPCheckBox");
						if(getWebDriver()==null)
						{
							seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
							LoginPage.get().loginApplication(struserProfile);
							waitForPageLoad(intMaxWaitTime);
						}						
					
//						FindPlanPage.get().findPlan("0906560453");
					CreatePlanPage.get().createPlan(true,460); 
					strPlanVersionID = getCellValue("PlanVersionID");
					strProxyID = getCellValue("PlanProxyID");
					waitForPageLoad(5, intMaxWaitTime);
					
					///Deductible////
					
					PlanOptionsPage.clickTab(strOptionsTab1, strOptionsTabValue1, intMaxWaitTime);
					waitForPageLoad(intMaxWaitTime);
					seClick(PlanLevelBenefitsPage.get().inNetIndDed, "In Network deductible");
					waitForPageLoad(intMaxWaitTime);
					seSetText(PlanLevelBenefitsPage.get().inNetIndDedValue, strAccumDeductibleValue[0], "Update deductible value ");
					waitForPageLoad(intMaxWaitTime);
					seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
					waitForPageLoad(100);
					seClick(PlanOptionsPage.get().saveButton, "Save");
					waitForPageLoad(600);
					
					///OOP///
					
					PlanOptionsPage.clickTab(strOptionsTab2, strOptionsTabValue2, intMaxWaitTime);
					waitForPageLoad(intMaxWaitTime);
					Boolean OOPCheckBoxValue = PlanOptionsPage.get().OOPCheckBox.isSelected();
					System.out.println(OOPCheckBoxValue);
					waitForPageLoad(600);
					
					///Copay///
					
					PlanOptionsPage.clickTab(strOptionsTab2, strOptionsTabValue2, intMaxWaitTime);
					waitForPageLoad(intMaxWaitTime);
					seClick(PlanOptionsPage.get().inNetInCareCopay, "In Network In Patient Care Copay");
					waitForPageLoad(intMaxWaitTime);
					seSetText(PlanOptionsPage.get().inNetInCareCopayVal, strAccumCopayValue[0], "Update copay value ");
					waitForPageLoad(intMaxWaitTime);
					seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
					waitForPageLoad(100);
					seClick(PlanOptionsPage.get().saveButton, "Save");
					waitForPageLoad(600);
					
                    PlanOptionsPage.clickBenefit();
                    waitForPageLoad(600);
                    seSetText(FindTemplatePage.get().benefitsSearchField, "Hospital / Facility Care", "Setting benefit value in search field");
                    waitForPageLoad(600); 
                    seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
                    waitForPageLoad(600); 
                    seClick(PlanOptionsPage.get().situationType("Tier1", "Inpatient Place of Service"), "click on Tier1");
                    waitForPageLoad(10,intMaxWaitTime);
                    String strDeductibleValue=seGetElementValue(PlanOptionsPage.get().DeductibleValueBenefit);
                    String strDeductibleValue1=strDeductibleValue.substring(1);
                    waitForPageLoad(10,intMaxWaitTime);
                    Boolean OOPCheckBenefitValue = PlanOptionsPage.get().OOPBenefitCheckbox.isSelected();
					System.out.println(OOPCheckBenefitValue);
					waitForPageLoad(20,intMaxWaitTime);
                    String strCopayValue=seGetElementValue(PlanOptionsPage.get().CopayValueBenefit.get(0));
                    String strCopayValue1=strCopayValue.substring(1);
                    System.out.println(strCopayValue1);
                    waitForPageLoad(5,intMaxWaitTime);
                   
                    if( strDeductibleValue1.equalsIgnoreCase(strAccumDeductibleValue[0]))
					{
						log(PASS,strDeductibleValue1,"deductible displays in benefit tab ",true);
					}
					else
					{
						log(FAIL,strDeductibleValue1,"deductible is not displayed in benefit tab",true);
					}
                    
					int checkBoxResult;
					checkBoxResult=OOPCheckBenefitValue.compareTo(OOPCheckBoxValue);
					if(checkBoxResult==0)
					{
						log(PASS,"Validating check boxes","Check box status is same");
					}
					else
					{
						log(FAIL,"Validating check boxes","Check box status is same");
					}
					
					if(strCopayValue1.equalsIgnoreCase(strAccumCopayValue[0]))
					{
						log(PASS,strCopayValue1,"copay displays in benefit tab ",true);
					}
					else
					{
						log(FAIL,strCopayValue1,"copay is not displayed in benefit tab ",true);
					}
                                                                                                                                                               
                    PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, intMaxWaitTime);
                    
                    if(RESULT_STATUS){
                    	DownloadXML(strPlanVersionID, strTestRegion, strDownloadPath);
                    	waitForPageLoad(500);
                    }
                    else
					{
						log(FAIL, "Validate Plan Design in XML", "Plan not moved to pending audit", true);
					}
                    String DeductibleValue= PlanXMLParser.getAccumulatorAmount(strDownloadPath+strTestRegion+"_"+strPlanVersionID+".xml","Deductible",strAccumName1,"Deductible");
                    System.out.println(DeductibleValue);
                    if(DeductibleValue.equalsIgnoreCase(strAccumDeductibleValue[1]))  
		              {
		                   										
		            	  log(PASS,strAccumDeductibleValue[1],"updated deductible values are displayed on the XML",true);
						}
						else
						{
							log(FAIL,strAccumDeductibleValue[1],"updated deductible values are not displayed on the XML",true);
						}
                    
                    String applyToXrefAccum=PlanXMLParser.getOOPValue(strDownloadPath+strTestRegion+"_"+strProxyID+".xml",strOptionsTabValue2,strOptionsTypeTextValue);
					if(applyToXrefAccum!=null)
					{
						if(strOOPCheckBoxValue.equalsIgnoreCase("Check"))
						{
							if(applyToXrefAccum.equalsIgnoreCase("false"))
							{
								log(PASS,"Validate if applyToXrefAccum text is displayed as false in xml","Verifying if applyToXrefAccum value is "+applyToXrefAccum);
							}
							else
							{
								log(FAIL,"Validate if applyToXrefAccum text is displayed as false in xml","Verifying if applyToXrefAccum value is "+applyToXrefAccum);
							}
						}
						else
						{
							if(applyToXrefAccum.equalsIgnoreCase("true"))
							{
								log(PASS,"Validate if applyToXrefAccum text is displayed as true in xml","Verifying if applyToXrefAccum value is "+applyToXrefAccum);
							}
							else
							{
								log(FAIL,"Validate if applyToXrefAccum text is displayed as true in xml","Verifying if applyToXrefAccum value is "+applyToXrefAccum);
							}
						}
					}
					else
					{
						RESULT_STATUS = false;
						log(FAIL, "Validate applyToXrefAccumin XML", "Not able to find the applyToXrefAccum in the XML");
					}
                 
                  String CopayValue=  PlanXMLParser.getAccumulatorAmount(strDownloadPath+strTestRegion+"_"+strPlanVersionID+".xml",strOptionsTabValue2,strAccumName,"Copayment");
                    if(CopayValue.equalsIgnoreCase(strAccumCopayValue[1]))  
		              {
		                   										
		            	  log(PASS,strAccumCopayValue[1],"updated copay values are displayed on the XML",true);
						}
						else
						{
							log(FAIL,strAccumCopayValue[1],"updated copay values are not displayed on the XML",true);
						}
                    
					seCloseBrowser();
					}
						
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} 
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();	

	}
	}

}
