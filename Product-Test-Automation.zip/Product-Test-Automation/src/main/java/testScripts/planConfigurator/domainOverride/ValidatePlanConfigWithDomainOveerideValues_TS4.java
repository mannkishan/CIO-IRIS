package testScripts.planConfigurator.domainOverride;


import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;


public class ValidatePlanConfigWithDomainOveerideValues_TS4 extends CoreSuperHelper {
	////Tc4,12////
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {

		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					if(strRunFlag.equalsIgnoreCase("YES")) {
						logExtentReport(strTCName);	
						seOpenBrowser(BrowserConstants.Chrome, baseURL);
						LoginPage.get().loginApplication(userProfile);
						String strOptionsTab = getCellValue("OptionsTab");
						String strAccumulatorType = getCellValue("AccumulatorType");						
						String strAccumName=getCellValue("AccumulatorName");
						String strAccumMaxValue=getCellValue("AccumulatorMaxValue");
						waitForPageLoad(intMaxWaitTime);
						CreatePlanPage.get().createPlan(true,460);	
						PlanOptionsPage.clickTab(strOptionsTab, strAccumulatorType, intMaxWaitTime);
						seClick(PlanOptionsPage.get().CopayMax(strAccumName),"Accumulator Name");
						waitForPageLoad(intMaxWaitTime);
						seSetText(PlanOptionsPage.get().CopayMaxValue(strAccumName),strAccumMaxValue,"Accumulator Max Value");
						waitForPageLoad(intMaxWaitTime);
						String strselectmsg=seGetElementValue(PlanOptionsPage.get().selectMsg);
						if(strselectmsg.equalsIgnoreCase("No Matches Found")){
							RESULT_STATUS=true;
							log(PASS,strAccumMaxValue,"custom value it should show  no matches found msg ",true);
						}
						else
						{
							RESULT_STATUS=false;
							log(FAIL,strAccumMaxValue,"custom value it not showing no matches found msg ",true);
						}

					}

				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					setResult("STATUS", RESULT_STATUS);
					seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();	

		}
	}

}
