package testScripts.planConfigurator.domainOverride;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;


import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;

public class ValidatePlanConfigWithDomainoverrideValues_TS_17 extends CoreSuperHelper {
	///TS17,18///
	
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {
		              
        try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
										 
					 String strRunFlag = getCellValue("Run_Flag");
					 String strTCName = getCellValue("TCName");
					 String strPlanVersionID=getCellValue("PlanProxyID");
					 String straccumValue1=getCellValue("accumValue1");
					 String straccumValue2=getCellValue("accumValue2");	 
					 String strSearch1=getCellValue("Search1");
					 String strTier=getCellValue("Tier");
						String strTierName=getCellValue("TierName");
					if(strRunFlag.equalsIgnoreCase("YES")) {
						logExtentReport(strTCName);	
						seOpenBrowser(BrowserConstants.Chrome, baseURL);
						 LoginPage.get().loginApplication(userProfile);
						 FindPlanPage.get().findPlan(strPlanVersionID);	
						 waitForPageLoad(600);
						 PlanOptionsPage.clickBenefit();
							waitForPageLoad(600);
							seSetText(FindTemplatePage.get().benefitsSearchField, strSearch1, "Setting benefit value in search field");
							waitForPageLoad(600); 
							seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
										waitForPageLoad(600); 
																		
																										
								seClick(PlanOptionsPage.get().situationType(strTier, strTierName), "click on Tier1");
								
								if(PlanOptionsPage.get().visualIndicator(strSearch1).isEnabled() && PlanOptionsPage.get().visualIndicatorTier.isEnabled()){
									RESULT_STATUS=true;
									log(PASS,"Visual Indicator","Validate that the user without Domain Override action rights is able to open the plan with Domain override values.",true);
								}
								else
								{
									RESULT_STATUS=false;
									log(FAIL,"Visual Indicator","Validate that the user without Domain Override action rights is able to open the plan with Domain override values.",true);
								}
								PlanOptionsPage.get().validateNMF(PlanOptionsPage.get().Copayment,"In Network Inpatient Care Copay", straccumValue2, intMaxWaitTime);	
								sePCSelectText(PlanOptionsPage.get().Copayment, "Copayment", straccumValue1, intMaxWaitTime);
								seClick(PlanOptionsPage.get().saveButton, "Save");
								if(RESULT_STATUS)
								{
									log(PASS,straccumValue1,"Validate that the user  can only enter the PM values from the range and not enter any override values.",true);
								}
								else
								{
									log(FAIL,straccumValue1,"Validate that the user  can not only enter the PM values from the range and not enter any override values.",true);
								}
						
								seClick(PlanOptionsPage.get().saveButton, "Save");
					}
				}
						
						
						
						

										
										
				catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					setResult("STATUS", RESULT_STATUS);
					 seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();	

	}
	}

}
