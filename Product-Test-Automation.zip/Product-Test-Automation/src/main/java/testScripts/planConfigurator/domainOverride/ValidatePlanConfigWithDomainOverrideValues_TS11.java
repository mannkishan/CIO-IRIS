package testScripts.planConfigurator.domainOverride;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;

import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;

public class ValidatePlanConfigWithDomainOverrideValues_TS11 extends CoreSuperHelper {


	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {

		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {

					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
										
					if(strRunFlag.equalsIgnoreCase("YES")) {
						logExtentReport(strTCName); 
						seOpenBrowser(BrowserConstants.Chrome, baseURL);
						LoginPage.get().loginApplication(userProfile);
						

						String strOptionsTab = getCellValue("OptionsTab");
						String strAccumulatorType = getCellValue("AccumulatorType");                                         
						String strAccumName=getCellValue("AccumulatorName");
						String strAccumMaxValue=getCellValue("AccumulatorMaxValue");
						String strPlanVersionID="";
						
						CreatePlanPage.get().createPlan(true,360);

						strPlanVersionID = getCellValue("PlanProxyID");
						waitForPageLoad(intMaxWaitTime);
						PlanOptionsPage.clickTab(strOptionsTab, strAccumulatorType, intMaxWaitTime);
						seClick(PlanOptionsPage.get().Copay(strAccumName),"Accumulator Name");
						waitForPageLoad(intMaxWaitTime);
						seSetText(PlanOptionsPage.get().CopayValue(strAccumName),strAccumMaxValue,"Accumulator Max Value");
						waitForPageLoad(intMaxWaitTime);
						seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
						waitForPageLoad(5,intMaxWaitTime); 
						boolean override=PlanOptionsPage.override(PlanOptionsPage.get().Copay(strAccumName));
						if(override==true)
						{
							RESULT_STATUS=true;
							log(PASS,"Value is Overriden","Value is Overriden");
						}
						else
						{
							RESULT_STATUS=false;
							log(FAIL,"Value is not Overriden","Value is not Overriden");
						}



					}


				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					setResult("STATUS", RESULT_STATUS);
					seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();     

		}
	}


}




