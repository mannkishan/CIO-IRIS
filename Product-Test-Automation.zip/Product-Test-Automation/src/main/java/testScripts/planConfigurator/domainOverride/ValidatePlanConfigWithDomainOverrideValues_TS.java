package testScripts.planConfigurator.domainOverride;

import java.util.HashMap;

import org.apache.bcel.generic.GETSTATIC;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.ExtentReportsUtility;
import com.relevantcodes.extentreports.model.Log;

import page.planConfigurator.FindPlanPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;
import utility.WebTable;
import utility.WebTableWithHeader;

public class ValidatePlanConfigWithDomainOverrideValues_TS extends CoreSuperHelper {

	///TC7////
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {

		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {

					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");


					if(strRunFlag.equalsIgnoreCase("YES")) {
						logExtentReport(strTCName);	
						seOpenBrowser(BrowserConstants.Chrome, baseURL);
						LoginPage.get().loginApplication(userProfile);
						getCellValue("OptionsTab");
						getCellValue("AccumulatorType");						
						String strAccumName=getCellValue("AccumulatorName");
						String strAccumMaxValue=getCellValue("AccumulatorMaxValue");
						getCellValue("PlanProxyID");
						String strTier=getCellValue("Tier");
						String strTierName=getCellValue("TierName");
						String strSearch1=getCellValue("Search1");	
						CreatePlanPage.get().createPlan(true,360);
						getCellValue("PlanProxyID");
						waitForPageLoad(intMaxWaitTime);
						PlanOptionsPage.clickBenefit();
						waitForPageLoad(600);
						seSetText(FindTemplatePage.get().benefitsSearchField, strSearch1, "Setting benefit value in search field");
						waitForPageLoad(600); 
						seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
						waitForPageLoad(600); 
						seClick(PlanOptionsPage.get().situationType(strTier, strTierName), "click on Tier1");
						seClick(PlanOptionsPage.get().selectAccum(strAccumName),strAccumName);
						PlanOptionsPage.get().validateNMF(PlanOptionsPage.get().selectAccum(strAccumName), strAccumName,strAccumMaxValue, intMaxWaitTime);
					}

				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();	

		}
	}



}
