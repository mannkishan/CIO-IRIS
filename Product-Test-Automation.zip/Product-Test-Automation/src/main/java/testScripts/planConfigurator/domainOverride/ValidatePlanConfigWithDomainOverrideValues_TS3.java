package testScripts.planConfigurator.domainOverride;



import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.anthem.crypt.EnvHelper;
import com.anthem.selenium.constants.BrowserConstants;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import utility.CoreSuperHelper;
import utility.PlanXMLParser;


public class ValidatePlanConfigWithDomainOverrideValues_TS3 extends CoreSuperHelper {

	/////TC1,5,6,8/////////
	static String baseURL = EnvHelper.getValue("pc.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static String strTestRegion = EnvHelper.getValue("test.environment");
	static int intMaxWaitTime=450;

	public static void main(String[] args) {

		try {
			MANUAL_TC_EXECUTION_EFFORT="00:10:00";
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strRunFlag = getCellValue("Run_Flag");
					String strTCName = getCellValue("TCName");
					if(strRunFlag.equalsIgnoreCase("YES")) {
						logExtentReport(strTCName);	
						seOpenBrowser(BrowserConstants.Chrome, baseURL);
						LoginPage.get().loginApplication(userProfile);
						String strOptionsTab = getCellValue("OptionsTab");
						String strAccumulatorType = getCellValue("AccumulatorType");						
						String strAccumName=getCellValue("AccumulatorName");
						String strAccumMaxValue=getCellValue("AccumulatorMaxValue");
						String strDownloadPath = getReportPathFolder(); 
						String strPlanVersionID = "";
						String strTier=getCellValue("Tier");
						String strTierName=getCellValue("TierName");
						String strSearch1=getCellValue("Search1");	
						CreatePlanPage.get().createPlan(true,360);
						strPlanVersionID = getCellValue("PlanProxyID");
						waitForPageLoad(intMaxWaitTime);
						PlanOptionsPage.clickTab(strOptionsTab, strAccumulatorType, intMaxWaitTime);
						waitForPageLoad(intMaxWaitTime);
						seClick(PlanOptionsPage.get().Copay(strAccumName),"Accumulator Name");
						waitForPageLoad(intMaxWaitTime);
						seSetText(PlanOptionsPage.get().CopayValue(strAccumName),strAccumMaxValue,"Accumulator Max Value");
						waitForPageLoad(intMaxWaitTime);
						seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
						seClick(PlanOptionsPage.get().saveButton, "Save");
						waitForPageLoad();
						PlanOptionsPage.clickBenefit();
						waitForPageLoad(600);
						seSetText(FindTemplatePage.get().benefitsSearchField, strSearch1, "Setting benefit value in search field");
						waitForPageLoad(600); 
						seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
						waitForPageLoad(600); 
						seClick(PlanOptionsPage.get().situationType(strTier, strTierName), "click on Tier1");
						String AccumValue=seGetText(PlanOptionsPage.get().Acuum(strAccumName));
						String AccumValue1=AccumValue.substring(1);
						if(AccumValue.equalsIgnoreCase(strAccumMaxValue)){
							RESULT_STATUS=true;
							log(PASS,AccumValue,"updates values are displayed on the Benefit Overview screen",true);
						}
						else
						{
							RESULT_STATUS=false;
							log(FAIL,AccumValue,"updates values are not displayed on the Benefit Overview screen",true);
						}
						PlanHeaderPage.get().requestAuditPlan(strPlanVersionID, intMaxWaitTime);
						if(RESULT_STATUS)
						{
							DownloadXML(strPlanVersionID, strTestRegion, strDownloadPath);
							waitForPageLoad(500);
						}  
						String expectedValue=PlanXMLParser.getAccumulatorAmount(strDownloadPath+strTestRegion+"_"+strPlanVersionID+".xml",strAccumulatorType,strAccumName,"Copayment");	
						String expectedValue1[]= expectedValue.split("\\.");
						System.out.println(expectedValue1[0].toString());
						if(expectedValue1[0].toString().equals(AccumValue1))  
						{
							RESULT_STATUS=true;
							log(PASS,strAccumMaxValue,"updates values are displayed on the XML");
						}
						else
						{
							RESULT_STATUS=false;
							log(FAIL,strAccumMaxValue,"updates values are not displayed on the XML");
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {
					setResult("STATUS", RESULT_STATUS);
					seCloseBrowser();
					endTestScript();	
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
		

		}
	}
}
