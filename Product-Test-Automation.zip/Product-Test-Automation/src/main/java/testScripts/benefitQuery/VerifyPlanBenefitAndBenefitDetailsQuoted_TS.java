package testScripts.benefitQuery;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.benefitQuery.LoginPage;
import page.benefitQuery.PlanOptionsDetailsPage;
import page.benefitQuery.QuotedPlanOptionsBenfitOptions;
import utility.CoreSuperHelper;

public class VerifyPlanBenefitAndBenefitDetailsQuoted_TS extends CoreSuperHelper {

	static String baseURL = EnvHelper.getValue("bqa.url");
	static String userProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strPlanId = getCellValue("Plan_Id");
					String strPlanServiceDate = getCellValue("Plan_Service_Date");
					logExtentReport("BQA Highlighting Quoted Items");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);
					waitForPageLoad();
					PlanOptionsDetailsPage.get().sePlanExistsInBQA(strPlanId, strPlanServiceDate);
					seClick(PlanOptionsDetailsPage.get().lblPlanStatus, "On Plan");
					LinkedHashMap<Integer, List<String>> valueVerifyPB = new LinkedHashMap<Integer, List<String>>();
					LinkedHashMap<Integer, List<String>> valueVerifyBenefitDetails = new LinkedHashMap<Integer, List<String>>();
					valueVerifyPB.put(0, QuotedPlanOptionsBenfitOptions.get().seCheckPlanOptionsAvailabilityInBQA());
					valueVerifyPB.put(1, QuotedPlanOptionsBenfitOptions.get().seCheckBenefitOptionsAvailabilityInBQA());
					valueVerifyBenefitDetails = QuotedPlanOptionsBenfitOptions.get()
							.seCheckBenefitDetailsAvailabilityInBQA();
					QuotedPlanOptionsBenfitOptions.get().seCheckQuotedValueAvailability(valueVerifyBenefitDetails,
							valueVerifyPB);
					seCloseBrowser();

				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occurred for the script execution", e.getLocalizedMessage());
		} finally {
			seCloseBrowser();
			endTestScript();
		}
	}
}
