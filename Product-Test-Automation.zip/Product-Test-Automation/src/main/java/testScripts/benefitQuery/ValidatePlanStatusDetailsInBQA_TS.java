package testScripts.benefitQuery;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.benefitQuery.LoginPage;
import page.benefitQuery.PlanOptionsDetailsPage;
import utility.CoreSuperHelper;

public class ValidatePlanStatusDetailsInBQA_TS extends CoreSuperHelper {

	static String baseURL = EnvHelper.getValue("bqa.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	
	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strPlanId = getCellValue("Plan_Id");
					String strPlanServiceDate = getCellValue("Plan_Service_Date");					
					logExtentReport("BQA Plan Status Validate");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);
					waitForPageLoad();
					/*Validates whether a Plan is in Production or Archived status */
					PlanOptionsDetailsPage.get().sePlanExistsInBQA(strPlanId, strPlanServiceDate);
					seCloseBrowser();
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			seCloseBrowser();
			endTestScript();
		}
	}


}
