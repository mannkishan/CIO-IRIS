package testScripts.benefitQuery;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Set;

import javax.validation.Path.Node;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.SeleniumLogLevels;
import com.thoughtworks.selenium.webdriven.SeleniumMutator;
import com.thoughtworks.selenium.webdriven.commands.SeleniumSelect;

import page.benefitQuery.FindPlanPage;
import page.benefitQuery.LoginPage;
import page.benefitQuery.PlanBenefitsPage;
import page.benefitQuery.PlanDefaultPage;
import page.benefitQuery.ExaminerActionVerbiage;
import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.BenefitsPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;

/**
 * @author af16393
 *
 */
public class VerifyExaminerActionVerbiage_TS extends CoreSuperHelper {

	static String baseURL = EnvHelper.getValue("bqa.url");
	static String userProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
				
					logExtentReport("BQA validation");
					String strProxyId=getCellValue("ProxyID");
					String strPlanId=getCellValue("PlanID");
					String strPcBenefitGroup=getCellValue("PC_Situation_group");
					String strBqaBenefitGroup=getCellValue("BQA_Situation_group");
					String strSituation=getCellValue("SituationType");
					String strBenefit=getCellValue("Benefit");
					String strServiceDate=getCellValue("BQA_ServiceDate");
					
					seOpenBrowser(BrowserConstants.Chrome, EnvHelper.getValue("pc.url"));
					page.planConfigurator.LoginPage.get().loginApplication(userProfile);
					waitForPageLoad();
					seClick(HomePage.get().find, "Find"); 
					seClick(HomePage.get().findPlan, "Find Plan");
					waitForPageLoad(60);
					seSetText(page.planConfigurator.FindPlanPage.get().planVersionID, strPlanId,"text in plan version id textbox");
					seWaitForClickableWebElement(page.planConfigurator.FindPlanPage.get().planSearch, 2);
					seClick(page.planConfigurator.FindPlanPage.get().planSearch, "Search plan");
					waitForPageLoad();
					seWaitForClickableWebElement(page.planConfigurator.FindPlanPage.get().selectSearchedPlan, 12);
					seClick(page.planConfigurator.FindPlanPage.get().selectSearchedPlan, " search result");
					waitForPageLoad();				
					seWaitForClickableWebElement(PlanLevelBenefitsPage.get().planLevelBenefits,2);
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",BenefitsPage.get().benefitTab);
					waitForPageLoad(75);					
					seClick(BenefitsPage.get().searchBenefit, " benefits search text box");
					seSetText(BenefitsPage.get().searchBenefit, strBenefit, "set benefitsearch text ");
					seClick(BenefitsPage.get().searchButtonBenefit, " benefit search button");
					waitForPageLoad();					
					LinkedList<String> PcExaminerAction=ExaminerActionVerbiage.get().seGetPcExaminerAction(strPcBenefitGroup, strSituation);
					seCloseBrowser();
     				seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);
					waitForPageLoad();
					seClick(FindPlanPage.get().findPlanTab, "click Find plan Tab");
					seSetText(FindPlanPage.get().planTextBox, strProxyId, "type plan id");
					seSetText(PlanDefaultPage.get().serviceDateContainer, strServiceDate);
					seClick(FindPlanPage.get().searchPlan, " search button");
					waitForPageLoad();
					seClick(FindPlanPage.get().searchTable, " search result");
					waitForPageLoad(75);

			    	seWaitForClickableWebElement(PlanDefaultPage.get().planOptionTab, 11);			    	
			    	LinkedList<String> bqaExaminerAction=ExaminerActionVerbiage.get().seGetBqaExaminerAction(strBenefit, strBqaBenefitGroup, strSituation);
			    	Iterator<String> pcNotes=PcExaminerAction.iterator();
					Iterator<String> bqaNotes=bqaExaminerAction.iterator();
					
					while(pcNotes.hasNext()&&bqaNotes.hasNext()){
						String strPcNotes=pcNotes.next().replaceAll("\\.", "");
						String strBqaNotes=bqaNotes.next().replaceAll("\\.", "");
						if(strPcNotes.equals(strBqaNotes)){
							log(PASS, "PC Examiner Action="+strPcNotes,"BQA Examiner Action="+strBqaNotes);
						}
						else{
							log(FAIL, "PC Examiner Action="+strPcNotes,"BQA Examiner Action="+strBqaNotes);

						}
					}
					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {

					//seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
