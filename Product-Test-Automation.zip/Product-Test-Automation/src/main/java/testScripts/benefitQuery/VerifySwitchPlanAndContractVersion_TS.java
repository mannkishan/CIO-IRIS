package testScripts.benefitQuery;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.Select;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.benefitQuery.FindPlanPage;
import page.benefitQuery.LoginPage;
import page.benefitQuery.PlanDefaultPage;
import utility.CoreSuperHelper;

/**
 * @author af16393
 *
 */
public class VerifySwitchPlanAndContractVersion_TS extends CoreSuperHelper {

	static String baseURL = EnvHelper.getValue("bqa.url");
	static String userProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();
			for (iROW = 1; iROW <= getRowCount(); iROW++) {

				try {
					logExtentReport("BQA validation");
                    String strContractId=getCellValue("ContractID");
                    String strPlanId=getCellValue("PlanID");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);
					waitForPageLoad();
					seSetText(FindPlanPage.get().contractTextBox, strContractId, "type contract id");
					seClick(FindPlanPage.get().searchPlan, " search button");
					waitForPageLoad();
					try{for(int i=1;i<5;i++){
						String strContractName=driver.findElement(By.xpath("//table[@class='table table-striped  dataTable']/tbody/tr["+i+"]/td[1]")).getText();
		        		String strEffectiveDate=driver.findElement(By.xpath("//table[@class='table table-striped  dataTable']/tbody/tr["+i+"]/td[2]")).getText();
		        		String strLob=driver.findElement(By.xpath("//table[@class='table table-striped  dataTable']/tbody/tr["+i+"]/td[3]")).getText();
		        		String strStatus=driver.findElement(By.xpath("//table[@class='table table-striped  dataTable']/tbody/tr["+i+"]/td[4]")).getText();
		        		log(PASS, ""+strContractName+"  "+strEffectiveDate+"",""+strLob+"  "+strStatus+"");
					}}catch(Exception e){}
					seClick(FindPlanPage.get().findPlanTab, "click Find plan Tab");
					waitForPageLoad();
					seSetText(FindPlanPage.get().planTextBox, strPlanId, "type contract id");
					seSetText(PlanDefaultPage.get().serviceDateContainer, "01012018");
					seClick(FindPlanPage.get().searchPlan, " search button");
                    waitForPageLoad(75);
                    seWaitForClickableWebElement(FindPlanPage.get().searchTable, 12);
					seClick(FindPlanPage.get().searchTable, " search result");
					waitForPageLoad(75);
					seClick(driver.findElement(By.xpath("//select[@class='switchPlanVersionDropdown']")), "switch");
					String[] a=new String[50];
					int j=0;
				try{	for( j=1;j<15;j++){
					 a[j]=seGetText(By.xpath("//select[@class='switchPlanVersionDropdown']/option["+j+"]"));
					 log(PASS, "Plan version"+j," "+a[j]);	 
				}}catch(Exception e){}
					
					Select Switch=new Select(driver.findElement(By.xpath("//select[@class='switchPlanVersionDropdown']")));
					
                   for(int k=1;k<=j-1;k++){
                	  
					Switch.selectByVisibleText(a[k]);
                    waitForPageLoad(2,45);
                    seWaitForClickableWebElement(driver.findElement(By.xpath("//div[@id='planDetailsTitleMain']")), 12);
                    seClick(driver.findElement(By.xpath("//div[@id='planDetailsTitleMain']")), "plan title");
                    String version=seGetText(By.xpath("//ul[@class='plan-header-pane']/li[contains(text(),'Plan Version')]/strong"));
                    String status=seGetText(By.xpath("//ul[@class='plan-header-pane3']/li[contains(text(),'Status')]/strong"));
					 log(PASS, "Plan version= "+version,"Status= "+status);	 

                   }
                    
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {

					seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
