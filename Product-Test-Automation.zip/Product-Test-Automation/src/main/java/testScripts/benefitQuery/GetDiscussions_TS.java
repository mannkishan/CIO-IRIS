package testScripts.benefitQuery;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.benefitQuery.FindPlanPage;
import page.benefitQuery.GetDiscussionPage;
import page.benefitQuery.LoginPage;
import page.benefitQuery.PlanBenefitsPage;
import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.BenefitsPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;

/**
 * @author af16393
 *
 */
public class GetDiscussions_TS extends CoreSuperHelper {

	static String baseURL = EnvHelper.getValue("gd.url");
	static String userProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
				

					logExtentReport("GetDiscussions");
					//seOpenBrowser(BrowserConstants.Chrome, baseURL);
					try{
						seOpenBrowser(InternetExplorer, baseURL);
					    log( PASS , "Browser launched sucessfully");
					    } catch (Exception e){System.out.println("logged in sucessfully");}					
					waitForPageLoad(45);
					Robot object=new Robot();
					
					//7 tab
					object.keyPress(KeyEvent.VK_TAB); System.out.println("going to tab clicked");
					System.out.println("tab clicked");
					
					// Press Enter
					object.keyPress(KeyEvent.VK_ENTER);
					object.keyRelease(KeyEvent.VK_ENTER);
					System.out.println("Enter clicked");
					waitForPageLoad(30);
					
					//fill home page
					WebElement objContractID = getWebDriver().findElement(By.xpath("//*[@id='ContractID']"));
					
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objContractID);
					System.out.println("enter details");
					waitForPageLoad();
					GetDiscussionPage.get().seEnter();
					log( PASS , "Sucessfully entered Credentials");
					
					waitForPageLoad(30);
					//click on Medical>>Plan options Button, get the plan id and the Status in production
					//PlanId	PlanStatus
					String strPlanId = getCellValue("PlanId"); waitForPageLoad();
					String strPlanStatus = getCellValue("PlanStatus");
					waitForPageLoad();
					GetDiscussionPage.get().seValidatePlanIDandStatus(strPlanId, strPlanStatus);
					
					waitForPageLoad(10);
					GetDiscussionPage.get().seUIActions();
					
					System.out.println("test passed");
					
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {

					//seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
