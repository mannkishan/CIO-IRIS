package testScripts.benefitQuery;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriverException;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.benefitQuery.FindPlanPage;
import page.benefitQuery.LoginPage;
import page.benefitQuery.PlanBenefitsPage;
import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.BenefitsPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;

/**
 * @author af16393
 *
 */
public class ValidateBenefit_TS extends CoreSuperHelper {

	static String baseURL = EnvHelper.getValue("bqa.url");
	static String userProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
				String strBenefit = getCellValue("Benefit").trim();
					String strPaymentLevel = getCellValue("Paymentlevel").trim();
					String strSituation = getCellValue("situation").trim();
					String strType = getCellValue("Type").trim();
					String strAccumulator = getCellValue("Accumulator").trim();
					String strSituationPath = strSituation.replaceAll("\\s+", "");
					String strPaymentLevelStatus = strPaymentLevel.replaceAll("\\s+", "");
					String strPlanId = getCellValue("PlanID").trim();
					String strOopPc;
					String strOopBqa;
					String strValPc;
					String strValBqa;

					logExtentReport("BQA validation");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);
					waitForPageLoad();
					seClick(FindPlanPage.get().findPlanTab, "click Find plan Tab");
					seSetText(FindPlanPage.get().planTextBox, strPlanId, "type contract id");
					seClick(FindPlanPage.get().searchPlan, " search button");
					waitForPageLoad();
					seClick(FindPlanPage.get().searchTable, " search result");
					waitForPageLoad(75);
					seWaitForClickableWebElement( PlanBenefitsPage.get().benefits, 12);
    				((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanBenefitsPage.get().benefits);


					try {
						PlanBenefitsPage.get().selectBenefit(strBenefit);

					} catch (WebDriverException e) {

						PlanBenefitsPage.clickBenefit(strBenefit);

					}

					waitForPageLoad();
					PlanBenefitsPage.clickPaymentLevel(strPaymentLevel);
					waitForPageLoad();
					PlanBenefitsPage.clickPaymentLevel(strSituation);
					waitForPageLoad();

					PlanBenefitsPage.clickBenefitDetails(strSituationPath, strAccumulator);
					waitForPageLoad();
					strValBqa = PlanBenefitsPage.getBenefitsTextValue(strSituationPath, strAccumulator);
					String strValBqa1 = strValBqa.substring(0, 3);

					strOopBqa = PlanBenefitsPage.getBenefitsTextOop(strSituationPath, strAccumulator);

					seClick(PlanBenefitsPage.get().closeBenefitInfo, "close benefit button");
					waitForPageLoad();

					seClick(FindPlanPage.get().logOut, "logout button");
					waitForPageLoad();

					seCloseBrowser();

					seOpenBrowser(BrowserConstants.Chrome, EnvHelper.getValue("pc.url"));

					page.planConfigurator.LoginPage.get().loginApplication(userProfile);
					waitForPageLoad();

					seClick(HomePage.get().find, "Find"); 
					seClick(HomePage.get().findPlan, "Find Plan");
					waitForPageLoad(60);

					seSetText(page.planConfigurator.FindPlanPage.get().planVersionID, strPlanId,
							"text in plan version id textbox");
					seClick(page.planConfigurator.FindPlanPage.get().planSearch, "Search plan");
					waitForPageLoad();

					seClick(page.planConfigurator.FindPlanPage.get().selectSearchedPlan, " search result");
					waitForPageLoad();
					((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",BenefitsPage.get().benefitTab);

					waitForPageLoad();

					seClick(BenefitsPage.get().searchBenefit, " benefits search text box");
					seSetText(BenefitsPage.get().searchBenefit, strBenefit, "set benefitsearch text ");
					seClick(BenefitsPage.get().searchButtonBenefit, " benefit search button");
					waitForPageLoad();

					PlanBenefitsPage.pcClick(strPaymentLevelStatus, strSituationPath);
					waitForPageLoad();

					strValPc = PlanBenefitsPage.getPcBenefitsValue(strPaymentLevelStatus, strSituationPath, strType);

					String strValPc1 = strValPc.substring(0, 3);

					try {
						PlanBenefitsPage.getPcBenefitsOop(strPaymentLevelStatus, strSituationPath, strType);
						strOopPc = "Yes";
					} catch (org.openqa.selenium.NoSuchElementException e) {
						strOopPc = "";
					}

					Boolean PC = seCompareStrings(strValBqa1, strValPc1, "=", "comparing accumulator values");
					Boolean BQA = seCompareStrings(strOopBqa, strOopPc, "=", "comparing out of pocket values");

					FindPlanPage.get().comparebool(PC, BQA);
					seClick(PlanHeaderPage.get().close, "Close button");
					waitForPageLoad();

					seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
					seClick(PlanHeaderPage.get().userLogout, "Logout");

				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				} finally {

					seCloseBrowser();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			endTestScript();
		}
	}
}
