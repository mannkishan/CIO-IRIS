package testScripts.benefitQuery;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.benefitQuery.BenefitScriptVerbiagePage;
import page.benefitQuery.LoginPage;
import page.benefitQuery.PlanOptionsDetailsPage;
import utility.CoreSuperHelper;

public class VerifyBenefitScriptVerbiageDisplayedInBQA_TS extends CoreSuperHelper {
	/*Verifies whether the verbiage and Benefit Tree, if any are available in Benefit Script for a given Benefit*/
	static String baseURL = EnvHelper.getValue("bqa.url");
	static String userProfile = EnvHelper.getValue("user.profile");

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					String strPlanId = getCellValue("Plan_Id");
					String strPlanServiceDate = getCellValue("Plan_Service_Date");
					logExtentReport("BQA OON Examiner Actions Availability");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);
					waitForPageLoad();					
					PlanOptionsDetailsPage.get().sePlanExistsInBQA(strPlanId, strPlanServiceDate);
					seClick(PlanOptionsDetailsPage.get().lblPlanStatus, "On Plan");
					BenefitScriptVerbiagePage.get().seCheckExaminerActionAvailabilityInBQA();

				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occurred for the script execution", e.getLocalizedMessage());
		} finally {
			//seCloseBrowser();
			endTestScript();
		}
	}
}