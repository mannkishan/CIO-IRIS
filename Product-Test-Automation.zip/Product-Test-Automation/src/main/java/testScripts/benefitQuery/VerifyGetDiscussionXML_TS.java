package testScripts.benefitQuery;


import java.awt.Robot;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.awt.*;
import org.openqa.selenium.Alert;

import java.awt.event.KeyEvent;
import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.benefitQuery.GetDiscussionXMLPage;
import utility.CoreSuperHelper;
import utility.SOAPServiceUtils;
import utility.SpiderWebService;

public class VerifyGetDiscussionXML_TS extends CoreSuperHelper {
	
	static String baseURL = EnvHelper.getValue("gd.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	static String endPointURL="https://spider-eps.uat.va.wellpoint.com/spiderpc/services/PlanConfiguratorWebservice";
	static String strDownloadPath = "";

	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {
					strDownloadPath = getReportPathFolder();				
				HashMap<String, String> ElementValue=new HashMap<>();
				String strDiscussionID=getCellValue("GetDiscussionID");			
				String proxyId=getCellValue("ProxyID");
				String strXMLFile=strDownloadPath+proxyId+".xml";
				String xmlInput=GetDiscussionXMLPage.get().getResponseWithDiscussionID(strDiscussionID);
				SOAPServiceUtils.get_Save_SOAPResponsefromRequestString(xmlInput, ElementValue, endPointURL,strXMLFile);
				String response = SOAPServiceUtils.getSOAPResponsefromRequestString(xmlInput,ElementValue,endPointURL);

				GetDiscussionXMLPage.get().getDiscussionViewBenefitXMLDetailsQuoted(strXMLFile);
				GetDiscussionXMLPage.get().getDiscussionViewUMRulesXMLDetails(strXMLFile);
				GetDiscussionXMLPage.get().getDiscussionViewBenefitScriptDetails(strXMLFile);
				GetDiscussionXMLPage.get().getDiscussionViewPlanOptionsAccumulatorQuoted(strXMLFile);
				GetDiscussionXMLPage.get().getDiscussionViewBenefitOptionsAccumulatorQuoted(strXMLFile);
				GetDiscussionXMLPage.get().getDiscussionViewBenefitXMLDetails(strXMLFile);
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occurred for the script execution", e.getLocalizedMessage());
		} finally {			
			endTestScript();
		}
	}
}