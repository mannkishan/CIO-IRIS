package testScripts.benefitQuery;

import java.awt.List;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.lang3.time.DateParser;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;
import com.sun.jna.platform.win32.OaIdl.DATE;

import benefitQuery.FindOptionPage;
import page.benefitQuery.PlanOptionsDetailsPage;
import page.benefitQuery.FindPlanPage;
import page.benefitQuery.LoginPage;
import page.benefitQuery.PlanBenefitsPage;
import page.benefitQuery.PlanOptionsDetailsPage;
import utility.CoreSuperHelper;

public class ValidatePlanAndContractStatusDetailsInBQA_TS extends CoreSuperHelper {

	static String baseURL = EnvHelper.getValue("bqa.url");
	static String userProfile = EnvHelper.getValue("user.profile");
	
	public static void main(String[] args) {
		try {
			initiateTestScript();

			for (iROW = 1; iROW <= getRowCount(); iROW++) {
				try {

					String strPlanId = getCellValue("Plan_Id");
					String strContractId = getCellValue("Contract_Id");
					String strContractServiceDate = getCellValue("Contract_Service_Date");
					String strPlanServiceDate = getCellValue("Plan_Service_Date");					
					logExtentReport("BQA Status Check");
					seOpenBrowser(BrowserConstants.Chrome, baseURL);
					LoginPage.get().loginApplication(userProfile);
					waitForPageLoad();
					/*Validates whether a Plan is in Production or Archived status */
					PlanOptionsDetailsPage.get().sePlanExistsInBQA(strPlanId, strPlanServiceDate);
					waitForPageLoad(10, 20);
					/*Validates whether a Contract is in Production or Archived or Terminated Status. Also verfies whether the header details are available for a Contract*/
					PlanOptionsDetailsPage.get().seContractExists(strContractId, strContractServiceDate);
					seCloseBrowser();
				} catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
		} finally {
			seCloseBrowser();
			endTestScript();
		}
	}


}
