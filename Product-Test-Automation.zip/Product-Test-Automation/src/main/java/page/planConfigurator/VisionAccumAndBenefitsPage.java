package page.planConfigurator;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class VisionAccumAndBenefitsPage  extends CoreSuperHelper{
	private static VisionAccumAndBenefitsPage thisIsTestObj;
	public  synchronized static VisionAccumAndBenefitsPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), VisionAccumAndBenefitsPage.class);
		return thisIsTestObj;
		}
	/*Pediatric Deductible starts here*/
	
	@FindBy(how = How.XPATH, using = "//*[@id='Base']/a")
	@CacheLookup
	public WebElement visionPlanLevelBenefitsTab;
	
	@FindBy(how = How.XPATH, using = "//a[@class='optionItem' and @data-target='#planOption_DeductiblePed']")
	@CacheLookup
	public WebElement visionPlanLevelBenefits_PediatricDeductible;
	
	@FindBy(how = How.XPATH, using = "//input[@id='POA_Base-_-DeductiblePed-_-Deductible-_-INN-_-ComingledWithMed']")
	@CacheLookup
	public WebElement visionPlanLevelBenefits_PediatricDeductible_ComingledWithMed_RadioButton;
		
	@FindBy(how = How.XPATH, using = "//input[@id='POA_Base-_-DeductiblePed-_-Deductible-_-INN-_-CominglingNotApplicable']")
	@CacheLookup
	public WebElement visionPlanLevelBenefits_PediatricDeductible_CominglingNotApplicable_RadioButton;

	/*Pediatric Deductible ends here*/
	
	
	
	/*Pediatric Routine Eye Exam starts here*/
	@FindBy(how = How.XPATH, using = "//*[@id='BenefitOption']/a")
	@CacheLookup
	public WebElement visionBenefitOptionsTab;
	
	@FindBy(how = How.XPATH, using = "//a[@class='optionItem' and @data-target='#planOption_RoutineEyeExamPediatric']")
	@CacheLookup
	public WebElement visionBenefitOptions_PediatricRoutineEyeExam;
		
	@FindBy(how = How.XPATH, using = "//input[@id='POA_BenefitOption-_-RoutineEyeExamPediatric-_-CoveredINNOON']")
	@CacheLookup
	public WebElement visionBenefitOptions_PediatricRoutineEyeExam_CoveredINOON_RadioButton;
	
	@FindBy(how = How.XPATH, using = "//input[@id='POA_BenefitOption-_-RoutineEyeExamPediatric-_-CoveredINNOON']//following::span[1]")
	@CacheLookup
	public WebElement visionBenefitOptions_PediatricRoutineEyeExam_CoveredINOONName;
	
	@FindBy(how = How.XPATH, using = "//*[@id='verticalBarMenu']/div[3]/div")
	public WebElement visionBenefitScroll;	
	
	@FindBy(how = How.XPATH, using = "//input[@id='POA_BenefitOption-_-RoutineEyeExamPediatric-_-CoveredINNOnly']")
	@CacheLookup
	public WebElement visionBenefitOptions_PediatricRoutineEyeExam_CoveredINNOnly_RadioButton;
	
	public void seIsVisionBenefitOptionsVisible()
	{	
		for(int i=0;i<2;i++)
		{
			seClick(VisionAccumAndBenefitsPage.get().visionBenefitScroll, "Benefit Scroll");
		}
		seWaitForClickableWebElement(visionBenefitOptionsTab, 20);
		seClick(VisionAccumAndBenefitsPage.get().visionBenefitOptionsTab, "Benefit Options");
		seWaitForClickableWebElement(visionBenefitOptions_PediatricRoutineEyeExam, 20);
		seClick(visionBenefitOptions_PediatricRoutineEyeExam, "Pediatric Routine Eye Exam");	
		String valueType="";
		if (AllergySerumBenefitOptionPage.get().seCheckIsElementNotSelected(visionBenefitOptions_PediatricRoutineEyeExam_CoveredINOON_RadioButton, "In Network Out Of Network")) 
		{					
			seClick(visionBenefitOptions_PediatricRoutineEyeExam_CoveredINOON_RadioButton, "In Network Out Of Network");
			seWaitForPageLoad(20);
			valueType="CoveredINNOON";
			for (int i = 0; i < 6; i++)
			{	
				seIsElementAvailable(getCellValue("CoveredINNOONAccumulatorValue" + i),valueType);
			}
		}
		else
		{			
			seClick(visionBenefitOptions_PediatricRoutineEyeExam_CoveredINNOnly_RadioButton, "In Network Only");
			valueType="CoveredINNOnly";
			for(int i=0;i<3;i++)
			{
				seIsElementAvailable(getCellValue("CoveredINNOnlyAccumulatorValue"+i),valueType);
			}		
				
		}		
	}
	
	/*Pediatric Routine Eye Exam ends here*/
	
	/*Pediatric Deductible starts here*/
	
	public void seIsVisionPlanOptionsVisible()
	{		
		String valueType="";
		seClick(visionPlanLevelBenefitsTab, "Plan Level Benefits");
		seClick(visionPlanLevelBenefits_PediatricDeductible, "Pediatric Deductible");				
		if(AllergySerumBenefitOptionPage.get().seCheckIsElementNotSelected(visionPlanLevelBenefits_PediatricDeductible_ComingledWithMed_RadioButton,"Comingled With Medical"))
		{
			seClick(visionPlanLevelBenefits_PediatricDeductible_ComingledWithMed_RadioButton, "Comingled With Medical");
			valueType="ComingledWithMed";
			for(int i=0;i<2;i++)
			{
				seIsElementAvailable(getCellValue("CoMingledWithMedAccumulatorValue"+i),valueType);				
			}			
		}
		else
		{
			seClick(visionPlanLevelBenefits_PediatricDeductible_CominglingNotApplicable_RadioButton, "Comingling Not Applicable");
			valueType="CominglingNotApplicable";
			for(int i=0;i<1;i++)
			{
				seIsElementAvailable(getCellValue("CominglingNotApplicableAccumulatorValue"+i),valueType);
				
			}			
		}			
	}
	/*Pediatric Deductible ends here*/
	
	/*Checks whether the given Accumulator is available under an Accumulator Group Type*/
	public void seIsElementAvailable(String valueName,String valueType)
	{
		String checkValue="";
		seWaitForPageLoad(40);
		checkValue=seGetText(driver.findElement(By.xpath("//div[contains(@id,'"+valueType+"')]//span[normalize-space(text())='"+valueName+"']"))).trim();		
		seVerifyFieldValue(driver.findElement(By.xpath("//div[contains(@id,'"+valueType+"')]//span[normalize-space(text())='"+valueName+"']")), checkValue, valueName);		
		
	}
	
}
