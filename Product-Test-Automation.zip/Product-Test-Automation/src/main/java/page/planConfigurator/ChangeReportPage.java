package page.planConfigurator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import com.anthem.selenium.constants.ApplicationConstants;
import com.anthem.selenium.utility.ExtentReportsUtility;

//import page.GroupInfoPage;
import utility.CoreSuperHelper;
import utility.WebTableWithHeader;

public class ChangeReportPage extends CoreSuperHelper {
	
	private static ChangeReportPage thisTestObj;	
	public synchronized static ChangeReportPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), ChangeReportPage.class);
		return thisTestObj;
	}
	
	@FindBy(how = How.CLASS_NAME, using = "plan-status-value")
	//@CacheLookup
	public WebElement planStatusValue;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Edit')]")
	//@CacheLookup
	public WebElement edit;
	
	@FindBy(how = How.XPATH, using = "//div[@class='col-xs-8 createButtonDiv']/button[2]")
	//@CacheLookup
	public WebElement SaveBtn;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Acupuncture')]")
	@CacheLookup
	public WebElement selectBenefit;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Ambulance')]")
	@CacheLookup
	public WebElement selectBenefit1;
	
	@FindBy(how = How.XPATH, using = "//button[@title='History']")
	//@CacheLookup
	public WebElement historyOption;
	
	
	
	@FindBy(how = How.XPATH, using = "//table[@id='DataTables_Table_2']//td[contains(text(),'Audit Requested')]")
	//@CacheLookup
	public WebElement auditRequested;
	
	@FindBy(how = How.XPATH, using = "//table[@id='DataTables_Table_3']//td[@class='changeReport ']/div")
		//@CacheLookup
	 public WebElement excelReportbtn;
	
	@FindBy(how = How.NAME, using = "BTC_Acupuncture-_-Tier1-_-INPTPOSPRFCLMTYP")
	@CacheLookup
	public WebElement selectCoveredStandard;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Inpatient Care Coinsurance')]//following::span[@class='select2-selection__arrow'][1]")
	//@CacheLookup
	public WebElement 	InNetworkInpatientCareCoins;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Covered Override')]//preceding::input[@name='BTC_Biologicals-_-Tier1-_-FormRetail'][3]")
	//@CacheLookup
	public WebElement selectCoveredOverride;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Covered - Standard Calculation')]//preceding::input[@name='BTC_Biologicals-_-C-_-FormTier2Retail'][2]")
	//@CacheLookup
	public WebElement selectCoveredStd;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Covered Override')]//preceding::input[@name='BTC_Biologicals-_-C-_-FormRetail'][3]")
	//@CacheLookup
	public WebElement selectCoveredOver;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Covered Override')]//preceding::input[@name='BTC_Biologicals-_-Tier1-_-FormMail'][3]")
	//@CacheLookup
	public WebElement selectCoveredOverFormulary;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Covered Override')]//preceding::input[@name='BTC_Biologicals-_-C-_-FormMail'][3]")
	//@CacheLookup
	public WebElement selectCoveredOverBioFormmail;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Covered - Standard Calculation')]//preceding::input[@name='BTC_Biologicals-_-C-_-FormTier1Retail'][2]")
	//@CacheLookup
	public WebElement selectCoveredStdCal;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Form Retail Copay')]//following::span[@class='select2-selection__arrow'][1]")
	//@CacheLookup
	public WebElement selectCopaydropRetail;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Form Mail Copay')]//following::span[@class='select2-selection__arrow'][1]")
	//@CacheLookup
	public WebElement selectCopaydropMail;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Form Mail Coinsurance')]//following::span[@class='select2-selection__arrow'][1]")
	//@CacheLookup
	public WebElement selectCoinsdropMail;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Formulary Tier 1 Retail Copay')]//following::span[@class='select2-selection__arrow'][1]")
	//@CacheLookup
	public WebElement selectCopaydropdownRetail1;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Formulary Tier 2 Retail Copay')]//following::span[@class='select2-selection__arrow'][1]")
	//@CacheLookup
	public WebElement selectCopaydropdownRetail2;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Formulary Tier 1 Mail Coinsurance')]//following::span[@class='select2-selection__arrow'][1]")
	//@CacheLookup
	public WebElement selectCoinsdropdownMail1;
	
	@FindBy(how = How.XPATH, using = "//div[@class='benefitDetailsWrapper']/div[1]")
	@CacheLookup
	public WebElement selectTire;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'In Network Inpatient Care Coinsurance')]//following::span[@class='select2-selection__arrow'][1]")
	public WebElement HFCParent;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Rx Mail Copay')]//following::span[@class='select2-selection__arrow'][1]")
	//@CacheLookup
	public WebElement selectCopaydropRxMail;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Rx Retail Copay')]//following::span[@class='select2-selection__arrow'][1]")
	//@CacheLookup
	public WebElement selectCopaydropRxRetail;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Rx Mail Coinsurance')]//following::span[@class='select2-selection__arrow'][1]")
	//@CacheLookup
	public WebElement selectCoinsdropRxMail;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Rx Retail Coinsurance')]//following::span[@class='select2-selection__arrow'][1]")
	//@CacheLookup
	public WebElement selectCoinsdropRxRetail;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Inpatient Care Coinsurance')]//following::input[@class='planOptionField INHERITED_FROM_PARENT'][1]")
	@CacheLookup
	public WebElement selectInNetworkInpatientOOP;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Rx Mail Coinsurance')]//following::input[@class='planOptionField INHERITED_FROM_PARENT'][1]")
	@CacheLookup
	public WebElement selectCoinsRxMailOOP;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Form Retail Copay')]//following::input[@class='planOptionField INHERITED_FROM_PARENT'][1]")
	@CacheLookup
	public WebElement selectFormRetailOOP;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Form Mail Coinsurance')]//following::input[@class='planOptionField INHERITED_FROM_PARENT'][1]")
	@CacheLookup
	public WebElement selectFormMailOOP;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Coinsurance')]//following::input[@class='planOptionField INHERITED_FROM_PARENT'][1]")
	@CacheLookup
	public WebElement selectInNetworkOOP;
	
	@FindBy(how = How.XPATH, using = "//table[@class='table planTransitions dataTable']")
	public WebElement historyTable;
	
	@FindBy(how = How.XPATH, using = "//input[@class='preAuth oopCheckBox planOptionField']")
	@CacheLookup
	public WebElement selectpreAuth;
	
	@FindBy(how = How.XPATH, using = "//input[@class='autoAdjud oopCheckBox planOptionField']")
	@CacheLookup
	public WebElement selectautoAdjud;
	
	public WebElement changeReport(int row)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//table[@class='table planTransitions dataTable']/tbody/tr["+row+"]/td[7]/div[@class='EXCEL-Icon report-button']"));
		return valueType;
	}
	
	public WebElement situationType(String Value)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//div[@class='benefitDetailsWrapper']/div["+Value+"]"));
		return valueType;
	} 
	
	public WebElement selectpreAuth(String Value)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//div[@class='benefitDetailsWrapper']/div["+Value+"]//input[@class='preAuth oopCheckBox planOptionField']"));
		return valueType;
	}
	
	public WebElement selectautoAdjud(String Value)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//div[@class='benefitDetailsWrapper']/div["+Value+"]//input[@class='autoAdjud oopCheckBox planOptionField']"));
		return valueType;
	}
	
	public WebElement selectOOP(String OOPValue)
	{
		WebElement oopvalueType = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+OOPValue+"')]//following::input[@class='planOptionField INHERITED_FROM_PARENT'][1]"));
		return oopvalueType;
	} 

	
	/**
	 * @author AF54545 
	 * @method The Method is used to validate Plan Status 
	 */
	public void validatePlanStatus(String strplanstatus) {
		try {
			String strPlanStatusvalue = seGetElementValue(planStatusValue).toString();
			if (strPlanStatusvalue.equalsIgnoreCase(strplanstatus)) {
				ExtentReportsUtility.log(ApplicationConstants.PASS, "Plan Status is in "+strPlanStatusvalue + "",
						"Verified Plan Status is in "+ strPlanStatusvalue +"", true);
			} else {
				ExtentReportsUtility.log(ApplicationConstants.FAIL, "Plan Status should be in Production",
						"Plan Status is not in Production", true);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @author AF54545 
	 * @method The Method is used to get the excel button element
	 */
	public  void excelButton(){
		   WebElement excelBtn = getWebDriver().findElement(By.xpath("//td[@class='changeReport ']/div")) ;
			 JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("window.scrollBy(0,200)","");
			 js.executeScript("arguments[0].scrollIntoView();",excelBtn);
			 seClick(excelBtn,"Excel Report");
			 waitForPageLoad(360);
	   }
	
	public boolean downloadChangeReport(){
		boolean downloadReport=false;
		try {
			seClick(PlanHeaderPage.get().history, "History");
			WebTableWithHeader hisotryTable = new WebTableWithHeader(ChangeReportPage.get().historyTable, "History table");
			int intTotalRows = hisotryTable.getRowsCount();
			for (int i = 1; i <= intTotalRows; i++) {
				String actionTaken=hisotryTable.getCellData(i, 3);
				if(actionTaken.equalsIgnoreCase("Audit Requested")){
					List<WebElement> changeReport=getWebDriver().findElements(By.xpath("//table[@class='table planTransitions dataTable']/tbody/tr["+i+"]/td[7]/div[@class='EXCEL-Icon report-button']"));
					if(changeReport.size()>0){
						seClick(ChangeReportPage.get().changeReport(i), "Download Change Report");
						downloadReport=true;
						break;
					}
					else if(!(changeReport.size()>0)){
						downloadReport=false;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return downloadReport;
	}
	
	public void requestAuditPlan(String strVersionID, int intMaxWaitTime)
	{
		waitForPageLoad(3, intMaxWaitTime);
		seClick(PlanHeaderPage.get().requestAudit, "Request Audit for Plan");
		waitForPageLoad(3, intMaxWaitTime);
		seClick(PlanTransitionPage.get().reasonCode, "Reason Code");
		waitForPageLoad(1, intMaxWaitTime);
		seClick(PlanTransitionPage.get().selectType("Other"), "Select Other from Reason Code");
		waitForPageLoad(intMaxWaitTime);
		seClick(PlanTransitionPage.get().requestAudit, "Request Audit");
		waitForPageLoad(intMaxWaitTime);
	}
}
