package page.planConfigurator;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class TemplateHeaderPage extends CoreSuperHelper{
	
	private static TemplateHeaderPage thisTestObj;	
	public synchronized static TemplateHeaderPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), TemplateHeaderPage.class);
		return thisTestObj;
	}
	
	//div[@id='actionsBarWrapper']/ul[@id='actionsBar']/li[4]/a
	@FindBy(how = How.LINK_TEXT, using = "Request Audit")
	@CacheLookup
	public WebElement requestAudit;
	
	@FindBy(how = How.XPATH, using = "//div[@id='actionsBarWrapper']/ul/li[5]/a[text()='Approve']")
	@CacheLookup
	public WebElement approveAudit;
	
	@FindBy(how = How.XPATH, using = "//a[@title='Plan Options']")
	@CacheLookup
	public WebElement planOption;
	
			
	@FindBy(how = How.XPATH, using = "//div[@id='actionsBarWrapper']/ul/li[3]/a")
	@CacheLookup
	public WebElement finalize;
		
	@FindBy(how = How.XPATH, using = "//div[@id='actionsBarWrapper']/ul/li[2]/a")
	@CacheLookup
	public WebElement moveToProduction;
	
	@FindBy(how = How.LINK_TEXT, using = "Edit")
	@CacheLookup
	public WebElement edit;  
	
	//*[@id=\"actionsBar\"]/li[5]/a
	@FindBy(how = How.LINK_TEXT, using = "Save")
	@CacheLookup
	public WebElement save;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"planHeaderWrapper\"]/div/div/div[2]/div[2]/div[2]/div/div[2]")
	@CacheLookup
	public WebElement templateVersionID;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"planHeaderWrapper\"]/div/div/div[2]/div[2]/div[2]/div/div[1]")
	@CacheLookup
	public WebElement  templateProxyID;
	
	public WebElement tempInfoHeader(String type)
    {
           WebElement valueType = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+type+"')]/ancestor::label/following::div[1]/span"));
           return valueType;
    }
	
	public String getTemplateVersionID()
	{
		waitForPageLoad(300);
		return seGetElementValue(templateVersionID).split(":")[1];
	}
	
	public WebElement status(String status)
    {
           WebElement statusvalue = getWebDriver().findElement(By.xpath("//div[@id='planHeaderWrapper']/div/div/div[2]/div[2]/div[1]/div[2]/span[contains(text(),'"+status+"')]"));
           return statusvalue;
    }
	
	@FindBy(how = How.XPATH, using = "//div[@id ='content-benefitSearchBar']/div[2]/div/input[@type='text']")
	@CacheLookup
	public WebElement search;
	
	@FindBy(how = How.XPATH, using = "//div[@id='workingArea']/div/div[1]/div[2]/button[2]")
	@CacheLookup
	public WebElement search_Btn;

	@FindBy(how = How.XPATH, using = "//button[@title='History']")
	@CacheLookup
	public WebElement history;
	
	public List<WebElement> createdtext(){
		List<WebElement> element = driver.findElements(By.xpath("//*[contains(@class,'actionTaken')][1]"));
		return element;
	}
	@FindBy(how = How.XPATH, using = "//*[contains(text(),'Copied')]/following-sibling::td[3]")
	@CacheLookup
	public WebElement createdValueCopied;

	@FindBy(how = How.XPATH, using = "//*[contains(text(),'Edited')]/following-sibling::td[3]")
	@CacheLookup
	public WebElement createdValueEdited;

	@FindBy(how = How.XPATH, using = "//*[contains(text(),'Created')]/following-sibling::td[3]")
	@CacheLookup
	public WebElement createdValueCreated;
	
	@FindBy(how = How.XPATH, using = "//*[contains(text(),'Action Taken Date')]")
	@CacheLookup
	public WebElement actionTakenDate;
}
