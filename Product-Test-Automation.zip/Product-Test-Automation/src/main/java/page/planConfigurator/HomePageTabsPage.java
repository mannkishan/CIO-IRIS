package page.planConfigurator;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;
//import utility.WebTable;

public class HomePageTabsPage extends CoreSuperHelper{

       private static HomePageTabsPage thisTestObj;    
       public synchronized static HomePageTabsPage get() {
              thisTestObj = PageFactory.initElements(getWebDriver(), HomePageTabsPage.class);
              return thisTestObj;
       }
       
       @FindBy(how = How.XPATH, using = "//*[@id=\"BenefitTree\"]/a")
    @CacheLookup
    public WebElement benefitsTab;


       @FindBy(how = How.XPATH, using = "//a[@title='Plan Options']")
    @CacheLookup
    public WebElement planOptionsTab;

       
       @FindBy(how = How.XPATH, using = "//*[@id=\"Base\"]/a")
    @CacheLookup
    public WebElement planLevelBenefitsTab;

       @FindBy(how = How.XPATH, using = "//div[@title='Scroll Up']")
       @CacheLookup
       public WebElement scrollUpButton;
       
       @FindBy(how = How.XPATH, using = "//div[@title='Scroll Down']")
       @CacheLookup
       public WebElement scrollDownButton;

       

       
       //update

       
       
       /*public void selectPlanFromResults(String strplanID)
       {
              waitForPageLoad();
              seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(planSearchResults));
                     WebTable tabledetails = new WebTable(planSearchResults, "Plan Search Results");
                     int rowNum = tabledetails.getRowWithCellTextInColumn(1,3,strplanID);
                     if(rowNum>0)
                     {
                           getWebDriver().findElement(By.xpath("//table[starts-with(@id,'DataTables_Table']/tbody/tr["+rowNum+"]/td[2]")).click();;
                     }
                     else
                     {
                           throw new IllegalArgumentException("Not able to find the value"+ strplanID+"in the table");
                     }
       }*/
       
}
