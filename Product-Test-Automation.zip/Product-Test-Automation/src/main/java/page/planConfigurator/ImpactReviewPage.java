package page.planConfigurator;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import utility.CoreSuperHelper;
import utility.WebTable;

public class ImpactReviewPage extends CoreSuperHelper{
	
	private static ImpactReviewPage thisTestObj;	
	public synchronized static ImpactReviewPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), ImpactReviewPage.class);
		return thisTestObj;
	}
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"bulk-impact-sectionWrapper\"]/div/div/div[1]/button")
	@CacheLookup
	public WebElement refresh;
	
	@FindBy(how = How.XPATH, using = "//div[@id='bulk-impact-sectionWrapper']/div/div/div[2]/div/table/thead/tr[2]/td[1]/input")
    @CacheLookup
    public WebElement id;
                               
    @FindBy(how = How.XPATH, using = "//div[@id='bulk-impact-sectionWrapper']/div/div/div[2]/div/table/tbody/tr[1]/td[9]/div/button[@title='Execute']")
    @CacheLookup
    public WebElement execute;
    
    @FindBy(how = How.XPATH, using = "//div[@id='bulk-impact-sectionWrapper']/div/div/div[2]/div/table/tbody/tr[1]/td[9]/div/button[@title='Schedule']")
    @CacheLookup
    public WebElement impactReporttableschedule;
    
    @FindBy(how = How.XPATH, using = "//div[@class='bulk-entries-container']/div/div[2]/div/table/tbody/tr[1]/td[8]/div")
    @CacheLookup
    public WebElement impactReport;
    
    @FindBy(how = How.NAME, using = "scheduleDate")
    @CacheLookup
    public WebElement scheduleDate;
    
    @FindBy(how = How.XPATH, using = "html/body/div[1]/div[1]/div/div[1]/div[8]/div/div/div/div[4]/div/div/div/div/div[2]/span/span[1]/span")
    @CacheLookup
    public WebElement scheduleTime;
    
    @FindBy(how = How.XPATH, using = "//div[@id='bulk-configure-sectionWrapper']/div/div/div[5]/button[contains(text(),'Schedule')]")
    @CacheLookup
    public WebElement schedulebutton;
    
	
	public void seWaitForBulkRepubishImactStatus(String strStatus)
	{
		
		
		ExpectedCondition<Boolean> expectation = new  ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
            	waitForPageLoad();
        		WebTable impactReviewTable = new WebTable(getWebDriver().findElement(By.xpath("//div[@class='bulk-entries-container']/div/div[2]/div/table")), "Impact Review results");
        		String userName=seGetText(HomePage.get().userName).toString().trim();
        		int rowNum = impactReviewTable.getRowWithCellTextInColumn(1, 2, userName);
        		if(rowNum>0)
        		{
        				String completionStatus  =impactReviewTable.getCell(rowNum, 7).getText().toString();
        				if(completionStatus.equalsIgnoreCase(strStatus))
                		{			
                		   return true;
                		}
                		else
                		{
                			ImpactReviewPage.get().refresh.click();
                			return false;
                		}
        		}
        		else
        		{
        			return false;
        		}
        		
        		
            	
            }
        };

        WebDriverWait wait = new WebDriverWait(getWebDriver(), 600);
        wait.pollingEvery(5, TimeUnit.SECONDS);
        wait.until(expectation);
	}
	

}
