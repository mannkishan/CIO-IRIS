package page.planConfigurator;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;


public class HomePage extends CoreSuperHelper{
	
	private static HomePage thisTestObj;	
	public synchronized static HomePage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), HomePage.class);
		return thisTestObj;
	}
	
	//div[@id=\"header-wrapper\"]/ul/li[2]/a
	@FindBy(how = How.LINK_TEXT, using = "Find")
	@CacheLookup
	public WebElement find;
	
	/**
	 * this element is visible only when the find element is clicked
	 */
	@FindBy(how = How.XPATH, using = "//div[@id='header-wrapper']/ul/li[2]/ul/li[1]/a")
	@CacheLookup
	public WebElement findPlan;
	
	@FindBy(how = How.XPATH, using = "//div[@id='header-wrapper']/ul/li[3]/a")
	@CacheLookup
	public WebElement create;
		
	@FindBy(how = How.XPATH, using = "//div[@id='header-wrapper']/ul/li[3]/ul/li/a[@class='create-customPlan']")
	@CacheLookup
	public WebElement plan;
	
	@FindBy(how = How.XPATH, using = "//div[@id='header-wrapper']/ul/li[4]/a")
	@CacheLookup
	public WebElement massUpdate;
	
	@FindBy(how = How.XPATH, using = "//div[@id='header-wrapper']/ul/li[4]/ul/li/a[@class='bulkCreate']")
	@CacheLookup
	public WebElement createNew;
	
	@FindBy(how = How.XPATH, using = "//div[@id='header-wrapper']/ul/li[4]/ul/li[1]/ul/li[1]/a[@class='bulkCreateRepublish']")
	@CacheLookup
	public WebElement bulkRepublish;
	
//	
	
	@FindBy(how = How.LINK_TEXT, using = "Bulk Finalize")
	public WebElement bulkFinalize;
	@FindBy(how = How.XPATH, using = "//div[@id='header-wrapper']/ul/li[4]/ul/li[2]/a") //[@class='Impact']
	@CacheLookup
	public WebElement impact;
	
	@FindBy(how = How.XPATH, using = "//div[@id='header-wrapper']/ul/li[4]/ul/li[3]/a")
	@CacheLookup
	public WebElement history;
	
	
	@FindBy(how = How.XPATH, using = "//div[@id='header-wrapper']/ul/li[2]/ul/li[2]/a")
	@CacheLookup
	public WebElement findTemplate;
		
	@FindBy(how = How.XPATH, using = "//div[@id='header-wrapper']/ul/li[7]/a")
	@CacheLookup
	public WebElement userName;
	
	@FindBy(how = How.XPATH, using = "//div[@id='ApplicationLogo']")
	@CacheLookup
	public WebElement homePageBtn;	
	
	@FindBy(how = How.XPATH, using = "//div[@id='header-wrapper']/ul/li/ul/li/a[text()='History']")
	@CacheLookup
	public WebElement historyLnk;

}
