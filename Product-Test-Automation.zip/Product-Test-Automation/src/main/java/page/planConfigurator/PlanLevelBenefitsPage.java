package page.planConfigurator;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class PlanLevelBenefitsPage extends CoreSuperHelper {

	private static PlanLevelBenefitsPage thisTestObj;

	public synchronized static PlanLevelBenefitsPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), PlanLevelBenefitsPage.class);
		return thisTestObj;

	}

	// This Class contains webelements that are identified in the
	// PlanLevelBenefits Tab

	@FindBy(how = How.XPATH, using = "//*[@id=\"Base\"]/a")
	@CacheLookup
	public WebElement planLevelBenefits;

	@FindBy(how = How.XPATH, using = "//*[@id=\"verticalBarMenuDetails\"]/div/nav/div[2]/ul/li[2]/a")
	// @CacheLookup
	public WebElement deductibleTab;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_Base-_-Deductible-_-Deductible-_-NA-_-NA-_-DedINNT1IndMed_-_indivMax-container\"]")
	@CacheLookup
	public WebElement innIndDedMax;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_Base-_-Deductible-_-Deductible-_-NA-_-NA-_-DedINNT1IndMed_-_indivMax-result-vnpa-5\"]")
	@CacheLookup
	public WebElement innIndDedMaxValue;

	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_Base-_-Deductible-_-Deductible-_-NA\"]/div/div/table/tbody/tr[2]/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement innindDedInput;

	@FindBy(how = How.XPATH, using = "//*[@class=\"select2-match\"]")
	@CacheLookup
	public WebElement innindDedEnter;
	
	
	@FindBy(how = How.ID, using = "POA_Base-_-Penalties-_-WithoutPenalty")
	public WebElement withOutPenalty;
	@FindBy(how = How.ID, using = "POA_Base-_-Penalties-_-WithPenalty")
	public WebElement withPenalty;
	

	
	@FindBy(how = How.XPATH, using = "//*[@attr-ref='UrgentCareFac']")
	// @CacheLookup
	public WebElement urgentCareFacility;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_Base-_-Deductible-_-Deductible-_-NA-_-NA-_-DedINNT1IndMed_-_indivMax-result-3aih-5\"]")
	@CacheLookup
	public WebElement innindDedText;

	@FindBy(how = How.XPATH, using = "//h4[contains(text(),'Deductible')]/following::span[contains(text(),'In Network Individual Deductible')]/following::span[2]")
	@CacheLookup
	public WebElement innindDedfield;

	@FindBy(how = How.XPATH, using = "//h4[contains(text(),'Deductible')]/following::span[contains(text(),'In Network Family Deductible')]/following::span[2]")
	@CacheLookup
	public WebElement innFamDedfield;

	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[2]/td[5]/span/span/span[1]")
	@CacheLookup
	public WebElement innDedFirst;

	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[2]/td[5]/span/span/span[2]")
	@CacheLookup
	public WebElement innDedSecond;

	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[2]/td[5]/span/span/span[2]")
	@CacheLookup
	public WebElement incdnDedSecond;

	@FindBy(how = How.XPATH, using = "//span[substring(@id,string-length(@id) - string-length('Coinsurance-_-Coinsurance-_-NA-_-NA-_-CoinOONMed_-_percentage-container') +1) = 'Coinsurance-_-Coinsurance-_-NA-_-NA-_-CoinOONMed_-_percentage-container']")
	@CacheLookup
	public WebElement outnCoinsurance;

	@FindBy(how = How.XPATH, using = "//span[substring(@id,string-length(@id) - string-length('Coinsurance-_-Coinsurance-_-NA-_-NA-_-CoinOONMed_-_percentage-container') +1) = 'Coinsurance-_-Coinsurance-_-NA-_-NA-_-CoinOONMed_-_percentage-container']/following::input[1]")
	@CacheLookup
	public WebElement outnCoinsuranceText;

	public WebElement accumMaxValue(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//table/tbody/tr/td/div/span[contains(text(),'"+type+"')]"));
		return valueType;
	}

	public WebElement accumMax(String value)
	{
		WebElement valueType=getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenuDetails']/div/nav/div[2]/ul/li/a[@attr-ref='"+value+"']"));
		return valueType;
	}

	@FindBy(how = How.CSS, using = "span[id='POA_Base-_-AdultAnnualMax-_-AdultAnnualMaxOONNotCovered-_-NA-_-NA-_-INNAdultAnnualMax_-_indivMax']")
	@CacheLookup
	public WebElement benefitPeriodMaxValue;

	@FindBy(how = How.CSS, using = "span[id='POA_Base-_-Coinsurance-_-Coinsurance-_-NA-_-NA-_-INNCoin_-_percentage']")	
	@CacheLookup
	public WebElement coinsuranceMaxValue;

	@FindBy(how = How.CSS, using = "span[id='POA_Base-_-UrgentCareAdvancedImaging-_-UrgentCareAdvancedImagingCopayCombinedCopayMax-_-NA-_-NA-_-INNAdvImagingCopayMax_-_indivMax']")
	@CacheLookup
	public WebElement copaymentMaxValue;

	@FindBy(how = How.CSS, using = "span[id='POA_Base-_-Deductible-_-Deductible-_-NA-_-NA-_-DedINNT1IndMed_-_indivMax']")
	@CacheLookup
	public WebElement deductibelMaxValue;

	@FindBy(how = How.CSS, using = "span[id='POA_Base-_-OOP-_-OOP-_-NA-_-NA-_-INNBLACOOPFam_-_indivMax']")
	@CacheLookup
	public WebElement oopMaxValue;

	@FindBy(how = How.CSS, using = "span[id='POA_Base-_-PreAuthPenalty-_-PercentAndDollar-_-NA-_-NA-_-ProfPreAuthPenalty_-_indivMax']")
	@CacheLookup
	public WebElement penalty;

	@FindBy(how = How.CSS, using = "span[id='POA_Base-_-UpfrontDeductible-_-UpfrontDeductible-_-NA-_-NA-_-UpfrntDedINNT1IndMed_-_indivMax']")
	@CacheLookup
	public WebElement upFrontDeductible;

	@FindBy(how = How.CSS, using = "span[id='POA_Base-_-DentalWaitingPeriods-_-DentalWaitingPeriods-_-NA-_-NA-_-AdultBasicWaitingPeriod_-_choice']")
	@CacheLookup
	public WebElement choice;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Family Deductible')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Max')]/following-sibling::div//span[contains(text(), '$')]")
	@CacheLookup
	public WebElement clickInFamDeductible;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Family Deductible')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Max')]/following-sibling::span/span/span[1]/input")
	@CacheLookup
	public WebElement enterInFamDeductible;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Out of Network Family Deductible')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Max')]/following-sibling::div//span[contains(text(), '$')]")
	@CacheLookup
	public WebElement clickOutFamDeductible;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Out of Network Family Deductible')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Max')]/following-sibling::span/span/span[1]/input")
	@CacheLookup
	public WebElement enterOutFamDeductible;

	@FindBy(how = How.XPATH, using = "//span[@class='select2-results']/ul/li[contains(@class,'highlighted')]/span/span")
	@CacheLookup
	public WebElement selectDeductible;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Accumulation Basis Deductible')]/ancestor::tr[1]/td[2]/div//span[contains(@id,'choice-container')]")
	@CacheLookup
	public WebElement clickAccumulationBasisDeductible;

	public WebElement enterAccumulationBasisDeductible(String accumBasis)
	{
		WebElement accumBasisDed = getWebDriver().findElement(By.xpath("//span[contains(text(),'Accumulation Basis Deductible')]/ancestor::tr[1]/td[2]/div//span/ul/li/span[text()='"+accumBasis+"']"));
		return accumBasisDed;
	}

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Deductible Cross Accumulation Rule')]/ancestor::tr[1]/td[2]/div//span[contains(@id,'choice-container')]")
	@CacheLookup
	public WebElement clickDeductibleCrossAccumRule;

	public WebElement enterDeductibleCrossAccumRule(String dedRule)
	{
		WebElement deductibleRule = getWebDriver().findElement(By.xpath("//span[contains(text(),'Deductible Cross Accumulation Rule')]/ancestor::tr[1]/td[2]/div//span/ul/li/span[text()='"+dedRule+"']"));
		return deductibleRule;
	}	

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Accumulation Basis Out of Pocket Maximum')]/ancestor::tr[1]/td[2]/div//span[contains(@id,'choice-container')]")
	@CacheLookup
	public WebElement OOPMaxAccumBasis;


	public WebElement OOPMaxAccumBasisValue(String strAccum)
	{
		WebElement oopMaxAccum = getWebDriver().findElement(By.xpath("//span[contains(text(),'Accumulation Basis Out of Pocket Maximum')]/ancestor::tr[1]/td[2]/div//span/ul/li/span[text()='"+strAccum+"']")); 
		return oopMaxAccum;
	}

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Out of Pocket Maximum Cross Accumulation Rule')]/ancestor::tr[1]/td[2]/div//span[contains(@id,'choice-container')]")
	@CacheLookup
	public WebElement OOPMaxCrossAccumRule;


	public WebElement OOPMaxCrossAccumRuleValue(String strAccum)
	{
		WebElement oopMaxAccum = getWebDriver().findElement(By.xpath("//span[contains(text(),'Out of Pocket Maximum Cross Accumulation Rule')]/ancestor::tr[1]/td[2]/div//span/ul/li/span[text()='"+strAccum+"']")); 
		return oopMaxAccum;
	}
	
	public WebElement penalty(String value)
	{
	       WebElement type=getWebDriver().findElement(By.xpath("//span[contains(text(),'"+value+"')]/ancestor::tr[1]/td[2]/div[2]/div/span[1]/span/span"));
	       return type;
	}

	public WebElement penaltyValue(String value)
	{
	       WebElement type=getWebDriver().findElement(By.xpath("//span[contains(text(),'"+value+"')]/ancestor::tr[1]/td[2]/div[2]/span/span/span/input"));
	       return type;
	}


	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Individual Deductible')]/ancestor::tr[1]/td[3]/span[2]/input")
	@CacheLookup
	public WebElement inNetIndDedOOPMax;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Family Deductible')]/ancestor::tr[1]/td[3]/span[2]/input")
	@CacheLookup
	public WebElement inNetFamDedOOPMax;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Out of Network Individual Deductible')]/ancestor::tr[1]/td[3]/span[2]/input")
	@CacheLookup
	public WebElement outNetIndDedOOPMax;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Out of Network Family Deductible')]/ancestor::tr[1]/td[3]/span[2]/input")
	@CacheLookup
	public WebElement outNetFamDedOOPMax;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Coinsurance')]/ancestor::tr[1]/td[3]/span[2]/input")
	@CacheLookup
	public WebElement inNetCoinsuOOPMax;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Out of Network Coinsurance')]/ancestor::tr[1]/td[3]/span[2]/input")
	@CacheLookup
	public WebElement outNetCoinsuOOPMax;

	/*
	 * @FindBy(how = How.XPATH, using =
	 * "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CopayINNT1UrgentCareFac_-_amount-container\"]")
	 * 
	 * @CacheLookup public WebElement innUrgCareFacCopay;
	 * 
	 * @FindBy(how = How.XPATH, using =
	 * "//*[@id=\"subCollapse2\"]/table/tbody/tr[3]/td[2]/div[2]/span/span/span[1]/input")
	 * 
	 * @CacheLookup public WebElement innUrgCareFacCopayAmount;
	 * 
	 * @FindBy(how = How.XPATH, using =
	 * "//*[@id=\"subCollapse2\"]/table/tbody/tr[3]/td[2]/div[2]/span/span/span[2]")
	 * 
	 * @CacheLookup public WebElement innUrgCareFacCopayEnter;
	 * 
	 * @FindBy(how = How.XPATH, using =
	 * "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CopayINNT1UrgentCareFac_-_amount-container\"]")
	 * 
	 * @CacheLookup public WebElement innUrgCareFacCopayText;
	 * 
	 * @FindBy(how = How.XPATH, using =
	 * "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[1]/td[5]/span/span/span/div[2]/span/span")
	 * 
	 * @CacheLookup public WebElement innUrgCareFacCopayTextBenefit;
	 * 
	 * @FindBy(how = How.XPATH, using =
	 * "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[3]/td[5]/span/span/span/div[2]/span/span[1]/span[1]/span")
	 * 
	 * @CacheLookup public WebElement innUrgCareFacCoinsurTextBenefit;
	 */

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CoinINNT1UrgentCareFac_-_percentage-container\"]")
	@CacheLookup
	public WebElement innUrgCareFacCoinsurText;

	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[1]/td[5]/span/span/span/div[2]/span/span")
	// @CacheLookup
	public WebElement copaymentText;

	// #########################################################################################################################################

	@FindBy(how = How.XPATH, using = "//span[substring(@id,string-length(@id) - string-length('Coinsurance-_-Coinsurance-_-NA-_-NA-_-CoinINNT1Med_-_percentage-container') +1) = 'Coinsurance-_-Coinsurance-_-NA-_-NA-_-CoinINNT1Med_-_percentage-container']")
	@CacheLookup
	public WebElement innCoinsurance;

	@FindBy(how = How.XPATH, using = "//span[substring(@id,string-length(@id) - string-length('Coinsurance-_-Coinsurance-_-NA-_-NA-_-CoinINNT1Med_-_percentage-container') +1) = 'Coinsurance-_-Coinsurance-_-NA-_-NA-_-CoinINNT1Med_-_percentage-container']/following::input[1]")
	@CacheLookup
	public WebElement innCoinsuranceText;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Individual Deductible')]/ancestor::tr[1]/td[2]/div[1]/div[2]/span/span[1]/span/span[1]")
	@CacheLookup
	public WebElement inNetIndDed;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Individual Deductible')]/ancestor::tr[1]/td[2]/div[1]/span/span/span/input")
	@CacheLookup
	public WebElement inNetIndDedValue;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Out of Network Individual Deductible')]/ancestor::tr[1]/td[2]/div[1]/div[2]/span/span[1]/span/span[1]")
	@CacheLookup
	public WebElement outNetIndDed;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Out of Network Individual Deductible')]/ancestor::tr[1]/td[2]/div[1]/span/span/span/input")
	@CacheLookup
	public WebElement outNetIndDedValue;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Family Deductible')]/ancestor::tr[1]/td[2]/div[1]/div[2]/span/span[1]/span/span[1]")
	@CacheLookup
	public WebElement inNetFamDed;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Family Deductible')]/ancestor::tr[1]/td[2]/div[1]/span/span/span/input")
	@CacheLookup
	public WebElement inNetFamDedValue;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Out of Network Family Deductible')]/ancestor::tr[1]/td[2]/div[1]/div[2]/span/span[1]/span/span[1]")
	@CacheLookup
	public WebElement outNetFamDed;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Out of Network Family Deductible')]/ancestor::tr[1]/td[2]/div[1]/span/span/span/input")
	@CacheLookup
	public WebElement outNetFamDedValue;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Tier 1 Network')]/ancestor::tr[1]/td[2]/div/div/span/span/span[1]")
	@CacheLookup
	public WebElement inNetTier1Network;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Tier 2 Network')]/ancestor::tr[1]/td[2]/div/div/span/span/span[1]")
	@CacheLookup
	public WebElement inNetTier2Network;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Tier 3 Network')]/ancestor::tr[1]/td[2]/div/div/span/span/span[1]")
	@CacheLookup
	public WebElement inNetTier3Network;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Tier 1 Network')]/ancestor::tr[1]/td[2]/div[1]/span/span/span/input")
	@CacheLookup
	public WebElement inNetTier1NetworkValue;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Out of Network Network')]/ancestor::tr[1]/td[2]/div/div/span/span/span[1]")
	@CacheLookup
	public WebElement outNetNetwork;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Out of Network Network')]/ancestor::tr[1]/td[2]/div[1]/span/span/span/input")
	@CacheLookup
	public WebElement outNetNetworkValue;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Individual Deductible')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Max')]/following-sibling::div//span[contains(text(), '$')]")
	@CacheLookup
	public WebElement clickInIndDeductible;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Individual Deductible')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Max')]/following-sibling::span/span/span[1]/input")
	@CacheLookup
	public WebElement enterInIndDeductible;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Out of Network Individual Deductible')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Max')]/following-sibling::div//span[contains(text(), '$')]")
	@CacheLookup
	public WebElement clickOutIndDeductible;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Out of Network Individual Deductible')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Max')]/following-sibling::span/span/span[1]/input")
	@CacheLookup
	public WebElement enterOutIndDeductible;


	public static void updateCoinsuranceValue(String strCoinsurance) {
		seClick(PlanLevelBenefitsPage.get().innCoinsurance, "In Network COinsurance");
		seSetText(PlanLevelBenefitsPage.get().innCoinsuranceText, strCoinsurance, "Update Coinsurance value ");
		PlanLevelBenefitsPage.get().innCoinsuranceText.sendKeys(Keys.ENTER);
	}

	public WebElement accumValue(String value)
	{
		WebElement valueType=getWebDriver().findElement(By.xpath("//table/tbody/tr/td/div/span[contains(text(),'"+value+"')]/ancestor::tr[1]/td[2]/div/div/span"));
		return valueType;
	}

	public WebElement accumType(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenuDetails']/div/nav/div[2]/ul/li/a[contains(text()[normalize-space()],'"+type+"')]"));
		return valueType;
	} 

	public  boolean acummDollarMaxComparision(String maximum,int expectedValue,int actualValue)
	{
		boolean result=false;
		try{
			switch (maximum) {
			case "=":
				if(expectedValue==actualValue)
				{
					log(PASS,"Expected Value is equal to actual Value "+expectedValue+"is equal to "+actualValue);
					result=true;
				}
				else
				{
					log(FAIL,"Expected Value is not equal to actual Value "+expectedValue+"is not equal to "+actualValue);
					result=false;
				}
				break;
			case ">":
				if(actualValue>expectedValue)
				{
					log(PASS,"Actual Value is greater than expected Value "+actualValue+"is > "+expectedValue);
					result=true;
				}
				else
				{
					log(FAIL,"Actual Value is not greater than expected Value"+actualValue+"is > "+expectedValue);
					result=false;
				}
				break;
			case "<":
				if(actualValue<expectedValue)
				{
					log(PASS,"Actual Value is less than expected Value"+actualValue+"is < "+expectedValue);
					result=true;
				}
				else
				{
					log(FAIL,"Actual Value is not less than expected Value"+actualValue+"is < "+expectedValue);
					result=false;
				}
				break;
			case ">=":
				if(actualValue>=expectedValue)
				{
					log(PASS,"Actual Value is greater than equal to expected Value"+actualValue+"is >= "+expectedValue);
					result=true;
				}
				else
				{
					log(FAIL,"Actual Value is not greater than equal expected Value"+actualValue+"is < "+expectedValue);
					result=false;
				}
				break;	
			case "<=":
				if(actualValue<=expectedValue)
				{
					log(PASS,"Actual Value is less than equal to expected Value"+actualValue+"is <= "+expectedValue);
					result=true;
				}
				else
				{
					log(FAIL,"Actual Value is not less than equal expected Value"+actualValue+"is < "+expectedValue);
					result=false;
				}
				break;
			default:
				break;	

			}
		}
		catch(Exception e)
		{
			log(ERROR,"Invalid maximum value","Invalid maximum value "+e.getLocalizedMessage());
		}
		return result;

	}

	public boolean verifyBenefitPeriodMax(String accumValue,String expectedValue,int expectedDollarMaxValue,String dollarMax,int intMaxTime)
	{
		boolean result=false;
		String actualValue="";
		String actualDollarMax="";
		int actualDollarMaxValue=0;
		try
		{
			seClick(PlanLevelBenefitsPage.get().planLevelBenefits, "Plan Level Benefits");
			waitForPageLoad(2,intMaxTime);
			Actions actions=new Actions(getWebDriver());
			actions.moveToElement(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).build().perform();
			actualValue=seGetElementValue(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).toString().trim();
			if(expectedValue.equalsIgnoreCase(actualValue))
			{
				log(PASS,"Expected Value "+expectedValue +"is equal to actual Value "+actualValue);				
				actualDollarMax=seGetElementValue(PlanLevelBenefitsPage.get().accumValue(accumValue)).replace("$", "").trim();
				if(actualDollarMax.contains(","))
				{
					actualDollarMax=actualDollarMax.replace(",", "");
				}
				actualDollarMaxValue=Integer.parseInt(actualDollarMax);
				result=PlanLevelBenefitsPage.get().acummDollarMaxComparision(dollarMax, expectedDollarMaxValue, actualDollarMaxValue);
			}
			else
			{
				log(FAIL,"Expected Value "+expectedValue +"is not equal to actual Value "+actualValue);
			}
		}
		catch(Exception e)
		{
			log(FAIL,"Data is incorrect","Data is incorrect"+e.getLocalizedMessage());
		}
		return result;
	}

	public boolean verifyCoinsuranceMax(String accumValue,String expectedValue,String dollarMax,int expectedDollarMaxValue,int intMaxTime)
	{
		boolean result=false;
		String actualValue="";
		String actualDollarMax="";
		int actualDollarMaxValue=0;
		try
		{
			seClick(PlanLevelBenefitsPage.get().planLevelBenefits, "Plan Level Benefits");
			waitForPageLoad(2,intMaxTime);
			Actions actions=new Actions(getWebDriver());
			actions.moveToElement(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).build().perform();			
			actualValue=seGetElementValue(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).toString().trim();
			if(expectedValue.equalsIgnoreCase(actualValue))
			{
				log(PASS,"Expected Value "+expectedValue +"is equal to actual Value "+actualValue);				
				actualDollarMax=seGetElementValue(PlanLevelBenefitsPage.get().accumValue(accumValue)).replace("%","").trim();
				if(actualDollarMax.contains(","))
				{
					actualDollarMax=actualDollarMax.replace(",", "");
				}
				actualDollarMaxValue=Integer.parseInt(actualDollarMax);
				result=PlanLevelBenefitsPage.get().acummDollarMaxComparision(dollarMax, expectedDollarMaxValue, actualDollarMaxValue);
			}       	
			else
			{
				log(FAIL,"Expected Value "+expectedValue +"is not equal to actual Value "+actualValue);
			}
		}
		catch(Exception e)
		{
			log(FAIL,"Data is incorrect","Data is incorrect"+e.getLocalizedMessage());
		}
		return result;
	}

	public boolean verifyCopaymentMax(String accumValue,String expectedValue,String dollarMax,int expectedDollarMaxValue,int intMaxTime)
	{
		boolean result=false;
		String actualValue="";
		String actualDollarMax="";
		int actualDollarMaxValue=0;
		try
		{
			seClick(PlanLevelBenefitsPage.get().planLevelBenefits, "Plan Level Benefits");
			waitForPageLoad(2,intMaxTime);
			Actions actions=new Actions(getWebDriver());
			actions.moveToElement(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).build().perform();		
			actualValue=seGetElementValue(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).toString().trim();
			if(expectedValue.equalsIgnoreCase(actualValue))
			{
				log(PASS,"Expected Value "+expectedValue +"is equal to actual Value "+actualValue);				
				actualDollarMax=seGetElementValue(PlanLevelBenefitsPage.get().accumValue(accumValue)).replace("$", "").trim();
				if(actualDollarMax.contains(","))
				{
					actualDollarMax=actualDollarMax.replace(",", "");
				}
				actualDollarMaxValue=Integer.parseInt(actualDollarMax);
				result=PlanLevelBenefitsPage.get().acummDollarMaxComparision(dollarMax, expectedDollarMaxValue, actualDollarMaxValue);
			}       	
			else
			{
				log(FAIL,"Expected Value "+expectedValue +"is not equal to actual Value "+actualValue);
			}
		}
		catch(Exception e)
		{
			log(FAIL,"Data is incorrect","Data is incorrect"+e.getLocalizedMessage());
		}
		return result;
	}

	public static void updateCoinsuranceValue(String strCoinsurance,String strCoinsuranceType) {
		if(strCoinsuranceType.equalsIgnoreCase("InNetwork"))
		{
			seClick(PlanLevelBenefitsPage.get().innCoinsurance, "In Network COinsurance");
			seSetText(PlanLevelBenefitsPage.get().innCoinsuranceText, strCoinsurance, "Update Coinsurance value ");
			PlanLevelBenefitsPage.get().innCoinsuranceText.sendKeys(Keys.ENTER);
			waitForPageLoad(300);			
		}
		else
		{
			seClick(PlanLevelBenefitsPage.get().outnCoinsurance, "Out of Network COinsurance");
			seSetText(PlanLevelBenefitsPage.get().outnCoinsuranceText, strCoinsurance, "Update Coinsurance value ");
			PlanLevelBenefitsPage.get().outnCoinsuranceText.sendKeys(Keys.ENTER);
		}
	}

	public boolean verifyDeductibleMax(String accumValue,String expectedValue,String dollarMax,int expectedDollarMaxValue,int intMaxTime)
	{
		boolean result=false;
		String actualValue="";
		String actualDollarMax="";
		int actualDollarMaxValue=0;
		try
		{
			seClick(PlanLevelBenefitsPage.get().planLevelBenefits, "Plan Level Benefits");
			waitForPageLoad(2,intMaxTime);
			Actions actions=new Actions(getWebDriver());
			actions.moveToElement(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).build().perform();	
			actualValue=seGetElementValue(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).toString().trim();
			if(expectedValue.equalsIgnoreCase(actualValue))
			{
				log(PASS,"Expected Value "+expectedValue +"is equal to actual Value "+actualValue);				
				actualDollarMax=seGetElementValue(PlanLevelBenefitsPage.get().accumValue(accumValue)).replace("$", "").trim();
				if(actualDollarMax.contains(","))
				{
					actualDollarMax=actualDollarMax.replace(",", "");
				}
				actualDollarMaxValue=Integer.parseInt(actualDollarMax);
				result=PlanLevelBenefitsPage.get().acummDollarMaxComparision(dollarMax, expectedDollarMaxValue, actualDollarMaxValue);
			}       	
			else
			{
				log(FAIL,"Expected Value "+expectedValue +"is not equal to actual Value "+actualValue);
			}
		}
		catch(Exception e)
		{
			log(FAIL,"Data is incorrect","Data is incorrect"+e.getLocalizedMessage());
		}
		return result;
	}

	public boolean verifyOutOfPocketMax(String accumValue,String expectedValue,String dollarMax,int expectedDollarMaxValue,int intMaxTime)
	{
		boolean result=false;
		String actualValue="";
		String actualDollarMax="";
		int actualDollarMaxValue=0;
		try
		{
			seClick(PlanLevelBenefitsPage.get().planLevelBenefits, "Plan Level Benefits");
			waitForPageLoad(2,intMaxTime);
			Actions actions=new Actions(getWebDriver());
			actions.moveToElement(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).build().perform();		
			actualValue=seGetElementValue(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).toString().trim();
			if(expectedValue.equalsIgnoreCase(actualValue))
			{
				log(PASS,"Expected Value "+expectedValue +"is equal to actual Value "+actualValue);				
				actualDollarMax=seGetElementValue(PlanLevelBenefitsPage.get().accumValue(accumValue)).replace("$", "").trim();
				if(actualDollarMax.contains(","))
				{
					actualDollarMax=actualDollarMax.replace(",", "");
				}
				actualDollarMaxValue=Integer.parseInt(actualDollarMax);
				result=PlanLevelBenefitsPage.get().acummDollarMaxComparision(dollarMax, expectedDollarMaxValue, actualDollarMaxValue);
			}       	
			else
			{
				log(FAIL,"Expected Value "+expectedValue +"is not equal to actual Value "+actualValue);
			}
		}
		catch(Exception e)
		{
			log(FAIL,"Data is incorrect","Data is incorrect"+e.getLocalizedMessage());
		}
		return result;
	}

	public boolean verifyPenalty(String accumValue,String expectedValue,String dollarMax,int expectedDollarMaxValue,int intMaxTime)
	{
		boolean result=false;
		String actualValue="";
		String actualDollarMax="";
		int actualDollarMaxValue=0;
		try
		{
			seClick(PlanLevelBenefitsPage.get().planLevelBenefits, "Plan Level Benefits");
			waitForPageLoad(2,intMaxTime);
			Actions actions=new Actions(getWebDriver());
			actions.moveToElement(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).build().perform();			
			actualValue=seGetElementValue(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).toString().trim();
			if(expectedValue.equalsIgnoreCase(actualValue))
			{
				log(PASS,"Expected Value "+expectedValue +"is equal to actual Value "+actualValue);				
				actualDollarMax=seGetElementValue(PlanLevelBenefitsPage.get().accumValue(accumValue)).replace("$", "").trim();
				if(actualDollarMax.contains(","))
				{
					actualDollarMax=actualDollarMax.replace(",", "");
				}
				actualDollarMaxValue=Integer.parseInt(actualDollarMax);
				result=PlanLevelBenefitsPage.get().acummDollarMaxComparision(dollarMax, expectedDollarMaxValue, actualDollarMaxValue);
			}       	
			else
			{
				log(FAIL,"Expected Value "+expectedValue +"is not equal to actual Value "+actualValue);
			}
		}
		catch(Exception e)
		{
			log(FAIL,"Data is incorrect","Data is incorrect"+e.getLocalizedMessage());
		}
		return result;
	}

	public boolean EnterPenaltyDetails(String InNetworkInstPercnt,String InNetworkInstDollar,String OutNetworkInstPercnt,String OutNetworkInstDollar,String InNetworkProfPercnt,String InNetworkProfDollar,String OutNetworkProfPercnt,String OutNetworkProfDollar,int intMaxWaitTime)
	{
		boolean result=false;
		try
		{
			sePCSelectText(PlanLevelBenefitsPage.get().InNetworkInstPercnt, "In Network Institutional Pre Authorization", InNetworkInstPercnt, intMaxWaitTime);
				waitForPageLoad(intMaxWaitTime);
			sePCSelectText(PlanLevelBenefitsPage.get().InNetworkInstDollar, "In Network Institutional Pre Authorization Indv Max", InNetworkInstDollar, intMaxWaitTime);
				waitForPageLoad(intMaxWaitTime);
			sePCSelectText(PlanLevelBenefitsPage.get().OutOfNetworkInstPercent, "Out of Network Institutional Pre Authorization Penalty Percent", OutNetworkInstPercnt, intMaxWaitTime);
				waitForPageLoad(intMaxWaitTime);
			sePCSelectText(PlanLevelBenefitsPage.get().OutOfNetworkInstDollar, "Out of Network Institutional Pre Authorization Penalty Dollar", OutNetworkInstDollar, intMaxWaitTime);
				waitForPageLoad(intMaxWaitTime);
			sePCSelectText(PlanLevelBenefitsPage.get().InNetworkProfPercnt, "In Network Professional Pre Authorization Penalty Percent", InNetworkProfPercnt, intMaxWaitTime);
				waitForPageLoad(intMaxWaitTime);
			sePCSelectText(PlanLevelBenefitsPage.get().InNetworkProfDollar, "In Network Professional Pre Authorization Penalty Dollar", InNetworkProfDollar, intMaxWaitTime);
				waitForPageLoad(intMaxWaitTime);
			sePCSelectText(PlanLevelBenefitsPage.get().OutOfNetworkProfPercent, "Out of Network Professional Pre Authorization Penalty Percent", OutNetworkProfPercnt, intMaxWaitTime);
				waitForPageLoad(intMaxWaitTime);
			sePCSelectText(PlanLevelBenefitsPage.get().OutOfNetworkProfDollar, "Out of Network Professional Pre Authorization Penalty Dollar", OutNetworkProfDollar, intMaxWaitTime);
				waitForPageLoad(intMaxWaitTime);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			log(FAIL,"Enter penalty details","Failed to enter the details");
		}
		return result;
	}

	@FindBy(how = How.ID, using = "select2-POA_Base-_-Penalties-_-WithPenalty-_-NA-_-NA-_-PenPreAuthINNT1Inst_-_percentage-container")
	public WebElement InNetworkInstPercnt;

	@FindBy(how = How.ID, using = "select2-POA_Base-_-Penalties-_-WithPenalty-_-NA-_-NA-_-PenPreAuthINNT1Inst_-_indivMax-container")
	public WebElement InNetworkInstDollar;

	@FindBy(how = How.ID, using = "select2-POA_Base-_-Penalties-_-WithPenalty-_-NA-_-NA-_-PenPreAuthOONInst_-_percentage-container")
	public WebElement OutOfNetworkInstPercent;

	@FindBy(how = How.ID, using = "select2-POA_Base-_-Penalties-_-WithPenalty-_-NA-_-NA-_-PenPreAuthOONInst_-_indivMax-container")
	public WebElement OutOfNetworkInstDollar;

	@FindBy(how = How.ID, using = "select2-POA_Base-_-Penalties-_-WithPenalty-_-NA-_-NA-_-PenPreAuthINNT1Prof_-_percentage-container")
	public WebElement InNetworkProfPercnt;

	@FindBy(how = How.ID, using = "select2-POA_Base-_-Penalties-_-WithPenalty-_-NA-_-NA-_-PenPreAuthINNT1Prof_-_indivMax-container")
	public WebElement InNetworkProfDollar;

	@FindBy(how = How.ID, using = "select2-POA_Base-_-Penalties-_-WithPenalty-_-NA-_-NA-_-PenPreAuthOONProf_-_percentage-container")
	public WebElement OutOfNetworkProfPercent;

	@FindBy(how = How.ID, using = "select2-POA_Base-_-Penalties-_-WithPenalty-_-NA-_-NA-_-PenPreAuthOONProf_-_indivMax-container")
	public WebElement OutOfNetworkProfDollar;

	@FindBy(how = How.XPATH, using = ".//*[@id='POA_Base-_-Penalties-_-WithPenalty-_-NA']/div/div/table/tbody/tr[1]/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement InNetworkInstPercntTextBox;

	@FindBy(how = How.XPATH, using = ".//*[@id='POA_Base-_-Penalties-_-WithPenalty-_-NA']/div/div/table/tbody/tr[1]/td[2]/div[2]/span/span/span[1]/input")
	@CacheLookup
	public WebElement InNetworkInstDollarTextBox;

	@FindBy(how = How.XPATH, using = ".//*[@id='POA_Base-_-Penalties-_-WithPenalty-_-NA']/div/div/table/tbody/tr[2]/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement OutOfNetworkInstPercentTextBox;

	@FindBy(how = How.XPATH, using = ".//*[@id='POA_Base-_-Penalties-_-WithPenalty-_-NA']/div/div/table/tbody/tr[2]/td[2]/div[2]/span/span/span[1]/input")
	@CacheLookup
	public WebElement OutOfNetworkInstDollarTextBox;

	@FindBy(how = How.XPATH, using = ".//*[@id='POA_Base-_-Penalties-_-WithPenalty-_-NA']/div/div/table/tbody/tr[3]/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement InNetworkProfPercntTextBox;

	@FindBy(how = How.XPATH, using = ".//*[@id='POA_Base-_-Penalties-_-WithPenalty-_-NA']/div/div/table/tbody/tr[3]/td[2]/div[2]/span/span/span[1]/input")
	@CacheLookup
	public WebElement InNetworkProfDollarTextBox;

	@FindBy(how = How.XPATH, using = ".//*[@id='POA_Base-_-Penalties-_-WithPenalty-_-NA']/div/div/table/tbody/tr[4]/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement OutOfNetworkProfPercentTextBox;

	@FindBy(how = How.XPATH, using = ".//*[@id='POA_Base-_-Penalties-_-WithPenalty-_-NA']/div/div/table/tbody/tr[4]/td[2]/div[2]/span/span/span[1]/input")
	@CacheLookup
	public WebElement OutOfNetworkProfDollarTextBox;

	@FindBy(how = How.CSS, using = ".select2-results__option.select2-results__option--highlighted>span>span")
	@CacheLookup
	public WebElement valueToBeSelected;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Up Front Deductible Individual')]/ancestor::tr[1]/td[2]/div[1]/div[2]/span/span[1]/span/span[1]")
	@CacheLookup
	public WebElement inNetUPFrontIndDed;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Up Front Deductible Individual')]/ancestor::tr[1]/td[2]/div[1]/span/span/span/input")
	@CacheLookup
	public WebElement inNetUpFrontIndDedValue;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Accumulation Basis Up Front Deductible')]/ancestor::tr[1]/td[2]/div//span[contains(@id,'choice-container')]")
	@CacheLookup
	public WebElement upFronAccumBasis;

	public WebElement upFrontAccumBasisValue(String strAccum)
	{
		WebElement oopMaxAccum = getWebDriver().findElement(By.xpath("//span[contains(text(),'Accumulation Basis Up Front Deductible')]/ancestor::tr[1]/td[2]/div//span/ul/li/span[text()='"+strAccum+"']")); 
		return oopMaxAccum;
	}


	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Upfront Deductible Cross Accumulation Rule')]/ancestor::tr[1]/td[2]/div//span[contains(@id,'choice-container')]")
	@CacheLookup
	public WebElement upFrontCrossAccumRule;

	public WebElement upFrontCrossAccumRuleValue(String strAccum)
	{
		WebElement oopMaxAccum = getWebDriver().findElement(By.xpath("//span[contains(text(),'Upfront Deductible Cross Accumulation Rule')]/ancestor::tr[1]/td[2]/div//span/ul/li/span[text()='"+strAccum+"']")); 
		return oopMaxAccum;
	}


	public boolean verifyUpFrontDeductible(String accumValue,String expectedValue,String dollarMax,int expectedDollarMaxValue,int intMaxTime)
	{
		boolean result=false;
		String actualValue="";
		String actualDollarMax="";
		int actualDollarMaxValue=0;
		try
		{
			seClick(PlanLevelBenefitsPage.get().planLevelBenefits, "Plan Level Benefits");
			waitForPageLoad(2,intMaxTime);
			Actions actions=new Actions(getWebDriver());
			actions.moveToElement(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).build().perform();			
			actualValue=seGetElementValue(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).toString().trim();
			if(expectedValue.equalsIgnoreCase(actualValue))
			{
				log(PASS,"Expected Value "+expectedValue +"is equal to actual Value "+actualValue);				
				actualDollarMax=seGetElementValue(PlanLevelBenefitsPage.get().accumValue(accumValue)).replace("$", "").trim();
				if(actualDollarMax.contains(","))
				{
					actualDollarMax=actualDollarMax.replace(",", "");
				}
				actualDollarMaxValue=Integer.parseInt(actualDollarMax);
				result=PlanLevelBenefitsPage.get().acummDollarMaxComparision(dollarMax, expectedDollarMaxValue, actualDollarMaxValue);
			}       	
			else
			{
				log(FAIL,"Expected Value "+expectedValue +"is not equal to actual Value "+actualValue);
			}
		}
		catch(Exception e)
		{
			log(FAIL,"Data is incorrect","Data is incorrect"+e.getLocalizedMessage());
		}
		return result;
	}

	public boolean verifyChoice(String accumValue,String expectedValue,String expectedDollarMaxValue,int intMaxTime)
	{
		boolean result=false;
		String actualValue="";
		String actualDollarMaxValue="";
		try
		{
			waitForPageLoad(2,intMaxTime);
			Actions actions=new Actions(getWebDriver());
			actions.moveToElement(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).build().perform();		
			actualValue=seGetElementValue(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).toString().trim();
			if(expectedValue.equalsIgnoreCase(actualValue))
			{
				log(PASS,"Expected Value "+expectedValue +"is equal to actual Value "+actualValue);				
				actualDollarMaxValue=seGetElementValue(PlanLevelBenefitsPage.get().accumValue(accumValue)).toString().trim();
				if(expectedDollarMaxValue.equalsIgnoreCase(actualDollarMaxValue))
				{
					result=true;
					log(PASS,"Expected value is equal to actual value","Expected Value "+expectedDollarMaxValue+"is equal to "+actualDollarMaxValue);
				}
				else
				{
					result=false;
					log(PASS,"Expected value is not equal to actual value","Expected Value "+expectedDollarMaxValue+"is not equal to "+actualDollarMaxValue);
				}
			}       	
			else
			{
				log(FAIL,"Expected Value "+expectedValue +"is not equal to actual Value "+actualValue);
			}
		}
		catch(Exception e)
		{
			log(FAIL,"Data is incorrect","Data is incorrect"+e.getLocalizedMessage());
		}
		return result;
	}

	public static void updateOONCoinsuranceValue(String strCoinsurance) {
		seClick(PlanLevelBenefitsPage.get().outnCoinsurance, "Out of Network COinsurance");
		seSetText(PlanLevelBenefitsPage.get().outnCoinsuranceText, strCoinsurance, "Update Coinsurance value ");
		PlanLevelBenefitsPage.get().outnCoinsuranceText.sendKeys(Keys.ENTER);
	}

	public void updateOOPMaxDetails(int intMaxWaitTime,String strAccumBasisValue,String strCrossAccumRuleValue,String strPlanType) throws Exception
	{
		try
		{
			PlanOptionsPage.clickTab("Plan Level Benefits", "Out of Pocket Maximum", intMaxWaitTime);
			if(strPlanType.equalsIgnoreCase("PPO") || strPlanType.equalsIgnoreCase("POS"))
			{
				seClick(PlanLevelBenefitsPage.get().OOPMaxAccumBasis,"Accum Basis");
				waitForPageLoad(5,intMaxWaitTime);
				seClick(PlanLevelBenefitsPage.get().OOPMaxAccumBasisValue(strAccumBasisValue),"Accum Basis Value");
				waitForPageLoad(5,intMaxWaitTime);
				seClick(PlanLevelBenefitsPage.get().OOPMaxCrossAccumRule,"Cross Accum Rule");
				waitForPageLoad(5,intMaxWaitTime);
				seClick(PlanLevelBenefitsPage.get().OOPMaxCrossAccumRuleValue(strCrossAccumRuleValue),"Cross Accum Rule Value");
				waitForPageLoad(5,intMaxWaitTime);
			}
			else
			{
				seClick(PlanLevelBenefitsPage.get().OOPMaxAccumBasis,"Accum Basis");
				waitForPageLoad(2,intMaxWaitTime);
				seClick(PlanLevelBenefitsPage.get().OOPMaxAccumBasisValue(strAccumBasisValue),"Accum Basis Value");
				waitForPageLoad(2,intMaxWaitTime);
			}
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	public void updateDeductibleMax(int intMaxWaitTime,String strAppliesToOOP,String strDedType,String strDedINNValue,String strDedOONValue,String strPlanType,boolean strDedAccumApplies) throws Exception
	{	
		try
		{
			PlanOptionsPage.clickTab("Plan Level Benefits", "Deductible", intMaxWaitTime);
			if(strPlanType.equalsIgnoreCase("PPO") || strPlanType.equalsIgnoreCase("POS"))
			{
				if(strDedType.equalsIgnoreCase("Individual")){				
					seClick(PlanLevelBenefitsPage.get().inNetIndDed, "In Network deductible");
					waitForPageLoad(intMaxWaitTime);
					seSetText(PlanLevelBenefitsPage.get().inNetIndDedValue, strDedINNValue, "Update deductible value ");
					waitForPageLoad(intMaxWaitTime);
					seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
					waitForPageLoad(5,intMaxWaitTime);
					waitForPageLoad(intMaxWaitTime);
					seClick(PlanLevelBenefitsPage.get().outNetIndDed, "Out of Network COinsurance");
					waitForPageLoad(intMaxWaitTime);
					seSetText(PlanLevelBenefitsPage.get().outNetIndDedValue, strDedOONValue, "Update deductible value ");
					waitForPageLoad(intMaxWaitTime);
					seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
					waitForPageLoad(5,intMaxWaitTime);
					if(strDedAccumApplies==true)
					{
						waitForPageLoad(5,intMaxWaitTime);
						waitForPageLoad(intMaxWaitTime);
						seClick(PlanLevelBenefitsPage.get().clickAccumulationBasisDeductible, "Accumulation Basis Deductible");
						waitForPageLoad(5,intMaxWaitTime);
						seClick(PlanLevelBenefitsPage.get().enterAccumulationBasisDeductible(getCellValue("AccumBasisRule")), "Accumulation Basis Deductible as "+getCellValue("AccumBasisRule"));
						waitForPageLoad(5,intMaxWaitTime);						
						seClick(PlanLevelBenefitsPage.get().clickDeductibleCrossAccumRule, "Deductible Cross Accumulation Rule");
						waitForPageLoad(5,intMaxWaitTime);
						seClick(PlanLevelBenefitsPage.get().enterDeductibleCrossAccumRule(getCellValue("CrossAccumRule")), "Deductible Cross Accumulation Rule as "+getCellValue("CrossAccumRule"));
						waitForPageLoad(5,intMaxWaitTime);
					}
					if(strAppliesToOOP.equalsIgnoreCase("Yes"))
					{
						if(!PlanLevelBenefitsPage.get().inNetIndDedOOPMax.isSelected())
							seClick(PlanLevelBenefitsPage.get().inNetIndDedOOPMax,"In Network Individual Deductible OOP checkbox");
						waitForPageLoad(intMaxWaitTime);
						if(!PlanLevelBenefitsPage.get().outNetIndDedOOPMax.isSelected())
							seClick(PlanLevelBenefitsPage.get().outNetIndDedOOPMax,"Out of Network Individual Deductible OOP checkbox");
						waitForPageLoad(intMaxWaitTime);

					}
					else
					{
						if(PlanLevelBenefitsPage.get().inNetIndDedOOPMax.isSelected())
							seClick(PlanLevelBenefitsPage.get().inNetIndDedOOPMax,"In Network Individual Deductible OOP checkbox");
						waitForPageLoad(intMaxWaitTime);
						if(PlanLevelBenefitsPage.get().outNetIndDedOOPMax.isSelected())
							seClick(PlanLevelBenefitsPage.get().outNetIndDedOOPMax,"Out of Network Individual Deductible OOP checkbox");
						waitForPageLoad(intMaxWaitTime);
					}					
				}
				else
				{
					seClick(PlanLevelBenefitsPage.get().inNetFamDed, "In Network Coinsurance");
					waitForPageLoad(intMaxWaitTime);
					seSetText(PlanLevelBenefitsPage.get().inNetFamDedValue, strDedINNValue, "Update deductible value ");
					waitForPageLoad(intMaxWaitTime);
					seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
					waitForPageLoad(intMaxWaitTime);			
					seClick(PlanLevelBenefitsPage.get().outNetFamDed, "Out of Network COinsurance");
					waitForPageLoad(intMaxWaitTime);
					seSetText(PlanLevelBenefitsPage.get().outNetFamDedValue, strDedOONValue, "Update deductible value ");
					waitForPageLoad(intMaxWaitTime);
					seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
					waitForPageLoad(intMaxWaitTime);					
					if(strAppliesToOOP.equalsIgnoreCase("Yes"))
					{
						if(!PlanLevelBenefitsPage.get().inNetFamDedOOPMax.isSelected())
							seClick(PlanLevelBenefitsPage.get().inNetFamDedOOPMax,"In Network Family Deductible OOP checkbox");
						waitForPageLoad(intMaxWaitTime);
						if(!PlanLevelBenefitsPage.get().outNetFamDedOOPMax.isSelected())
							seClick(PlanLevelBenefitsPage.get().outNetFamDedOOPMax,"Out of Network Family Deductible OOP checkbox");
						waitForPageLoad(intMaxWaitTime);
					}
					else
					{
						if(PlanLevelBenefitsPage.get().inNetFamDedOOPMax.isSelected())
							seClick(PlanLevelBenefitsPage.get().inNetFamDedOOPMax,"In Network Family Deductible OOP checkbox");
						waitForPageLoad(intMaxWaitTime);
						if(PlanLevelBenefitsPage.get().outNetFamDedOOPMax.isSelected())
							seClick(PlanLevelBenefitsPage.get().outNetFamDedOOPMax,"Out of Network Family Deductible OOP checkbox");
						waitForPageLoad(intMaxWaitTime);
					}
					if(strDedAccumApplies==true)
					{				
						seClick(PlanLevelBenefitsPage.get().clickAccumulationBasisDeductible, "Accumulation Basis Deductible");
						waitForPageLoad(intMaxWaitTime);
						seClick(PlanLevelBenefitsPage.get().enterAccumulationBasisDeductible(getCellValue("AccumBasisRule")), "Accumulation Basis Deductible as "+getCellValue("AccumBasisRule"));
						waitForPageLoad(intMaxWaitTime);
						seClick(PlanLevelBenefitsPage.get().clickDeductibleCrossAccumRule, "Deductible Cross Accumulation Rule");
						waitForPageLoad(intMaxWaitTime);
						seClick(PlanLevelBenefitsPage.get().enterDeductibleCrossAccumRule(getCellValue("CrossAccumRule")), "Deductible Cross Accumulation Rule as "+getCellValue("CrossAccumRule"));
						waitForPageLoad(intMaxWaitTime);
					}
				}	
			}

			else
			{
				if(strDedType.equalsIgnoreCase("Individual")){	
					waitForPageLoad(2,intMaxWaitTime);
					seClick(PlanLevelBenefitsPage.get().inNetIndDed, "In Network deductible");
					waitForPageLoad(2,intMaxWaitTime);
					seSetText(PlanLevelBenefitsPage.get().inNetIndDedValue, strDedINNValue, "Update deductible value ");
					waitForPageLoad(2,intMaxWaitTime);
					seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
					waitForPageLoad(2,intMaxWaitTime);
					waitForPageLoad(intMaxWaitTime);
					if(strDedINNValue.equalsIgnoreCase("N"))
					{
						updateDeductibleMax(intMaxWaitTime,strAppliesToOOP , "Family",strDedINNValue,strDedOONValue,strPlanType,strDedAccumApplies);
					}
					if(strDedAccumApplies==true)
					{	
						waitForPageLoad(2,intMaxWaitTime);
						seClick(PlanLevelBenefitsPage.get().clickAccumulationBasisDeductible, "Accumulation Basis Deductible");
						waitForPageLoad(2,intMaxWaitTime);
						seClick(PlanLevelBenefitsPage.get().enterAccumulationBasisDeductible(getCellValue("AccumBasisRule")), "Accumulation Basis Deductible as "+getCellValue("AccumBasisRule"));
						waitForPageLoad(2,intMaxWaitTime);
					}
					if(strAppliesToOOP.equalsIgnoreCase("Yes"))
					{
						if(!PlanLevelBenefitsPage.get().inNetIndDedOOPMax.isSelected())
							seClick(PlanLevelBenefitsPage.get().inNetIndDedOOPMax,"In Network Individual Deductible OOP checkbox");
						waitForPageLoad(intMaxWaitTime);					
					}
					else
					{
						if(PlanLevelBenefitsPage.get().inNetIndDedOOPMax.isSelected())
							seClick(PlanLevelBenefitsPage.get().inNetIndDedOOPMax,"In Network Individual Deductible OOP checkbox");
						waitForPageLoad(intMaxWaitTime);
					}
					
				}
				else
				{
					seClick(PlanLevelBenefitsPage.get().inNetFamDed, "In Network Coinsurance");
					waitForPageLoad(intMaxWaitTime);
					seSetText(PlanLevelBenefitsPage.get().inNetFamDedValue, strDedINNValue, "Update deductible value ");
					waitForPageLoad(intMaxWaitTime);
					seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
					waitForPageLoad(intMaxWaitTime);
					if(strDedAccumApplies==true)
					{				
						seClick(PlanLevelBenefitsPage.get().clickAccumulationBasisDeductible, "Accumulation Basis Deductible");
						waitForPageLoad(intMaxWaitTime);
						seClick(PlanLevelBenefitsPage.get().enterAccumulationBasisDeductible(getCellValue("AccumBasisRule")), "Accumulation Basis Deductible as "+getCellValue("AccumBasisRule"));
						waitForPageLoad(intMaxWaitTime);
					}
					if(strAppliesToOOP.equalsIgnoreCase("Yes"))
					{
						if(!PlanLevelBenefitsPage.get().inNetFamDedOOPMax.isSelected())
							seClick(PlanLevelBenefitsPage.get().inNetFamDedOOPMax,"In Network Family Deductible OOP checkbox");
						waitForPageLoad(intMaxWaitTime);
					}
					else
					{
						if(PlanLevelBenefitsPage.get().inNetFamDedOOPMax.isSelected())
							seClick(PlanLevelBenefitsPage.get().inNetFamDedOOPMax,"In Network Family Deductible OOP checkbox");
						waitForPageLoad(intMaxWaitTime);
					}
					
				}	
			}			
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	public void updateCoinsuranceMax(int intMaxWaitTime,String strCoinsuranceAppliesToOOP,String strCoinsuranceINNValue,String strCoinsuranceOONValue,String strPlanType)throws Exception
	{
		try
		{
			PlanOptionsPage.clickTab("Plan Level Benefits", "Coinsurance", intMaxWaitTime);
			if(strPlanType.equalsIgnoreCase("PPO") || strPlanType.equalsIgnoreCase("POS"))
			{
				seClick(PlanLevelBenefitsPage.get().innCoinsurance, "In Network COinsurance");
				waitForPageLoad(intMaxWaitTime);
				seSetText(PlanLevelBenefitsPage.get().innCoinsuranceText, strCoinsuranceINNValue, "Update Coinsurance value ");
				waitForPageLoad(intMaxWaitTime);
				seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
				waitForPageLoad(intMaxWaitTime);			
				seClick(PlanLevelBenefitsPage.get().outnCoinsurance, "Out of Network COinsurance");
				waitForPageLoad(intMaxWaitTime);
				seSetText(PlanLevelBenefitsPage.get().outnCoinsuranceText, strCoinsuranceOONValue, "Update Coinsurance value ");
				waitForPageLoad(intMaxWaitTime);
				seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");			
				if(strCoinsuranceAppliesToOOP.equalsIgnoreCase("Yes"))
				{
					if(!PlanLevelBenefitsPage.get().inNetCoinsuOOPMax.isSelected())
						seClick(PlanLevelBenefitsPage.get().inNetCoinsuOOPMax, "OOP Max");
					waitForPageLoad(intMaxWaitTime);
					if(!PlanLevelBenefitsPage.get().outNetCoinsuOOPMax.isSelected())
						seClick(PlanLevelBenefitsPage.get().outNetCoinsuOOPMax, "OOP Max");
					waitForPageLoad(intMaxWaitTime);					
				}
				else
				{
					if(PlanLevelBenefitsPage.get().inNetCoinsuOOPMax.isSelected())
						seClick(PlanLevelBenefitsPage.get().inNetCoinsuOOPMax, "OOP Max");
					waitForPageLoad(intMaxWaitTime);
					if(PlanLevelBenefitsPage.get().outNetCoinsuOOPMax.isSelected())
						seClick(PlanLevelBenefitsPage.get().outNetCoinsuOOPMax, "OOP Max");
					waitForPageLoad(intMaxWaitTime);
				}
			}
			else
			{
				seClick(PlanLevelBenefitsPage.get().innCoinsurance, "In Network COinsurance");
				waitForPageLoad(intMaxWaitTime);
				seSetText(PlanLevelBenefitsPage.get().innCoinsuranceText, strCoinsuranceINNValue, "Update Coinsurance value ");
				waitForPageLoad(intMaxWaitTime);
				seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
				waitForPageLoad(intMaxWaitTime);						
				if(strCoinsuranceAppliesToOOP.equalsIgnoreCase("Yes"))
				{
					if(!PlanLevelBenefitsPage.get().inNetCoinsuOOPMax.isSelected())
						seClick(PlanLevelBenefitsPage.get().inNetCoinsuOOPMax, "OOP Max");
					waitForPageLoad(intMaxWaitTime);				
				}
				else
				{
					if(PlanLevelBenefitsPage.get().inNetCoinsuOOPMax.isSelected())
						seClick(PlanLevelBenefitsPage.get().inNetCoinsuOOPMax, "OOP Max");
					waitForPageLoad(intMaxWaitTime);
				}
			}
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	public void updatePlanTierSetUp(int intMaxWaitTime,String strINNValue,String strOONValue) throws Exception
	{
		try
		{
			PlanOptionsPage.clickTab("Plan Setup", "Plan Tier Setup", intMaxWaitTime);
			seClick(PlanLevelBenefitsPage.get().inNetTier1Network, "In Network COinsurance");
			waitForPageLoad(intMaxWaitTime);
			seSetText(PlanLevelBenefitsPage.get().inNetTier1NetworkValue, strINNValue, "Update Tier1 network value ");
			waitForPageLoad(intMaxWaitTime);
			seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
			waitForPageLoad(intMaxWaitTime);
			seClick(PlanLevelBenefitsPage.get().outNetNetwork, "In Network COinsurance");
			waitForPageLoad(intMaxWaitTime);
			seSetText(PlanLevelBenefitsPage.get().outNetNetworkValue, strOONValue, "Update out of network value ");
			waitForPageLoad(intMaxWaitTime);
			seClick(PlanOptionsPage.get().valueToBeSelected,"Accumulator Value");
			waitForPageLoad(intMaxWaitTime);

		}
		catch(Exception e)
		{
			throw e;
		}
	}	
	
	
	public void enablePenalty(String strIsPenaltyEnabled) throws Exception
	{
		try
		{
			if(strIsPenaltyEnabled.equalsIgnoreCase("YES"))
			{
				if(!PlanLevelBenefitsPage.get().withPenalty.isSelected())
				{
					seClick(PlanLevelBenefitsPage.get().withPenalty, "With Penalty");
					
				}
			}
			else
			{
				if(!PlanLevelBenefitsPage.get().withOutPenalty.isSelected())
				{
					seClick(PlanLevelBenefitsPage.get().withOutPenalty, "With Out Penalty");
					
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Exception occured in enable penalty method in Plan Level Benefilt \n"+e.getLocalizedMessage());
			// TODO: handle exception
		}
	}

}
