package page.planConfigurator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;

public class RecheckPOTCheckboxPage extends CoreSuperHelper {
	private static RecheckPOTCheckboxPage thisIsTestObj;

	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	
	public synchronized static RecheckPOTCheckboxPage get() {
		thisIsTestObj = PageFactory.initElements(getWebDriver(), RecheckPOTCheckboxPage.class);
		return thisIsTestObj;
	}
	
	@FindBy(how = How.XPATH, using = "//*[@id='actionsBar']/li[4]/a")
	public WebElement editTemplate;	
	
	@FindBy(how = How.XPATH, using = "//*[@id='planHeaderWrapper']/div/div/div[2]/div[2]/div[2]/div/div[2]")
	public WebElement templateVersionID;	
		
	/*@FindBy(how = How.XPATH, using = "//span[contains(@id,'POA_BenefitOption-_-SingleVisionPediatric-_-CoveredINNOON-_-NA-_-NA-_-CopayINNPedSingleVision_-_amount')]")
	public WebElement visionPediatricSingleVision_CoveredINOON_INNPediatricSingleVisionCopay;*/
	
	String visionPediatricSingleVision_CoveredINOON_INNPediatricSingleVisionCopay="//span[contains(@id,'POA_BenefitOption-_-SingleVisionPediatric-_-CoveredINNOON-_-NA-_-NA-_-CopayINNPedSingleVision_-_amount')]";
		
	/*@FindBy(how = How.XPATH, using = "//span[contains(@id,'POA_BenefitOption-_-SingleVisionPediatric-_-CoveredINNOON-_-NA-_-NA-_-DlrLmtINNOONPedSnglVisLens_-_indivMax')]")
	public WebElement visionPediatricSingleVision_CoveredINOON_INNOONPedSnglVisLensDlrLmt;*/
	
	String visionPediatricSingleVision_CoveredINOON_INNOONPedSnglVisLensDlrLmt="//span[contains(@id,'POA_BenefitOption-_-SingleVisionPediatric-_-CoveredINNOON-_-NA-_-NA-_-DlrLmtINNOONPedSnglVisLens_-_indivMax')]";
	
	/*@FindBy(how = How.XPATH, using = "//span[contains(@id,'POA_BenefitOption-_-SingleVisionPediatric-_-CoveredINNOON-_-NA-_-NA-_-DlrLmtOONReimbMaxPedSingleVisionLenses_-_indivMax')]")
	public WebElement visionPediatricSingleVision_CoveredINOON_OONReimbMaxPedSingleVisionLensesDlrLmt;*/
	String visionPediatricSingleVision_CoveredINOON_OONReimbMaxPedSingleVisionLensesDlrLmt="//span[contains(@id,'POA_BenefitOption-_-SingleVisionPediatric-_-CoveredINNOON-_-NA-_-NA-_-DlrLmtOONReimbMaxPedSingleVisionLenses_-_indivMax')]";
	
	
	public void seRecheckPOT(String strTemplateId)
	{
		try
		{
			
			seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
			LoginPage.get().loginApplication(strUserProfile);
			seWaitForClickableWebElement(HomePage.get().find, 10);
			String strPlanID = getCellValue("PlanVersionID");
			seClick(HomePage.get().find, "Find");
			seClick(HomePage.get().findPlan, "Find Plan");
			seSetText(FindPlanPage.get().planVersionID, strPlanID, "Enter Plan ID");
			seWaitForClickableWebElement(FindPlanPage.get().planSearch, 30);
			seClick(FindPlanPage.get().planSearch, "Search Plan");
			seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().openClickedPlan, 10);
			seClick(PCPSPCBreakoutSetupPage.get().openClickedPlan, "Search");
			waitForPageLoad();
			seClick(BenefitRetainsInProductionPage.get().editButton, "Edit Button");
			waitForPageLoad(30, 10);
			seClick(BenefitRetainsInProductionPage.get().saveButton, "Save");
			waitForPageLoad();
			
			String strPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
			waitForPageLoad();
			String strPlanProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
			waitForPageLoad();
			setCellValue("PlanVersionID", strPlanVersionID);
			setCellValue("PlanProxyID",strPlanProxyID);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", UncheckedFlagAttributeVisiblePage.get().visionBenefitOptions);
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision,25);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision, "Single Vision");
			RecheckPOTCheckboxPage.get().seCheckElementIsNotChangeable(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision_CoveredINOON_INNPediatricSingleVisionCopay, "In Network Pediatric Single Vision Copay");
			RecheckPOTCheckboxPage.get().seCheckElementIsNotChangeable(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision_CoveredINOON_INNOONPedSnglVisLensDlrLmt,"In Network & Out of Network Pediatric Single Vision Lens Dollar Limit");
			RecheckPOTCheckboxPage.get().seCheckElementIsNotChangeable(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision_CoveredINOON_OONReimbMaxPedSingleVisionLensesDlrLmt,"Out of Network Pediatric Single Vision Lenses Reimbursement Maximum Dollar Limit");
			
			CreateVisionMasterProductTemplate.get().seMoveVisionPlanToProduction(getCellValue("PlanVersionID"));			
			
			seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
			waitForPageLoad();
			LoginPage.get().loginApplication(strUserProfile);
			waitForPageLoad();
			seClick(HomePage.get().find, "Find");
			seClick(HomePage.get().findTemplate, "Find Template");
			waitForPageLoad();			
			seSetText(page.planConfigurator.FindTemplatePage.get().templateVersionID, strTemplateId,"text in Template Version ID textbox");				
			seClick(page.planConfigurator.FindTemplatePage.get().templateSearch, "Search template");
			waitForPageLoad(40);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);
			waitForPageLoad(20);
			seClick(RecheckPOTCheckboxPage.get().editTemplate, "Edit Template");
			seWaitForPageLoad(20);
			seClick(BenefitRetainsInProductionPage.get().saveButton, "Save");
			waitForPageLoad();	
			String strTemplateVersionID=seGetElementValue(RecheckPOTCheckboxPage.get().templateVersionID).split(":")[1];
			System.out.println(strTemplateVersionID);
			setCellValue("TemplateVersionID",strTemplateVersionID);
			
			
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", UncheckedFlagAttributeVisiblePage.get().visionBenefitOptions);
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision,25);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision, "Single Vision");
			seWaitForPageLoad(30);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision_Uncheck);			
			seWaitForPageLoad(30);
			seWaitForClickableWebElement(PlanHeaderPage.get().save, 20);
			seClick(PlanHeaderPage.get().save, "Save button");
			seWaitForPageLoad(25);
			seWaitForClickableWebElement(PlanHeaderPage.get().close,20);
			seClick(PlanHeaderPage.get().close, "Close button");
			seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
			waitForPageLoad();				
			seClick(PlanHeaderPage.get().userLogout, "Logout");
			waitForPageLoad();
			seCloseBrowser();
			CreateVisionMasterProductTemplate.get().seMoveVisionTemplateToProduction(getCellValue("TemplateVersionID"));		
			
			seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
			waitForPageLoad();
			LoginPage.get().loginApplication(strUserProfile);
			waitForPageLoad();
			/*seClick(HomePage.get().create, "Clicking on create link");
			waitForPageLoad();
			seClick(HomePage.get().plan, "Plan");
			seWaitForPageLoad(30);
			waitForPageLoad();			
			CreateVisionMasterProductTemplate.get().seCreateVisionPlan(true, 50);*/
			
			seWaitForClickableWebElement(HomePage.get().find, 10);
			String strEditedPlanID = getCellValue("PlanVersionID");
			seClick(HomePage.get().find, "Find");
			seClick(HomePage.get().findPlan, "Find Plan");
			seSetText(FindPlanPage.get().planVersionID, strEditedPlanID, "Enter Plan ID");
			seWaitForClickableWebElement(FindPlanPage.get().planSearch, 30);
			seClick(FindPlanPage.get().planSearch, "Search Plan");
			seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().openClickedPlan, 10);
			seClick(PCPSPCBreakoutSetupPage.get().openClickedPlan, "Search");
			waitForPageLoad();
			seClick(BenefitRetainsInProductionPage.get().editButton, "Edit Button");
			waitForPageLoad(30, 10);
			seClick(BenefitRetainsInProductionPage.get().saveButton, "Save");
			waitForPageLoad();

			strPlanVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
			waitForPageLoad();
			strPlanProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
			waitForPageLoad();
			setCellValue("PlanVersionID", strPlanVersionID);
			setCellValue("PlanProxyID",strPlanProxyID);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", UncheckedFlagAttributeVisiblePage.get().visionBenefitOptions);
			
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision,25);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision, "Single Vision");
					
			
			seCheckElementAvailablIsChangeable(RecheckPOTCheckboxPage.get().visionPediatricSingleVision_CoveredINOON_INNPediatricSingleVisionCopay,"In Network Pediatric Single Vision Copay");
			seCheckElementAvailablIsChangeable(RecheckPOTCheckboxPage.get().visionPediatricSingleVision_CoveredINOON_INNOONPedSnglVisLensDlrLmt, "In Network & Out of Network Pediatric Single Vision Lens Dollar Limit");
			seCheckElementAvailablIsChangeable(RecheckPOTCheckboxPage.get().visionPediatricSingleVision_CoveredINOON_OONReimbMaxPedSingleVisionLensesDlrLmt, "Out of Network Pediatric Single Vision Lenses Reimbursement Maximum Dollar Limit");
			
			CreateVisionMasterProductTemplate.get().seMoveVisionPlanToProduction(getCellValue("PlanVersionID"));
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	public void seCheckElementIsNotChangeable(WebElement wbTestObject,String strName)
	{
		
		try {
			wbTestObject.sendKeys(Keys.ENTER);			
			log(FAIL, "Accumulator "+strName+" is Changeable in Plan");
		} catch (WebDriverException e) {
			seHighlightElement(wbTestObject);
			log(PASS, "Accumulator "+strName+" is Unchangeable in Plan");
		}
	}
	
	
	public void seCheckElementAvailablIsChangeable(String wbTestObject,String strName)
	{
		String strChangeAdd="/following::input[1]";		
		if(getWebDriver().findElement(By.xpath(wbTestObject)).isEnabled())
		{
			try {
				seClick(getWebDriver().findElement(By.xpath(wbTestObject)), strName);
				String valueCheck=wbTestObject.toString();
				seSetText(getWebDriver().findElement(By.xpath(wbTestObject+strChangeAdd)),"75");
				getWebDriver().findElement(By.xpath(wbTestObject+strChangeAdd)).sendKeys(Keys.ENTER);
				seHighlightElement(getWebDriver().findElement(By.xpath(wbTestObject)));
				log(PASS, "Accumulator "+strName+" is Changeable in Plan");
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		else
		{
			log(FAIL,"Accumulator "+strName+" is Unchangeable in Plan");
		}
	}
}
