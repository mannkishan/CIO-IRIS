package page.planConfigurator;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import utility.CoreSuperHelper;
import utility.PCUtils;

public class MassUpdatePage extends CoreSuperHelper{

	private static MassUpdatePage thisTestObj;	
	public synchronized static MassUpdatePage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), MassUpdatePage.class);
		return thisTestObj;
	}


	@FindBy(how = How.XPATH, using = "//form[@id='findPlanSearch']/div[3]/div/div[4]/input")
	@CacheLookup
	public WebElement effeThruDate;

	@FindBy(how = How.XPATH, using = "//div[@class='typeAheadContainer main']/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement status;

	@FindBy(how = How.XPATH, using = "//div[@class='typeAheadContainer sub']/span/span/span/ul[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement statusValue;

	public WebElement selectType(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//span[@class='select2-results']/ul/li/span[text()='"+type+"']"));
		return valueType;
	}


	@FindBy(how = How.XPATH, using = "//form[@id='findPlanSearch']/div[6]/button[2]")
	@CacheLookup
	public WebElement search;

	@FindBy(how = How.XPATH, using = "//div[@class='findPlanResults']/div[2]/table/tbody")
	@CacheLookup
	public WebElement searchResults;

	@FindBy(how = How.XPATH, using = "//div[@class='findPlanResults']/div/button[3]")
	@CacheLookup
	public WebElement bulkRepublishButton;

	@FindBy(how = How.XPATH, using = "//div[@id='bulk-republish-sectionWrapper']/div[3]/div/div[2]/div[1]/a[2]")
	@CacheLookup
	public WebElement nextPage;

	public By spinner=By.xpath("//div[@class='spinner ui-widget-overlay ajax-loader-modal']");

	@FindBy(how = How.XPATH, using = "//span[@title='Status']")
	@CacheLookup
	public WebElement headerCriteriaType;

	//Line of Business
	public WebElement headerCritTypeValue(String type)
	{
		WebElement headerType = getWebDriver().findElement(By.xpath("//div[starts-with(@class,'typeAheadContainer main')]/span/span/span/ul/li[contains(text(),'"+type+"')]"));
		return headerType;
	}

	@FindBy(how = How.NAME, using = "criteria[modDateFromString]")
	@CacheLookup
	public WebElement modifiedFromDate;

	@FindBy(how = How.NAME, using = "criteria[modDateToString]")
	@CacheLookup
	public WebElement modifiedThruDate;

	@FindBy(how = How.CLASS_NAME, using = "searchResultsTable")
	public WebElement searchResultsTable; 
	

	/**
	 * This method is used to create a bulk republish, plans will be selected based on the template name and effective date
	 * @param strTemplateName: Name of the template which will be used to select the plans
	 * @param strEffectiveDate: Effective date which will be used to search the plans
	 * @return : ID of the bulk republish will be returned which will be used to identify the Impact report
	 */
	public static String bulkRepublish(String strTemplateName,String strEffectiveDate)
	{
		String planID=null;
		String planId1=null;
		String planId2=null;
		try{
			waitForPageLoad(360);
			seClick(HomePage.get().massUpdate,"Mass Update link");
			seWaitForElementLoad(HomePage.get().createNew);
			seClick(HomePage.get().createNew,"Create New");
			seWaitForElementLoad(HomePage.get().bulkRepublish);
			seClick(HomePage.get().bulkRepublish, "Bulk Republish");
			waitForPageLoad(360);
			seWaitForElementLoad(MassUpdatePage.get().effeThruDate);
			seSetText(MassUpdatePage.get().effeThruDate, strEffectiveDate, "Setting text value in effective date text field");
			WebElement pressEnter = MassUpdatePage.get().effeThruDate;
			pressEnter.sendKeys(Keys.ENTER);
			seWaitForElementLoad(MassUpdatePage.get().statusValue);
			seClick(MassUpdatePage.get().statusValue, "Status Value");
			waitForPageLoad(360);
			seClick(MassUpdatePage.get().selectType("Production"),"Selecting status type");
			waitForPageLoad(360);
			seWaitForElementLoad(MassUpdatePage.get().search);			
			seClick(MassUpdatePage.get().search,"Search button");
			seWaitForWebElement(420, ExpectedConditions.visibilityOf(MassUpdatePage.get().searchResults));
			if(MassUpdatePage.get().searchResults.isDisplayed())
			{
				log(PASS,"Search Results are displayed","Search results are displayed for the criteria given",true);
				int counter=0;
				int loopCounter= 0;
				while (counter<=2 && loopCounter<4)
				{
					List<WebElement> template=getWebDriver().findElements(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr"));
					for(int i=1;i<template.size();i++)	
					{	

						String templateText=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr["+i+"]/td[4]")).getText().toString().trim();							
						if(templateText.equalsIgnoreCase(strTemplateName)) 
						{
							counter=counter+1;
							if(counter==1)
							{
								planId1=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr["+i+"]/td[3]")).getText().toString().trim();
								WebElement checkBox=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr["+i+"]/td[1]/input"));
								if(!checkBox.isSelected())
									checkBox.click();
							}
							if(counter==2)
							{
								planId2=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr["+i+"]/td[3]")).getText().toString().trim();
								WebElement checkBox=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr["+i+"]/td[1]/input"));
								if(!checkBox.isSelected())
									checkBox.click();
							}
						}	

					}
					if(counter<2)
					{
					seClick(MassUpdatePage.get().nextPage,"Clicking on Next button");
					waitForPageLoad();	
					}
					loopCounter++;
				}
				planID=planId1+":"+planId2;	
				seClick(MassUpdatePage.get().bulkRepublishButton,"Clicking on bulk republish button");
				waitForPageLoad(200);
				seClick(ConfigureBulkRepublisPage.get().reasonCode,"Reason Code drop down");
				waitForPageLoad();
				seClick(MassUpdatePage.get().selectType("Other"),"Selecting other and clicking on that");
				waitForPageLoad();
				seSetText(ConfigureBulkRepublisPage.get().comment, "Test", "Setting text in comment field");//check
				seClick(TemplateTransitionPage.get().submit,"Clikcing on submit button");
				seWaitForWebElement(20, ExpectedConditions.invisibilityOfElementLocated(MassUpdatePage.get().spinner));

			}
			else
			{
				log(FAIL,"Search Results are not displayed","Search results are not displayed for the criteria given",true);
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			log(FAIL,"Exception Caught in Bulk Republish method",e.getMessage(),true);
		}
		return planID;
	}

	public static void validateReasonCodeValues(String strLOB) throws Exception
	{
		try
		{
			String reasonCodeValues = "";
			if(strLOB.equalsIgnoreCase("PHARMACY"))
			{
				reasonCodeValues= "Error Correction,Default - Run normal process,Other,Disregard - Maintenance only,Project - Run ABL,Release Change,Change Request,Project - Bypass ABL - Spreadsheet Process";
			}
			else
			{
				reasonCodeValues= "Error Correction,Other,Release Change,Change Request";
			}
			
				WebElement reasonCode = getWebDriver().findElement(By.name("reasonCode"));
				Select select = new Select(reasonCode);
				List<WebElement> optionElements = select.getOptions();
				ArrayList<String> optionValues = new ArrayList<>();
				for (WebElement webElement : optionElements) {
					String optionValue = webElement.getText();
					optionValues.add(optionValue);
				}
				String[] reasonCodeValue = reasonCodeValues.split(",");
				for (String string : reasonCodeValue) {
				if(optionValues.contains(string))
				{
					RESULT_STATUS = true;
					log(PASS, "Validate reason code values", "Reason Code value "+string+" is present in the list");
				}
				else
				{
					RESULT_STATUS = false;
					log(FAIL, "Validate reason code values", "Reason Code value "+string+" is not present in the list");
				}
				}
				if(optionValues.size()>reasonCodeValue.length)
				{
					RESULT_STATUS = false;
					log(FAIL, "Validate reason code values", "More values are present in the reason code drop down than expected :"+optionValues.toString());
				}
				
				
				
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Exception Occured in the validate reason code values method");
		}
	}
	
	public static String bulkRepublish(String strTemplateName,String strEffectiveDate,String LOB)
	{
		String planID=null;
		String planId1=null;
		String planId2=null;
		String planId3=null;
		try{
			waitForPageLoad(360);
			seClick(HomePage.get().massUpdate,"Mass Update link");
			seWaitForElementLoad(HomePage.get().createNew);
			seClick(HomePage.get().createNew,"Create New");
			seWaitForElementLoad(HomePage.get().bulkRepublish);
			seClick(HomePage.get().bulkRepublish, "Bulk Republish");
			seWaitForElementLoad(MassUpdatePage.get().effeThruDate);
			seSetText(MassUpdatePage.get().effeThruDate, strEffectiveDate, "Setting text value in effective date text field");
			WebElement pressEnter = MassUpdatePage.get().effeThruDate;
			pressEnter.sendKeys(Keys.ENTER);
			seWaitForElementLoad(MassUpdatePage.get().statusValue);
			seClick(MassUpdatePage.get().statusValue, "Status Value");
			waitForPageLoad(60);
			seClick(MassUpdatePage.get().selectType("Production"),"Selecting status type");
			waitForPageLoad(360);
			seClick(MassUpdatePage.get().headerCriteriaType, "Select Type");
			seClick(MassUpdatePage.get().headerCritTypeValue("Line of Business"), "Select Type value as LOB");
			waitForPageLoad(360);
			seWaitForElementLoad(MassUpdatePage.get().statusValue);
			seClick(MassUpdatePage.get().statusValue, "Status Value");
			seClick(MassUpdatePage.get().selectType(LOB),"Selecting LOB");
			waitForPageLoad(360);
			seWaitForElementLoad(MassUpdatePage.get().search);			
			seClick(MassUpdatePage.get().search,"Search button");
			seWaitForWebElement(420, ExpectedConditions.visibilityOf(MassUpdatePage.get().searchResults));
			boolean isPlanID1Present = false;
			boolean isPlanID2Present = false;
			if(MassUpdatePage.get().searchResults.isDisplayed())
			{
				log(PASS,"Search Results are displayed","Search results are displayed for the criteria given",true);								
				int counter=0;
				int loopCounter= 0;
				while (((!isPlanID1Present)|| (!isPlanID2Present)) && (loopCounter<4) && counter<=3)
				{
					List<WebElement> template=getWebDriver().findElements(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr"));	
					for(int i=1;i<=template.size();i++)
					{	
						String templateText=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr["+i+"]/td[4]")).getText().toString().trim();							
						if(templateText.equalsIgnoreCase(strTemplateName)) 
						{
							counter=counter+1;
							if(counter==1)
							{
								planId1=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr["+i+"]/td[3]")).getText().toString().trim();
								WebElement checkBox=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr["+i+"]/td[1]/input"));
								if(!checkBox.isSelected())
									checkBox.click();
							}
							if(counter==2)
							{
								planId2=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr["+i+"]/td[3]")).getText().toString().trim();
								WebElement checkBox=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr["+i+"]/td[1]/input"));
								if(!checkBox.isSelected())
									checkBox.click();
							}
							if(counter==3)
								planId3=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr["+i+"]/td[3]")).getText().toString().trim();
						}																																				
					}
					if(counter<3)
					{
					if(MassUpdatePage.get().nextPage.isDisplayed())
					{
						seClick(MassUpdatePage.get().nextPage,"Clicking on Next button");
					}
					}
					waitForPageLoad();	
					loopCounter++;	
				}
				planID=planId1+":"+planId2+":"+planId3;	
				seClick(MassUpdatePage.get().bulkRepublishButton,"Clicking on bulk republish button");
				waitForPageLoad(200);
				validateReasonCodeValues(LOB);
				waitForPageLoad(200);
				seClick(ConfigureBulkRepublisPage.get().reasonCode,"Reason Code drop down");
				waitForPageLoad();
				seClick(MassUpdatePage.get().selectType("Other"),"Selecting other and clicking on that");
				waitForPageLoad();
				seSetText(ConfigureBulkRepublisPage.get().comment, "Test", "Setting text in comment field");
				seClick(TemplateTransitionPage.get().submit,"Clikcing on submit button");
				seWaitForWebElement(20, ExpectedConditions.invisibilityOfElementLocated(MassUpdatePage.get().spinner));

			}
			else
			{
				log(FAIL,"Search Results are not displayed","Search results are not displayed for the criteria given",true);
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			log(FAIL,"Exception Caught in Bulk Republish method",e.getMessage(),true);
		}
		return planID;
	}

	public static String bulkRepublish(String strTemplateName, String planID1, String planID2,String strEffectiveDate, String strModifiedFromDate, String strModifiedThruDate, String LOB)
	{
		String planID=null;
		try{
			seClick(HomePage.get().massUpdate,"Mass Update link");
			seWaitForElementLoad(HomePage.get().createNew);
			seClick(HomePage.get().createNew,"Create New");
			seWaitForElementLoad(HomePage.get().bulkRepublish);
			seClick(HomePage.get().bulkRepublish, "Bulk Republish");
			seWaitForElementLoad(MassUpdatePage.get().effeThruDate);
			seSetText(MassUpdatePage.get().effeThruDate, strEffectiveDate, "Setting text value in effective date text field");
			WebElement pressEnter = MassUpdatePage.get().effeThruDate;
			pressEnter.sendKeys(Keys.ENTER);
			seSetText(MassUpdatePage.get().modifiedFromDate, strModifiedFromDate, "Setting text value in modified from date text field");
			pressEnter = MassUpdatePage.get().modifiedFromDate;
			pressEnter.sendKeys(Keys.ENTER);
			seSetText(MassUpdatePage.get().modifiedThruDate, strModifiedThruDate, "Setting text value in modified thru date text field");
			pressEnter = MassUpdatePage.get().modifiedThruDate;
			pressEnter.sendKeys(Keys.ENTER);
			waitForPageLoad(10);
			seWaitForElementLoad(MassUpdatePage.get().statusValue);
			seClick(MassUpdatePage.get().statusValue, "Status Value");
			waitForPageLoad(20);
			seClick(MassUpdatePage.get().selectType("Production"),"Selecting status type");
			waitForPageLoad(60);
			seClick(MassUpdatePage.get().headerCriteriaType, "Select Type");
			seClick(MassUpdatePage.get().headerCritTypeValue("Line of Business"), "Select Type value as LOB");
			waitForPageLoad(30);
			seWaitForElementLoad(MassUpdatePage.get().statusValue);
			seClick(MassUpdatePage.get().statusValue, "Status Value");
			seClick(MassUpdatePage.get().selectType(LOB),"Selecting status type");
			waitForPageLoad(30);
			seWaitForElementLoad(MassUpdatePage.get().search);			
			seClick(MassUpdatePage.get().search,"Search button");
			seWaitForWebElement(120, ExpectedConditions.visibilityOf(MassUpdatePage.get().searchResults));
			boolean isPlanID1Present = false;
			boolean isPlanID2Present = false;
			String actPlanId = "";
			if(MassUpdatePage.get().searchResults.isDisplayed())
			{
				log(PASS,"Search Results are displayed","Search results are displayed for the criteria given",true);
				int loopCounter= 0;
				while (((!isPlanID1Present)|| (!isPlanID2Present)) && (loopCounter<9))
				{
					List<WebElement> template=getWebDriver().findElements(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr"));
					for(int i=1;i<template.size();i++)	
					{	
						String templateText=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr["+i+"]/td[4]")).getText().toString().trim();							
						if(templateText.equalsIgnoreCase(strTemplateName)) 
						{
							actPlanId=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr["+i+"]/td[3]")).getText().toString().trim();
							if((actPlanId.equalsIgnoreCase(planID1))||(actPlanId.equalsIgnoreCase(planID2)))
							{
								WebElement checkBox=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div[2]/table/tbody/tr["+i+"]/td[1]/input"));
								if(!checkBox.isSelected())
								{
									checkBox.click();
								}
								if(actPlanId.equalsIgnoreCase(planID1))
								{
									isPlanID1Present= true;
								}
								else{
									isPlanID2Present= true;
								}
							}
						}	

					}
					if(MassUpdatePage.get().nextPage.isDisplayed())
					{
						seClick(MassUpdatePage.get().nextPage,"Clicking on Next button");
					}
					waitForPageLoad();	
					loopCounter++;
				}
				planID=planID1+":"+planID2;	
				waitForPageLoad();
				seClick(MassUpdatePage.get().bulkRepublishButton,"Clicking on bulk republish button");
				waitForPageLoad();
				seClick(ConfigureBulkRepublisPage.get().reasonCode,"Reason Code drop down");			
				seClick(MassUpdatePage.get().selectType("Other"),"Selecting other and clicking on that");
				seWaitForPageLoad(60);
				waitForPageLoad();
				seSetText(ConfigureBulkRepublisPage.get().comment, "Test", "Setting text in comment field");//check
				seClick(TemplateTransitionPage.get().submit,"Clikcing on submit button");
				seWaitForWebElement(20, ExpectedConditions.invisibilityOfElementLocated(MassUpdatePage.get().spinner));
			}
			else
			{
				log(FAIL,"Search Results are not displayed","Search results are not displayed for the criteria given",true);
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
			log(FAIL,"Exception Caught in Bulk Republish method",e.getMessage(),true);
		}
		return planID;
	}
	


}
