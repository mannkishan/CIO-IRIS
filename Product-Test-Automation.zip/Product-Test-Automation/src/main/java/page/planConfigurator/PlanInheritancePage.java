package page.planConfigurator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


import utility.CoreSuperHelper;

public class PlanInheritancePage extends CoreSuperHelper {
	
	private static PlanInheritancePage thisIsTestObj;
	public  synchronized static PlanInheritancePage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), PlanInheritancePage.class);
		return thisIsTestObj;
		}
		
	@FindBy(how=How.XPATH,using="//div[@id='verticalBarMenuDetails']//li[3]")
	public WebElement level1NetworkCoverage;
	
	@FindBy(how=How.XPATH,using="//select[@id='POA_Base-_-FormCovg-_-FourTier-_-NA-_-NA-_-FormTier2RetailCoin_-_percentage']//following-sibling::span[1]/span[1]/span/span[2]")
	public WebElement formularyTier2RetailCoinsurance ;
	
	@FindBy(how=How.XPATH,using="//span[@class='select2-search select2-search--dropdown']//input[@class='select2-search__field']")
	public WebElement textFormularyTier2RetailCoinsurance ;
	
	//@FindBy(how=How.ID,using="//li[@id='select2-POA_Base-_-FormCovg-_-FourTier-_-NA-_-NA-_-FormTier2RetailCoin_-_percentage-result-4mj2-2']")
	//public WebElement selectPlanLevelValue;
	
	@FindBy(how=How.XPATH,using="//ul[@id='actionsBar']/li[7]/a")
	public WebElement selectSave;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Biologicals')]")
	@CacheLookup
	public WebElement selectBenefit;
	
	@FindBy(how = How.XPATH, using = "//div[@class='benefitDetailsWrapper']/div[2]")
	@CacheLookup
	public WebElement selectFormularyTier2Retail;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Hospital / Facility Care')]")
	@CacheLookup
	public WebElement selectParentBenefitHFC;
	
	@FindBy(how = How.XPATH, using = "//div[@id='content-planBenefitDetails']/div[2]/div[1]/div[1]/div[1]")
	@CacheLookup
	public WebElement  selectParentInpatientPlaceofService;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'In Network Inpatient Care Copay')]//following::span[@class='select2-selection__arrow'][1]")
	public WebElement HFCParentcopayment;
	
	@FindBy(how=How.XPATH,using="//span[@class='select2-search select2-search--dropdown']//input[@class='select2-search__field']")
	public WebElement textHFCParentcopayment;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'In Network Inpatient Care Copay')]//following::span[@class='select2-selection__arrow'][2]")
	public WebElement HFCParentcoinsurance;
	
	@FindBy(how=How.XPATH,using="//span[@class='select2-search select2-search--dropdown']/input[@class='select2-search__field']")
	public WebElement textHFCParentcoinsurance;
	
	@FindBy(how = How.XPATH, using = "//div[@class='benefitListEntry identifier clearfix benefitDetailsActivated']//a")
	@CacheLookup
	public WebElement selectChildBenefitBariatric;
	
	@FindBy(how = How.XPATH, using = "//div[@class='situationGroupOptionWrapper panel-default  0_Tier1 1_InpatientPlaceofService 2_ALL 3_InpatientHospital 4_ 5_ mix_all']")
	@CacheLookup
	public WebElement  selectChildInpatientPlaceofService;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Filling')]")
	@CacheLookup
	public WebElement selectBenefitFilling;
	
	@FindBy(how = How.XPATH, using = "//div[@class='benefitDetailsWrapper']/div[2]")
	@CacheLookup
	public WebElement selectAdultTire1;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Pediatric Basic Services Copay')]//following::span[@class='select2-selection__arrow'][1]")
	@CacheLookup
	public WebElement selectParentFillingCopayment;
	
	@FindBy(how = How.XPATH, using = "//span[@class='select2-search select2-search--dropdown']/input[@class='select2-search__field']")
	@CacheLookup
	public WebElement textParentFillingCopayment;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Pediatric Basic Services Copay')]//following::span[@class='select2-selection__arrow'][2]")
	@CacheLookup
	public WebElement selectParentFillingCoinsurance;
	
	@FindBy(how = How.XPATH, using = "//span[@class='select2-search select2-search--dropdown']/input[@class='select2-search__field']")
	@CacheLookup
	public WebElement textParentFillingCoinsurance;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Amalgam')]")
	@CacheLookup
	public WebElement selectChildBenefitAmalgam;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Vision Exam')]")
	@CacheLookup
	public WebElement selectBenefitVisionExam;
	
	@FindBy(how = How.XPATH, using = "//div[@class='benefitDetailsWrapper']/div[1]")
	@CacheLookup
	public WebElement selectParticipating;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Vision Exam Copay')]//following::span[@class='select2-selection__arrow'][1]")
	@CacheLookup
	public WebElement selectParentVisionCoinsurance;
	
	@FindBy(how = How.XPATH, using = "//span[@class='select2-search select2-search--dropdown']/input[@class='select2-search__field']")
	@CacheLookup
	public WebElement textParentVisionCoinsurance;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Vision Exam Copay')]//following::span[@class='select2-selection__arrow'][2]")
	@CacheLookup
	public WebElement selectParentVisionCopayment;
	
	@FindBy(how = How.XPATH, using = "//span[@class='select2-search select2-search--dropdown']/input[@class='select2-search__field']")
	@CacheLookup
	public WebElement textParentVisionCopayment;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Contact Lens Exam')]")
	@CacheLookup
	public WebElement selectChildBenefitOfVisionExam;
	
	////////////Banaja/////////////
	
	
	
	public WebElement AccumValue(String Accum)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+Accum+"')]/ancestor::tr[1]/td[2]/div/div[2]/span[1]/span[1]/span/span[1]"));
		
		return valueType;
	} 
	public WebElement benefitAccumValue(String Accum)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+Accum+"')]/ancestor::tr[1]/td[5]/span/span/span/div[2]/span/span/span[1]/span"));
		
		return valueType;
	} 
	
	
	public WebElement benefitAccumValueProduction(String Accum)
	{		WebElement valueType = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+Accum+"')]/ancestor::tr[1]/td[5]/span/span/span/span"));
		return valueType;
	} 
	
	public WebElement copay(String Accum)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//span[text()='"+Accum+"']/ancestor::tr[1]/td[5]/span/span/span/div[2]/span/span/span/span"));
		return valueType;
	} 
	
	
		@FindBy(how=How.XPATH,using ="//div[@id='content-benefitSearchBar']/div[2]/button[1]")
	@CacheLookup
	public WebElement clearButton;
	
	@FindBy(how=How.XPATH,using ="//div[@id='content-planBenefitDetails']/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[1]/span/input")
	@CacheLookup
	public WebElement radioButton;
			
	
	public boolean parentFeildvalue (String strValue){
		WebElement element = getWebDriver().findElement(By.xpath("//*[@id='content-planBenefitDetails']//span[@class='changed']/span[contains(text(),'"+ strValue +"')]"));
		return element.isDisplayed();
	}
		
		public boolean childFeildvalue (String strValue){
			WebElement element = getWebDriver().findElement(By.xpath("//div[contains(text(),' Percentage ')]//following-sibling::span[contains(text(),'"+ strValue +"')]"));
			return element.isDisplayed();
		
		
	}
		


		public boolean level2Feildvalue (String strValue){
			WebElement element = getWebDriver().findElement(By.xpath("//div[@class='benefitDetailsWrapper']/div[1]//span[contains(@title,'"+ strValue +"')]"));
			return element.isDisplayed();
		}
		
	/////////
		
	public boolean coinsuranceValue (String PlanLevelCoinsValue){
	WebElement element = getWebDriver().findElement(By.xpath("//*[contains(@title,'"+ PlanLevelCoinsValue +"')]"));
	return element.isDisplayed();
	}
	
	public boolean copaymentValue (String PlanLevelCopayValue){
	WebElement element = getWebDriver().findElement(By.xpath("//*[contains(@title,'"+ PlanLevelCopayValue +"')]"));
	return element.isDisplayed();
	}
		
	public void planLevelbenefit(){
		   WebElement Planlevelbenefit = getWebDriver().findElement(By.xpath("//a[@title='Plan Level Benefits']")) ;
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",Planlevelbenefit); 
	   }
	
	@FindBy(how=How.XPATH,using="//div[@id='verticalBarMenuDetails']//li[3]/a[1]")
	public WebElement mailCoverage;
	
	@FindBy(how=How.XPATH,using="//select[@id='POA_Base-_-MailCovg-_-MailCovg-_-Tier1-_-Tier1-_-CoinFormTier1MailRx_-_percentage']//following-sibling::span[1]/span[1]/span/span[2]")
	public WebElement formularyTier2MailCoinsurance ;
	
	//*[@id="select2-POA_Base-_-MailCovg-_-MailCovg-_-Tier1NotSplit-_-Tier1NotSplit-_-CoinFormTier1MailRx_-_percentage-container"]

	@FindBy(how=How.XPATH,using="//span[@class='select2-search select2-search--dropdown']//input[@class='select2-search__field']")
	public WebElement textFormularyTier2MailCoinsurance ;
	
}
	
	
