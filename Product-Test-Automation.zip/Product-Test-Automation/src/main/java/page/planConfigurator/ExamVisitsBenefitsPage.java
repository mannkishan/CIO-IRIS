package page.planConfigurator;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class ExamVisitsBenefitsPage extends CoreSuperHelper{
	private static ExamVisitsBenefitsPage thisIsTestObj;
	public  synchronized static ExamVisitsBenefitsPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), ExamVisitsBenefitsPage.class);
		return thisIsTestObj;
		}
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"BenefitTree\"]/a")
	@CacheLookup
	public WebElement benefits;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-benefitSearchBar\"]/div[2]/div/input")
	@CacheLookup
	public WebElement benefitsSearch;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-benefitSearchBar\"]/div[2]/button[2]")
	@CacheLookup
	public WebElement benefitsSearchButton;
	
	
	@FindBy(how = How.XPATH, using = "//div[@class=\"benefitDetailsContents\"]//span[@class=\"optionHeaderDetail\" and contains(text(),\"Home by a Primary Care Physician\")]")
	@CacheLookup
	public WebElement physMedServ_ExmVst_HomeBy_PCP;
	
	
	@FindBy(how = How.XPATH, using = "//td[@fullpath=\"BTC_Physician_MedSvcs-_-BTC_ExamVst-_-Tier1-_-HOMEPOSPCPNCH-_-Standard-_-1PeUmUmCpCmCmUdSdDeCnDmDm-_-POA_PlanOptions_OfficeExamsPCP_CoveredINNOON_CostSharesINNT1_BenefitSpecificCostShares_CopayINNT1PCP\"]//span[contains(text(),'In Network Primary Care Physician Copay')]")
	@CacheLookup
	public WebElement physMedServ_ExmVst_HomeBy_PCPName;	
	
	
	@FindBy(how = How.XPATH, using = "//td[@fullpath=\"BTC_Physician_MedSvcs-_-BTC_ExamVst-_-Tier1-_-HOMEPOSPCPNCH-_-Standard-_-1PeUmUmCpCmCmUdSdDeCnDmDm-_-POA_PlanOptions_OfficeExamsPCP_CoveredINNOON_CostSharesINNT1_BenefitSpecificCostShares_CopayINNT1PCP\"]//span[@class=\"select2-selection__rendered\"]")
	@CacheLookup
	public WebElement physMedServ_ExmVst_HomeBy_PCPValue;
	
	
	@FindBy(how = How.XPATH, using = "//div[@class=\"benefitDetailsContents\"]//span[@class=\"optionHeaderDetail\" and contains(text(),\"Home by a Specialist\")]")
	@CacheLookup
	public WebElement physMedServ_ExmVst_HomeBy_SPC;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[2]/table/tbody/tr[2]/td[4]/span")
	@CacheLookup
	public WebElement physMedServ_ExmVst_HomeBy_SPCName;
	
	@FindBy(how = How.XPATH, using = "//td[@fullpath='BTC_Physician_MedSvcs-_-BTC_ExamVst-_-Tier1-_-HOMEPOSSPCNCH-_-Standard-_-1PeUmUmCpCmCmUdSdDeCnDmDm-_-POA_PlanOptions_OfficeExamsSpec_CoveredINNOON_CostSharesINNT1_BenefitSpecificCostShares_CopayINNT1Spec']//span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement physMedServ_ExmVst_HomeBy_SPCValue;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[1]/span[3]")
	@CacheLookup
	public WebElement physMedServ_ExmVst_FootCare_PCP;
		
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[2]/table/tbody/tr[2]/td[4]/span")
	@CacheLookup
	public WebElement physMedServ_ExmVst_FootCare_PCPName;
	

	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[2]/table/tbody/tr[2]/td[5]/span/span/span/div[2]/span/span/span[1]/span")
	@CacheLookup
	public WebElement physMedServ_ExmVst_FootCare_PCPValue;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[2]/div[1]/span[3]")
	@CacheLookup
	public WebElement physMedServ_ExmVst_FootCare_Spc;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[2]/table/tbody/tr[2]/td[4]/span")
	@CacheLookup
	public WebElement physMedServ_ExmVst_FootCare_SpcName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[2]/div[2]/div[2]/div[1]/div[2]/div[2]/table/tbody/tr[2]/td[5]/span/span/span/div[2]/span/span/span[1]/span")
	@CacheLookup
	public WebElement physMedServ_ExmVst_FootCare_SpcValue;
	
}
