package page.planConfigurator;


import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class CreatePlanL extends CoreSuperHelper{
	
	private static CreatePlanL thisTestObj;	
	public synchronized static CreatePlanL get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), CreatePlanL.class);
		return thisTestObj;
	}				
	@FindBy(how = How.NAME, using = "effectiveDate")
	@CacheLookup
	public WebElement enterEffectiveDate;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[1]/td[2]")
	@CacheLookup
	public WebElement date;
	
	@FindBy(how = How.NAME, using = "productDataModel")
	@CacheLookup
	public WebElement selectProductModelData;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	@CacheLookup
	public WebElement productModelDataOption;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[3]")
	@CacheLookup
	public WebElement masterProductOption;


	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[4]/div/span/span[1]/span")
	@CacheLookup
	public WebElement selectApprovalStatus;
	//*******************************************************************************************************************************
	@FindBy(how = How.NAME, using = "customizationLevel")
	@CacheLookup
	public WebElement customizationLevel;
	
	
	@FindBy(how = How.XPATH, using = "(//span[contains(text(),'Customization Level')])[1]/following::span[contains(text(),'- Please Select -')][1]")
	@CacheLookup
	public WebElement selectCustomizationLevel;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	@CacheLookup
	public WebElement customizationLevelInput;
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[4]")
	@CacheLookup
	public WebElement customizationLeveldropdown;
	
	//seSetText(driver.findElement(By.xpath("(//span[contains(text(),'"+accName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]/following::input[3]")), accVal, "setting text");
	
	
	public static void cl(String cl, String AccumName)
	{
		// Customization Level
		
		seWaitForClickableWebElement(driver.findElement(By.xpath("(//span[contains(text(),'"+AccumName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]")), 10);
		seClick(driver.findElement(By.xpath("(//span[contains(text(),'"+AccumName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]")), "CustomizationLevel drop down");
		seSetText(driver.findElement(By.xpath("//span[contains(text(),'"+AccumName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]/following::input[3]")),cl, "setting text");
		seClick(driver.findElement(By.xpath("(//span[contains(text(),'"+AccumName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]/following::input[3]/following::span[contains(text(),'"+cl+"')]")), "option");
		
		/*
		seClick(CreatePlanPage.get().customizationLevelInput, "CustomizationLevel text field");
		seSetText(CreatePlanPage.get().templateState, cl, "Set State as New York");
		//seSetText(driver.findElement(By.xpath("(//span[contains(text(),'Customization level')])[1]/following::span[contains(text(),'- Please Select -')][1]/following::input[3]")), cl, "setting text");
		seClick(CreatePlanPage.get().customizationLeveldropdown, "CustomizationLevel Enter");
		*/
		
	}
	
	//*******************************************************************************************************************************
	@FindBy(how = How.NAME, using = "state")
	@CacheLookup
	public WebElement state;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[6]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectState;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	@CacheLookup
	public WebElement stateInput;
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[12]")
	@CacheLookup
	public WebElement stateDropdown;
    //********************************************************************************************************************************
	@FindBy(how = How.NAME, using = "marketSegment")
	@CacheLookup
	public WebElement marketSegment;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[7]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectMarketSegment;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement marketSegmentInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[2]")
	@CacheLookup
	public WebElement marketSegmentDropdown;
    //********************************************************************************************************************************
	@FindBy(how = How.NAME, using = "marketUnit")
	@CacheLookup
	public WebElement marketUnit;
	@FindBy(how = How.NAME, using = "lob")
	@CacheLookup
	public WebElement lob;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[9]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectLob;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement lobInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[3]")
	@CacheLookup
	public WebElement lobDropdown;
	
	 //********************************************************************************************************************************
	@FindBy(how = How.NAME, using = "productType")
	@CacheLookup
	public WebElement productName;
	
	@FindBy(how = How.NAME, using = "productFamily")
	@CacheLookup
	public WebElement productFamily;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[11]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectPdtFam;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement pdtFamInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[5]")
	@CacheLookup
	public WebElement pdtFamDropdown;
	
	 //********************************************************************************************************************************
	
	@FindBy(how = How.NAME, using = "cdhpType")
	@CacheLookup
	public WebElement cdhType;
	
	@FindBy(how = How.NAME, using = "planDesign")
	@CacheLookup
	public WebElement planDesign;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[12]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectcdhp;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement cdhpInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[4]")
	@CacheLookup
	public WebElement cdhpDropdown;
	
	 //********************************************************************************************************************************
	@FindBy(how = How.NAME, using = "benefitPeriod")
	@CacheLookup
	public WebElement benefitPeriod;

	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[14]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectBenefitPd;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement benfpdInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[2]")
	@CacheLookup
	public WebElement benfpdDropdown;
	
	 //********************************************************************************************************************************
	
	@FindBy(how = How.NAME, using = "fundingCode")
	@CacheLookup
	public WebElement fundingArrangement;
	
	@FindBy(how = How.NAME, using = "businessEntity")
	@CacheLookup
	public WebElement businessEntity;
	
	
	
	@FindBy(how = How.NAME, using = "businessUnit")
	@CacheLookup
	public WebElement businessUnit;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[18]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectBusiUnit;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement busiUnitInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[2]")
	@CacheLookup
	public WebElement buisunitDropdown;
	
	 //********************************************************************************************************************************
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[19]/div/div/button")
	@CacheLookup
	public WebElement searchTemplate;
	
	@FindBy(how = How.CSS, using = "button[class='selectTemplate btn btn-primary']")
	@CacheLookup
	public WebElement selectTemplate;
	
	
	
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"DataTables_Table_0\"]/tbody/tr/td[5]")
	@CacheLookup
	public WebElement selectAvailTemplate;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/form/div[2]/div[6]/div/button[1]")
	//@CacheLookup
	public WebElement cancelButton;
	//html/body/div[9]/div/div/div/div[3]/button[2]
	//*[@class="btn btn-primary withFocus dialog-action"][text()="Yes"]
	@FindBy(how = How.XPATH, using = "/html/body/div[9]/div/div/div/div[3]/button[2]")
	//@CacheLookup
	public WebElement yesToCancel;
	@FindBy(how = How.XPATH, using = "/html/body/div[9]/div/div/div")
	//@CacheLookup
	public WebElement popup;
	//Plan
	@FindBy(how = How.ID, using = "Plan")
	//@CacheLookup
	public WebElement homepage;
	
	public void strcomparebool(Boolean var1, Boolean var2) {
		   
		if(var1 == var2)
		{
			log(PASS, "Once Cancel confirmed, the Home page is displayed sucessfully","Hompage displayed as expected,RESULT=PASS");
			
			
		}
		else
		{
			log(FAIL, "Once Cancel confirmed, the Home page is NOT displayed sucessfully","Hompage NOT displayed as expected,RESULT=FAIL");
			
			
		}
		
		
		   }
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"header-wrapper\"]/ul/li[3]/ul/li[2]/a[@class='create-Template']")
	//@CacheLookup
	public WebElement findTemplate;
	
	@FindBy(how = How.NAME, using = "planName")
	//@CacheLookup
	public WebElement templateName;
	
	
	@FindBy(how = How.NAME, using = "planDescription")
	//@CacheLookup
	public WebElement templateDesc;
	
	
	//********************************************************************************************************************************** 
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[3]/div/span/span[1]/span/ul/li[2]/input")
	//@CacheLookup
	public WebElement templateState;
	
	//*[@id="content-create-customPlan"]/span/span/span
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span")
	//@CacheLookup
	public WebElement templateStateText;
	
	//********************************************************************************************************************************** 
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[4]/div/span/span[1]/span/ul/li[2]/input")
		//@CacheLookup
	public WebElement templateMarketSegment;
		
	//*[@id="content-create-customPlan"]/span/span/span
		@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span")
		//@CacheLookup
	public WebElement templateMSText;
	
//********************************************************************************************************************************** 
    @FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[5]/div/span/span[1]/span/span[2]")
		//@CacheLookup
	public WebElement templateLob;

	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
		//@CacheLookup
	public WebElement templateLobInput;	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]")
	//@CacheLookup
    public WebElement templateLobText;
	
	//********************************************************************************************************************************** 
    @FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[6]/div/span/span[1]/span/ul/li[2]/input")
		//@CacheLookup
	public WebElement templateProductFmly;

	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span")
		//@CacheLookup
	public WebElement templateProductfmlyinput;	

	//********************************************************************************************************************************** 
    @FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[8]/div/span/span[1]/span/span[2]")
		//@CacheLookup
	public WebElement templateNetwkTier;

	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
		//@CacheLookup
	public WebElement templateNetwkInput;	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]")
	//@CacheLookup
    public WebElement templateNetwrkText;
	//********************************************************************************************************************************** 
	//span[text()=\"Consumer Driven Health Plan \"]//following::li[@class=\"select2-search select2-search--inline\"])[1]

	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[9]/div/span/span[1]/span/ul/li[2]/input")
		//@CacheLookup
	public WebElement templateCDHPInput;	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span")
	//@CacheLookup
    public WebElement templateCDHPText;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/form/div[2]/div[6]/div/button[2]/span")
	//@CacheLookup
    public WebElement createPlan;
//******************************************************************************************************************************
	//*********************************************************************************************
	
	public static void pleaseSelect(String accumName, String accumValue, int waitTime)
	{
		seWaitForClickableWebElement(driver.findElement(By.xpath("(//span[contains(text(),'"+accumName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]")), 10);
		waitForPageLoad(waitTime);
		seClick(driver.findElement(By.xpath("(//span[contains(text(),'"+accumName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]")), "CustomizationLevel drop down");
		//seClick(driver.findElement(By.xpath("(//span[contains(text(),'"+accumName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]")), "CustomizationLevel drop down");
		waitForPageLoad(waitTime);
		//driver.findElement(By.xpath("//span[contains(text(),'"+accumName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]/following::input[3]")).sendKeys(accumValue);;
		seSetText(driver.findElement(By.xpath("//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")),accumValue,"setting text");
		waitForPageLoad(waitTime);
		seClick(driver.findElement(By.xpath("(//span[contains(text(),'"+accumName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]/following::input[3]/following::span[contains(text(),'"+accumValue+"')]")), "option");
		
	}
	
	
	
//*****************************************************************************************************************
	//**************************************************************************************************
	
	
	public  void createPlan(boolean isMasterPlan,int maxWaitTime) throws Exception
	{
		String strEffectiveDate = getCellValue("EffectiveDate");
		
		String strProductModel = "";
		if(isMasterPlan == true)
		{
			strProductModel= "Master Product";
			String strTemplateVersionID = getCellValue("TemplateVersionID");
			String strApprovalStatus = getCellValue("ApprovalStatus");
			String strCustomizationLevel = getCellValue("CustomizationLevel");
			String strState = getCellValue("State");
			String strMarketSegment = getCellValue("MarketSegment");
			String strMarketUnit = getCellValue("MarketUnit");
			String strProductFamily = getCellValue("ProductFamily");
			String strProductName = getCellValue("ProductName");
			String strCDHPType = getCellValue("CDHP");
			String strBenefitPeriod = getCellValue("BenefitPeriod");
			String strFundingArrangement = getCellValue("FundingArrangement");
			String strBusinessUnit	 = getCellValue("BusinessUnit");
			String strLineOfBusiness = getCellValue("LOB");
			
			waitForPageLoad(maxWaitTime);
			seClick(HomePage.get().create, "Create");
			seClick(HomePage.get().plan, "Plan");
			waitForPageLoad(4,maxWaitTime);
			seSetText(CreatePlanL.get().enterEffectiveDate, strEffectiveDate, "Effective date");
			CreatePlanL.get().enterEffectiveDate.sendKeys(Keys.TAB);
			waitForPageLoad(maxWaitTime);
			seSelectText(CreatePlanL.get().selectProductModelData, strProductModel, "Product Model",maxWaitTime);
			if(strApprovalStatus.equalsIgnoreCase("Approved"))
			{
				
			}
			seSelectText(CreatePlanL.get().customizationLevel, strCustomizationLevel, "Customization Level",maxWaitTime);
			seSelectText(CreatePlanL.get().state, strState, "State",maxWaitTime);
			seSelectText(CreatePlanL.get().marketSegment, strMarketSegment, "Market Segment",maxWaitTime);
			seSelectText(CreatePlanL.get().marketUnit, strMarketUnit, "Market Unit",maxWaitTime);
			seSelectText(CreatePlanL.get().lob, strLineOfBusiness, "Line of Business",maxWaitTime);
			seSelectText(CreatePlanL.get().productName, strProductName, "Product Name",maxWaitTime);
			seSelectText(CreatePlanL.get().productFamily, strProductFamily, "Product Family",maxWaitTime);
			seSelectText(CreatePlanL.get().cdhType, strCDHPType, "Consumer Driven Health Plan",maxWaitTime);
			seSelectText(CreatePlanL.get().benefitPeriod, strBenefitPeriod, "Benefit Period",maxWaitTime);
			seSelectText(CreatePlanL.get().fundingArrangement,strFundingArrangement, "Funding Arrangement",maxWaitTime);
			seSelectText(CreatePlanL.get().businessUnit, strBusinessUnit, "Business Unit",maxWaitTime);
			if(isMasterPlan)
			{
			seClick(CreatePlanL.get().selectTemplate	, "Select Template");
			waitForPageLoad(4,maxWaitTime);
			seSwitchFrame(FindTemplatePage.get().findTemplateFrame);
			seWaitForClickableWebElement(FindTemplatePage.get().searchCriteria, 60);
			seClick(FindTemplatePage.get().searchCriteria	, "Search Criteria");
			seWaitForClickableWebElement(FindTemplatePage.get().versionId, 120);
			seSetText(FindTemplatePage.get().versionId, strTemplateVersionID, "Template Version ID");
			seClick(FindTemplatePage.get().searchButton	, "Search Criteria");
			waitForPageLoad(maxWaitTime);
			FindTemplatePage.get().selectTemplate(strTemplateVersionID);
			}
			waitForPageLoad(maxWaitTime);
			getWebDriver().switchTo().defaultContent();
			waitForPageLoad(maxWaitTime);
			seClick(CreatePlanL.get().createPlan, "Create Plan");
			waitForPageLoad(5,maxWaitTime);
			String planVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];;
			String planProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
			setCellValue("PlanVersionID", planVersionID);
			setCellValue("PlanProxyID", planProxyID);
		}
		else
		{	
	    strProductModel= "BI Product";
		//String strTemplateVersionID = getCellValue("TemplateVersionID");
		//String strApprovalStatus = getCellValue("ApprovalStatus");
		String strCustomizationLevel = getCellValue("Level");
		String strState = getCellValue("State");
		String strMarketSegment = getCellValue("Market Segment");
		String strMarketUnit = getCellValue("Market Unit");
		//String strProductFamily = getCellValue("ProductFamily");
		String strProductName = getCellValue("Product Name");
		String strCDHPType = getCellValue("CDHP");
		String strPlanDesign = getCellValue("Plan Design");
		String strBenefitPeriod = getCellValue("Benefit Period");
		String strFundingArrangement = getCellValue("Funding");
		String strBusinessUnit	 = getCellValue("Unit");
		String strBusinessEntity = getCellValue("Entity");
		String strLineOfBusiness = getCellValue("LOB");
		
		waitForPageLoad(maxWaitTime);
		seClick(HomePage.get().create, "Create");
		seClick(HomePage.get().plan, "Plan");
		waitForPageLoad(4,maxWaitTime);
		seSetText(CreatePlanL.get().enterEffectiveDate, strEffectiveDate, "Effective date");
		
		CreatePlanL.get().enterEffectiveDate.sendKeys(Keys.ENTER);
		CreatePlanL.get().enterEffectiveDate.sendKeys(Keys.TAB);
		waitForPageLoad(maxWaitTime);
		seSelectText(CreatePlanL.get().selectProductModelData, strProductModel, "Product Model",maxWaitTime);
		//seSelectText(CreatePlanL.get().cl, strCustomizationLevel, "Customization Level",maxWaitTime);
		//Accum name
		String strcustlvl = "Customization Level";
		pleaseSelect(strcustlvl,strCustomizationLevel,10);
		seSelectText(CreatePlanL.get().state, strState, "State",maxWaitTime);
		seSelectText(CreatePlanL.get().marketSegment, strMarketSegment, "Market Segment",maxWaitTime);
		seSelectText(CreatePlanL.get().marketUnit, strMarketUnit, "Market Unit",maxWaitTime);
		seSelectText(CreatePlanL.get().lob, strLineOfBusiness, "Line of Business",maxWaitTime);
		seSelectText(CreatePlanL.get().productName, strProductName, "Product Name",maxWaitTime);
		//seSelectText(CreatePlanL.get().productFamily, strProductFamily, "Product Family",maxWaitTime);
		seSelectText(CreatePlanL.get().cdhType, strCDHPType, "Consumer Driven Health Plan",maxWaitTime);

		seSelectText(CreatePlanL.get().planDesign, strPlanDesign, "Plan Design",maxWaitTime);
		
		
		seSelectText(CreatePlanL.get().benefitPeriod, strBenefitPeriod, "Benefit Period",maxWaitTime);
		seSelectText(CreatePlanL.get().fundingArrangement,strFundingArrangement, "Funding Arrangement",maxWaitTime);
		seSelectText(CreatePlanL.get().businessEntity, strBusinessEntity, "Business Entity",maxWaitTime);
		seSelectText(CreatePlanL.get().businessUnit, strBusinessUnit, "Business Unit",maxWaitTime);
		waitForPageLoad(maxWaitTime);
		seClick(CreatePlanL.get().createPlan, "Create Plan");
		waitForPageLoad(5,maxWaitTime);
		/*String planVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];;
		String planProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
		setCellValue("PlanVersionID", planVersionID);
		setCellValue("PlanProxyID", planProxyID);*/
		}
	}
	
	public  void cancelPlan(boolean isMasterPlan,int maxWaitTime) throws Exception
	{
		String strEffectiveDate = getCellValue("EffectiveDate");
		String strProductModel = "";
		if(isMasterPlan)
		{
			strProductModel= "Master Product";
		}
		String strTemplateVersionID = getCellValue("TemplateVersionID");
		String strApprovalStatus = getCellValue("ApprovalStatus");
		String strCustomizationLevel = getCellValue("CustomizationLevel");
		String strState = getCellValue("State");
		String strMarketSegment = getCellValue("MarketSegment");
		String strMarketUnit = getCellValue("MarketUnit");
		String strProductFamily = getCellValue("ProductFamily");
		String strProductName = getCellValue("ProductName");
		String strCDHPType = getCellValue("CDHP");
		String strBenefitPeriod = getCellValue("BenefitPeriod");
		String strFundingArrangement = getCellValue("FundingArrangement");
		String strBusinessUnit	 = getCellValue("BusinessUnit");
		String strLineOfBusiness = getCellValue("LOB");
		
		waitForPageLoad(maxWaitTime);
		seClick(HomePage.get().create, "Create");
		seClick(HomePage.get().plan, "Plan");
		waitForPageLoad(4,maxWaitTime);
		seSetText(CreatePlanL.get().enterEffectiveDate, strEffectiveDate, "Effective date");
		CreatePlanL.get().enterEffectiveDate.sendKeys(Keys.TAB);
		waitForPageLoad(maxWaitTime);
		seSelectText(CreatePlanL.get().selectProductModelData, strProductModel, "Product Model",maxWaitTime);
		if(strApprovalStatus.equalsIgnoreCase("Approved"))
		{
			
		}
		seSelectText(CreatePlanL.get().customizationLevel, strCustomizationLevel, "Customization Level",maxWaitTime);
		seSelectText(CreatePlanL.get().state, strState, "State",maxWaitTime);
		seSelectText(CreatePlanL.get().marketSegment, strMarketSegment, "Market Segment",maxWaitTime);
		seSelectText(CreatePlanL.get().marketUnit, strMarketUnit, "Market Unit",maxWaitTime);
		seSelectText(CreatePlanL.get().lob, strLineOfBusiness, "Line of Business",maxWaitTime);
		seSelectText(CreatePlanL.get().productName, strProductName, "Product Name",maxWaitTime);
		seSelectText(CreatePlanL.get().productFamily, strProductFamily, "Product Family",maxWaitTime);
		seSelectText(CreatePlanL.get().cdhType, strCDHPType, "Consumer Driven Health Plan",maxWaitTime);
		seSelectText(CreatePlanL.get().benefitPeriod, strBenefitPeriod, "Benefit Period",maxWaitTime);
		seSelectText(CreatePlanL.get().fundingArrangement,strFundingArrangement, "Funding Arrangement",maxWaitTime);
		seSelectText(CreatePlanL.get().businessUnit, strBusinessUnit, "Business Unit",maxWaitTime);
		if(isMasterPlan)
		{
		seClick(CreatePlanL.get().selectTemplate	, "Select Template");
		waitForPageLoad(4,maxWaitTime);
		seSwitchFrame(FindTemplatePage.get().findTemplateFrame);
		seWaitForClickableWebElement(FindTemplatePage.get().searchCriteria, 60);
		seClick(FindTemplatePage.get().searchCriteria	, "Search Criteria");
		seWaitForClickableWebElement(FindTemplatePage.get().versionId, 120);
		seSetText(FindTemplatePage.get().versionId, strTemplateVersionID, "Template Version ID");
		seClick(FindTemplatePage.get().searchButton	, "Search Criteria");
		waitForPageLoad(maxWaitTime);
		FindTemplatePage.get().selectTemplate(strTemplateVersionID);
		}
		waitForPageLoad(maxWaitTime);
		getWebDriver().switchTo().defaultContent();
		waitForPageLoad(5,maxWaitTime);
		seWaitForClickableWebElement(CreatePlanL.get().cancelButton, 1);
		seClick(CreatePlanL.get().cancelButton, "Cancel Button");
		waitForPageLoad(5,maxWaitTime); 
	}
	
	
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
		
}	

