package page.planConfigurator;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class UrgentCarePlanOptionPage extends CoreSuperHelper{
	private static UrgentCarePlanOptionPage thisIsTestObj;
	public  synchronized static UrgentCarePlanOptionPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), UrgentCarePlanOptionPage.class);
		return thisIsTestObj;
		}
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[1]/a")
	@CacheLookup
	public WebElement closePlan;
	
	/*Covered INOON starts here*/
	@FindBy(how = How.XPATH, using = "//*[@id=\"verticalBarMenuDetails\"]/div/nav/div[2]/ul/li[7]/a")
	@CacheLookup
	public WebElement urgentCare;
	
	@FindBy(how = How.XPATH, using = "//a[contains(@attr-ref,'UrgentCare')]")
	@CacheLookup
	public WebElement urgentCareBenefit;
	
	
	@FindBy(how = How.XPATH, using = "(//input[contains(@id,'UrgentCare-_-CoveredINNOON')])[1]")
	@CacheLookup
	public WebElement urgentCareINNOON;	

	@FindBy(how = How.XPATH, using = "(//input[contains(@id,'UrgentCare-_-CoveredINNOnly')])[1]")
	@CacheLookup
	public WebElement urgentCareINNOnly;	

	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-UrgentCare-_-CoveredINNOON\"]")
	@CacheLookup
	public WebElement urgentCareCoveredINNOON;	

	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac\"]/h4")
	@CacheLookup
	public WebElement urgentCareCoveredINNOOONCostSharesFacilityName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac\"]/div/div[1]/div/h4")
	@CacheLookup
	public WebElement urgentCareCoveredINNOOONINNCostSharesFacilityPaidPlnLvlName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac\"]/div/div[2]/div/h4")
	@CacheLookup
	public WebElement urgentCareCoveredINNOOONINNCostSharesFacilityBenSpecCoShareName;
	
	/*Covered INOON ends here*/
	
	/*Covered INN Only starts here*/
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-UrgentCare-_-CoveredINNOnly\"]")
	@CacheLookup
	public WebElement urgentCareCoveredINNOnly;
	
		
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-UrgentCare-_-CoveredINNOnly-_-CostSharesINNT1Fac\"]/h4")
	@CacheLookup
	public WebElement urgentCareCoveredINNOnlyName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-UrgentCare-_-CoveredINNOnly-_-CostSharesINNT1Fac\"]/h4")
	@CacheLookup
	public WebElement urgentCareCoveredINNOnlyINCostSharesFacName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-UrgentCare-_-CoveredINNOnly-_-CostSharesINNT1Fac\"]/div/div[1]/div/h4")
	@CacheLookup
	public WebElement urgentCareCoveredINNOnlyINCostSharesFacPaidPlnLvlName;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-UrgentCare-_-CoveredINNOnly-_-CostSharesINNT1Fac\"]/div/div[2]/div/h4")
	@CacheLookup
	public WebElement urgentCareCoveredINNOnlyINCostSharesFacBenSpecCoShareName;
	
	@FindBy(how = How.XPATH, using = "//input[@id='POA_Base-_-UrgentCareFac-_-CoveredINNOON-_-INNCostShares-_-Copay']")
	@CacheLookup
	public WebElement rBtnUCFacINOONInNetworkCostSharesCopay;

	@FindBy(how = How.XPATH, using = "//*[@id='select2-POA_Base-_-UrgentCareFac-_-CoveredINNOON-_-INNCostShares-_-Copay-_-INNUrgentCareFacCopay_-_amount-container']")
	@CacheLookup
	public WebElement txtUCFacINOONInNetworkCostSharesCopayAmountContainer;

	@FindBy(how = How.XPATH, using = "//*[@class='select2-search__field']")
	@CacheLookup
	public WebElement txtUCFacINOONInNetworkCostSharesCopayAmount;
	
	@FindBy(how = How.XPATH, using = "//*[@id='select2-POA_Base-_-UrgentCareFac-_-CoveredINNOON-_-INNCostShares-_-Copay-_-INNUrgentCareFacCopay_-_amount-results']")
	@CacheLookup
	public WebElement txtUCFacINOONInNetworkCostSharesCopayAmountResults;
	
	public static Boolean seIsAccumulatorTypeVisible(String Accumulator,String Benefit,String covered){
	WebElement wbAccumulatorType=driver.findElement(By.xpath("(//h4[contains(text(),'"+Benefit+"')]/following::span[text()='"+covered+"'])[1]/preceding::input[1]/following::h4[contains(text(),'"+Accumulator+"')][1]"));
	new Actions(driver).moveToElement(wbAccumulatorType).click().build().perform();
	((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", wbAccumulatorType);
	try{
		seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 6);
		}	catch(TimeoutException e){}	
	Boolean result=seIsElementDisplayed(wbAccumulatorType,"AccumulatorType");
	log(PASS, Accumulator,"Visible");
		 return result;
		
	}
	
	public static Boolean seIsAccumulatorSubTypeVisible(String Accumulator,String Benefit,String subType,String covered){
		WebElement wbAccumulatorType=driver.findElement(By.xpath("(//h4[contains(text(),'"+Benefit+"')]/following::span[text()='"+covered+"'])[1]/preceding::input[1]/following::h4[contains(text(),'"+Accumulator+"')][1]/following::h4[text()[contains(.,'"+subType+"')] and not(contains(.,'"+" "+subType+"')) and not(contains(.,'"+subType+" "+"'))]"));
		new Actions(driver).moveToElement(wbAccumulatorType).click().build().perform();
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", wbAccumulatorType);
		try{
			seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 6);
			}	catch(TimeoutException e){}	
		Boolean result=seIsElementDisplayed(wbAccumulatorType,"AccumulatorSubType");
				log(PASS, subType,"Visible");
				 return result;


		}
	public static Boolean seIsAccumulatorNameVisible(String Accumulator,String Benefit,String subType,String Name,String covered){
		WebElement wbAccumulatorType=driver.findElement(By.xpath("(//h4[contains(text(),'"+Benefit+"')]/following::span[text()='"+covered+"'])[1]/preceding::input[1]/following::h4[contains(text(),'"+Accumulator+"')][1]/following::h4[text()[contains(.,'"+subType+"')] and not(contains(.,'"+" "+subType+"')) and not(contains(.,'"+subType+" "+"'))][1]/following::span[normalize-space()='"+Name+"'][1]"));
		new Actions(driver).moveToElement(wbAccumulatorType).click().build().perform();
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", wbAccumulatorType);
		try{
			seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 6);
			}	catch(TimeoutException e){}	
		Boolean result=seIsElementDisplayed(wbAccumulatorType,"AccumulatorName");
		log(PASS, Name,"Visible");
			 return result;
			
		}
	
	/*Covered INN Only ends here*/
	/**
	 * Method to verify whether a Web Element name matches the expected name
	 * @param wbAccumulatorName: Web Element name
	 * @param strExpectedName:Expected name provided for verification
	 */
	
	public static void seIsAccumulatorNameVisible(WebElement wbAccumulatorName,String strExpectedName)
	{
		try {
			if (seIsElementDisplayed(wbAccumulatorName, strExpectedName)
					&& (seGetText(wbAccumulatorName).equalsIgnoreCase(strExpectedName))) {
				RESULT_STATUS = true;
				log(PASS, "Given Accumulator [" + seGetText(wbAccumulatorName) + "] is visible", "RESULT_STATUS=PASS");
			} else {

				RESULT_STATUS = false;
				log(FAIL, "Given Accumulator [" + seGetText(wbAccumulatorName) + "] is not visible",
						"RESULT_STATUS=FAIL");

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	/**
	 * Method to verify whether the Web Element selected matches the expected value
	 * @param testObject: The Web Element to be checked whether selected or not
	 * @param strElementName: The value which is expected
	 * @return blnIsElementNotSelectedSuccess: Boolean value if Web Element is selected or not
	 */
	public boolean seCheckIsElementNotSelected(WebElement testObject, String strElementName) {
		boolean blnIsElementNotSelectedSuccess = false;
		try {
			if (!testObject.isSelected()) {
				blnIsElementNotSelectedSuccess = true;

			} else {
				RESULT_STATUS = false;

			}
		} catch (Exception e) {
			e.printStackTrace();
			RESULT_STATUS = false;
		}
		return blnIsElementNotSelectedSuccess;
	}
	
	/**
	 * Method to verify whether an Accumulator is available or not in Accumulator Group Type	
	 */
	public void seUrgentCareVerifyAccumulator()
	{
		try
		{
		if(UrgentCarePlanOptionPage.get().seCheckIsElementNotSelected(UrgentCarePlanOptionPage.get().urgentCareCoveredINNOON, "Covered In Network & Out of Network"))
		{
			seWaitForClickableWebElement(UrgentCarePlanOptionPage.get().urgentCareCoveredINNOON, 30);
			seClick(UrgentCarePlanOptionPage.get().urgentCareCoveredINNOON, getCellValue("CoveredINNOON"));
			seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().savePage, 30);
			seClick(PCPSPCBreakoutSetupPage.get().savePage, "Save");
			UrgentCarePlanOptionPage.seIsAccumulatorNameVisible(
					UrgentCarePlanOptionPage.get().urgentCareCoveredINNOOONCostSharesFacilityName,
					getCellValue("INCostSharesFac"));			
			UrgentCarePlanOptionPage.seIsAccumulatorNameVisible(
					UrgentCarePlanOptionPage
							.get().urgentCareCoveredINNOOONINNCostSharesFacilityPaidPlnLvlName,
					getCellValue("PaidAsPlnLvl"));			
			UrgentCarePlanOptionPage.seIsAccumulatorNameVisible(
					UrgentCarePlanOptionPage
							.get().urgentCareCoveredINNOOONINNCostSharesFacilityBenSpecCoShareName,
					getCellValue("BenSpecCostShares"));	
		}
		else
		{
			seWaitForClickableWebElement(UrgentCarePlanOptionPage.get().urgentCareCoveredINNOnly, 30);
			seClick(UrgentCarePlanOptionPage.get().urgentCareCoveredINNOnly,
					getCellValue("CoveredINNOnly"));
			seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().savePage, 30);
			seClick(PCPSPCBreakoutSetupPage.get().savePage, "Save");
			seWaitForClickableWebElement(UrgentCarePlanOptionPage.get().urgentCareCoveredINNOnly, 30);
			seClick(UrgentCarePlanOptionPage.get().urgentCareCoveredINNOnly, "Covered In Network Only");
			UrgentCarePlanOptionPage.seIsAccumulatorNameVisible(
					UrgentCarePlanOptionPage.get().urgentCareCoveredINNOnlyINCostSharesFacName,
					getCellValue("INOnlyINCostSharesFacility"));			
			UrgentCarePlanOptionPage.seIsAccumulatorNameVisible(
					UrgentCarePlanOptionPage.get().urgentCareCoveredINNOnlyINCostSharesFacPaidPlnLvlName,
					getCellValue("INOnlyPaidAsPlnLvl"));			
			UrgentCarePlanOptionPage.seIsAccumulatorNameVisible(
					UrgentCarePlanOptionPage
							.get().urgentCareCoveredINNOnlyINCostSharesFacBenSpecCoShareName,
					getCellValue("INOnlyBenSpecCostShares"));
		}
		}
		catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * This Method opens the 'Urgent Care Facility' tab under 'Plan Level Benefits' and updates the Accumulator values for 
	 * Covered in Network & Out of Network -> In Network Cost Shares -> Benefit Specific Cost Shares 
	 * @param strCopayAmount (required) copay $ Amount value
	 */
	public void seUpdateUrgentCareFacility(String strCopayAmount) {
		try {
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanLevelBenefitsPage.get().planLevelBenefits);
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanLevelBenefitsPage.get().urgentCareFacility);

			seWaitForClickableWebElement(UrgentCarePlanOptionPage.get().rBtnUCFacINOONInNetworkCostSharesCopay, 60);
			seClick(UrgentCarePlanOptionPage.get().rBtnUCFacINOONInNetworkCostSharesCopay, "Copay");

			seWaitForClickableWebElement(UrgentCarePlanOptionPage.get().txtUCFacINOONInNetworkCostSharesCopayAmountContainer, 10);
			seClick(UrgentCarePlanOptionPage.get().txtUCFacINOONInNetworkCostSharesCopayAmountContainer, "INNUrgCareFacCopay");
			seClick(UrgentCarePlanOptionPage.get().txtUCFacINOONInNetworkCostSharesCopayAmount, "Input Field INNUrgCareFacCopay");
			seSetText(UrgentCarePlanOptionPage.get().txtUCFacINOONInNetworkCostSharesCopayAmount, strCopayAmount, "In Network Urgent care Facility Copay Amount");
			seWaitForClickableWebElement(UrgentCarePlanOptionPage.get().txtUCFacINOONInNetworkCostSharesCopayAmountResults, 60);
			seClick(UrgentCarePlanOptionPage.get().txtUCFacINOONInNetworkCostSharesCopayAmountResults, "Copay Amount result");

			seWaitForClickableWebElement(PlanOptionsPage.get().saveButton, 60);
			seClick(PlanOptionsPage.get().saveButton, "Save");
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
		
			log(INFO, "Provided the Urgent Care Facility accumulator values for Legacy Plan and saved the details.");
		} catch (Exception e) {
			log(ERROR, "Exception while executing 'seUpdateUrgentCareFacility' method");
		}
	}

	/**
	 * This Method opens the 'Urgent Care Facility' tab under 'Plan Level Benefits' and validates the Accumulator values for 
	 * Covered in Network & Out of Network -> In Network Cost Shares -> Benefit Specific Cost Shares
	 * after the 'Request Audit' option is selected for the plan i.e., Accumulator fields should be disabled 
	 * @param strCopayAmount (required)  value to be compared across the copay $ Amount value in application
	 */
	public void seVerifyUrgentCareFacilityValues(String strCopayAmount) {
		try{
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanLevelBenefitsPage.get().planLevelBenefits);
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanLevelBenefitsPage.get().urgentCareFacility);

			seWaitForClickableWebElement(PlanOptionsPage.get().lblUrgentCareFacilityCoveredINOONInNtkCostSharesCopay, 60);
			seVerifyFieldValue(PlanOptionsPage.get().lblUrgentCareFacilityCoveredINOONInNtkCostSharesCopay, strCopayAmount, "Urgent Care Copay Amount");
		} catch (Exception e) {
			log(ERROR, "Exception while executing 'seVerifyUrgentCareFacilityValues' method");
		}
	}

	/**
	 * This Method opens the 'Urgent Care' tab under 'Plan Options' and updates the Accumulator values for 
	 * Covered in Network & Out of Network -> In Network Cost Shares Facility -> Benefit Specific Cost Shares 
	 * @param strApplyDeductible (required) Value to be set to 'Apply Deductible' pick list
	 * @param strCoinsurance (required) Coinsurance Percentage value
	 * @param strCopayAmount (required) copay $ Amount value
	 */
	public void seUpdateUrgentCare(String strApplyDeductible, String strCoinsurance, String strCopayAmount) {
		try{
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanOptionsPage.get().planOptions);
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanOptionsPage.get().urgentCare);

			seWaitForClickableWebElement(PlanOptionsPage.get().benefitSpecificINNRadioBtn, 60);
			seClick(PlanOptionsPage.get().benefitSpecificINNRadioBtn, "Benefit Specific Cost Shares");

			seWaitForClickableWebElement(PlanOptionsPage.get().applyDeductible, 60);
			seClick(PlanOptionsPage.get().applyDeductible, "Apply Deductible");
			seClick(PlanOptionsPage.get().applyDeductibleText, "Input Field Apply Deductible");
			seSetText(PlanOptionsPage.get().applyDeductibleText, strApplyDeductible, "Input value Apply deductible");
			seWaitForClickableWebElement(PlanOptionsPage.get().applyDeductibleYes, 60);
			seClick(PlanOptionsPage.get().applyDeductibleYes, "Apply Deductible Result");

			seWaitForClickableWebElement(PlanOptionsPage.get().innUrgentCare, 60);
			seClick(PlanOptionsPage.get().innUrgentCare, "INNUrgentCare Facility");
			seClick(PlanOptionsPage.get().innUrgentCareText, "Input Field INNUrgentCare Facility");
			seSetText(PlanOptionsPage.get().innUrgentCareText, strCoinsurance, "Set percentage in INNUrgentCare Facility");
			seWaitForClickableWebElement(PlanOptionsPage.get().collapseInputField, 60);
			seClick(PlanOptionsPage.get().collapseInputField, "Coinsurance Percentage Result");

			seWaitForClickableWebElement(PlanOptionsPage.get().innUrgCareFacCopay, 60);
			seClick(PlanOptionsPage.get().innUrgCareFacCopay, "Input Field INNUrgCareFacCopay");
			seClick(PlanOptionsPage.get().innUrgCareFacCopayAmount, "Input Field INNUrgCareFacCopay");
			seSetText(PlanOptionsPage.get().innUrgCareFacCopayAmount, strCopayAmount, "In Network Urgent care Facility Copay Amount");
			seWaitForClickableWebElement(PlanOptionsPage.get().innUrgCareFacCopayResult, 60);
			seClick(PlanOptionsPage.get().innUrgCareFacCopayResult, "Copay Amount Result");

			seWaitForClickableWebElement(PlanOptionsPage.get().saveButton, 60);
			seClick(PlanOptionsPage.get().saveButton, "Save");
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);

			log(INFO, "Provided the Urgent Care accumulator values for Master Plan and saved the details.");
		} catch (Exception e) {
			log(ERROR, "Exception while executing 'seUpdateUrgentCare' method");
		}
	}

	/**
	 * This Method opens the 'Urgent Care' tab under 'Plan Options' and validates the Accumulator values for 
	 * Covered in Network & Out of Network -> In Network Cost Shares Facility -> Benefit Specific Cost Shares
	 * after the 'Request Audit' option is selected for the plan i.e., Accumulator fields should be disabled
	 * @param strApplyDeductible (required) Value to be compared to 'Apply Deductible' pick list in application
	 * @param strCoinsurance (required) value to be compared across the Coinsurance Percentage value in application
	 * @param strcopayAmount (required) value to be compared across the copay $ Amount value in application
	 */
	public void seVerifyUrgentCareValues(String strApplyDeductible, String strCoinsurance, String strcopayAmount) {
		try {
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanOptionsPage.get().planOptions);
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanOptionsPage.get().urgentCare);

			seWaitForClickableWebElement(PlanOptionsPage.get().lblApplyDeductiblevalue, 60);
			seVerifyFieldValue(PlanOptionsPage.get().lblApplyDeductiblevalue, strApplyDeductible, "Urgent Care Apply Deductible");
			seVerifyFieldValue(PlanOptionsPage.get().lblInnUrgentCareFacCoinsuranceValue, strCoinsurance, "Urgent Care Coinsurance Percentage");
			seVerifyFieldValue(PlanOptionsPage.get().lblInnUrgentCareFacCopayAmountvalue, strcopayAmount, "Urgent Care Copay Amount");
		} catch (Exception e) {
			log(ERROR, "Exception while executing 'seVerifyUrgentCareValues' method");
		}
	}
	
}
