package page.planConfigurator;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class AllergyTestingBenefitOptionPage extends CoreSuperHelper {
	private static AllergyTestingBenefitOptionPage thisIsTestObj;

	public synchronized static AllergyTestingBenefitOptionPage get() {
		thisIsTestObj = PageFactory.initElements(getWebDriver(), AllergyTestingBenefitOptionPage.class);
		return thisIsTestObj;
	}

	@FindBy(how = How.XPATH, using = "//*[@id='POA_BenefitOption-_-AllergyTesting-_-CoveredINNOON-_-INNCostShares-_-Copay']")
	@CacheLookup
	public WebElement rBtnCoveredINOONINCostSharesCopay;

	@FindBy(how = How.XPATH, using = "//*[@id='select2-POA_BenefitOption-_-AllergyTesting-_-CoveredINNOON-_-INNCostShares-_-Copay-_-INNAllergyTestingApplyDed_-_choice-container']")
	@CacheLookup
	public WebElement txtCoveredINOONINCostSharesCopayApplyDeductibleContainer;

	@FindBy(how = How.XPATH, using = "//*[@class='select2-search__field']")
	@CacheLookup
	public WebElement txtCoveredINOONINCostSharesCopayApplyDeductible;
	
	@FindBy(how = How.XPATH, using = "//*[@id='select2-POA_BenefitOption-_-AllergyTesting-_-CoveredINNOON-_-INNCostShares-_-Copay-_-INNAllergyTestingApplyDed_-_choice-results']")
	@CacheLookup
	public WebElement txtCoveredINOONINCostSharesCopayApplyDeductibleResults;
	
	@FindBy(how = How.XPATH, using = "//*[@id='select2-POA_BenefitOption-_-AllergyTesting-_-CoveredINNOON-_-INNCostShares-_-Copay-_-INNAllergyTestingCoin_-_percentage-container']")
	@CacheLookup
	public WebElement txtCoveredINOONINCostSharesCoinsuranceContainer;

	@FindBy(how = How.XPATH, using = "//*[@class='select2-search__field']")
	@CacheLookup
	public WebElement txtCoveredINOONINCostSharesCoinsurance;
	
	@FindBy(how = How.XPATH, using = "//*[@id='select2-POA_BenefitOption-_-AllergyTesting-_-CoveredINNOON-_-INNCostShares-_-Copay-_-INNAllergyTestingCoin_-_percentage-results']")
	@CacheLookup
	public WebElement txtCoveredINOONINCostSharesCoinsuranceResults;

	@FindBy(how = How.XPATH, using = "//*[@id='select2-POA_BenefitOption-_-AllergyTesting-_-CoveredINNOON-_-INNCostShares-_-Copay-_-INNAllergyTestingCoin_-_benefitPeriod-container']")
	@CacheLookup
	public WebElement txtCoveredINOONINCostSharesBenefitPeriodContainer;

	@FindBy(how = How.XPATH, using = "//*[@class='select2-search__field']")
	@CacheLookup
	public WebElement txtCoveredINOONINCostSharesBenefitPeriod;

	@FindBy(how = How.XPATH, using = "//*[@id='select2-POA_BenefitOption-_-AllergyTesting-_-CoveredINNOON-_-INNCostShares-_-Copay-_-INNAllergyTestingCoin_-_benefitPeriod-results']")
	@CacheLookup
	public WebElement txtCoveredINOONINCostSharesBenefitPeriodResults;

	@FindBy(how = How.XPATH, using = "//span[@id='POA_BenefitOption-_-AllergyTesting-_-CoveredINNOON-_-INNCostShares-_-Copay-_-INNAllergyTestingCoin_-_percentage']")
	@CacheLookup
	public WebElement lblAllergyTestingCoinsurancePercentage;

	@FindBy(how = How.XPATH, using = "//span[@id='POA_BenefitOption-_-AllergyTesting-_-CoveredINNOON-_-INNCostShares-_-Copay-_-INNAllergyTestingApplyDed_-_choice']")
	@CacheLookup
	public WebElement lblAllergyTestingApplyDeductibleValue;

	/**
	 * This Method opens the 'Allergy Testing' tab under 'Benefit Options' and updates the Accumulator values for 
	 * Covered in Network & Out of Network -> In Network Cost Shares Facility -> Benefit Specific Cost Shares  
	 * @param strDeductible (required) Value to be set to 'Apply Deductible' pick list
	 * @param strCoinsurance (required) Coinsurance Percentage value
	 * @param strBenefitPeriod (required) Benefit Period pick list value
	 */
	public void seUpdateAllergyTesting(String strDeductible, String strCoinsurance, String strBenefitPeriod) {
		try{
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanBenefitOptionsPage.get().benefitOptionsTab);
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanBenefitOptionsPage.get().allergyTesting);

			seWaitForClickableWebElement(AllergyTestingBenefitOptionPage.get().rBtnCoveredINOONINCostSharesCopay, 60);
			seClick(AllergyTestingBenefitOptionPage.get().rBtnCoveredINOONINCostSharesCopay, "Copay");

			seWaitForClickableWebElement(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesCopayApplyDeductibleContainer, 60);
			seClick(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesCopayApplyDeductibleContainer, "Apply Deductible");
			seClick(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesCopayApplyDeductible, "Input Field Apply Deductible");
			seSetText(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesCopayApplyDeductible, strDeductible, "Input value Apply deductible");
			seWaitForClickableWebElement(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesCopayApplyDeductibleResults, 60);
			seClick(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesCopayApplyDeductibleResults, "Apply Deductible Result");

			seWaitForClickableWebElement(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesCoinsuranceContainer, 60);
			seClick(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesCoinsuranceContainer, "INN Coinsurance");
			seClick(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesCoinsurance, "Input Field Coinsurance");
			seSetText(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesCoinsurance, strCoinsurance, "Set percentage in Coinsurance");
			seWaitForClickableWebElement(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesCoinsuranceResults, 60);
			seClick(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesCoinsuranceResults, "Coinsurance Result");

			seWaitForClickableWebElement(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesBenefitPeriodContainer, 60);
			seClick(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesBenefitPeriodContainer, "Benefit Period");
			seClick(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesBenefitPeriod, "Input Field Benefit Period");
			seSetText(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesBenefitPeriod, strBenefitPeriod, "Set Benefit Period");
			seWaitForClickableWebElement(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesBenefitPeriodResults, 60);
			seClick(AllergyTestingBenefitOptionPage.get().txtCoveredINOONINCostSharesBenefitPeriodResults, "Benefit Period Result");

			seWaitForClickableWebElement(PlanOptionsPage.get().saveButton, 60);
			seClick(PlanOptionsPage.get().saveButton, "Save");
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);

			log(INFO, "Provided the Allergy Testing accumulator values for Legacy Plan and saved the details.");
		} catch (Exception e) {
			log(ERROR, "Exception while executing the 'seUpdateAllergyTesting' method");
		}
	}

	/**
	 * This Method opens the 'Allergy Testing' tab under 'Benefit Options' and validates the Accumulator values for 
	 * Covered in Network & Out of Network -> In Network Cost Shares Facility -> Benefit Specific Cost Shares  
	 * after the 'Request Audit' option is selected for the plan i.e., Accumulator fields should be disabled
	 * @param strDeductible (required) Value to be compared to 'Apply Deductible' pick list in application
	 * @param strCoinsurance (required) value to be compared across the Coinsurance Percentage value in application
	 */
	public void seVerifyAllergyTestingValues(String strDeductible, String strCoinsurance) {
		try {
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanBenefitOptionsPage.get().benefitOptionsTab);
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanBenefitOptionsPage.get().allergyTesting);

			seWaitForClickableWebElement(AllergyTestingBenefitOptionPage.get().lblAllergyTestingApplyDeductibleValue, 60);
			seVerifyFieldValue(AllergyTestingBenefitOptionPage.get().lblAllergyTestingApplyDeductibleValue, strDeductible, "Allergy Testing Apply Deductible");
			seVerifyFieldValue(AllergyTestingBenefitOptionPage.get().lblAllergyTestingCoinsurancePercentage, strCoinsurance, "Allergy Testing Coinsurance Percentage");
		} catch (Exception e) {
			log(ERROR, "Exception while executing the 'seVerifyAllergyTestingValues' method");
		}
		
	}

}
