package page.planConfigurator;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.anthem.selenium.utility.ExtentReportsUtility;

import utility.CoreSuperHelper;
import utility.WebTable;

public class HistoryPage extends CoreSuperHelper{
	
	private static HistoryPage thisTestObj;	
	public synchronized static HistoryPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), HistoryPage.class);
		return thisTestObj;
	}
	
	@FindBy(how = How.XPATH, using = "//div[@id='bulk-history-sectionWrapper']/div/div/div/button")
	@CacheLookup
	public WebElement refresh;
	
	@FindBy(how = How.XPATH, using = "//div[@id='bulk-history-sectionWrapper']/div/div/div/div[2]/div/div/span/a")
	@CacheLookup
	public WebElement next;
	
	@FindBy(how = How.XPATH, using = "//div[@id='bulk-history-sectionWrapper']/div/div/div[2]/div/table/thead/tr[2]/td[1]/input")
    @CacheLookup
    public WebElement id;
	
	@FindBy(how = How.XPATH, using = "//button[@class='close icon']")
    public WebElement close;
		
	
	public void seWaitForBulkRepulishUpdate(String strStatus,String strbulkRepublisID)
	{
				
		ExpectedCondition<Boolean> expectation = new  ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
            	waitForPageLoad(350);
        		WebTable impactReviewTable = new WebTable(getWebDriver().findElement(By.xpath("//div[@id='bulk-history-sectionWrapper']/div/div/div[2]/div/table")), "Completed results");
        		int rowNum = impactReviewTable.getRowWithCellTextInColumn(1, 1, strbulkRepublisID);
        		if(rowNum>0)
        		{
        				String completionStatus  =impactReviewTable.getCell(rowNum, 7).getText().toString();
        				if(completionStatus.equalsIgnoreCase(strStatus))
                		{			
                		   return true;
                		}
                		else
                		{
                			HistoryPage.get().refresh.click();
                			return false;
                		}
        		}
        		else
        		{
        			return false;
        		}
        		
        		
            	
            }
        };

        WebDriverWait wait = new WebDriverWait(getWebDriver(), 600);
        wait.pollingEvery(5, TimeUnit.SECONDS);
        wait.until(expectation);
	}
	
	public String downloadUpdateReport(String strBulkRepublishID)
	{
		boolean found = false;

		try{
			waitForPageLoad(360);
			seClick(HistoryPage.get().refresh, "Refressh Button");
			waitForPageLoad(100);
			seSetText(HistoryPage.get().id,strBulkRepublishID,"ID Field");
			WebTable impactReviewTable = new WebTable(getWebDriver().findElement(By.xpath("//div[@id='bulk-history-sectionWrapper']/div/div/div[2]/div/table")), "Completed results");
			int rowNum = impactReviewTable.getRowWithCellTextInColumn(1, 1, strBulkRepublishID);
			int loopCounter = 0;
			while(rowNum<0)
			{
				loopCounter++;
				seClick(HistoryPage.get().refresh, "Refressh Button");
				impactReviewTable = new WebTable(getWebDriver().findElement(By.xpath("//div[@id='bulk-history-sectionWrapper']/div/div/div[2]/div/table")), "Completed results");
				rowNum = impactReviewTable.getRowWithCellTextInColumn(1, 1, strBulkRepublishID);
				if(loopCounter==20)
				{
					break;
				}
				
			}
			if(rowNum>0)
			{
					HistoryPage.get().seWaitForBulkRepulishUpdate("Completed",strBulkRepublishID);
					seSetText(HistoryPage.get().id,strBulkRepublishID,"ID Field");
					impactReviewTable = new WebTable(getWebDriver().findElement(By.xpath("//div[@id='bulk-history-sectionWrapper']/div/div/div[2]/div/table")), "Completed results");
					String completionStatus  =impactReviewTable.getCell(rowNum, 7).getText().toString();
					if(completionStatus.equalsIgnoreCase("Completed"))
					{
						found = true;
						getWebDriver().findElement(By.xpath("//div[@id='bulk-history-sectionWrapper']/div/div/div[2]/div/table/tbody/tr["+rowNum+"]/td[9]/div")).click();
						ExtentReportsUtility.log(PASS,"The request is moved to Complete & downloaded the update report",
								"Verify plan request is moved to Complete & able to download Update Report");
						Thread.sleep(5000);
						return impactReviewTable.getCell(rowNum, 1).getText().toString().trim();
					}
			}

			if(!found)
			{
				ExtentReportsUtility.log(FAIL," The request is moved to complete & downloaded the update report",
						"Not able to find the ID in the history Results table"+strBulkRepublishID,true);
				return "";
				
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return "";
	}

}
