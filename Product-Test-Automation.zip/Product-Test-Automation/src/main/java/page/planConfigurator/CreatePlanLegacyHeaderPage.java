package page.planConfigurator;


import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.constants.KeyConstants;

import utility.CoreSuperHelper;

/**
 *This Method have Xpaths of the Header Page and the Method to Populate header page for a Master Plan/Legacy Plan and creates a plan.
 * 
 */
public class CreatePlanLegacyHeaderPage extends CoreSuperHelper{
	
	private static CreatePlanLegacyHeaderPage thisTestObj;	
	public synchronized static CreatePlanLegacyHeaderPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), CreatePlanLegacyHeaderPage.class);
		return thisTestObj;
	}				
	@FindBy(how = How.NAME, using = "effectiveDate")
	@CacheLookup
	public WebElement enterEffectiveDate;
	
	public static WebElement wbOptionTab(String strOptionTab)
	{
		return driver.findElement(By.xpath("//a[contains(text(),'" + strOptionTab + "')]"));
		
	}
	@FindBy(how = How.XPATH, using = "//*[@id=\"header-wrapper\"]/ul/li[7]/a")
	@CacheLookup
	public WebElement user;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[1]/td[2]")
	@CacheLookup
	public WebElement date;
	
	@FindBy(how = How.NAME, using = "productDataModel")
	@CacheLookup
	public WebElement selectProductModelData;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	@CacheLookup
	public WebElement productModelDataOption;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[3]")
	@CacheLookup
	public WebElement masterProductOption;


	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[4]/div/span/span[1]/span")
	@CacheLookup
	public WebElement selectApprovalStatus;
	//*******************************************************************************************************************************
	@FindBy(how = How.NAME, using = "customizationLevel")
	@CacheLookup
	public WebElement customizationLevel;
	
	
	@FindBy(how = How.XPATH, using = "(//span[contains(text(),'Customization Level')])[1]/following::span[contains(text(),'- Please Select -')][1]")
	@CacheLookup
	public WebElement selectCustomizationLevel;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	@CacheLookup
	public WebElement customizationLevelInput;
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[4]")
	@CacheLookup
	public WebElement customizationLeveldropdown;

	//*******************************************************************************************************************************
	@FindBy(how = How.NAME, using = "state")
	@CacheLookup
	public WebElement state;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[6]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectState;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	@CacheLookup
	public WebElement stateInput;
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[12]")
	@CacheLookup
	public WebElement stateDropdown;
    //********************************************************************************************************************************
	@FindBy(how = How.NAME, using = "marketSegment")
	@CacheLookup
	public WebElement marketSegment;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[7]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectMarketSegment;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement marketSegmentInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[2]")
	@CacheLookup
	public WebElement marketSegmentDropdown;
    //********************************************************************************************************************************
	@FindBy(how = How.NAME, using = "marketUnit")
	@CacheLookup
	public WebElement marketUnit;
	@FindBy(how = How.NAME, using = "lob")
	@CacheLookup
	public WebElement lob;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[9]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectLob;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement lobInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[3]")
	@CacheLookup
	public WebElement lobDropdown;
	
	 //********************************************************************************************************************************
	@FindBy(how = How.NAME, using = "productType")
	@CacheLookup
	public WebElement productName;
	
	@FindBy(how = How.NAME, using = "productFamily")
	@CacheLookup
	public WebElement productFamily;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[11]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectPdtFam;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement pdtFamInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[5]")
	@CacheLookup
	public WebElement pdtFamDropdown;
	
	 //********************************************************************************************************************************
	
	@FindBy(how = How.NAME, using = "cdhpType")
	@CacheLookup
	public WebElement cdhType;
	
	@FindBy(how = How.NAME, using = "planDesign")
	@CacheLookup
	public WebElement planDesign;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[12]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectcdhp;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement cdhpInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[4]")
	@CacheLookup
	public WebElement cdhpDropdown;
	
	 //********************************************************************************************************************************
	@FindBy(how = How.NAME, using = "benefitPeriod")
	@CacheLookup
	public WebElement benefitPeriod;

	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[14]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectBenefitPd;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement benfpdInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[2]")
	@CacheLookup
	public WebElement benfpdDropdown;
	
	 //********************************************************************************************************************************
	
	@FindBy(how = How.NAME, using = "fundingCode")
	@CacheLookup
	public WebElement fundingArrangement;
	
	@FindBy(how = How.NAME, using = "businessEntity")
	@CacheLookup
	public WebElement businessEntity;
	
	
	
	@FindBy(how = How.NAME, using = "businessUnit")
	@CacheLookup
	public WebElement businessUnit;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[18]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectBusiUnit;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement busiUnitInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[2]")
	@CacheLookup
	public WebElement buisunitDropdown;
	
	 //********************************************************************************************************************************
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[19]/div/div/button")
	@CacheLookup
	public WebElement searchTemplate;
	
	@FindBy(how = How.CSS, using = "button[class='selectTemplate btn btn-primary']")
	@CacheLookup
	public WebElement selectTemplate;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"DataTables_Table_0\"]/tbody/tr/td[5]")
	@CacheLookup
	public WebElement selectAvailTemplate;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/form/div[2]/div[6]/div/button[1]")
	//@CacheLookup
	public WebElement cancelButton;
	
	@FindBy(how = How.XPATH, using = "/html/body/div[9]/div/div/div/div[3]/button[2]")
	//@CacheLookup
	public WebElement yesToCancel;
	@FindBy(how = How.XPATH, using = "/html/body/div[9]/div/div/div")
	//@CacheLookup
	public WebElement popup;
	//Plan
	@FindBy(how = How.ID, using = "Plan")
	//@CacheLookup
	public WebElement homepage;
	
	public void strcomparebool(Boolean var1, Boolean var2) {  
		if(var1 == var2)
		{
			log(PASS, "Once Cancel confirmed, the Home page is displayed sucessfully","Hompage displayed as expected,RESULT=PASS");
		
		}
		else
		{
			log(FAIL, "Once Cancel confirmed, the Home page is NOT displayed sucessfully","Hompage NOT displayed as expected,RESULT=FAIL");
		
		}
	  }
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"header-wrapper\"]/ul/li[3]/ul/li[2]/a[@class='create-Template']")
	//@CacheLookup
	public WebElement findTemplate;
	
	@FindBy(how = How.NAME, using = "planName")
	//@CacheLookup
	public WebElement templateName;
	
	
	@FindBy(how = How.NAME, using = "planDescription")
	//@CacheLookup
	public WebElement templateDesc;
	
	
	//********************************************************************************************************************************** 
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[3]/div/span/span[1]/span/ul/li[2]/input")
	//@CacheLookup
	public WebElement templateState;
	
	//*[@id="content-create-customPlan"]/span/span/span
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span")
	//@CacheLookup
	public WebElement templateStateText;
	
	//********************************************************************************************************************************** 
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[4]/div/span/span[1]/span/ul/li[2]/input")
		//@CacheLookup
	public WebElement templateMarketSegment;
		
	//*[@id="content-create-customPlan"]/span/span/span
		@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span")
		//@CacheLookup
	public WebElement templateMSText;
	
//********************************************************************************************************************************** 
    @FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[5]/div/span/span[1]/span/span[2]")
		//@CacheLookup
	public WebElement templateLob;

	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
		//@CacheLookup
	public WebElement templateLobInput;	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]")
	//@CacheLookup
    public WebElement templateLobText;
	
	//********************************************************************************************************************************** 
    @FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[6]/div/span/span[1]/span/ul/li[2]/input")
		//@CacheLookup
	public WebElement templateProductFmly;

	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span")
		//@CacheLookup
	public WebElement templateProductfmlyinput;	

	//********************************************************************************************************************************** 
    @FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[8]/div/span/span[1]/span/span[2]")
		//@CacheLookup
	public WebElement templateNetwkTier;

	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
		//@CacheLookup
	public WebElement templateNetwkInput;	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]")
	//@CacheLookup
    public WebElement templateNetwrkText;
	//********************************************************************************************************************************** 
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[9]/div/span/span[1]/span/ul/li[2]/input")
		//@CacheLookup
	public WebElement templateCDHPInput;	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span")
	//@CacheLookup
    public WebElement templateCDHPText;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/form/div[2]/div[6]/div/button[2]/span")
	//@CacheLookup
    public WebElement createPlan;
//******************************************************************************************************************************

	
	/**
	 * @param strAccumName : Accumulator Name
	 * @param strAccumValue : Accumulator Value
	 * @param intWaitTime : Wait Time
	 */
	public static void seCustomizationLevel(String strAccumName, String strAccumValue, int intWaitTime)
	{try{
		seWaitForClickableWebElement(driver.findElement(By.xpath("(//span[contains(text(),'"+strAccumName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]")), 10);
		waitForPageLoad(intWaitTime);
		seClick(driver.findElement(By.xpath("(//span[contains(text(),'"+strAccumName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]")), "CustomizationLevel drop down");
		waitForPageLoad(intWaitTime);
		seSetText(driver.findElement(By.xpath("//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")),strAccumValue,"setting text");
		waitForPageLoad(intWaitTime);
		seClick(driver.findElement(By.xpath("(//span[contains(text(),'"+strAccumName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]/following::input[3]/following::span[contains(text(),'"+strAccumValue+"')]")), "Customization Level option Select");
	} catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
	}
}	
	
	
	
	
//*****************************************************************************************************************
	/**
	 * @param strBenefits : Benefits 
	 * @param strAccumulatorGroupName : AccumulatorGroupName
	 * @param strAccumulatorName : AccumulatorName
	 * @param strAccumulatorFirstValue : AccumulatorFirstValue
	 * @param strAccumulatorSecondValue : AccumulatorSecondValue
	 * @param strAccumulatorThirdValue : AccumulatorThirdValue
	 * @param blnFirstAccumulatorValuePresent : checks if FirstAccumulatorValuePresent 
	 * @param blnSecondAccumulatorValuePresent : check if SecondAccumulatorValuePresent
	 * @param blnThirdAccumulatorValuePresent : check if ThirdAccumulatorValuePresent
	 */
	public static void seAccumulatorValueFillTrueFalse(String strBenefits, String strAccumulatorGroupName, String strAccumulatorName, String strAccumulatorFirstValue, String strAccumulatorSecondValue, String strAccumulatorThirdValue, Boolean blnFirstAccumulatorValuePresent,  Boolean blnSecondAccumulatorValuePresent, Boolean blnThirdAccumulatorValuePresent )
	{try{
		//System.out.println("true false");
		//reference : blnFirstLevelAccumulatorPresent==true &&blnSecondLevelAccumulatorPresent==false
            WebElement objRadioButton=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefits   + "')]/following::span[text()='" + strAccumulatorGroupName + "'])[1]/preceding::input[1]"));
            ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objRadioButton); 
            waitForPageLoad();                                     
            if (blnFirstAccumulatorValuePresent) {
                seClick(getWebDriver().findElement(By.xpath("((//h4[contains(text(),'"+strBenefits+"')]/following::span[text()='"+strAccumulatorGroupName+"'])/following::*[contains(text(),'"+strAccumulatorName+"')][1]/following::span[@title='- Please Select -'])[1]")),strAccumulatorName);
                waitForPageLoad(); 
                seSetText(getWebDriver().findElement(By.xpath("((//h4[contains(text(),'"+strBenefits+"')]/following::span[text()='"+strAccumulatorGroupName+"'])/following::*[contains(text(),'"+strAccumulatorName+"')][1]/following::span[@title='- Please Select -'])[1]/following::input[1]")),strAccumulatorFirstValue, "setting text value for First Accumulator");
                seInputKeys(getWebDriver().findElement(By.xpath("((//h4[contains(text(),'"+strBenefits+"')]/following::span[text()='"+strAccumulatorGroupName+"'])/following::*[contains(text(),'"+strAccumulatorName+"')][1]/following::span[@title='- Please Select -'])[1]/following::input[1]")), KeyConstants.ENTER, "Click on Enter ");
            }
            if (blnSecondAccumulatorValuePresent) {
                
            	seClick(getWebDriver().findElement(By.xpath("((//h4[contains(text(),'"+strBenefits+"')]/following::span[text()='"+strAccumulatorGroupName+"'])/following::*[contains(text(),'"+strAccumulatorName+"')][1]/following::span[@title='- Please Select -'])[1]")),strAccumulatorName);
                waitForPageLoad(); 
                seSetText(getWebDriver().findElement(By.xpath("((//h4[contains(text(),'"+strBenefits+"')]/following::span[text()='"+strAccumulatorGroupName+"'])/following::*[contains(text(),'"+strAccumulatorName+"')][1]/following::span[@title='- Please Select -'])[1]/following::input[1]")),strAccumulatorSecondValue, "setting text value for First Accumulator");
                seInputKeys(getWebDriver().findElement(By.xpath("((//h4[contains(text(),'"+strBenefits+"')]/following::span[text()='"+strAccumulatorGroupName+"'])/following::*[contains(text(),'"+strAccumulatorName+"')][1]/following::span[@title='- Please Select -'])[1]/following::input[1]")), KeyConstants.ENTER, "Click on Enter ");
           
            
            
            }
            if (blnThirdAccumulatorValuePresent) {
                
                seClick(getWebDriver().findElement(By.xpath("((//h4[contains(text(),'"+strBenefits+"')]/following::span[text()='"+strAccumulatorGroupName+"'])/following::*[contains(text(),'"+strAccumulatorName+"')][1]/following::span[@title='- Please Select -'])[1]")),strAccumulatorName);
                waitForPageLoad(); 
                seSetText(getWebDriver().findElement(By.xpath("((//h4[contains(text(),'"+strBenefits+"')]/following::span[text()='"+strAccumulatorGroupName+"'])/following::*[contains(text(),'"+strAccumulatorName+"')][1]/following::span[@title='- Please Select -'])[1]/following::input[1]")),strAccumulatorThirdValue, "setting text value for First Accumulator");
                seInputKeys(getWebDriver().findElement(By.xpath("((//h4[contains(text(),'"+strBenefits+"')]/following::span[text()='"+strAccumulatorGroupName+"'])/following::*[contains(text(),'"+strAccumulatorName+"')][1]/following::span[@title='- Please Select -'])[1]/following::input[1]")), KeyConstants.ENTER, "Click on Enter ");
                waitForPageLoad();
            }
	} catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
	}}
	
	/**
	 * @param strAccumulatorGroupNameClicked 
	 * @param strAccumulatorGroupNameSecondClicked
	 * @param strBenefits
	 * @param strAccumulatorGroupName
	 * @param strAccSubType
	 * @param strAccSubButton
	 * @param strAccumulatorName
	 * @param strAccumulatorFirstValue
	 * @param blnFirstAccumulatorValuePresent
	 * @param blnSecondAccumulatorValuePresent
	 * @param blnThirdAccumulatorValuePresent
	 * @param strAccumulatorSecondValue
	 * @param strAccumulatorThirdValue
	 */
	public static void seAccumulatorValueFillTrueTrue(String strAccumulatorGroupNameClicked, String strAccumulatorGroupNameSecondClicked, String strBenefits, String strAccumulatorGroupName, String strAccSubType, String strAccSubButton, String strAccumulatorName, String strAccumulatorFirstValue, Boolean blnFirstAccumulatorValuePresent, Boolean blnSecondAccumulatorValuePresent, Boolean blnThirdAccumulatorValuePresent, String strAccumulatorSecondValue, String strAccumulatorThirdValue )
	{try{//System.out.println("true true");
		//reference : blnFirstLevelAccumulatorPresent==true &&blnSecondLevelAccumulatorPresent==true
		if(strAccumulatorGroupNameClicked.equalsIgnoreCase("Yes"))
    	{
    		WebElement objRadioButtonFirstLevel=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefits   + "')]/following::span[text()='" + strAccumulatorGroupName + "'])[1]/preceding::input[1]"));
    		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objRadioButtonFirstLevel);  
    		waitForPageLoad();}
    	if(strAccumulatorGroupNameSecondClicked.equalsIgnoreCase("Yes"))
    	{
            WebElement objRadioButtonSecondLevel=getWebDriver().findElement(By.xpath("//h4[contains(text(),'"+strBenefits+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccSubType+"')][1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/input[1]"));		
        	((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objRadioButtonSecondLevel);
        	waitForPageLoad();
        }  
       if (blnFirstAccumulatorValuePresent) {
       	 seClick(getWebDriver().findElement(By.xpath("//h4[contains(text(),'"+strBenefits+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccSubType+"')][1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/following::*[@title='- Please Select -'][1]")),strAccumulatorName);
      	 waitForPageLoad();
      	 seSetText(getWebDriver().findElement(By.xpath("//h4[contains(text(),'"+strBenefits+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccSubType+"')][1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/input[1]/following::*[@title='- Please Select -'][1]/following::input[1]")),strAccumulatorFirstValue, "setting text value for First Accumulator");
         waitForPageLoad();
         seClick(getWebDriver().findElement(By.xpath("//h4[contains(text(),'"+strBenefits+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccSubType+"')][1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/input[1]/following::*[@title='- Please Select -'][1]/following::input[1]/following::span[@class='select2-results']")), "Select the value from drop down");
         waitForPageLoad();}
       
       if(blnSecondAccumulatorValuePresent){
        
    	   seClick(getWebDriver().findElement(By.xpath("//h4[contains(text(),'"+strBenefits+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccSubType+"')][1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/following::*[@title='- Please Select -'][1]")),strAccumulatorName);
        	 waitForPageLoad();
        	 seSetText(getWebDriver().findElement(By.xpath("//h4[contains(text(),'"+strBenefits+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccSubType+"')][1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/input[1]/following::*[@title='- Please Select -'][1]/following::input[1]")),strAccumulatorSecondValue, "setting text value for First Accumulator");
           waitForPageLoad();
           seClick(getWebDriver().findElement(By.xpath("//h4[contains(text(),'"+strBenefits+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccSubType+"')][1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/input[1]/following::*[@title='- Please Select -'][1]/following::input[1]/following::span[@class='select2-results']")), "Select the value from drop down");
           waitForPageLoad(); 
       
       
       
       }
       
       if(blnThirdAccumulatorValuePresent){
    	
                          
         seClick(getWebDriver().findElement(By.xpath("//h4[contains(text(),'"+strBenefits+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccSubType+"')][1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/following::*[@title='- Please Select -'][1]")),strAccumulatorName);
         waitForPageLoad();
         seSetText(getWebDriver().findElement(By.xpath("//h4[contains(text(),'"+strBenefits+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccSubType+"')][1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/input[1]/following::*[@title='- Please Select -'][1]/following::input[1]")),strAccumulatorThirdValue, "setting text value for First Accumulator");
         waitForPageLoad();
         seClick(getWebDriver().findElement(By.xpath("//h4[contains(text(),'"+strBenefits+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccSubType+"')][1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/input[1]/following::*[@title='- Please Select -'][1]/following::input[1]/following::span[@class='select2-results']")), "Select the value from drop down");
         waitForPageLoad();                   
                          
                          
                          
                         }
	} catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
	}
	}
	
	/**
	 * @param blnFirstAccumulatorValuePresent
	 * @param blnSecondAccumulatorValuePresent
	 * @param blnThirdAccumulatorValuePresent
	 * @param strBenefits
	 * @param strAccumulatorName
	 * @param strAccumulatorFirstValue
	 * @param strAccumulatorSecondValue
	 * @param strAccumulatorThirdValue
	 */
	public static void seAccumulatorValueFillFalseFalse( Boolean blnFirstAccumulatorValuePresent, Boolean blnSecondAccumulatorValuePresent, Boolean blnThirdAccumulatorValuePresent, String strBenefits , String strAccumulatorName, String strAccumulatorFirstValue, String strAccumulatorSecondValue, String strAccumulatorThirdValue  )
	{try{//System.out.println("false false");
		//blnFirstLevelAccumulatorPresent==false &&blnSecondLevelAccumulatorPresent==false
		if(blnFirstAccumulatorValuePresent){   
        	seClick(getWebDriver().findElement(By.xpath("//h4[contains(text(),'"+strBenefits+"')]/following::select[@frontend-name='"+strAccumulatorName+"']/..//span[contains(text(),'- Please Select -')]")),strAccumulatorName);	
            waitForPageLoad(); 
            seSetText(getWebDriver().findElement(By.xpath("(//span[contains(text(),'"+strAccumulatorName+"')])[1]/following::*[@class='select2-search select2-search--dropdown']/input[1]")),strAccumulatorFirstValue, "setting text value for First Accumulator");
            waitForPageLoad();
            seClick(getWebDriver().findElement(By.xpath("(//span[contains(text(),'"+strAccumulatorName+"')])[1]/following::*[@class='select2-search select2-search--dropdown']/input[1]/following::span[@class='select2-results']")), "Select the value from Drop Down");
            waitForPageLoad();}
        if(blnSecondAccumulatorValuePresent){       
        	
        	
        	seClick(getWebDriver().findElement(By.xpath("//h4[contains(text(),'"+strBenefits+"')]/following::select[@frontend-name='"+strAccumulatorName+"']/..//span[contains(text(),'- Please Select -')]")),strAccumulatorName);	
            waitForPageLoad(); 
            seSetText(getWebDriver().findElement(By.xpath("(//span[contains(text(),'"+strAccumulatorName+"')])[1]/following::*[@class='select2-search select2-search--dropdown']/input[1]")),strAccumulatorSecondValue, "setting text value for First Accumulator");
            waitForPageLoad();
            seClick(getWebDriver().findElement(By.xpath("(//span[contains(text(),'"+strAccumulatorName+"')])[1]/following::*[@class='select2-search select2-search--dropdown']/input[1]/following::span[@class='select2-results']")), "Select the value from Drop Down");
            waitForPageLoad();
        }
        	
        if(blnThirdAccumulatorValuePresent){
        	
        	
            
            seClick(getWebDriver().findElement(By.xpath("//h4[contains(text(),'"+strBenefits+"')]/following::select[@frontend-name='"+strAccumulatorName+"']/..//span[contains(text(),'- Please Select -')]")),strAccumulatorName);	
            waitForPageLoad(); 
            seSetText(getWebDriver().findElement(By.xpath("(//span[contains(text(),'"+strAccumulatorName+"')])[1]/following::*[@class='select2-search select2-search--dropdown']/input[1]")),strAccumulatorThirdValue, "setting text value for First Accumulator");
            waitForPageLoad();
            seClick(getWebDriver().findElement(By.xpath("(//span[contains(text(),'"+strAccumulatorName+"')])[1]/following::*[@class='select2-search select2-search--dropdown']/input[1]/following::span[@class='select2-results']")), "Select the value from Drop Down");
            waitForPageLoad();
            
         }
        
        
	} catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
	}	
		
	}	
	/**
	 * @param strBenefits
	 * @param strAccSubType
	 * @param strAccSubButton
	 * @param strAccumulatorName
	 * @param strAccumulatorGroupName
	 * @param strAccumulatorFirstValue
	 * @param strAccumulatorSecondValue
	 * @param strAccumulatorThirdValue
	 * @param blnFirstAccumulatorValuePresent
	 * @param blnSecondAccumulatorValuePresent
	 * @param blnThirdAccumulatorValuePresent
	 */
	public static void seAccumulatorValueFillFalseTrue( String strBenefits, String strAccSubType, String strAccSubButton, String strAccumulatorName, String strAccumulatorGroupName, String strAccumulatorFirstValue, String strAccumulatorSecondValue, String strAccumulatorThirdValue, Boolean blnFirstAccumulatorValuePresent, Boolean  blnSecondAccumulatorValuePresent, Boolean blnThirdAccumulatorValuePresent)
	{try{
		
		//blnFirstLevelAccumulatorPresent==false &&blnSecondLevelAccumulatorPresent==true
        WebElement objSecondRadioButton=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefits+ "')][1]/following::h4[contains(text(),'" + strAccSubType+ "')][1]/following::h4[contains(.,'" + strAccSubButton + "')]/input)[1]"));
        seClick(objSecondRadioButton,      "second level radio button");
        waitForPageLoad();
        if (blnFirstAccumulatorValuePresent) {
            seClick(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefits+"')]/following::*[contains(text(),'"+strAccSubType+"')])[1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/following::span[contains(text(),'"+strAccumulatorName+"')]/following::span[@role='combobox'][1]")),strAccumulatorName);
            waitForPageLoad();    
            seSetText(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefits+"')]/following::*[contains(text(),'"+strAccSubType+"')])[1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/following::span[contains(text(),'"+strAccumulatorName+"')]/following::span[@role='combobox'][1]/following::input[1]")),strAccumulatorFirstValue, "setting text value for first Accumulator");
            waitForPageLoad();
            seClick(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefits+"')]/following::*[contains(text(),'"+strAccSubType+"')])[1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/following::span[contains(text(),'"+strAccumulatorName+"')]/following::span[@role='combobox'][1]/following::*[@class='select2-search select2-search--dropdown']/input[1]/following::span[@class='select2-results']")), "Select the value from Drop Down");
            waitForPageLoad();
        }
         if(blnSecondAccumulatorValuePresent){
            
        	 seClick(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefits+"')]/following::*[contains(text(),'"+strAccSubType+"')])[1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/following::span[contains(text(),'"+strAccumulatorName+"')]/following::span[@role='combobox'][1]")),strAccumulatorName);
             waitForPageLoad();    
             seSetText(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefits+"')]/following::*[contains(text(),'"+strAccSubType+"')])[1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/following::span[contains(text(),'"+strAccumulatorName+"')]/following::span[@role='combobox'][1]/following::input[1]")),strAccumulatorSecondValue, "setting text value for first Accumulator");
             waitForPageLoad();
             seClick(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefits+"')]/following::*[contains(text(),'"+strAccSubType+"')])[1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/following::span[contains(text(),'"+strAccumulatorName+"')]/following::span[@role='combobox'][1]/following::*[@class='select2-search select2-search--dropdown']/input[1]/following::span[@class='select2-results']")), "Select the value from Drop Down");
             waitForPageLoad(); 
        	 
        	 
         }
         if(blnThirdAccumulatorValuePresent){
        	 
           
            
        	 seClick(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefits+"')]/following::*[contains(text(),'"+strAccSubType+"')])[1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/following::span[contains(text(),'"+strAccumulatorName+"')]/following::span[@role='combobox'][1]")),strAccumulatorName);
             waitForPageLoad();    
             seSetText(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefits+"')]/following::*[contains(text(),'"+strAccSubType+"')])[1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/following::span[contains(text(),'"+strAccumulatorName+"')]/following::span[@role='combobox'][1]/following::input[1]")),strAccumulatorThirdValue, "setting text value for first Accumulator");
             waitForPageLoad();
             seClick(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefits+"')]/following::*[contains(text(),'"+strAccSubType+"')])[1]/following::h4[contains(.,'"+strAccSubButton+"')][1]/following::span[contains(text(),'"+strAccumulatorName+"')]/following::span[@role='combobox'][1]/following::*[@class='select2-search select2-search--dropdown']/input[1]/following::span[@class='select2-results']")), "Select the value from Drop Down");
             waitForPageLoad(); 
                        }
                 
                              
	} catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
	}  
   }

//*****************************************************************************************************************
   /**
    * This Method populates all the header fields for a MasterProduct Plan and cancels the plan
 * @param blnMasterPlan
 * @param intMaxWaitTime
 * @throws Exception
 */
public  void seCancelPlan(boolean blnMasterPlan,int intMaxWaitTime) throws Exception
	{try{
		String strEffectiveDate = getCellValue("EffectiveDate");
		String strProductModel = "";
		if(blnMasterPlan)
		{
			strProductModel= "Master Product";
		}
		String strTemplateVersionID = getCellValue("TemplateVersionID");
		String strApprovalStatus = getCellValue("ApprovalStatus");
		String strCustomizationLevel = getCellValue("CustomizationLevel");
		String strState = getCellValue("State");
		String strMarketSegment = getCellValue("MarketSegment");
		String strMarketUnit = getCellValue("MarketUnit");
		String strProductFamily = getCellValue("ProductFamily");
		String strProductName = getCellValue("ProductName");
		String strCDHPType = getCellValue("CDHP");
		String strBenefitPeriod = getCellValue("BenefitPeriod");
		String strFundingArrangement = getCellValue("FundingArrangement");
		String strBusinessUnit	 = getCellValue("BusinessUnit");
		String strLineOfBusiness = getCellValue("LOB");
		waitForPageLoad(intMaxWaitTime);
		seClick(HomePage.get().create, "Create");
		seClick(HomePage.get().plan, "Plan");
		waitForPageLoad(4,intMaxWaitTime);
		seSetText(CreatePlanLegacyHeaderPage.get().enterEffectiveDate, strEffectiveDate, "Effective date");
		CreatePlanLegacyHeaderPage.get().enterEffectiveDate.sendKeys(Keys.TAB);
		waitForPageLoad(intMaxWaitTime);
		seSelectText(CreatePlanLegacyHeaderPage.get().selectProductModelData, strProductModel, "Product Model",intMaxWaitTime);
		if(strApprovalStatus.equalsIgnoreCase("Approved"))
		{
			
		}
		seSelectText(CreatePlanLegacyHeaderPage.get().customizationLevel, strCustomizationLevel, "Customization Level",intMaxWaitTime);
		seSelectText(CreatePlanLegacyHeaderPage.get().state, strState, "State",intMaxWaitTime);
		seSelectText(CreatePlanLegacyHeaderPage.get().marketSegment, strMarketSegment, "Market Segment",intMaxWaitTime);
		seSelectText(CreatePlanLegacyHeaderPage.get().marketUnit, strMarketUnit, "Market Unit",intMaxWaitTime);
		seSelectText(CreatePlanLegacyHeaderPage.get().lob, strLineOfBusiness, "Line of Business",intMaxWaitTime);
		seSelectText(CreatePlanLegacyHeaderPage.get().productName, strProductName, "Product Name",intMaxWaitTime);
		seSelectText(CreatePlanLegacyHeaderPage.get().productFamily, strProductFamily, "Product Family",intMaxWaitTime);
		seSelectText(CreatePlanLegacyHeaderPage.get().cdhType, strCDHPType, "Consumer Driven Health Plan",intMaxWaitTime);
		seSelectText(CreatePlanLegacyHeaderPage.get().benefitPeriod, strBenefitPeriod, "Benefit Period",intMaxWaitTime);
		seSelectText(CreatePlanLegacyHeaderPage.get().fundingArrangement,strFundingArrangement, "Funding Arrangement",intMaxWaitTime);
		seSelectText(CreatePlanLegacyHeaderPage.get().businessUnit, strBusinessUnit, "Business Unit",intMaxWaitTime);
		if(blnMasterPlan)
		{
		seClick(CreatePlanLegacyHeaderPage.get().selectTemplate	, "Select Template");
		waitForPageLoad(4,intMaxWaitTime);
		seSwitchFrame(FindTemplatePage.get().findTemplateFrame);
		seWaitForClickableWebElement(FindTemplatePage.get().searchCriteria, 60);
		seClick(FindTemplatePage.get().searchCriteria	, "Search Criteria");
		seWaitForClickableWebElement(FindTemplatePage.get().versionId, 120);
		seSetText(FindTemplatePage.get().versionId, strTemplateVersionID, "Template Version ID");
		seClick(FindTemplatePage.get().searchButton	, "Search Criteria");
		waitForPageLoad(intMaxWaitTime);
		FindTemplatePage.get().selectTemplate(strTemplateVersionID);
		}
		waitForPageLoad(intMaxWaitTime);
		getWebDriver().switchTo().defaultContent();
		waitForPageLoad(5,intMaxWaitTime);
		seWaitForClickableWebElement(CreatePlanLegacyHeaderPage.get().cancelButton, 1);
		seClick(CreatePlanLegacyHeaderPage.get().cancelButton, "Cancel Button");
		waitForPageLoad(5,intMaxWaitTime); 
	} catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
	} 
	}
	
		
}	

