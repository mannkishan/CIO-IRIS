package page.planConfigurator;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import com.anthem.selenium.constants.BrowserConstants;
import com.wellpoint.cssd.spider.DownloadFinalizeXML;

import utility.CoreSuperHelper;

public class MasterProductAndLegacyPlanOptionsXMLPage extends CoreSuperHelper {
	private static MasterProductAndLegacyPlanOptionsXMLPage thisIsTestObj;

	public synchronized static MasterProductAndLegacyPlanOptionsXMLPage get() {
		thisIsTestObj = PageFactory.initElements(getWebDriver(), MasterProductAndLegacyPlanOptionsXMLPage.class);
		return thisIsTestObj;
	}

	/* Finding Status of a Plan */
	@FindBy(how = How.XPATH, using = "//table[@class=\"table searchResultsTable fjaTable dataTable\"]//tr[@class=\"rowlink odd\"]//td[contains(text(),'Production')]")
	@CacheLookup
	public WebElement planStatus;

	@FindBy(how = How.XPATH, using = "//*[@id=\"planHeaderWrapper\"]/div/div/div[2]/div[1]/button[2]")
	@CacheLookup
	public WebElement xmlButton;

	@FindBy(how = How.XPATH, using = "/html/body/div[9]/div/div/div/div[2]/table/tbody/tr/td/div/div/div[1]/div/div[2]/button")
	@CacheLookup
	public WebElement xmlFileDownload;

	@FindBy(how = How.XPATH, using = "/html/body/div[9]/div/div/div/div[1]/button")
	@CacheLookup
	public WebElement xmlFileDownloadClose;

	public static int finalAccumCount = 0;

	/**
	 * Method to download XML file for a given Plan
	 * 
	 * @param strID:
	 *            Plan ID
	 * @param strRegion:
	 *            Environment to download XML file from
	 * @param strDownloadPath:
	 *            Path to save the XML file
	 * @return : Whether the file download was successful
	 */
	public boolean seFileDownloadXML(String strID, String strRegion, String strDownloadPath) {
		try {
			File currentFolder = new File(strDownloadPath);
			if (!currentFolder.exists()) {
				new File(strDownloadPath).mkdirs();
			}
			DownloadFinalizeXML.downloadXML(strRegion, strDownloadPath, strID);
			File xmlFileAvailable = new File(strDownloadPath + strRegion + "_" + strID + ".xml");
			if (!xmlFileAvailable.exists()) {
				RESULT_STATUS = false;
				log(FAIL, "XML file is not downloadable",
						"XML file unavailable for download from the region:[" + strRegion + "] for [" + strID + "]");
				return false;
			}
			RESULT_STATUS = true;
			log(PASS, "XML file is downloadable",
					"Downloaded the XML file from the region:[" + strRegion + "] for [" + strID + "]");
			return true;
		} catch (Exception e) {
			RESULT_STATUS = false;
			log(FAIL, "XML file is not downloadable",
					"XML file unavailable for download from the region:[" + strRegion + "] for [" + strID + "]");
			return false;
		}
	}

	/**
	 * Method to build a store all the sheets specified in a workbook
	 * 
	 * @param filename:
	 *            Contains the name of the Workbook to be manipulated
	 * @param strSheetName:
	 *            Contains sheet name
	 * @return : sheet containing all the cell values
	 */
	public HashMap<String, LinkedHashMap<Integer, LinkedList<String>>> seLoadExcelLines(File filename,
			String strSheetName) {
		HashMap<String, LinkedHashMap<Integer, LinkedList<String>>> map = new HashMap<>();
		LinkedHashMap<Integer, LinkedList<String>> hashMap = new LinkedHashMap<Integer, LinkedList<String>>();
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(filename);
			XSSFWorkbook workBook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workBook.getSheet(strSheetName);
			Iterator rows = sheet.rowIterator();
			while (rows.hasNext()) {
				XSSFRow row = (XSSFRow) rows.next();
				Iterator cells = row.cellIterator();
				LinkedList<String> data = new LinkedList();
				while (cells.hasNext()) {
					XSSFCell cell = (XSSFCell) cells.next();
					cell.setCellType(Cell.CELL_TYPE_STRING);
					data.add(cell.getRichStringCellValue().getString().trim());
				}
				hashMap.put(row.getRowNum(), data);
			}
			map.put(strSheetName, hashMap);
			workBook.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return map;
	}

	public boolean seFileDownloadXMLFromUIForPF(String strID) {
        try {              
               File xmlFileAvailable = new File("C:\\Users\\AF16391\\Downloads\\Plan"+ "_" + strID + "_FrontEnd"+".xml");
               if (!xmlFileAvailable.exists()) {
                     RESULT_STATUS = false;
                     log(FAIL, "XML file is not downloadable",
                                   "XML file unavailable for download ");
                     return false;
               }
               RESULT_STATUS = true;
               log(PASS, "XML file is downloadable",
                            "Downloaded the XML file ");
               return true;
        } catch (Exception e) {
               RESULT_STATUS = false;
               log(FAIL, "XML file is not downloadable",
                            "XML file unavailable for download ");
               return false;
        }
}

	
	
	
	
	
	public boolean seFileDownloadXMLFromUI(String strID, String strUserID) {
		try {
			String strXmlFileLocation = "C:\\Users\\"+strUserID+"\\Downloads\\Plan"+ "_" + strID + "_FrontEnd"+".xml";
			File xmlFileAvailable = new File(strXmlFileLocation);
			//System.out.println(strXmlFileLocation);
			String strXmlFileLocationSlash = strXmlFileLocation.replaceAll("[\\,]","\\"); 
			//System.out.println(strXmlFileLocationSlash);
			setCellValue("FileName", strXmlFileLocationSlash);
			if (!xmlFileAvailable.exists()) {
				RESULT_STATUS = false;
				
				log(FAIL, "XML file is not downloadable",
						"XML file unavailable for download");
				return false;
			}
			RESULT_STATUS = true;
			
			log(PASS, "XML file is downloadable",
					"Downloaded the XML file"+strXmlFileLocation);
			return true;
		} catch (Exception e) {
			RESULT_STATUS = false;
			log(FAIL, "XML file is not downloadable",
					"XML file unavailable for download ");
			return false;
		}
	}
	
	
	public boolean seFileDownloadXMLFromUINew(String strID, String strUserID ) {
		try {
			String strXmlFileLocation = "C:\\Users\\"+strUserID+"\\Downloads\\Plan"+ "_" + strID + "_FrontEnd (1)"+".xml";
			File xmlFileAvailable = new File(strXmlFileLocation);
			//System.out.println(strXmlFileLocation);
			String strXmlFileLocationSlash = strXmlFileLocation.replaceAll("[\\,]","\\"); 
			//System.out.println(strXmlFileLocationSlash);
			setCellValue("FileName", strXmlFileLocationSlash);
			if (!xmlFileAvailable.exists()) {
				RESULT_STATUS = false;
				log(FAIL, "XML file is not downloadable",
						"XML file unavailable for download ");
				return false;
			}
			RESULT_STATUS = true;
			log(PASS, "XML file is downloadable",
					"Downloaded the New XML file succesfully at"+strXmlFileLocation);
			return true;
		} catch (Exception e) {
			RESULT_STATUS = false;
			log(FAIL, "XML file is not downloadable",
					"XML file unavailable for download ");
			return false;
		}
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * Method to check if a plan is in production status
	 * 
	 * @param strPlanID:
	 *            Contains the Plan ID for which status is required
	 * @return : sheet containing all the cell values
	 */
	public boolean seCheckPlanInProductionStatus(String strPlanID) {
		try {
			seWaitForClickableWebElement(HomePage.get().find, 10);
			seClick(HomePage.get().find, "Find");
			seClick(HomePage.get().findPlan, "Find Plan");
			seSetText(FindPlanPage.get().planVersionID, strPlanID, "Enter Plan ID");
			seWaitForClickableWebElement(FindPlanPage.get().planSearch, 30);
			seClick(FindPlanPage.get().planSearch, "Search Plan");
			if ((seGetText(MasterProductAndLegacyPlanOptionsXMLPage.get().planStatus).toString())
					.equalsIgnoreCase("Production")) {
				seWaitForClickableWebElement(PlanOptionsPage.get().clickSearchedPlan, 30);
				seClick(PlanOptionsPage.get().clickSearchedPlan, "Click the plan from Search Result");
				seWaitForClickableWebElement(MasterProductAndLegacyPlanOptionsXMLPage.get().xmlButton, 30);
				seClick(MasterProductAndLegacyPlanOptionsXMLPage.get().xmlButton, "XML Button");
				seWaitForClickableWebElement(MasterProductAndLegacyPlanOptionsXMLPage.get().xmlFileDownload, 30);
				seClick(MasterProductAndLegacyPlanOptionsXMLPage.get().xmlFileDownload, "XML Download");
				seWaitForClickableWebElement(MasterProductAndLegacyPlanOptionsXMLPage.get().xmlFileDownloadClose, 30);
				seClick(MasterProductAndLegacyPlanOptionsXMLPage.get().xmlFileDownloadClose, "Close XML");
				return true;
			} else {
				log(INFO, "Plan [" + strPlanID + "] unavailable in Production");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * Method to read form each sheet in a workbook
	 * 
	 * @param strFileFeed:Contains
	 *            the Excel workbook file name
	 * @param strXMLFileName:
	 *            Contains the name of the XML file name
	 * @throws IndexOutOfBoundsException
	 */
	public void seReadTabContents(String strFileFeed, String strXMLFileName) {
		try {
			File fileName = new File(strFileFeed);
			FileInputStream fis = null;
			java.util.List<String> sheetNames = new LinkedList<String>();
			fis = new FileInputStream(fileName);
			XSSFWorkbook workBook = new XSSFWorkbook(fis);
			for (int i = 0; i < workBook.getNumberOfSheets(); i++) {
				sheetNames.add(workBook.getSheetName(i));
			}
			for (String temp : sheetNames) {
				String sheetName = temp;
				XSSFSheet sheet = workBook.getSheet(sheetName);
				int rows = sheet.getPhysicalNumberOfRows();
				finalAccumCount = finalAccumCount + (rows - 1);
				HashMap<String, LinkedHashMap<Integer, LinkedList<String>>> mp = MasterProductAndLegacyPlanOptionsXMLPage
						.get().seLoadExcelLines(fileName, sheetName);
				LinkedHashMap<Integer, LinkedList<String>> map = mp.get(sheetName);
				try {
					for (int i = 1; i <= rows - 1; i++) {
						LinkedList<String> list = map.get(i);
						String strPlanOptionType = list.get(0).trim();
						String strPlanOptionName = list.get(1).trim();
						String strGroupType = list.get(3).trim();
						String strAccumulatorGroupType = list.get(4).trim();
						String strAccumulatorName = list.get(7).trim();
						String strAccumulatorValue1 = list.get(8).trim();
						String strAccumulatorValue2 = list.get(9).trim();
						String strAccumulatorValue3 = list.get(10).trim();
						MasterProductAndLegacyPlanOptionsXMLPage.get().sePlanOptionsAccumulatorValidation(
								strXMLFileName, strPlanOptionType, strGroupType, strAccumulatorGroupType,strAccumulatorName,
								strAccumulatorValue1, strAccumulatorValue2, strAccumulatorValue3);
					}

				} catch (IndexOutOfBoundsException e) {
					e.printStackTrace();
				}
			}
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			log(INFO, "Total Rows Verified [" + finalAccumCount + "]");
			workBook.close();
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
		}
	}

	/**
	 * Method to validate Accumulator values in Plan Options
	 * 
	 * @param strXMLFileName:Contains
	 *            the Excel workbook file name
	 * @param strReqdPlanOptionType:
	 *            Contains the name of the Plan Option Type
	 * @param strReqdGroupType:
	 *            Contains the name of the Group Type
	 * @param strReqdAccumulatorName:
	 *            Contains the name of the Accumulator Name
	 * @param strReqdAccumulatorValue1:
	 *            Contains the name of the first Accumulator Value
	 * @param strReqdAccumulatorValue2:
	 *            Contains the name of the second Accumulator Value
	 * @param strReqdAccumulatorValue3:
	 *            Contains the name of the third Accumulator Value
	 * @throws ClassCastException
	 */
	public void sePlanOptionsAccumulatorValidation(String strXMLFileName, String strReqdPlanOptionType,
			String strReqdGroupType, String strReqdAccumulatorGroupType, String strReqdAccumulatorName, String strReqdAccumulatorValue1,
			String strReqdAccumulatorValue2, String strReqdAccumulatorValue3) {
		try {
			File inputFile = new File(strXMLFileName);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			if (!strReqdGroupType.equalsIgnoreCase("NIL") || !strReqdAccumulatorName.equalsIgnoreCase("NIL")) {
				List<Node> nodes = document.selectNodes("//planOptionGroup/planOption");
				for (Node node : nodes) {

					String planOptionType = ((Element) (node.selectSingleNode("planOptionType")))
							.attributeValue("text");
					if (planOptionType.equalsIgnoreCase(strReqdPlanOptionType)) {
						String planOptionName = ((Element) (node.selectSingleNode("planOptionName")))
								.attributeValue("text");
						List<Node> accumulatorListNode = node.selectSingleNode("accumulatorGroups")
								.selectNodes("accumulatorGroup");
						for (Node accumulatorGroupNode : accumulatorListNode) {
							String accumulatorGroupName = ((Element) (accumulatorGroupNode
									.selectSingleNode("accumulatorList"))).getName();
							if (!strReqdGroupType.equalsIgnoreCase("NIL")) {
								try {
									String groupType = null;
									groupType = ((Element) (accumulatorGroupNode.selectSingleNode("accumulatorList")
											.selectSingleNode("groupType"))).attributeValue("text");
									if (groupType != null) {

										if (groupType.equalsIgnoreCase(strReqdGroupType)) {

											List<Node> accumulatorNodes = accumulatorGroupNode
													.selectSingleNode("accumulatorList")
													.selectSingleNode("accumulators").selectNodes("accumulator");
											seCheckIfNIL(accumulatorNodes, strReqdPlanOptionType, strReqdGroupType,strReqdAccumulatorGroupType,
													strReqdAccumulatorName, strReqdAccumulatorValue1,
													strReqdAccumulatorValue2, strReqdAccumulatorValue3);
										}
									}
								} catch (ClassCastException e) {
									RESULT_STATUS = false;
									log(FAIL, "Given Accumulator " + strReqdAccumulatorName
											+ " values are not available in XML", "RESULT_STATUS=FAIL");

								} catch (NullPointerException e) {

									log(INFO, "Throws Null Pointer Exception As Group Type Not Applicable");
								}
							} else if (strReqdGroupType.equalsIgnoreCase("NIL")
									&& (!strReqdAccumulatorName.equalsIgnoreCase("NIL"))) {
								List<Node> accumulatorNodes = accumulatorGroupNode.selectSingleNode("accumulatorList")
										.selectSingleNode("accumulators").selectNodes("accumulator");
								seCheckIfNIL(accumulatorNodes, strReqdPlanOptionType, strReqdGroupType,strReqdAccumulatorGroupType,
										strReqdAccumulatorName, strReqdAccumulatorValue1, strReqdAccumulatorValue2,
										strReqdAccumulatorValue3);
							}
						}
					}
				}
			} else {
				log(INFO, "Plan Option [" + strReqdPlanOptionType + "] does not have Accumulator ["
						+ strReqdAccumulatorName + "]");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to validate Accumulator values in Plan Options
	 * 
	 * @param strAccumulatorNodes:
	 *            Contains the Accumulator Node values
	 * @param strReqdPlanOptionType:
	 *            Contains the name of the Plan Option Type
	 * @param strReqdPlanOptionType:
	 *            Contains the name of the Plan Option Type
	 * @param strReqdGroupType:
	 *            Contains the name of the Group Type
	 * @param strReqdAccumulatorName:
	 *            Contains the name of the Accumulator Name
	 * @param strReqdAccumulatorValue1:
	 *            Contains the name of the first Accumulator Value
	 * @param strReqdAccumulatorValue2:
	 *            Contains the name of the second Accumulator Value
	 * @param strReqdAccumulatorValue3:
	 *            Contains the name of the third Accumulator Value
	 */
	public void seCheckIfNIL(List<Node> strAccumulatorNodes, String strReqdPlanOptionType, String strReqdGroupType,String strReqdAccumulatorGroupType,
			String strReqdAccumulatorName, String strReqdAccumulatorValue1, String strReqdAccumulatorValue2,
			String strReqdAccumulatorValue3) {
		boolean blnCheckValidAccumValues = false;
		for (Node accumulator : strAccumulatorNodes) {
			String accumulatorName = ((Element) (accumulator.selectSingleNode("accumulatorName")))
					.attributeValue("text");
			String accumulatorTypeValue = ((Element) (accumulator.selectSingleNode("accumulatorType")))
					.attributeValue("text");
			if (accumulatorName.equalsIgnoreCase(strReqdAccumulatorName)&&accumulatorTypeValue.equalsIgnoreCase(strReqdAccumulatorGroupType)) {
				switch (accumulatorTypeValue) {
				case "Choice":
					if (!strReqdAccumulatorValue1.equalsIgnoreCase("NIL")) {

						String choiceValue = ((Element) (accumulator.selectSingleNode("choiceValue")))
								.attributeValue("text");
						if (strReqdAccumulatorName.equalsIgnoreCase("Pursue Strategy")) {
							if (choiceValue.equalsIgnoreCase("Yes")) {
								strReqdAccumulatorValue1 = "Yes";
							} else {
								break;
							}
						}
						blnCheckValidAccumValues = choiceValue.equalsIgnoreCase(strReqdAccumulatorValue1) ? true
								: false;
						seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
								accumulatorName, strReqdAccumulatorValue1, choiceValue);
					}
					break;

				case "Copayment":
					if (!strReqdAccumulatorValue1.equalsIgnoreCase("NIL")
							|| !strReqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
						String amountValue = ((Element) (accumulator.selectSingleNode("amount"))).getText();
						String modifiedAmountValue = amountValue.substring(0, amountValue.indexOf("."));
						if (!seIsAccumNumeric(strReqdAccumulatorValue1)
								&& !strReqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
							String copayChoiceValue = ((Element) (accumulator.selectSingleNode("choiceValue")))
									.attributeValue("text");
							blnCheckValidAccumValues = copayChoiceValue.equalsIgnoreCase(strReqdAccumulatorValue1)
									? true : false;
							seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
									accumulatorName, strReqdAccumulatorValue1, copayChoiceValue);
						}

						if (!strReqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
							blnCheckValidAccumValues = modifiedAmountValue
									.equalsIgnoreCase(strReqdAccumulatorValue2.replaceAll("[$,]", "")) ? true : false;
							seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
									accumulatorName, strReqdAccumulatorValue2, modifiedAmountValue);
						}
					}
					break;

				case "Coinsurance":
					if (!strReqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
						String percentValue = ((Element) (accumulator.selectSingleNode("percentage"))).getText();
						String modifiedPercentValue = percentValue.substring(0, percentValue.indexOf("."));
						blnCheckValidAccumValues = modifiedPercentValue
								.equalsIgnoreCase(strReqdAccumulatorValue1.replaceAll("[$,]", "")) ? true : false;
						seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
								accumulatorName, strReqdAccumulatorValue1, modifiedPercentValue);
					}
					break;

				case "Unit":
					if (!strReqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
						String indivUnitsValue = ((Element) (accumulator.selectSingleNode("individualUnits")))
								.getText();
						String modifiedIndivUnitsValue = indivUnitsValue.substring(0, indivUnitsValue.indexOf("."));
						if (strReqdAccumulatorValue1.equalsIgnoreCase("Unlimited")) {
							strReqdAccumulatorValue1 = "-1";
						}
						blnCheckValidAccumValues = modifiedIndivUnitsValue.equalsIgnoreCase(strReqdAccumulatorValue1)
								? true : false;
						seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
								accumulatorName, strReqdAccumulatorValue1, modifiedIndivUnitsValue);
					}
					if (!strReqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
						String unitBenefitPeriod = ((Element) (accumulator.selectSingleNode("benefitPeriod")))
								.attributeValue("text");
						blnCheckValidAccumValues = unitBenefitPeriod.equalsIgnoreCase(strReqdAccumulatorValue2) ? true
								: false;
						seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
								accumulatorName, strReqdAccumulatorValue2, unitBenefitPeriod);
					}
					break;

				case "Dollar Limit":
					
						if (!strReqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
							String dollarLimitValue = ((Element) (accumulator.selectSingleNode("individualMax")))
									.getText();
							String modifiedDollarLimitValue = dollarLimitValue.substring(0,
									dollarLimitValue.indexOf("."));
							blnCheckValidAccumValues = modifiedDollarLimitValue
									.equalsIgnoreCase(strReqdAccumulatorValue1.replaceAll("[$,]", "")) ? true : false;
							seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
									accumulatorName, strReqdAccumulatorValue1, modifiedDollarLimitValue);
						}
						if (!strReqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
							String dollarBenefitPeriod = ((Element) (accumulator.selectSingleNode("benefitPeriod")))
									.attributeValue("text");
							blnCheckValidAccumValues = dollarBenefitPeriod.equalsIgnoreCase(strReqdAccumulatorValue2)
									? true : false;
							seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
									accumulatorName, strReqdAccumulatorValue2, dollarBenefitPeriod);
						}
					
					break;

				case "Penalty":
					if (!strReqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
						String penaltyPercentValue = ((Element) (accumulator.selectSingleNode("percentage"))).getText();
						String modifiedPenaltyPercentValue = penaltyPercentValue.substring(0,
								penaltyPercentValue.indexOf("."));
						blnCheckValidAccumValues = modifiedPenaltyPercentValue
								.equalsIgnoreCase(strReqdAccumulatorValue1) ? true : false;
						seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
								accumulatorName, strReqdAccumulatorValue1, modifiedPenaltyPercentValue);
					}
					if (!strReqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
						String indivMaxValue = ((Element) (accumulator.selectSingleNode("individualMax"))).getText();
						String modifiedIndivMaxValue = indivMaxValue.substring(0, indivMaxValue.indexOf("."));
						blnCheckValidAccumValues = modifiedIndivMaxValue.equalsIgnoreCase(strReqdAccumulatorValue2)
								? true : false;
						seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
								accumulatorName, strReqdAccumulatorValue2, modifiedIndivMaxValue);
					}
					break;

				case "Deductible":
					if (!strReqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
						String dedIndivMaxValue = ((Element) (accumulator.selectSingleNode("individualMax"))).getText();
						String modifiedDedIndivMaxValue = dedIndivMaxValue.substring(0, dedIndivMaxValue.indexOf("."));
						blnCheckValidAccumValues = modifiedDedIndivMaxValue
								.equalsIgnoreCase(strReqdAccumulatorValue1.replaceAll("[$,]", "")) ? true : false;
						seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
								accumulatorName, strReqdAccumulatorValue1, modifiedDedIndivMaxValue);
					}
					if (!strReqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
						String dedBenefitPeriod = ((Element) (accumulator.selectSingleNode("benefitPeriod")))
								.attributeValue("text");
						blnCheckValidAccumValues = dedBenefitPeriod.equalsIgnoreCase(strReqdAccumulatorValue2) ? true
								: false;
						seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
								accumulatorName, strReqdAccumulatorValue2, dedBenefitPeriod);
					}
					break;

				case "Out of Pocket Maximum":
					if (!strReqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
						String oOPMaxindivMaxValue = ((Element) (accumulator.selectSingleNode("individualMax")))
								.getText();
						String modifiedOOPMaxIndivMaxValue = oOPMaxindivMaxValue.substring(0,
								oOPMaxindivMaxValue.indexOf("."));
						blnCheckValidAccumValues = modifiedOOPMaxIndivMaxValue
								.equalsIgnoreCase(strReqdAccumulatorValue1.replaceAll("[$,]", "")) ? true : false;
						seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
								accumulatorName, strReqdAccumulatorValue1, modifiedOOPMaxIndivMaxValue);
					}
					if (!strReqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
						String oopBenefitPeriod = ((Element) (accumulator.selectSingleNode("benefitPeriod")))
								.attributeValue("text");
						blnCheckValidAccumValues = oopBenefitPeriod.equalsIgnoreCase(strReqdAccumulatorValue2) ? true
								: false;
						seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
								accumulatorName, strReqdAccumulatorValue2, oopBenefitPeriod);
					}
					break;

				case "Copayment Maximum":
					if (!strReqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
						String copayMaxindivMaxValue = ((Element) (accumulator.selectSingleNode("individualMax")))
								.getText();
						String modifiedCopayMaxIndivMaxValue = copayMaxindivMaxValue.substring(0,
								copayMaxindivMaxValue.indexOf("."));
						blnCheckValidAccumValues = modifiedCopayMaxIndivMaxValue
								.equalsIgnoreCase(strReqdAccumulatorValue1.replaceAll("[$,]", "")) ? true : false;
						seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
								accumulatorName, strReqdAccumulatorValue1, modifiedCopayMaxIndivMaxValue);
					}
					if (!strReqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
						String copayMaxBenefitPeriod = ((Element) (accumulator.selectSingleNode("benefitPeriod")))
								.attributeValue("text");
						blnCheckValidAccumValues = copayMaxBenefitPeriod.equalsIgnoreCase(strReqdAccumulatorValue2)
								? true : false;
						seRegisterAccumulatorValueStatus(blnCheckValidAccumValues, strReqdPlanOptionType,
								accumulatorName, strReqdAccumulatorValue2, copayMaxBenefitPeriod);
					}
					break;
				}
			}
		}
	}

	/**
	 * Method to validate Accumulator values in Plan Options
	 * 
	 * @param blnAccStatus:
	 * @param strPlanOptionTypeName:
	 *            Contains the name of the Plan Option Type
	 * @param strAccumulatorName:
	 *            Contains the name of the Accumulator
	 * @param strExpectedAccValue:
	 *            Contains the Expected Accumulator value
	 * @param strFetchedAccValue:
	 *            Contains the Fetched Accumulator value
	 */
	public void seRegisterAccumulatorValueStatus(boolean blnAccStatus, String strPlanOptionTypeName,
			String strAccumulatorName, String strExpectedAccValue, String strFetchedAccValue) {
		try {

			if (blnAccStatus) {

				log(PASS,
						"Plan Option Type " + strPlanOptionTypeName + " with Accumulator " + strAccumulatorName
								+ " having Given value [" + strExpectedAccValue + "] and Expected value ["
								+ strFetchedAccValue + "] are available in XML",
						"RESULT_STATUS=PASS");
			} else {
				log(FAIL,
						"Plan Option Type " + strPlanOptionTypeName + " with Accumulator " + strAccumulatorName
								+ " having Given value [" + strExpectedAccValue + "] and Expected value ["
								+ strFetchedAccValue + "] are not available in XML",
						"RESULT_STATUS=FAIL");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	public void seAccumulatorValidation12() throws Exception {
	try {
		File inputFile = new File("C:\\Users\\AF47903\\Downloads\\Plan_3052470320_FrontEnd.xml");
		System.out.println("file found");
		SAXReader reader = new SAXReader();
		Document document = reader.read(inputFile);
		System.out.println("sax reader");
		List<Node> nodes = document.selectNodes("//planOptionGroup/planOption");
		for (Node node : nodes) {
		String strPlanOptionType = ((Element) (node.selectSingleNode("planOptionType"))).attributeValue("text");
				if (strPlanOptionType.equalsIgnoreCase("Pediatric Vision")) { System.out.println("planOptionType: "+strPlanOptionType);
				
			
				
				
			/*		String strAccumulatorName = ((Element) (node.selectSingleNode("accumulatorName"))).attributeValue("text");
					if (strAccumulatorName.equalsIgnoreCase("In Network Pediatric Vision Coinsurance")) {System.out.println("strAccumulatorName"+strAccumulatorName);
						String strPercentage = ((Element) (node.selectSingleNode("percentage"))).getText();
								if (strPercentage.equalsIgnoreCase("65.0")) {System.out.println("percentage"+strPercentage);	
						             
						              System.out.println( "test passed");
				
									}
								}
				*/
					}}} catch (ClassCastException e) {
								System.out.println("error");
						
							}
						} 
					
	

	public void seAccumulatorValidation(String strPlanOptionTypeUI,String strAccumulatorNameUI,String strPercentageUI) throws Exception {
		try {
    String strFileName = getCellValue("FileName");
	File inputFile = new File(strFileName);
	SAXReader reader = new SAXReader();
	Document document = reader.read(inputFile);
	
		List<Node> nodes = document.selectNodes("//planOptionGroup/planOption");
		for (Node node : nodes) {
			String strPlanOptionTypeXML = ((Element) (node.selectSingleNode("planOptionType"))).attributeValue("text");
			if (strPlanOptionTypeXML.equalsIgnoreCase(strPlanOptionTypeUI)) { System.out.println("planOptionType: "+strPlanOptionTypeXML);
			
				String strPlanOptionName = ((Element) (node.selectSingleNode("planOptionName"))).attributeValue("text");
				//System.out.println("planOptionName: "+strPlanOptionName);
				List<Node> accumulatorListNode = node.selectSingleNode("accumulatorGroups").selectNodes("accumulatorGroup");
				//System.out.println("accumulator accu Gps");
				for (Node accumulatorGroupNode : accumulatorListNode) {
					String strAccumulatorGroupName = ((Element) (accumulatorGroupNode.selectSingleNode("accumulatorList"))).getName();
					//System.out.println("Accumulator List: "+strAccumulatorGroupName);
						try {
							String groupType = null;
							groupType = ((Element) (accumulatorGroupNode.selectSingleNode("accumulatorList")
									.selectSingleNode("groupType"))).attributeValue("text");
							if (groupType != null) {								
									List<Node> accumulatorNodes = accumulatorGroupNode.selectSingleNode("accumulatorList").selectSingleNode("accumulators").selectNodes("accumulator");
									//For finding accvalues
								}
						} catch (ClassCastException e) {
							
						} catch (NullPointerException e) {

							//log(INFO, "Throws Null Pointer Exception As Group Type Not Applicable");
						}
				
						List<Node> accumulatorNodes = accumulatorGroupNode.selectSingleNode("accumulatorList").selectSingleNode("accumulators").selectNodes("accumulator");
						//System.out.println("Now in accumulator");
						for(Node accumulatorNameNode : accumulatorNodes){
						String strAccumulatorNameXML = ((Element) (accumulatorNameNode.selectSingleNode("accumulatorName"))).attributeValue("text");
						
						if (strAccumulatorNameXML.equalsIgnoreCase(strAccumulatorNameUI)) {//System.out.println("strAccumulatorName"+strAccumulatorNameXML);
							String strPercentageXML = ((Element) (accumulatorNameNode.selectSingleNode("individualMax"))).getText();
									if (strPercentageXML.equalsIgnoreCase(strPercentageUI)) {//System.out.println("percentage"+strPercentageXML);	
							             
							              //System.out.println( "test passed");
							              log(PASS, "Validated the Accumulator value from UI against the XML file located at "+strFileName,"RESULT =PASS");
										}
									else{//System.out.println("percentage"+strPercentageXML);	
						             
						              //System.out.println( "test failed");
						              log(FAIL, "Validation for Accumulator value from UI against the XML file located at "+strFileName+" failed","RESULT =FAIL");
									}
									}
				}}}
		}
		}
		catch (Exception e) {
			log(FAIL, "Exception occured while parsing XML");
		}
	}
	
	public void seAccumulatorValidationNew(String strPlnOptionType,String strAccumName,String strPercent) throws Exception {
		try {
    String strFileName = getCellValue("FileName");
	File inputFile = new File(strFileName);
	SAXReader reader = new SAXReader();
	Document document = reader.read(inputFile);
	
		List<Node> nodes = document.selectNodes("//planOptionGroup/planOption");
		for (Node node : nodes) {
			String strPlanOptionType = ((Element) (node.selectSingleNode("planOptionType"))).attributeValue("text");
			if (strPlanOptionType.equalsIgnoreCase(strPlnOptionType)) { System.out.println("planOptionType: "+strPlanOptionType);
			
				String strPlanOptionName = ((Element) (node.selectSingleNode("planOptionName"))).attributeValue("text");
				System.out.println("planOptionName: "+strPlanOptionName);
				List<Node> accumulatorListNode = node.selectSingleNode("accumulatorGroups").selectNodes("accumulatorGroup");
				System.out.println("accumulator accu Gps");
				for (Node accumulatorGroupNode : accumulatorListNode) {
					String strAccumulatorGroupName = ((Element) (accumulatorGroupNode.selectSingleNode("accumulatorList"))).getName();
					System.out.println("Accumulator List: "+strAccumulatorGroupName);
						try {
							String groupType = null;
							groupType = ((Element) (accumulatorGroupNode.selectSingleNode("accumulatorList")
									.selectSingleNode("groupType"))).attributeValue("text");
							if (groupType != null) {								
									List<Node> accumulatorNodes = accumulatorGroupNode.selectSingleNode("accumulatorList").selectSingleNode("accumulators").selectNodes("accumulator");
									//For finding accvalues
								}
						} catch (ClassCastException e) {
							
						} catch (NullPointerException e) {

							log(INFO, "Throws Null Pointer Exception As Group Type Not Applicable");
						}
				
						List<Node> accumulatorNodes = accumulatorGroupNode.selectSingleNode("accumulatorList").selectSingleNode("accumulators").selectNodes("accumulator");
						System.out.println("Now in accumulator");
						for(Node accumulatorNameNode : accumulatorNodes){
						String strAccumulatorName = ((Element) (accumulatorNameNode.selectSingleNode("accumulatorName"))).attributeValue("text");
						
						if (strAccumulatorName.equalsIgnoreCase(strAccumName)) {System.out.println("strAccumulatorName"+strAccumulatorName);
							String strPercentage = ((Element) (accumulatorNameNode.selectSingleNode("individualMax"))).getText();
									if (strPercentage.equalsIgnoreCase(strPercent)) {System.out.println("percentage"+strPercentage);	
							             
							              System.out.println( "test passed");
							              log(PASS, "New XML File is generated and downloaded at"+strFileName);
							              log(PASS, "Validated the Accumulator value from UI against the new XML file located at "+strFileName);
										}
									}
				}}}
		}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	
	
	/**
	 * Method to validate Accumulator values in Plan Options
	 * 
	 * @param strValue:
	 *            Contains the value to be verified for number or string
	 * @throws: NumberFormatException
	 * @return: whether the given value is a string or number
	 */
	public static boolean seIsAccumNumeric(String strValue) {
		try {
			double dblValue = Double.parseDouble(strValue);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
}
