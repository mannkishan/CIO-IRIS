package page.planConfigurator;


import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.groupConfigurator.LoginPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.FindTemplatePage;
import page.planConfigurator.HomePage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;


public class TemplateCreation extends CoreSuperHelper {
	
	
	private static TemplateCreation thisTestObj;	
	public synchronized static TemplateCreation get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), TemplateCreation.class);
		return thisTestObj;
	}

	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	static String strTemperoaryBenefitName;

	@FindBy(how = How.XPATH, using = "//a[@class='create-Template' and text()='Template']")
	@CacheLookup
	public WebElement createTemplate;
	
	@FindBy(how = How.XPATH, using = "//textarea[@data-name='Template Name']")
	@CacheLookup
	public WebElement templateNameBox;
	
	@FindBy(how = How.XPATH, using = "//select[@data-name='State']/../span/span[1]/span/ul/li[2]/input")
	@CacheLookup
	public WebElement templateState;
	
	@FindBy(how = How.XPATH, using = "//select[@data-name='Market Segment']/../span/span[1]/span/ul/li[2]/input")
	@CacheLookup
	public WebElement templateMarketSegment;
	
	@FindBy(how = How.XPATH, using = "//select[@data-name='Line of Business']/../span/span[1]/span")
	@CacheLookup
	public WebElement templateLOB;
	
	@FindBy(how = How.XPATH, using = "//li[@role='treeitem' and substring(@id,string-length(@id) - string-length('Medical') +1) = 'Medical']")
	@CacheLookup
	public WebElement medicalLOB;
	
	@FindBy(how = How.XPATH, using = "//select[@data-name='Product Family']/../span/span[1]/span/ul/li[@class='select2-search select2-search--inline']/input[1]")
	@CacheLookup
	public WebElement templateProductFamily;
	
	@FindBy(how = How.XPATH, using = "//select[@data-name='Network Tier']/../span/span[1]/span")
	@CacheLookup
	public WebElement networkTier;
		
	@FindBy(how = How.XPATH, using = "//li[@role='treeitem' and substring(@id,string-length(@id) - string-length('Tier1') +1) = 'Tier1']")
	@CacheLookup
	public WebElement network2Tier;
	
	@FindBy(how = How.XPATH, using = "//select[@data-name='Consumer Driven Health Plan']/../span/span[1]/span/ul/li[@class='select2-search select2-search--inline']/input[1]")
	@CacheLookup
	public WebElement Cdhp;
	
	@FindBy(how = How.XPATH, using = "//select[@data-name='Funding Arrangement']/../span/span[1]/span/ul/li[2]/input")
	@CacheLookup
	public WebElement fundingArrangement;
	
	@FindBy(how = How.XPATH, using = "//button[@class='doAction btn btn-primary pull-right']")
	@CacheLookup
	public WebElement create;
	
	@FindBy(how = How.XPATH, using = "//div/span[text()='Template Version ID: ']/..")
	@CacheLookup
	public WebElement getPlanId;
	
   

	
	/**
	 * Method to fetch the Data from Excel file and put into the spider PC application
	 * @param strTemplateId :The template ID which is to be filled with data from the excel sheet
	 * @param strFilePath :the path where the data excel sheet is located
	 * @return :returns the template ID after moving it to production status
	 * @throws Exception 
	 */
	public static String seTemplateCreation(String strTemplateId,String strFilePath) throws Exception {
		
           try{
				seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
			    LoginPage.get().loginApplication(strUserProfile);
				waitForPageLoad();
				seClick(HomePage.get().find, "Find");

				seClick(HomePage.get().findTemplate, "Find Plan");
				waitForPageLoad();
				
				seSetText(page.planConfigurator.FindTemplatePage.get().templateVersionID, strTemplateId,"text in plan version id textbox");				
				seClick(page.planConfigurator.FindTemplatePage.get().templateSearch, "Search template");
				waitForPageLoad(40);
				((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);
				waitForPageLoad();
				Boolean blnIsLevelOneAccumTypePresent;
				Boolean blnIsLevelTwoAccumTypePresent;
				Boolean blnIsTextValueOnePresent;
				Boolean blnIsTextValueTwoPresent;
				Boolean blnIsTextValueThreePresent;

				File fileName = new File(strFilePath);
				FileInputStream fis = null;
				List<String> sheetNames = new LinkedList<String>();
				fis = new FileInputStream(fileName);
				XSSFWorkbook workBook = new XSSFWorkbook(fis);
				
				for (int i = 0; i < workBook.getNumberOfSheets(); i++) {
					sheetNames.add(workBook.getSheetName(i));
				}

				for (String strTemp : sheetNames) {
					String strSheetName = strTemp;
					XSSFSheet sheet = workBook.getSheet(strSheetName);
					int rows = sheet.getPhysicalNumberOfRows();

					HashMap<String, LinkedHashMap<Integer, LinkedList<String>>> mp = TemplateCreation.get().seLoadExcelLines(fileName, strSheetName);
					LinkedHashMap<Integer, LinkedList<String>> map = mp.get(strSheetName);
					
					for (int i = 1; i <= rows - 1; i++)

					{
						LinkedList<String> list = map.get(i);
						String strOptionTab = strSheetName;
						String strBenefit = list.get(0).trim();
						String strAccumulatorGroupName = list.get(1).trim();
						String strFirstLevelRadioButtonStatus=list.get(2).trim();
						String strAccumulatorTypeName = list.get(3).trim();
						String strAccumulatorSubTypeName = list.get(5).trim();
						String strSubLevelRadioButtonStatus=list.get(6).trim();
						String strAccumulatorName = list.get(7).trim();
						String strFirstTextBoxValue = list.get(8).trim();
						String strSecondTextBoxValue = list.get(9).trim();
						String strThirdTextBoxValue = list.get(10).trim();

						if (strAccumulatorGroupName.contains("NIL")) {
							blnIsLevelOneAccumTypePresent = false;
						} else {
							blnIsLevelOneAccumTypePresent = true;
						}
						if (strAccumulatorTypeName.contains("NIL")) {
							blnIsLevelTwoAccumTypePresent = false;
						} else {
							blnIsLevelTwoAccumTypePresent = true;
						}
 
						if (strFirstTextBoxValue.contains("NIL")) {
							blnIsTextValueOnePresent = false;
						} else {
							blnIsTextValueOnePresent = true;
						}
						if (strSecondTextBoxValue.contains("NIL")) {
							blnIsTextValueTwoPresent = false;
						} else {
							blnIsTextValueTwoPresent = true;
						}
						if (strThirdTextBoxValue.contains("NIL")) {
							blnIsTextValueThreePresent = false;
						} else {
							blnIsTextValueThreePresent = true;
						}
						
						if(i==1)
						{
						WebElement wbOptionTab = getWebDriver().findElement(By.xpath("//a[contains(text(),'" + strOptionTab + "')]"));
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", wbOptionTab);
						waitForPageLoad();
						
						}												
				       if(strBenefit.equals(strTemperoaryBenefitName)==false)  
				       {   TemplateCreation.get().seClickBenefit(strBenefit);
				       }
				if (blnIsLevelOneAccumTypePresent == true && blnIsLevelTwoAccumTypePresent == false)
				{
					seSetAccumulatorTextBoxValues(strFirstLevelRadioButtonStatus, strBenefit, strAccumulatorGroupName,blnIsTextValueOnePresent, blnIsTextValueTwoPresent, blnIsTextValueThreePresent, strAccumulatorName,strFirstTextBoxValue, strSecondTextBoxValue, strThirdTextBoxValue);
				}
				else if (blnIsLevelOneAccumTypePresent == true && blnIsLevelTwoAccumTypePresent == true) 
				{
					seSetAccumulatorTextBoxValues(strFirstLevelRadioButtonStatus, strSubLevelRadioButtonStatus,strBenefit, strAccumulatorGroupName, strAccumulatorTypeName, strAccumulatorSubTypeName,strAccumulatorName, blnIsTextValueOnePresent, blnIsTextValueTwoPresent, blnIsTextValueThreePresent,strFirstTextBoxValue, strSecondTextBoxValue, strThirdTextBoxValue);
				} 
				else if (blnIsLevelOneAccumTypePresent == false && blnIsLevelTwoAccumTypePresent == false) 
				{
					seSetAccumulatorTextBoxValues(strBenefit, strAccumulatorName, blnIsTextValueOnePresent,blnIsTextValueTwoPresent, blnIsTextValueThreePresent, strFirstTextBoxValue, strSecondTextBoxValue,strThirdTextBoxValue);

				} else if (blnIsLevelOneAccumTypePresent == false && blnIsLevelTwoAccumTypePresent == true) {

					seSetAccumulatorTextBoxValues(strSubLevelRadioButtonStatus, strBenefit, strAccumulatorTypeName,	strAccumulatorSubTypeName, strAccumulatorName, blnIsTextValueOnePresent, blnIsTextValueTwoPresent,blnIsTextValueThreePresent, strFirstTextBoxValue, strSecondTextBoxValue, strThirdTextBoxValue);
				}					
					}}  
				waitForPageLoad();

				return strTemplateId;
}            
           catch (Exception e) {
					e.printStackTrace();
					//log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());					
					return strTemplateId;
} 
           
	}
	
		
	
	/**
	 * Method to provide values to the accumulator
	 * @param strSubLevelRadioButtonStatus :whether radio button is present at sub level
	 * @param strBenefit : Benefit name
	 * @param strAccumulatorTypeName :Accumulator type name were the current accumulator belongs to
	 * @param strAccumulatorSubTypeName : Accumulator type name were the current accumulator belongs to
	 * @param strAccumulatorName :current accumulator that is to be filled with values
	 * @param blnIsTextValueOnePresent : first text box is to be filled or not
	 * @param blnIsTextValueTwoPresent : second text box is to be filled or not
	 * @param blnIsTextValueThreePresent : third text box is to be filled or not
	 * @param strFirstTextBoxValue : value of the first text box
	 * @param strSecondTextBoxValue : value of the second text box
	 * @param strThirdTextBoxValue : value of the third text box
	 */
	private static void seSetAccumulatorTextBoxValues(String strSubLevelRadioButtonStatus, String strBenefit,
			String strAccumulatorTypeName, String strAccumulatorSubTypeName, String strAccumulatorName,
			Boolean blnIsTextValueOnePresent, Boolean blnIsTextValueTwoPresent, Boolean blnIsTextValueThreePresent,
			String strFirstTextBoxValue, String strSecondTextBoxValue, String strThirdTextBoxValue) {
		try{
			 Actions act=new Actions(driver);
			
		if( strSubLevelRadioButtonStatus.equalsIgnoreCase("Yes")&&getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit+ "')][1]/following::h4[contains(text(),'" + strAccumulatorTypeName+ "')][1]/following::h4[text()[contains(.,'"+strAccumulatorSubTypeName+"')] and not(contains(.,'"+" "+strAccumulatorSubTypeName+"')) and not(contains(.,'"+strAccumulatorSubTypeName+" "+"'))]/input)[1]")).isSelected()==false)		
		{
			WebElement RadioButton2=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit+ "')][1]/following::h4[contains(text(),'" + strAccumulatorTypeName+ "')][1]/following::h4[text()[contains(.,'"+strAccumulatorSubTypeName+"')] and not(contains(.,'"+" "+strAccumulatorSubTypeName+"')) and not(contains(.,'"+strAccumulatorSubTypeName+" "+"'))]/input)[1]"));
		    seClick(RadioButton2,	strAccumulatorSubTypeName);
			waitForPageLoad(75);}
    		
               if(blnIsTextValueOnePresent){	
            	   
      		        waitForPageLoad(1,175);
            		WebElement clickTextBox=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')]/input)[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][1]/span[1]"));
            		act.moveToElement(clickTextBox).click().build().perform();
                    seSetText(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')]/input)[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][1]/following::input[3]")),strFirstTextBoxValue, strFirstTextBoxValue+" as text value");
	                act.moveToElement(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')]/input)[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][1]/following::input[3]/following::span[@class='select2-match' and contains(text(),'"+strFirstTextBoxValue+"')]"))).click().build().perform();
	                waitForPageLoad(1,200);
	              }
             
	          if(blnIsTextValueTwoPresent){
			        waitForPageLoad(1,175);
	        	    WebElement clickTextBox=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')]/input)[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][2]/span[1]"));
            		act.moveToElement(clickTextBox).click().build().perform();
	                seSetText(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')]/input)[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][2]/following::input[3]")),strSecondTextBoxValue, strSecondTextBoxValue+" as text value");
	                act.moveToElement(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')]/input)[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][2]/following::input[3]/following::span[@class='select2-match' and contains(text(),'"+strSecondTextBoxValue+"')]"))).click().build().perform();
	                waitForPageLoad(1,200);
   
	          }
            
	         if(blnIsTextValueThreePresent){
		           waitForPageLoad(1,175);
	        	   WebElement clickTextBox=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')]/input)[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][3]/span[1]"));
            		act.moveToElement(clickTextBox).click().build().perform();
	               seSetText(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')]/input)[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][3]/following::input[3]")),strThirdTextBoxValue, strThirdTextBoxValue+" as text value");
	               act.moveToElement(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')]/input)[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][3]/following::input[3]/following::span[@class='select2-match' and contains(text(),'"+strThirdTextBoxValue+"')]"))).click().build().perform();
	                waitForPageLoad(1,200);

	         }
		} 
		catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());}

		
	}

public static void seMoveTemplateToProduction(String strTemplateId)
{
	seClick(PlanHeaderPage.get().save, "Save button");
waitForPageLoad(60);
seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//a[text()='Request Audit']")), 5);
seClick(getWebDriver().findElement(By.xpath("//a[text()='Request Audit']")), "request audit");
waitForPageLoad();
seClick(getWebDriver().findElement(By.xpath("//label[text()='Reason Code']/following::span[text()='- Please Select -'][1]")), "reason code");
seSetText(getWebDriver().findElement(By.xpath("//label[text()='Reason Code']/following::span[text()='- Please Select -'][1]/following::input[@role='textbox'][1]")), "Other", "reason code");
seClick(getWebDriver().findElement(By.xpath("//label[text()='Reason Code']/following::span[text()='- Please Select -'][1]/following::input[@role='textbox'][1]/following::span[@class='select2-match' and text()='Other']")), "Other");
seSetText(getWebDriver().findElement(By.xpath("//label[text()='Comment']/../div/textarea")), "test", "comment");
seClick(getWebDriver().findElement(By.xpath("//button[@class='workflowAction btn btn-primary pull-right']")), "request audit button");
waitForPageLoad(45);				
try{
	seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 180);}				
catch(TimeoutException e){
seClick(PlanHeaderPage.get().close, "Close button");}

seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
waitForPageLoad();				
seClick(PlanHeaderPage.get().userLogout, "Logout");
waitForPageLoad();
seCloseBrowser();
seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
waitForPageLoad();
LoginPage.get().loginApplication(strUserProfileApprover);
waitForPageLoad();
seClick(HomePage.get().find, "Find");
seClick(HomePage.get().findTemplate, "Find template");
waitForPageLoad();
seClick(FindTemplatePage.get().templateVersionID, "template ID textbox");
seSetText(page.planConfigurator.FindTemplatePage.get().templateVersionID, strTemplateId,strTemplateId+"in plan version id textbox");				
seClick(page.planConfigurator.FindTemplatePage.get().templateSearch, "Search template");
waitForPageLoad();

((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);
waitForPageLoad(45);
seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 2);
Boolean status= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
 
 if(status==true)
	{
		log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");												
	}
	else
	{
		log(FAIL, "plan takes more time to load","plan is still in 'process in progress' status,RESULT=FAIL");												
	}
waitForPageLoad();
seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 5);
((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanHeaderPage.get().approveAudit);
waitForPageLoad(185);
seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "reason code");
seClick(PlanTransitionPage.get().approved, "approved");
seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
waitForPageLoad(45);
seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//a[text()='Finalize']")), 6);
seClick(getWebDriver().findElement(By.xpath("//a[text()='Finalize']")), "finalize");
waitForPageLoad();
seClick(PlanTransitionPage.get().finalizeButtoninPT, "finalize");
waitForPageLoad(45);
seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//a[text()='Move to Production']")), 6);
seClick(getWebDriver().findElement(By.xpath("//a[text()='Move to Production']")), "move to production");
waitForPageLoad();

seClick(getWebDriver().findElement(By.xpath("//button[@class='workflowAction btn btn-primary pull-right']")),"move to production");
waitForPageLoad();
}


	/**
 	 * Method to provide values to the accumulator
	 * @param strBenefit : Benefit name
	 * @param strAccumulatorName :current accumulator that is to be filled with values
	 * @param blnIsTextValueOnePresent : first text box is to be filled or not
	 * @param blnIsTextValueTwoPresent : second text box is to be filled or not
	 * @param blnIsTextValueThreePresent : third text box is to be filled or not
	 * @param strFirstTextBoxValue : value of the first text box
	 * @param strSecondTextBoxValue : value of the second text box
	 * @param strThirdTextBoxValue : value of the third text box
	 */
	private static void seSetAccumulatorTextBoxValues(String strBenefit, String strAccumulatorName,
			Boolean blnIsTextValueOnePresent, Boolean blnIsTextValueTwoPresent, Boolean blnIsTextValueThreePresent,
			String strFirstTextBoxValue, String strSecondTextBoxValue, String strThirdTextBoxValue) {
		try{
			 Actions act=new Actions(driver);
		   if(blnIsTextValueOnePresent){		
		        waitForPageLoad(1,175);
			     WebElement clickTextBox=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[1]/span[1]"));
          		act.moveToElement(clickTextBox).click().build().perform();
		         seSetText(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[1]/following::input[3]")),strFirstTextBoxValue, strFirstTextBoxValue+" as text value");		         
	             act.moveToElement(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[1]/following::input[3]/following::span[@class='select2-match' and contains(text(),'"+strFirstTextBoxValue+"')]"))).click().build().perform();
	                waitForPageLoad(1,200);
	            }
	        
	        if(blnIsTextValueTwoPresent){	
		        waitForPageLoad(1,175);
	        	 WebElement clickTextBox=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[2]/span[1]"));
         		act.moveToElement(clickTextBox).click().build().perform();
	             seSetText(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox']])[2]/following::input[3]")),strSecondTextBoxValue, strSecondTextBoxValue+" as text value");
	             act.moveToElement(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[2]/following::input[3]/following::span[@class='select2-match' and contains(text(),'"+strSecondTextBoxValue+"')]"))).click().build().perform();
	                waitForPageLoad(1,200);
	             }
	        
	        if(blnIsTextValueThreePresent){	
	        
	          	 WebElement clickTextBox=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[3]/span[1]"));
			        waitForPageLoad(1,175);
         		act.moveToElement(clickTextBox).click().build().perform();
	             seSetText(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[3]/following::input[3]")),strThirdTextBoxValue, strThirdTextBoxValue+" as text value");
	             act.moveToElement(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[3]/following::input[3]/following::span[@class='select2-match' and contains(text(),'"+strThirdTextBoxValue+"')]"))).click().build().perform();
	                waitForPageLoad(1,200);
		}	} 
		catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());}
	
	}




	/**
 	 * Method to provide values to the accumulator
	 * @param strFirstLevelRadioButtonStatus : whether radio button is present at first level
	 * @param strSubLevelRadioButtonStatus : whether radio button is present at sub level
	 * @param strBenefit : Benefit name
	 * @param strAccumulatorGroupName : Accumulator group name were the accumulator belongs to
	 * @param strAccumulatorTypeName : Accumulator type name were the current accumulator belongs to
	 * @param strAccumulatorSubTypeName : Accumulator type name were the current accumulator belongs to
	 * @param strAccumulatorName :current accumulator that is to be filled with values
	 * @param blnIsTextValueOnePresent : first text box is to be filled or not
	 * @param blnIsTextValueTwoPresent : second text box is to be filled or not
	 * @param blnIsTextValueThreePresent : third text box is to be filled or not
	 * @param strFirstTextBoxValue : value of the first text box
	 * @param strSecondTextBoxValue : value of the second text box
	 * @param strThirdTextBoxValue : value of the third text box
	 */
	private static void seSetAccumulatorTextBoxValues(String strFirstLevelRadioButtonStatus,
			String strSubLevelRadioButtonStatus, String strBenefit, String strAccumulatorGroupName,
			String strAccumulatorTypeName, String strAccumulatorSubTypeName, String strAccumulatorName,
			Boolean blnIsTextValueOnePresent, Boolean blnIsTextValueTwoPresent, Boolean blnIsTextValueThreePresent, String strFirstTextBoxValue, String strSecondTextBoxValue, String strThirdTextBoxValue)
	{
		try{	
			 Actions act=new Actions(driver);
		if(strFirstLevelRadioButtonStatus.equalsIgnoreCase("Yes")&&getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit	+ "')]/following::span[text()='" + strAccumulatorGroupName + "'])[1]/preceding::input[1]")).isSelected()==false){	
            WebElement RadioButton1=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit	+ "')]/following::span[text()='" + strAccumulatorGroupName + "'])[1]/preceding::input[1]"));
            seClick(RadioButton1,	strAccumulatorGroupName);
		    waitForPageLoad(75);
		    }
		
		if(strSubLevelRadioButtonStatus.equalsIgnoreCase("Yes")&&getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit+ "')]/following::span[contains(text(),'" + strAccumulatorGroupName+ "')][1]/preceding::input[1]/following::h4[contains(text(),'" + strAccumulatorTypeName+ "')][1]/following::h4[text()[contains(.,'"+strAccumulatorSubTypeName+"')] and not(contains(.,'"+" "+strAccumulatorSubTypeName+"')) and not(contains(.,'"+strAccumulatorSubTypeName+" "+"'))]/input)[1]")).isSelected()==false){
		    WebElement RadioButton2=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit+ "')]/following::span[contains(text(),'" + strAccumulatorGroupName+ "')][1]/preceding::input[1]/following::h4[contains(text(),'" + strAccumulatorTypeName+ "')][1]/following::h4[text()[contains(.,'"+strAccumulatorSubTypeName+"')] and not(contains(.,'"+" "+strAccumulatorSubTypeName+"')) and not(contains(.,'"+strAccumulatorSubTypeName+" "+"'))]/input)[1]"));
			seClick(RadioButton2,	strAccumulatorSubTypeName);
			waitForPageLoad(75);}
		
				if (blnIsTextValueOnePresent) {
			        waitForPageLoad(1,175);
					WebElement clickTextBox=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')])[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][1]/span[1]"));
            		act.moveToElement(clickTextBox).click().build().perform();
			        seSetText(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')])[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][1]/following::input[3]")),strFirstTextBoxValue, strFirstTextBoxValue+" as text value");
			        act.moveToElement(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')])[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][1]/following::input[3]/following::span[@class='select2-match' and contains(text(),'"+strFirstTextBoxValue+"')]"))).click().build().perform();
	                waitForPageLoad(1,200);
				}
				if(blnIsTextValueTwoPresent){
			        waitForPageLoad(1,175);
					WebElement clickTextBox=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')])[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][2]/span[1]"));
            		act.moveToElement(clickTextBox).click().build().perform();
					seSetText(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')])[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][2]/following::input[3]")),strSecondTextBoxValue, strSecondTextBoxValue+" as text value");
			        act.moveToElement(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')])[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][2]/following::input[3]/following::span[@class='select2-match' and contains(text(),'"+strSecondTextBoxValue+"')]"))).click().build().perform();
	                waitForPageLoad(1,200);
				}
				if(blnIsTextValueThreePresent)
				{
			        waitForPageLoad(1,175);
					WebElement clickTextBox=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')])[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][3]/span[1]"));
            		act.moveToElement(clickTextBox).click().build().perform();
				    seSetText(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')])[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][3]/following::input[3]")),strThirdTextBoxValue, strThirdTextBoxValue+" as text value");
			        act.moveToElement(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/preceding::input[1]/following::h4[contains(text(),'"+strAccumulatorTypeName+"')][1]/following::h4[contains(.,'"+strAccumulatorSubTypeName+"')])[1]/following::span[normalize-space()='"+strAccumulatorName+"'][1]/following::span[@role='combobox'][3]/following::input[3]/following::span[@class='select2-match' and contains(text(),'"+strThirdTextBoxValue+"')]"))).click().build().perform();
	                waitForPageLoad(1,200);
				}	} 
		catch (Exception e) {
					e.printStackTrace();
					log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());}
	
	}




	/**
 	 * Method to provide values to the accumulator
	 * @param strFirstLevelRadioButtonStatus : whether radio button is present at first level
	 * @param strBenefit : Benefit name
	 * @param strAccumulatorGroupName : Accumulator group name were the accumulator belongs to
	 * @param strAccumulatorName :current accumulator that is to be filled with values
	 * @param blnIsTextValueOnePresent : first text box is to be filled or not
	 * @param blnIsTextValueTwoPresent : second text box is to be filled or not
	 * @param blnIsTextValueThreePresent : third text box is to be filled or not
	 * @param strFirstTextBoxValue : value of the first text box
	 * @param strSecondTextBoxValue : value of the second text box
	 * @param strThirdTextBoxValue : value of the third text box
	 */
	private static void seSetAccumulatorTextBoxValues(String strFirstLevelRadioButtonStatus, String strBenefit,
			String strAccumulatorGroupName, Boolean blnIsTextValueOnePresent, Boolean blnIsTextValueTwoPresent,
			Boolean blnIsTextValueThreePresent, String strAccumulatorName, String strFirstTextBoxValue,
			String strSecondTextBoxValue, String strThirdTextBoxValue) {
		
	try{	  Actions act=new Actions(driver);
		if( strFirstLevelRadioButtonStatus.equalsIgnoreCase("Yes") && getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit	+ "')]/following::span[text()='" + strAccumulatorGroupName + "'])[1]/preceding::input[1]")).isSelected()==false){
                         WebElement RadioButton1=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit	+ "')]/following::span[text()='" + strAccumulatorGroupName + "'])[1]/preceding::input[1]"));
                         seClick(RadioButton1, strAccumulatorGroupName)	;
                         waitForPageLoad(75);}
           
			  if (blnIsTextValueOnePresent) {
			        waitForPageLoad(1,175);
		           WebElement clickTextBox=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit + "')][1]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[1]/span[1]"));
           		   act.moveToElement(clickTextBox).click().build().perform();
		           seSetText(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit + "')][1]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[1]/following::input[3]")),strFirstTextBoxValue, strFirstTextBoxValue+" as text value");
		           act.moveToElement(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit + "')][1]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[1]/following::input[3]/following::span[@class='select2-match' and contains(text(),'"+strFirstTextBoxValue+"')]"))).click().build().perform();
	                waitForPageLoad(1,200);
		           }
			
		        if (blnIsTextValueTwoPresent) {
			        waitForPageLoad(1,175);
		        	WebElement clickTextBox=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit + "')][1]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[2]/span[1]"));
            		act.moveToElement(clickTextBox).click().build().perform();
		            seSetText(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit + "')][1]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[2]/following::input[3]")),strSecondTextBoxValue, strSecondTextBoxValue+" as text value");
			        act.moveToElement(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit + "')][1]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[2]/following::input[3]/following::span[@class='select2-match' and contains(text(),'"+strSecondTextBoxValue+"')]"))).click().build().perform();
	                waitForPageLoad(1,200);
			        }
			
		        if (blnIsTextValueThreePresent) {
			        waitForPageLoad(1,175);
		        	WebElement clickTextBox=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit + "')][1]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[3]/span[1]"));
                    act.moveToElement(clickTextBox).click().build().perform();
		            seSetText(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit + "')][1]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[3]/following::input[3]")),strThirdTextBoxValue, strThirdTextBoxValue+" as text value");
				    act.moveToElement(getWebDriver().findElement(By.xpath("(//h4[contains(text(),'" + strBenefit + "')][1]/following::span[contains(text(),'"+strAccumulatorGroupName+"')][1]/following::select[@frontend-name='"+strAccumulatorName+"']/../span/span/span[@role='combobox'])[3]/following::input[3]/following::span[@class='select2-match' and contains(text(),'"+strThirdTextBoxValue+"')]"))).click().build().perform();
	                waitForPageLoad(1,200);
		        	}

	}  catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());}


		
	}




	/**
	 * method to read the data from excel using hash map
	 * @param filename :Name of the file from which the data is extracted
	 * @param sheetName :sheet name of the workbook
	 * @return
	 */
	public HashMap<String,LinkedHashMap<Integer,LinkedList<String>>> seLoadExcelLines(File filename,String sheetName)
	{
		HashMap<String, LinkedHashMap<Integer, LinkedList<String>>> map = new HashMap<>();
		LinkedHashMap<Integer, LinkedList<String>> hashMap = new LinkedHashMap<Integer, LinkedList<String>>();

		FileInputStream fis = null;
		try {
			fis = new FileInputStream(filename);
			XSSFWorkbook workBook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workBook.getSheet(sheetName);
			Iterator rows = sheet.rowIterator();
			while (rows.hasNext()) {
				XSSFRow row = (XSSFRow) rows.next();
				Iterator cells = row.cellIterator();
				LinkedList<String> data = new LinkedList();
				while (cells.hasNext())
				{
					XSSFCell cell = (XSSFCell) cells.next();
					cell.setCellType(Cell.CELL_TYPE_STRING);
					data.add(cell.getRichStringCellValue().getString().trim());
				}
				hashMap.put(row.getRowNum(), data);
			}
			map.put(sheetName, hashMap);

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
	        }
	    }

	    return map;

	}

/**
 * Method to click the benefit of every option tab
 * @param strBenefit :the current benefit that is to be clicked in options tab in PC
 */
public void seClickBenefit(String strBenefit){
	
try{	WebElement Benefits= getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]"));
	((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();", Benefits);
    strTemperoaryBenefitName=strBenefit;}
    catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());}
}


}
