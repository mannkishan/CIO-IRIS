package page.planConfigurator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class PCPSPCBreakoutSetupPage extends CoreSuperHelper{
	private static PCPSPCBreakoutSetupPage thisIsTestObj;
	public  synchronized static PCPSPCBreakoutSetupPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), PCPSPCBreakoutSetupPage.class);
		return thisIsTestObj;
		}
	
		
	@FindBy(how = How.XPATH, using = "//*[@id=\"BenefitTree\"]/a")
	@CacheLookup
	public WebElement benefitTab;
	
	/**
	 * Method to scroll down to Benefits Tab
	 */
	public void benefitsScrollDownButton()
	{
		JavascriptExecutor je = ((JavascriptExecutor) driver);
		je.executeScript("arguments[0].scrollIntoView(true);",benefitTab);
	} 
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[7]/a")
	@CacheLookup
	public WebElement savePage;	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[1]/a")
	@CacheLookup
	public WebElement closePlan;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"PlanSetup\"]/a")
	@CacheLookup
	public WebElement pageSetup;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"verticalBarMenuDetails\"]/div/nav/div[2]/ul/li[3]/a")
	@CacheLookup
	public WebElement pcpSPCSetup;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanSetup-_-CopaySetup-_-SplitCopay\"]")
	@CacheLookup
	public WebElement pcpSPCBreakOut;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanSetup-_-CopaySetup-_-SplitCopay-_-NA-_-NA-_-PCPSpecProviderNetwork_-_choice-container\"]")
	@CacheLookup
	public WebElement pcpSPCProvideListing;	
			
	@FindBy(how = How.XPATH, using = "//*[@id='PlanOptions']/a")
	@CacheLookup
	public WebElement planOptions;	
	
	@FindBy(how = How.XPATH, using = "//*[@id='BenefitOption']/a")
	@CacheLookup
	public WebElement benefitOptions;	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"BenefitTree\"]/a")
	@CacheLookup
	public WebElement benefits;
	
	@FindBy(how = How.XPATH, using = "//*[@id='Base']/a")
	@CacheLookup
	public WebElement planLevelBenefits;
	
	@FindBy(how = How.XPATH, using = "//*[@id='verticalBarMenuDetails']/div/nav/div[2]/ul/li[7]/a")
	@CacheLookup
	public WebElement urgentCare;	
	
	@FindBy(how = How.XPATH, using = "//*[@id='POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac']/div/div[2]/div[1]/h4")
	@CacheLookup
	public WebElement inNetworkCostSharesFacility;	
	
	@FindBy(how = How.XPATH, using = "//*[@id='select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CopayINNT1UrgentCareFac_-_choice-container']")
	@CacheLookup
	public WebElement inNetworkUrgentCareFacilityCoinsurance;	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"header-wrapper\"]/ul/li[7]/a")
	@CacheLookup
	public WebElement logoutDropDown;	
	
	/**
	 * this element is visible only when the find element is clicked
	 */
	@FindBy(how = How.XPATH, using = "//*[@id=\"action_logout\"]")
	@CacheLookup
	public WebElement logout;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"DataTables_Table_1\"]/tbody/tr/td[4]")
	@CacheLookup
	public WebElement openClickedPlan;
	
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"verticalBarMenu\"]/div[3]/div")
	@CacheLookup
	public WebElement scrollDown;
	
	@FindBy(how = How.XPATH, using = "//*[@id='verticalBarMenu']/div[1]/div")
	@CacheLookup
	public WebElement scrollUp;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[3]/a")
	@CacheLookup
	public WebElement copyButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/form/div[2]/div[6]/div/button[2]")
	@CacheLookup
	public WebElement createButton;
	
	/**
	 * Method to verify a given value against received value after removing any special characters
	 * @param givenValue: Value to be verified
	 * @param receivedValue: Value fetched from Benefit
	 * @return : whether matches or not
	 */
	public boolean validateValue(String givenValue, String receivedValue) {
		try{
			if (givenValue.equals(receivedValue.replaceAll("[$,]", ""))) {

				return true;
			}
		}
		catch (Exception e) {
				e.printStackTrace();
		}
		

		return false;
	}
	/**
	 * Method to log the values which are matching or not
	 * @param validateStatus: Contains status of the comparison  
	 * @param givenValue: Value provided in Office Exams Primary Care Physician and Office Exams
	 * @param receivedValue: Value fetched from Benefits Tab	 
	 */
	public void checkPCPSPCStatus(boolean validateStatus,String givenValue, String receivedValue)
	{
		try{
			if (validateStatus) {
				RESULT_STATUS = true;
				log(PASS, "Given value [$"+givenValue+"] matches the Extracted value ["+receivedValue+"] from Benefits", "RESULT_STATUS=PASS");
			} else {
				RESULT_STATUS = false;
				log(FAIL,
						"Mismatch between Given value [$"+givenValue+"] matches the Extracted value ["+receivedValue+"]",
						"RESULT_STATUS=FAIL");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	

}
