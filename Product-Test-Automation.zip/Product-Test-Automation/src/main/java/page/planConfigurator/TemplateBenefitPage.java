package page.planConfigurator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class TemplateBenefitPage extends CoreSuperHelper{
	
	private static TemplateBenefitPage thisTestObj;	
	public synchronized static TemplateBenefitPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), TemplateBenefitPage.class);
		return thisTestObj;
	}
	
	@FindBy(how = How.XPATH, using = "//*[@id='content-planBenefitDetails']/div[2]/div/div[1]/div[1]/span[2]/span[2]/div/div[1]/input")
	public WebElement inpatientPlaceOfService;  
	
	@FindBy(how = How.LINK_TEXT, using = "Exam Visit")
	@CacheLookup
	public WebElement examVisit;  
	
	public  boolean addOrRemoveBenefit(String benefit, String strAddRemoveFlag)
	{
		boolean addOrBenefitStatus=false;	
		String benefitValue = "";
		try{					
			WebElement Benefits = getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenu']/div[2]/ul/li[@id=\"BenefitTree\"]/a")) ;
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",Benefits);
			waitForPageLoad(600);
			if(strAddRemoveFlag.equalsIgnoreCase("ADD"))
			{
				if(!FindTemplatePage.get().urgentCareAdvImg.isSelected())
				{
					waitForPageLoad(600);
					log(PASS,"Benefit value is enabled","Benefit type urgent care advanced imaging is enabled",true);
					FindTemplatePage.get().urgentCareAdvImg.click();
//					seClick(true,FindTemplatePage.get().urgentCareAdvImg, "Clicking urgent care advanced imaging checkbox");
					benefitValue=seGetText(FindTemplatePage.get().benefitValue);
					addOrBenefitStatus = true;
					if(benefitValue.equalsIgnoreCase(benefit))
					{
						
						benefitValue ="/UrgentCare/UrgentCareProfessional/UrgentCareAdvancedImaging";
					}
					else
					{
						log(FAIL,"Benefit not found","Expected benefit is not found");
					}
				}
				else
				{
					log(FAIL,"Benefit value is disabled","Benefit type urgent care advanced imaging is already selected",true);
				}
			}
			else if(strAddRemoveFlag.equalsIgnoreCase("REMOVE"))
			{
				if(FindTemplatePage.get().urgentCareAdvImg.isSelected())
				{
					waitForPageLoad(600);
					log(PASS,"Benefit value is enabled","Benefit type urgent care advanced imaging is enabled",true);
					FindTemplatePage.get().urgentCareAdvImg.click();
//					seClick(FindTemplatePage.get().urgentCareAdvImg, "Clicking urgent care advanced imaging checkbox");
					benefitValue=seGetText(FindTemplatePage.get().benefitValue);
					addOrBenefitStatus = true;
					if(benefitValue.equalsIgnoreCase(benefit))
					{
						
						benefitValue="/UrgentCare/UrgentCareProfessional/UrgentCareAdvancedImaging";
					}
					else
					{
						log(FAIL,"Benefit not found","Expected benefit is not found");
					}
				}
				else
				{
					log(FAIL,"Not a valid test","Please check the test data",true);
				}
				
			}
			waitForPageLoad(350);
//			seClick(FindTemplatePage.get().save, "Click Save Button ");
			waitForPageLoad(360);	
				
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
			log(FAIL,"Benefit is disabled","Benefit is disabled",true);
		}
		
		return addOrBenefitStatus; 
	}

	public boolean  addOrRemoveSituationType(String strAddOrRemoveSituation)
	{
		boolean addOrRemoveStiuationStatus = false;
		String strStepName = strAddOrRemoveSituation+" Inpatient Place of Service to a template";
		try
		{
			WebElement Benefits = getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenu']/div[2]/ul/li[@id=\"BenefitTree\"]/a")) ;
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",Benefits);
			waitForPageLoad(600);
		waitForPageLoad(300);
		seWaitForClickableWebElement(TemplateBenefitPage.get().examVisit, 120);
		seClick(TemplateBenefitPage.get().examVisit, "Exam Visit link");
		if(strAddOrRemoveSituation.equalsIgnoreCase("ADD"))
		{
			if(!TemplateBenefitPage.get().inpatientPlaceOfService.isSelected())
			{
				addOrRemoveStiuationStatus = true;
				seClick(true, TemplateBenefitPage.get().inpatientPlaceOfService, "Inpatient Place Of Service");
				waitForPageLoad(300);
				boolean booSelected = TemplateBenefitPage.get().inpatientPlaceOfService.isSelected();
				log(booSelected?PASS:FAIL, strStepName);
			}
			else
			{
				log(FAIL, strStepName,"Not a valid test data as the Inpatient Place of service is already selected");
			}
			
		}
		else if(strAddOrRemoveSituation.equalsIgnoreCase("REMOVE"))
		{
			if(TemplateBenefitPage.get().inpatientPlaceOfService.isSelected())
			{
				addOrRemoveStiuationStatus = true;
				seClick(true, TemplateBenefitPage.get().inpatientPlaceOfService, "Inpatient Place Of Service");
				boolean booSelected = TemplateBenefitPage.get().inpatientPlaceOfService.isSelected();
				log(booSelected?FAIL:PASS, strStepName);
			}
			else
			{
				log(FAIL, strStepName,"Not a valid test data as the Inpatient Place of service is already removed");
			}
		}
		else
		{
			log(FAIL, strStepName,"Please specify the valid option");
		}
		
		
		
		}
		catch (Exception e) {
			log(FAIL, strStepName, "Exception occured in the method: "+e.getLocalizedMessage());
		}
		



		return addOrRemoveStiuationStatus; 
	}

}
