package page.planConfigurator;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.utility.ExtentReportsUtility;

import utility.CoreSuperHelper;
import utility.WebTableWithHeader;

public class BulkFinalizeFindPlanPage extends CoreSuperHelper{
	
	private static BulkFinalizeFindPlanPage thisTestObj;	
	public synchronized static BulkFinalizeFindPlanPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), BulkFinalizeFindPlanPage.class);
		return thisTestObj;
	}
	
	@FindBy(how = How.NAME, using = "criteria[effDateToString]")
	public WebElement effectiveDate;
	
	@FindBy(how = How.NAME, using = "criteria[name]")
	public WebElement PlanName;
	

	@FindBy(how = How.XPATH, using = "//*[@id='BulkFinalizeFind-header-criteria-collapse']/div/div[1]/div[2]/div[1]/span[1]")
	public WebElement headerValue;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='BulkFinalizeFind-header-criteria-collapse']/div/div[1]/div[1]/div[1]/span[1]/span[1]/span")
	public WebElement headerCritera;
	
	public WebElement optionCriteriaInclude(String row)
	{	
		WebElement include = getWebDriver().findElement(By.xpath("//div[@id='planOption-criteria-collapse']/div/div["+row+"]//div[text()[normalize-space()='Include']]/input[@type='radio']"));
		return include;
	}
	
	public WebElement optionCriteriaExclude(String row)
	{	
		WebElement exclude = getWebDriver().findElement(By.xpath("//div[@id='planOption-criteria-collapse']/div/div["+row+"]//div[text()[normalize-space()='Exclude']]/input[@type='radio']"));
		return exclude;
	} 
	
	public WebElement planOptionArea(String row)
	{	
		WebElement planoptionarea = getWebDriver().findElement(By.xpath("//div[@id='planOption-criteria-collapse']/div/div["+row+"]/div/div/div[2]/span[1]/span/span/span/span[1]"));
		return planoptionarea;
	}
	
	public WebElement planOptionType(String row)
	{	
		WebElement planoptionarea = getWebDriver().findElement(By.xpath("//div[@id='planOption-criteria-collapse']/div/div["+row+"]/div/div/div[2]/span[2]/span/span[1]/span/span[1]"));
		return planoptionarea;
	}
	
	public WebElement planOptionName(String row)
	{	
		WebElement planoptionarea = getWebDriver().findElement(By.xpath("//div[@id='planOption-criteria-collapse']/div/div["+row+"]/div/div/div[2]/span[3]/span/span[1]/span/span[1]"));
		return planoptionarea;
	}
	
	public WebElement planOptionValue(String text)
	{	
		WebElement value = getWebDriver().findElement(By.xpath("//ul[contains(@id,'results')]/li/span[text()='"+text+"']"));
		return value;
	}
	
	
	public List<WebElement> planOptionNameInPlan(String planName)
	{	
		List<WebElement> planoptionarea = getWebDriver().findElements(By.xpath("//div[@id='content-planOptionList']/div/div/span[span/h4[text()='"+planName+"']]/following-sibling::div/div/div[contains(@id,'Group')]/div/div/h4/span"));
		return planoptionarea;
	}	
	
	public WebElement checkBoxBulkFinalize(int row)
	{	
		WebElement value = getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div/table[contains(@id,'DataTables_Table')]/tbody/tr["+row+"]/td[1]/input[@type='checkbox']"));
		return value;
	}
	@FindBy(how = How.XPATH, using = "//form[@id='findPlanSearch']/div[6]/button[contains(text(),'Search')]")
	public WebElement searchButton;
	
	@FindBy(how = How.XPATH, using = "//div[@id='planOption-criteria-collapse']//a[@title='Add Criteria']")
	public WebElement optionCriteriaAdd;
	
	@FindBy(how = How.XPATH, using = "//ul[@id='actionsBar']/li[1]/a[text()='Close']")
	public WebElement planCloseButton;	
	
	@FindBy(how = How.XPATH, using = "//div[@id='bulk-finalize-sectionWrapper']/div[3]/div/div[1]/button[contains(text(),'Bulk Finalize')]")
	public WebElement bulkFinalizeButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='bulk-finalize-sectionWrapper']/div[3]/div/div[1]/button[1]/span")
	public WebElement selectAllButton;
	
	@FindBy(how = How.XPATH, using = "//div[@id='bulk-configure-sectionWrapper']/div/div/div[2]/div/textarea")
	public WebElement commentBulkFinalize;
	
	@FindBy(how = How.XPATH, using = "//div[@id='bulk-configure-sectionWrapper']/div/div/div[5]/button[text()='Submit']")
	public WebElement submitBulkFinalizeButton;
	
	@FindBy(how = How.XPATH, using = "//div[@class='bulk-entries-container']/div/div[2]/div/table")
	public WebElement impactReviewTable;

	
	/**
	 * The below method is to validate to option criteria for the plans to perform Bulk Finalize
	 * @param isIncluded
	 * @param isExcluded
	 * @throws Exception
	 */
	public void validateOptionCrteriaBulkFinalize(boolean isIncluded, boolean isExcluded) throws Exception
	{
		try
		{
			int intMaxWaitTime = 360;
			String strInclPlanOptionArea = getCellValue("IncludePlanOptionArea");
			String strInclPlanOptionType = getCellValue("IncludePlanOptionType");
			String strInclPlanOptionName = getCellValue("IncludePlanOptionName");
			String strExclPlanOptionArea = getCellValue("ExcludePlanOptionArea");
			String strExclPlanOptionType = getCellValue("ExcludePlanOptionType");
			String strExclPlanOptionName = getCellValue("ExcludePlanOptionName");
			String srPlanStatus=getCellValue("Status");
			if(isIncluded)
			{
				waitForPageLoad(intMaxWaitTime);
				seClick(BulkFinalizeFindPlanPage.get().optionCriteriaInclude("1"), "Include radio button");
				enterOPtionCriteria(strInclPlanOptionArea, strInclPlanOptionType, strInclPlanOptionName, "1");
			}

			if(isExcluded)
			{
				if(isIncluded)
				{
					waitForPageLoad(intMaxWaitTime);
					seClick(BulkFinalizeFindPlanPage.get().optionCriteriaAdd, "Add Criteria");
					waitForPageLoad(intMaxWaitTime);
					seClick(BulkFinalizeFindPlanPage.get().optionCriteriaExclude("2"), "Exclude radio button");				
					enterOPtionCriteria(strExclPlanOptionArea, strExclPlanOptionType, strExclPlanOptionName, "2");
				}
				else
				{
					waitForPageLoad(intMaxWaitTime);
					seClick(BulkFinalizeFindPlanPage.get().optionCriteriaExclude("1"), "Exclude radio button");				
					enterOPtionCriteria(strExclPlanOptionArea, strExclPlanOptionType, strExclPlanOptionName, "1");
				}
			}

			waitForPageLoad();
			seClick(BulkFinalizeFindPlanPage.get().searchButton, "Search button");
			waitForPageLoad(20,500);
			WebTableWithHeader searchResults = new WebTableWithHeader(FindPlanPage.get().searchResults, "Plan Search Results");
			
			int rowcount =searchResults.getRowsCount();
			int intRowNum = searchResults.getRowWithCellTextInColumn(1, 1, "No matching records found");
			if(intRowNum<0&&rowcount>0){
				if(rowcount>=2)
				{
				for(int i=1;i<=2;i++)
				{
					String strStatus=searchResults.getCellData(i, 9).toString().trim();
					seCompareStrings(strStatus, srPlanStatus, "=", "Verify Status");
					seClick(searchResults.getCell(i, 2), "Plan");
					waitForPageLoad(intMaxWaitTime);
					verifyPlanIsIncludedorExcluded(strInclPlanOptionArea,strInclPlanOptionType, strInclPlanOptionName, true, false);
					verifyPlanIsIncludedorExcluded(strExclPlanOptionArea,strExclPlanOptionType, strExclPlanOptionName, false, true);
					seClick(BulkFinalizeFindPlanPage.get().planCloseButton, "Close");
					waitForPageLoad(intMaxWaitTime);
				}
				}
				else
				{
					String strStatus=searchResults.getCellData(1, 9).toString().trim();
					seCompareStrings(strStatus, srPlanStatus, "=", "Verify Status");
					seClick(searchResults.getCell(1, 2), "Plan");
					waitForPageLoad(intMaxWaitTime);
					verifyPlanIsIncludedorExcluded(strInclPlanOptionArea,strInclPlanOptionType, strInclPlanOptionName, true, false);
					verifyPlanIsIncludedorExcluded(strExclPlanOptionArea,strExclPlanOptionType, strExclPlanOptionName, false, true);
					seClick(BulkFinalizeFindPlanPage.get().planCloseButton, "Close");
					waitForPageLoad(intMaxWaitTime);
				}
			}
			else
			{
				log(SKIP, "Find Plan","Plan not found with given Optionr Criteria "+strInclPlanOptionType);
			}
		}
		catch(Exception e)
		{
			throw e;
		}
}
	
	/**
	 * The below method is to enter the OptionCriteria in Bulk Finalize page.
	 * @param strInclPlanOptionArea
	 * @param strInclPlanOptionType
	 * @param strInclPlanOptionName
	 * @param row
	 */
	public void enterOPtionCriteria(String strInclPlanOptionArea, String strInclPlanOptionType, String strInclPlanOptionName, String row)
	{
		try
		{
			int intMaxWaitTime = 360;
			waitForPageLoad(intMaxWaitTime);
			seClick(BulkFinalizeFindPlanPage.get().planOptionArea(row), "Plan Option Area");
			seClick(BulkFinalizeFindPlanPage.get().planOptionValue(strInclPlanOptionArea),"PlanOptionArea value "+strInclPlanOptionArea);

			waitForPageLoad(intMaxWaitTime);
			seClick(BulkFinalizeFindPlanPage.get().planOptionType(row), "Plan Option Type");
			seClick(BulkFinalizeFindPlanPage.get().planOptionValue(strInclPlanOptionType),"PlanOptionType "+strInclPlanOptionType);

			waitForPageLoad(intMaxWaitTime);
			seClick(BulkFinalizeFindPlanPage.get().planOptionName(row), "Plan Option Name");
			seClick(BulkFinalizeFindPlanPage.get().planOptionValue(strInclPlanOptionName),"PlanOptionName "+strInclPlanOptionName);
		}
		catch(Exception e)
		{
			throw e;
		}
	}
	
	/**
	 * The below method is to validate whether the plan name is included or excluded for a particular plan.
	 * @param strPlanOptionArea
	 * @param strPlanOptionType
	 * @param strPlanOptionName
	 * @param isIncluded
	 * @param isExcluded
	 * @throws Exception
	 */
	public void verifyPlanIsIncludedorExcluded(String strPlanOptionArea, String strPlanOptionType, String strPlanOptionName, boolean isIncluded, boolean isExcluded) throws Exception
	{
		boolean isPlanTypeFound = false;
		boolean isPlanNameFound = false;
		int intMaxWaitTime = 360;
		try
		{
			WebElement optionsTab = PlanOptionsPage.get().optionsTab(strPlanOptionArea);
			PlanOptionsPage.get().clickAtObject(optionsTab);
			waitForPageLoad(intMaxWaitTime);
			for (WebElement element : PlanOptionsPage.get().planOptionValues) {
				Actions act = new Actions(getWebDriver());
				act.moveToElement(element).build().perform();
				String strOptionValue = element.getText();
				if(strOptionValue.equalsIgnoreCase(strPlanOptionType))
				{
					isPlanTypeFound = true;
					for (WebElement element1 : BulkFinalizeFindPlanPage.get().planOptionNameInPlan(strPlanOptionType)) {
						String strPlanName = element1.getText();
						if(strPlanName.equalsIgnoreCase(strPlanOptionName))
						{
							isPlanNameFound = true;
							break;
						}
					}
					break;
				}
			}
			if(isIncluded)
			{
				if(isPlanTypeFound&&isPlanNameFound)
				{
					log(PASS, "Verify the PlanOptionName","The PlanOptionName "+strPlanOptionName+" is included as expected under planOptionType "+strPlanOptionType);
				}
				else
				{
					log(FAIL, "Verify the PlanOptionName","The PlanOptionName "+strPlanOptionName+" is not included under planOptionType "+strPlanOptionType);
				}
			}
			if(isExcluded)
			{
				if(isPlanTypeFound)
				{
					if(!isPlanNameFound)
					{
						log(PASS, "Verify the PlanOptionName","The PlanOptionName "+strPlanOptionName+" is excluded as expected under planOptionType "+strPlanOptionType);
					}
					else
					{
						log(FAIL, "Verify the PlanOptionName","The PlanOptionName "+strPlanOptionName+" is not excluded under planOptionType "+strPlanOptionType);
					}
				}
				else
				{
					log(PASS, "Verify the PlanOptionName","The PlanOptionName "+strPlanOptionName+" is excluded as expected under planOptionType "+strPlanOptionType);
				}
			}
		}
		catch(Exception e)
		{
			throw e;
		}
	}
	
	public String schedulebulkFinalize(String strscheduleDate,String strTime)
	{
		boolean found = false;
		String id="";

		try{
			waitForPageLoad();
			WebTableWithHeader impactReviewTable = new WebTableWithHeader(BulkFinalizeFindPlanPage.get().impactReviewTable, "Impact Review Table");
			String userName=seGetText(HomePage.get().userName).toString().trim();
			int rowNum = impactReviewTable.getRowWithCellTextInColumn(1, 2, userName);

			if(rowNum>0)
			{
				ImpactReviewPage.get().seWaitForBulkRepubishImactStatus("Pending Review");
				impactReviewTable = new WebTableWithHeader(BulkFinalizeFindPlanPage.get().impactReviewTable, "Impact Review Table");
				String completionStatus  =impactReviewTable.getCell(rowNum, 7).getText().toString();
				System.out.println(completionStatus);
				if(completionStatus.equalsIgnoreCase("Pending Review")){
					id=impactReviewTable.getCell(rowNum,1).getText().toString().trim();
					Thread.sleep(5000);
					seSetText(ImpactReviewPage.get().id,id,"ID Field");
					seClick(ImpactReviewPage.get().impactReport,"Impact Report");
					
					seClick(ImpactReviewPage.get().impactReporttableschedule,"Schedule button");
					seSetText(ImpactReviewPage.get().scheduleDate,strscheduleDate,"Schedule Date");
					WebElement time=getWebDriver().findElement(By.name("scheduleTime"));
					seSelectText(time, strTime, "Time");
					seClick(ImpactReviewPage.get().schedulebutton,"Schedule button");
					waitForPageLoad(100);
					seSetText(ImpactReviewPage.get().id,id,"ID Field");
					impactReviewTable = new WebTableWithHeader(BulkFinalizeFindPlanPage.get().impactReviewTable, "Impact Review Table");
					completionStatus  =impactReviewTable.getCell(1, 7).getText().toString();
					
					if(completionStatus.equalsIgnoreCase("Update Scheduled")){
						found = true;
						ExtentReportsUtility.log(PASS,"Bulk Finalize request is moved to Update Scheduled & Scheduled For Bulk Finalize","Verify plan Bulk Finalize  request is moved to Update Scheduled & Scheduled For Bulk Finalize");
						return id;
					}
				}
				else
					ExtentReportsUtility.log(FAIL,"Bulk Finalize request is not moved to Pending Review","Not able to find the user in the Impact Results table");
			}

			if(!found){
				ExtentReportsUtility.log(FAIL,"Bulk Finalize request is not moved to Update Scheduled","Not able to find the user in the Impact Results table");
				return "";
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return id;
	}
	
	/**
	 * The below method is to verify the plan status as Pending Finalization or Production
	 * @param strPlanVersionID1
	 * @return
	 */
	public boolean verifyPlanStatus(String strPlanVersionID1)
	{
		try
		{
			int intMaxWaitTime = 360;
			FindPlanPage.get().findPlan(strPlanVersionID1);
			waitForPageLoad(intMaxWaitTime);
			String strStatus  =getWebDriver().findElement(By.className("plan-status-value")).getText().toString().trim();
			if((strStatus.contains("Production"))||(strStatus.contains("Pending Finalization")))
			{
				RESULT_STATUS = true;
				log(PASS,"Verify Status","Status is "+strStatus,true);
			}
			else
			{
				RESULT_STATUS = false;
				log(FAIL,"Verify Status","Status is not Pending Finalization or Production",true);
			}
		}
		catch(Exception e)
		{
			throw e;
		}
		return RESULT_STATUS;
	}
	
	public String clickBulkFinalizeCheckBox(boolean strSchedule) throws Exception{
		WebTableWithHeader searchResults = new WebTableWithHeader(FindPlanPage.get().searchResults, "Plan Search Results");
		int rowcount =searchResults.getRowsCount();
		String strPlanVersionID1 = "";
		String strPlanVersionID2 = "";
		if(strSchedule){
			if(rowcount>3)
			{
				for (int i = 1; i <3; i++) {
					strPlanVersionID1 = searchResults.getCell(i, 3).getText().toString().trim();
					seClick(BulkFinalizeFindPlanPage.get().checkBoxBulkFinalize(i), "CheckBox for "+strPlanVersionID1);										
				}
				return strPlanVersionID1;
			}
			else
			{
				log(FAIL, "Validate Bulk finalize Search for schedule", "There are no search results displaying for schedule, plesae modify the search criteria", true);
			}
		}
		else{
			if(rowcount>=2)
			{
				strPlanVersionID1 = searchResults.getCell(1, 3).getText().toString().trim();
				strPlanVersionID2 = searchResults.getCell(2, 3).getText().toString().trim();
				seClick(BulkFinalizeFindPlanPage.get().checkBoxBulkFinalize(1), "CheckBox for "+strPlanVersionID1);
				seClick(BulkFinalizeFindPlanPage.get().checkBoxBulkFinalize(2), "CheckBox for "+strPlanVersionID2);
				return strPlanVersionID1+":"+strPlanVersionID2;
			}
			else if(rowcount>0)
			{
				strPlanVersionID1 = searchResults.getCell(1, 3).getText().toString().trim();
				seClick(BulkFinalizeFindPlanPage.get().checkBoxBulkFinalize(1), "CheckBox for "+strPlanVersionID1);
				return strPlanVersionID1;
				
			}
			else
			{
				log(FAIL, "Validate Bulk finalize Search", "There are no search results displaying, plesae modify the search criteria", true);
			}
		}
		 return "";
	}
}
