package page.planConfigurator;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class EditTemplateInformationPage extends CoreSuperHelper{
	
	private static EditTemplateInformationPage thisTestObj;	
	public synchronized static EditTemplateInformationPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), EditTemplateInformationPage.class);
		return thisTestObj;
	}
	
	@FindBy(how = How.CSS, using = "button[class='doAction btn btn-primary pull-right']")
	@CacheLookup
	public WebElement save;

}
