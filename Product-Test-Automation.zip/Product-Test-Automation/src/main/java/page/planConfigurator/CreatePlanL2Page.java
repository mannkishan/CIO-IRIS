package page.planConfigurator;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class CreatePlanL2Page extends CoreSuperHelper{
	
	private static CreatePlanL2Page thisTestObj;	
	public synchronized static CreatePlanL2Page get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), CreatePlanL2Page.class);
		return thisTestObj;
	}				
	public HashMap<String,LinkedHashMap<Integer,LinkedList<String>>> loadExcelLines(File filename,String sheetName)
	{
	    HashMap<String,LinkedHashMap<Integer, LinkedList<String>>> map=new HashMap<>();
	    LinkedHashMap<Integer, LinkedList<String>> hashMap = new LinkedHashMap<Integer, LinkedList<String>>();

	    FileInputStream fis = null;
	    try
	    {
	        fis = new FileInputStream(filename);
	        XSSFWorkbook workBook = new XSSFWorkbook(fis);
	        
	            XSSFSheet sheet = workBook.getSheet(sheetName);

	            Iterator rows = sheet.rowIterator();
	            while (rows.hasNext())
	            {
	                XSSFRow row = (XSSFRow) rows.next();
	                Iterator cells = row.cellIterator();

	                LinkedList<String> data = new LinkedList();
	                while (cells.hasNext())
	                {
	                    XSSFCell cell = (XSSFCell) cells.next();
	                    cell.setCellType(Cell.CELL_TYPE_STRING);
	                    data.add(cell.getRichStringCellValue().getString().trim());
	                }
	                hashMap.put(row.getRowNum(), data);
	            }
	        map.put(sheetName, hashMap);

	    }
	    catch (IOException e)
	    {
	        e.printStackTrace();
	    }
	    finally
	    {
	        if (fis != null)
	        {
	            try
	            {
	                fis.close();
	            }
	            catch (IOException e)
	            {                e.printStackTrace();
	            }
	        }
	    }

	    return map;

	}

	
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
public void scrolldown()
{
	JavascriptExecutor jse = (JavascriptExecutor)driver;
	jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");	
}
public void scrollup()
{
	JavascriptExecutor jse = (JavascriptExecutor)driver;
	jse.executeScript("window.scrollBy(0,-1000)", "");	
}
public void scroll()
{
	((JavascriptExecutor)driver).executeScript("scroll(0,400)");
}


}	

