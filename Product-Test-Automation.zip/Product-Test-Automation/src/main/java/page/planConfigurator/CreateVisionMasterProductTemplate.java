package page.planConfigurator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;

public class CreateVisionMasterProductTemplate extends CoreSuperHelper {
	private static CreateVisionMasterProductTemplate thisIsTestObj;
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");

	public synchronized static CreateVisionMasterProductTemplate get() {
		thisIsTestObj = PageFactory.initElements(getWebDriver(), CreateVisionMasterProductTemplate.class);
		return thisIsTestObj;
	}

	public void seCreateVisionTemplate() {
		try {
			seClick(HomePage.get().create, "Clicking on create link");
			waitForPageLoad();
			seClick(TemplateCreation.get().createTemplate, "Clicking on plan option");
			waitForPageLoad();
			seSetText(FindPlanPage.get().planEffectiveDate, getCellValue("Temp_EffectiveDate"), "Effective date");
			WebElement pressEnter = FindPlanPage.get().planEffectiveDate;
			pressEnter.sendKeys(Keys.ENTER);
			waitForPageLoad();
			seClick(TemplateCreation.get().templateNameBox, "template name text box");
			seSetText(TemplateCreation.get().templateNameBox, getCellValue("Temp_Name"), "Template name");
			waitForPageLoad();
			String strStates = getCellValue("Temp_state").trim();
			String[] strSplitStateValues = strStates.split(",");
			for (int j = 0; j < strSplitStateValues.length; j++) {
				seClick(TemplateCreation.get().templateState, "State");
				seSetText(TemplateCreation.get().templateState, strSplitStateValues[j], "state name");
				TemplateCreation.get().templateState.sendKeys(Keys.ENTER);
				waitForPageLoad();
			}
			seClick(TemplateCreation.get().templateMarketSegment, "Market segment");
			seSetText(TemplateCreation.get().templateMarketSegment, getCellValue("Temp_MarketSegment"),
					"Market segment");
			TemplateCreation.get().templateMarketSegment.sendKeys(Keys.ENTER);
			waitForPageLoad();
			seSetText(TemplateCreation.get().templateMarketSegment, getCellValue("Temp_MarketSegment"),
					"Market segment");
			TemplateCreation.get().templateMarketSegment.sendKeys(Keys.ENTER);
			waitForPageLoad();
			seClick(TemplateCreation.get().templateLOB, "Line of Business");
			seClick(UncheckedFlagAttributeVisiblePage.get().visionLOB, "Vision Line of Business");
			waitForPageLoad();
			String strProductFamilies = getCellValue("Temp_Product_family").trim();
			String[] strSplitPfValues = strProductFamilies.split(",");
			for (int i = 0; i < strSplitPfValues.length; i++) {
				seClick(TemplateCreation.get().templateProductFamily, "Product family");
				seSetText(TemplateCreation.get().templateProductFamily, strSplitPfValues[i], "Product family");
				TemplateCreation.get().templateProductFamily.sendKeys(Keys.ENTER);
				waitForPageLoad();
			}

			String strCdhp = getCellValue("Temp_cdhp").trim();
			String[] strSplitCdhpValues = strCdhp.split(",");

			for (int i = 0; i < strSplitCdhpValues.length; i++) {
				seClick(TemplateCreation.get().Cdhp, "CDHP");
				seSetText(TemplateCreation.get().Cdhp, strSplitCdhpValues[i], "CDHP");
				TemplateCreation.get().Cdhp.sendKeys(Keys.ENTER);
				waitForPageLoad();
			}
			seClick(TemplateCreation.get().fundingArrangement, "Funding arrangement");
			seSetText(TemplateCreation.get().fundingArrangement, getCellValue("Temp_FundindArrangement"),
					"funding arrangement");
			TemplateCreation.get().fundingArrangement.sendKeys(Keys.ENTER);
			waitForPageLoad();
			seClick(TemplateCreation.get().create, "create");
			waitForPageLoad(105);
			seWaitForClickableWebElement(PlanHeaderPage.get().save, 45);
			String strPlanID = TemplateCreation.get().getPlanId.getText();
			String strPlan = strPlanID.substring(strPlanID.lastIndexOf(" ") + 1);
			seClick(PlanHeaderPage.get().save, "Save button");
			waitForPageLoad();
			seClick(PlanHeaderPage.get().close, "Close button");
			waitForPageLoad();
			seCloseBrowser();
			String strTemplateId = TemplateCreation.seTemplateCreation(strPlan.trim(), getCellValue("MP_File_path"));
			setCellValue("TemplateVersionID", strTemplateId);
			seWaitForClickableWebElement(PlanHeaderPage.get().save, 45);
			seClick(PlanHeaderPage.get().save, "Save button");			
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	public static void seMoveVisionTemplateToProduction(String strTemplateId)
	{
		try
		{
			seOpenBrowser(BrowserConstants.Chrome, strBaseURL, "testscripts");
			LoginPage.get().loginApplication(strUserProfile);
			waitForPageLoad(65);
			waitForPageLoad();
			seClick(HomePage.get().find, "Find");
			seClick(HomePage.get().findTemplate, "Find Plan");
			waitForPageLoad();			
			seSetText(page.planConfigurator.FindTemplatePage.get().templateVersionID, strTemplateId,"text in Template Version ID textbox");				
			seClick(page.planConfigurator.FindTemplatePage.get().templateSearch, "Search template");
			waitForPageLoad(40);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);
			waitForPageLoad(20);
			seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//a[text()='Request Audit']")), 20);
			seClick(getWebDriver().findElement(By.xpath("//a[text()='Request Audit']")), "request audit");
			waitForPageLoad();			
			waitForPageLoad();
			seClick(getWebDriver().findElement(By.xpath("//label[text()='Reason Code']/following::span[text()='- Please Select -'][1]")), "reason code");
			seSetText(getWebDriver().findElement(By.xpath("//label[text()='Reason Code']/following::span[text()='- Please Select -'][1]/following::input[@role='textbox'][1]")), "Other", "reason code");
			seClick(getWebDriver().findElement(By.xpath("//label[text()='Reason Code']/following::span[text()='- Please Select -'][1]/following::input[@role='textbox'][1]/following::span[@class='select2-match' and text()='Other']")), "Other");
			seSetText(getWebDriver().findElement(By.xpath("//label[text()='Comment']/../div/textarea")), "test", "comment");
			seClick(getWebDriver().findElement(By.xpath("//button[@class='workflowAction btn btn-primary pull-right']")), "request audit button");
			waitForPageLoad(45);				
			try{
				seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 180);}				
			catch(TimeoutException e){
			seClick(PlanHeaderPage.get().close, "Close button");}
	
			seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
			waitForPageLoad();				
			seClick(PlanHeaderPage.get().userLogout, "Logout");
			waitForPageLoad();
			seCloseBrowser();
			seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
			waitForPageLoad();
			LoginPage.get().loginApplication(strUserProfileApprover);
			waitForPageLoad();
			seClick(HomePage.get().find, "Find");
			seClick(HomePage.get().findTemplate, "Find template");
			waitForPageLoad();
			seClick(FindTemplatePage.get().templateVersionID, "template ID textbox");
			seSetText(page.planConfigurator.FindTemplatePage.get().templateVersionID, strTemplateId,strTemplateId+"in plan version id textbox");				
			seClick(page.planConfigurator.FindTemplatePage.get().templateSearch, "Search template");
			waitForPageLoad();
	
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);
			waitForPageLoad(45);
			seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 2);
			Boolean status= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
			 
			 if(status==true)
				{
					log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");												
				}
				else
				{
					log(FAIL, "plan takes more time to load","plan is still in 'process in progress' status,RESULT=FAIL");												
				}
			waitForPageLoad();
			seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 5);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanHeaderPage.get().approveAudit);
			waitForPageLoad(185);
			seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "reason code");
			seClick(PlanTransitionPage.get().approved, "approved");
			seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
			waitForPageLoad(45);
			seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//a[text()='Finalize']")), 6);
			seClick(getWebDriver().findElement(By.xpath("//a[text()='Finalize']")), "finalize");
			waitForPageLoad();
			seClick(PlanTransitionPage.get().finalizeButtoninPT, "finalize");
			waitForPageLoad(45);
			seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//a[text()='Move to Production']")), 6);
			seClick(getWebDriver().findElement(By.xpath("//a[text()='Move to Production']")), "move to production");
			waitForPageLoad();
	
			seClick(getWebDriver().findElement(By.xpath("//button[@class='workflowAction btn btn-primary pull-right']")),"move to production");
			waitForPageLoad();
			seCloseBrowser();
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
			}
	public  void seCreateVisionPlan(boolean isMasterPlan,int maxWaitTime)
	{
		try {
			String strEffectiveDate = getCellValue("EffectiveDate");
			String strProductModel = "";
			if(isMasterPlan)
			{
				strProductModel= "Master Product";
			}
			String strTemplateVersionID = getCellValue("TemplateVersionID");
			String strApprovalStatus = getCellValue("ApprovalStatus");
			String strCustomizationLevel = getCellValue("CustomizationLevel");
			String strState = getCellValue("State");
			String strMarketSegment = getCellValue("MarketSegment");
			String strMarketUnit = getCellValue("MarketUnit");
			String strProductFamily = getCellValue("ProductFamily");
			String strProductName = getCellValue("ProductName");
			String strCDHPType = getCellValue("CDHP");
			String strBenefitPeriod = getCellValue("BenefitPeriod");
			String strFundingArrangement = getCellValue("FundingArrangement");
			String strBusinessUnit	 = getCellValue("BusinessUnit");
			String strLineOfBusiness = getCellValue("LOB");
			
			waitForPageLoad(maxWaitTime);
			seClick(HomePage.get().create, "Create");
			seClick(HomePage.get().plan, "Plan");
			waitForPageLoad(4,maxWaitTime);
			seSetText(CreatePlanPage.get().enterEffectiveDate, strEffectiveDate, "Effective Date");
			CreatePlanPage.get().enterEffectiveDate.sendKeys(Keys.TAB);
			waitForPageLoad(maxWaitTime);
			seSelectText(CreatePlanPage.get().selectProductModelData, strProductModel, "Product Model",maxWaitTime);
			
			seSelectText(CreatePlanPage.get().customizationLevel, strCustomizationLevel, "Customization Level",maxWaitTime);
			seSelectText(CreatePlanPage.get().state, strState, "State",maxWaitTime);
			seSelectText(CreatePlanPage.get().marketSegment, strMarketSegment, "Market Segment",maxWaitTime);
			seSelectText(CreatePlanPage.get().marketUnit, strMarketUnit, "Market Unit",maxWaitTime);
			seSelectText(CreatePlanPage.get().lob, strLineOfBusiness, "Line of Business",maxWaitTime);
			seSelectText(CreatePlanPage.get().productName, strProductName, "Product Name",maxWaitTime);
			seSelectText(CreatePlanPage.get().productFamily, strProductFamily, "Product Family",maxWaitTime);
			seSelectText(CreatePlanPage.get().cdhType, strCDHPType, "Consumer Driven Health Plan",maxWaitTime);
			seSelectText(CreatePlanPage.get().benefitPeriod, strBenefitPeriod, "Benefit Period",maxWaitTime);
			seSelectText(CreatePlanPage.get().fundingArrangement,strFundingArrangement, "Funding Arrangement",maxWaitTime);
			seSelectText(CreatePlanPage.get().businessUnit, strBusinessUnit, "Business Unit",maxWaitTime);
			if(isMasterPlan)
			{
			seClick(CreatePlanPage.get().selectTemplate	, "Select Template");
			waitForPageLoad(4,maxWaitTime);
			seSwitchFrame(FindTemplatePage.get().findTemplateFrame);
			seWaitForClickableWebElement(FindTemplatePage.get().searchCriteria, 60);
			seClick(FindTemplatePage.get().searchCriteria	, "Search Criteria");
			seWaitForClickableWebElement(FindTemplatePage.get().versionId, 120);
			seSetText(FindTemplatePage.get().versionId, strTemplateVersionID, "Template Version ID");
			seClick(FindTemplatePage.get().searchButton	, "Search Criteria");
			seWaitForPageLoad(150);
			FindTemplatePage.get().selectTemplate(strTemplateVersionID);
			}
			waitForPageLoad(maxWaitTime);
			getWebDriver().switchTo().defaultContent();
			waitForPageLoad(maxWaitTime);
			seClick(CreatePlanPage.get().createPlan, "Create Plan");
			waitForPageLoad(5,maxWaitTime);
			waitForPageLoad(5,maxWaitTime);
			String planVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
			waitForPageLoad(5,maxWaitTime);
			String planProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
			setCellValue("PlanVersionID", planVersionID);
			setCellValue("PlanProxyID", planProxyID);
				
		} catch (Exception e) {
			
		}
		
	}
	public void seMoveVisionPlanToProduction(String strPlanVersionID)
	{
		try
		{
			seClick(PlanHeaderPage.get().save, "Save button");
			waitForPageLoad(45);
			seWaitForClickableWebElement(PlanHeaderPage.get().requestAudit, 20);
			seClick(PlanHeaderPage.get().requestAudit, "request Audit");
			waitForPageLoad();
			
			PlanTransitionPage.get().updateReasonCode("Other");
			seClick(PlanTransitionPage.get().requestAudit, "Request Audit button");
			waitForPageLoad();
			
			try{
				seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 360);				
		    }		
			catch(TimeoutException e){
				seClick(PlanHeaderPage.get().close, "Close button");
				waitForPageLoad();
            }
		
		    seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
			waitForPageLoad();
			
			seClick(PlanHeaderPage.get().userLogout, "Logout");
			waitForPageLoad(); 
			
			seCloseBrowser();
	       
			seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
	        LoginPage.get().loginApplication(strUserProfileApprover);
			waitForPageLoad();
			
			FindPlanPage.seSearchPlanByPlanVersionID(strPlanVersionID);
			waitForPageLoad(45);
			
			 Boolean auditStatus= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
			 
			 if(auditStatus==true){
					log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");
				}
				else { 
					throw new TimeoutException("Plan is not in Pending Audit status");
				}	
					
	            seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 10);
			    seClick(PlanHeaderPage.get().approveAudit, "Approve Audit");
				waitForPageLoad(30);
				
				seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
				PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
				PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
				PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ENTER);
				
				seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, 10);
				seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
				seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeText, 1);
				
				seSetText(PlanTransitionPage.get().planTransitionReasonCodeText, "Approved", "as " + "Approved");
				seClick(PlanTransitionPage.get().approved, "approved reason code");
				seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
				waitForPageLoad(45);
				seWaitForClickableWebElement(PlanHeaderPage.get().moveToTestPHPage, 12);
				seClick(PlanHeaderPage.get().moveToTestPHPage, "Move to test button");
				waitForPageLoad();
				seClick(PlanTransitionPage.get().moveToTest, "Move to test ");
				waitForPageLoad(45);
				seWaitForClickableWebElement(PlanHeaderPage.get().approveTestForFinalize, 12);
				seClick(PlanHeaderPage.get().approveTestForFinalize, "Approve test button");
				waitForPageLoad();
				
				seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "reason code");
				seClick(PlanTransitionPage.get().approved,"approved");
				seClick(PlanTransitionPage.get().approvedTest, "approve test");
				waitForPageLoad(45);
				seWaitForClickableWebElement(PlanHeaderPage.get().finalize, 12);
				seClick(PlanHeaderPage.get().finalize, "Finalize");
				waitForPageLoad();
				
				seClick(PlanTransitionPage.get().finalizeButtoninPT, "finalize");
				waitForPageLoad();
				
	        	try{
	        		seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 300);
	        		}
				
				catch(TimeoutException e){
		            seClick(PlanHeaderPage.get().close, "Close button");
					waitForPageLoad();
	
		            }
				
				((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);
				waitForPageLoad(45);
				
	            Boolean finalStatus= PlanHeaderPage.get().seVerifyPlanStatus("Production");
			 
	            if(finalStatus==true)
	            {
	              	log(PASS, "plan takes correct time to load","plan is in Production status,RESULT=PASS");
	             }
	            else 
	            { 
	            	throw new TimeoutException("Plan is not in Production status");
	              }	
	             waitForPageLoad();
			     seClick(FindPlanPage.get().clickPlanLevelBenefit,"plan level benefit");
			     waitForPageLoad();			    		    
			     seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
			     seClick(PlanHeaderPage.get().userLogout, "Logout");

	}
      catch(TimeoutException e){
		e.printStackTrace();
		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
	}
	catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
	}
	
	finally{
		seCloseBrowser();
	}
	}

}
