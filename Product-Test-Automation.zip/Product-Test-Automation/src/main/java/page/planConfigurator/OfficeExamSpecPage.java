package page.planConfigurator;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class OfficeExamSpecPage extends CoreSuperHelper{
	private static OfficeExamSpecPage thisIsTestObj;
	public  synchronized static OfficeExamSpecPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), OfficeExamSpecPage.class);
		return thisIsTestObj;
		}
	@FindBy(how = How.XPATH, using = "//*[@id=\"verticalBarMenuDetails\"]/div/nav/div[2]/ul/li[2]/a")
	@CacheLookup
	public WebElement officeExamSpecilaist;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExamsSpec-_-CoveredINNOON-_-NA-_-NA-_-PREFApplies_-_choice-container\"]")
	@CacheLookup
	public WebElement officeExamSpecilaistPrefApply;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExamsSpec-_-CoveredINNOON-_-NA\"]/div/div/table/tbody/tr/td[2]/div/span/span/span[1]/input")
	@CacheLookup
	public WebElement officeExamSpecilaistPrefApplySearchBar;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExamsSpec-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares\"]")
	@CacheLookup
	public WebElement officeExamSpecilaistINNBenSpecCostShares;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExamsSpec-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-ApplyDed_-_choice-container\"]")
	@CacheLookup
	public WebElement officeExamSpecilaistApplyDeductible;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[1]/td[2]/div/span/span/span[1]/input")
	@CacheLookup
	public WebElement officeExamSpecilaistApplyDeductibleSearchBar;
	
		
	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExamsSpec-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-CopayINNT1Spec_-_amount-container\"]")
	@CacheLookup
	public WebElement officeExamSpecilaistINNSpcCopay;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[2]/td[2]/div[2]/span/span/span[1]/input")
	@CacheLookup
	public WebElement officeExamSpecilaistINNSpcCopaySearchBar;
	
		
	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExamsSpec-_-CoveredINNOON-_-Limitations-_-Lmt-_-DlrLmtNonRoutinePodiatricLmt_-_indivMax-container\"]")
	@CacheLookup
	public WebElement officeExamSpecilaistNonRtnPdDlrLmt;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExamsSpec-_-CoveredINNOON-_-Limitations\"]/div/div/div[2]/table/tbody/tr/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement officeExamSpecilaistNonRtnPdDlrLmtSearchBar;
}