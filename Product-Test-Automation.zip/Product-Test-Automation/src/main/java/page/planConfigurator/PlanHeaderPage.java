package page.planConfigurator;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import utility.CoreSuperHelper;

public class PlanHeaderPage extends CoreSuperHelper{
	private static PlanHeaderPage thisTestObj;	
	public synchronized static PlanHeaderPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), PlanHeaderPage.class);
		return thisTestObj;
	}
	@FindBy(how = How.XPATH, using = "//div[@class='wgsService']/span[contains(text(),'WGS Response')]")
	@CacheLookup
	public WebElement planWGSResponse;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"planHeaderWrapper\"]/div/div/div[1]/div[2]/div[1]")
	@CacheLookup
	public WebElement planTitle;
	
	@FindBy(how = How.XPATH, using = "//*[@id='header-wrapper']/ul/li[2]/ul/li[2]/a")
	@CacheLookup
	public WebElement findTemplate;
	
	@FindBy(how = How.XPATH, using = "//*[@class='table searchResultsTable fjaTable dataTable']/tbody/tr/td[3]")
	@CacheLookup
	public WebElement searchTemplates;
	
	@FindBy(how = How.XPATH, using = "//*[@id='actionsBar']/li[4]/a")
	@CacheLookup
	public WebElement editTemplate;
	
	@FindBy(how = How.XPATH, using = "//*[@id='content-create-customPlan']/form/div[2]/div[6]/div/button[2]")
	@CacheLookup
	public WebElement headerSave;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"planHeaderWrapper\"]/div/div/div[2]/div[2]/div[2]/div/div[1]")
	@CacheLookup
	public WebElement planProxyID;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"planHeaderWrapper\"]/div/div/div[2]/div[2]/div[2]/div/div[2]")
	@CacheLookup
	public WebElement planVersionID;
	
	@FindBy(how = How.XPATH, using = "//*[@id='planHeaderWrapper']/div/div/div[1]/div[4]/div[2]/span[2]")
	@CacheLookup
	public WebElement templateVersionID;

	@FindBy(how = How.XPATH, using = "//*[@id='planHeaderWrapper']/div/div/div[2]/div[2]/div[2]/div/div[2]")
	@CacheLookup
	public WebElement templateVersion;
	
	//*[@id="planHeaderWrapper"]/div/div/div[1]/div[4]/div[2]/span[2]
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"planHeaderWrapper\"]/div/div/div[1]/div[2]/div[3]/span[2]")
	@CacheLookup
	public WebElement planDescription;
	
	@FindBy(how = How.XPATH, using = ".//*[@id='planHeaderWrapper']/div/div/div[2]/div[2]/div[1]/div[1]")
	@CacheLookup
	public WebElement planEffDate;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"planHeaderWrapper\"]/div/div/div[1]/div[2]/div[5]/span[2]")
	@CacheLookup
	public WebElement planProductName;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"planHeaderWrapper\"]/div/div/div[1]/div[2]/div[4]/span[2]")
	@CacheLookup
	public WebElement planState;
	
	@FindBy(how = How.XPATH, using = "//div[@id='actionsBarWrapper']/ul/li[5]/a[text()='Approve']")
	@CacheLookup
	public WebElement approveAudit;
	
	@FindBy(how = How.XPATH, using = "//*[@id='actionsBar']/li[4]/a[text()='Reject']")
	@CacheLookup
	public WebElement rejectAudit;
			
	@FindBy(how = How.XPATH, using = "//li/a[text()='Finalize']")
	@CacheLookup
	public WebElement finalize;
		
	@FindBy(how = How.XPATH, using = "//div[@id='actionsBarWrapper']/ul/li[3]/a[text()='Move To Test']")
	@CacheLookup
	public WebElement moveToTest; 
	
	@FindBy(how = How.XPATH, using = "//div[@id='actionsBarWrapper']/ul/li[4]/a[text()='Approve Test']")
	@CacheLookup
	public WebElement approveTest;
	
	@FindBy(how = How.XPATH, using = "//div[@id='actionsBarWrapper']//a[text()='Reject Test']")
	@CacheLookup
	public WebElement rejectTest;

	@FindBy(how = How.XPATH, using = "//div[@id='actionsBarWrapper']//a[text()='Edit']")
	@CacheLookup
	public WebElement editPlan;
		
	@FindBy(how = How.LINK_TEXT, using = "Save")
	@CacheLookup
	public WebElement save;
	
	@FindBy(how = How.XPATH, using = "id('actionsBar')/li[3]/a[1]")
	@CacheLookup
	public WebElement moveT0Test;
	
	@FindBy(how = How.XPATH, using = "id('actionsBar')/li[4]/a[1]")
	@CacheLookup
	public WebElement approve;
	
	@FindBy(how = How.XPATH, using = "//*[@id='content-workflow']/form/div[3]/div[5]/div/button[2]")
	@CacheLookup
	public WebElement moveToTestButton;
	
	@FindBy(how = How.XPATH, using = "//a[text()='Request Audit']")
	@CacheLookup
	public WebElement requestAudit;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Status')]/following-sibling::span[@class='plan-status-value']")
	@CacheLookup
	public WebElement planStatus;
	
	@FindBy(how = How.XPATH, using = "//*[@id='actionsBar']/li[1]/a")
	@CacheLookup
	public WebElement close;
	
	@FindBy(how = How.XPATH, using = "//*[@id='actionsBar']/li[3]/a")
	@CacheLookup
	public WebElement moveToTestPHPage; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='header-wrapper']/ul/li[7]/a")
	@CacheLookup
	public WebElement userNameHeader;
	
	@FindBy(how = How.XPATH, using = "//*[@id='action_logout']")
	@CacheLookup
	public WebElement userLogout;
	
	@FindBy(how = How.XPATH, using = "//li/a[text()='Approve Test']")
	@CacheLookup
	public WebElement approveTestForFinalize;
	
	@FindBy(how = How.NAME, using = "effectiveDate")
	@CacheLookup
	public WebElement effectiveDate;	
	
	@FindBy(how = How.CSS, using = "button[class='close icon']")
	@CacheLookup
	public WebElement closebutton;
	
	@FindBy(how = How.XPATH, using = "//button[@title='History']")
	@CacheLookup
	public WebElement history;
	
	public WebElement valueType(String strType)
    {
		WebElement valueType = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+strType+"')]/ancestor::label/following::div[1]"));
        return valueType;
    }
	
	public WebElement planstatus(String strStatus)
    {
           WebElement statusValue = getWebDriver().findElement(By.xpath("//div[@id='planHeaderWrapper']/div/div/div[2]/div[2]/div[1]/div[2]/span[contains(text(),'"+strStatus+"')]"));
           return statusValue;
    }
	
	/**
	 * Method to check whether the current status of the plan matches with the status given as string
	 * @param strPlanStatus : checking status of a plan is given as string to match
	 * @return true if plan status matches the string , false if it does not matches
	 */
	public Boolean seVerifyPlanStatus(String strPlanStatus) { 
		try {
			seWaitForWebElement(60,ExpectedConditions.textToBePresentInElement(PlanHeaderPage.get().planStatus, strPlanStatus));
		}   catch (org.openqa.selenium.TimeoutException e)
		{
			seClick(PlanHeaderPage.get().close, "Close button");
			waitForPageLoad(45);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",
			FindPlanPage.get().selectSearchedPlan);
			waitForPageLoad();
		}
		    String strNewPlanStatus = PlanHeaderPage.get().planStatus.getText();
		    log(strNewPlanStatus.equalsIgnoreCase(strPlanStatus) ? PASS : FAIL, "Verify Plan Status","Verify Plan status is " + strPlanStatus + "Actual Status is " + strNewPlanStatus, true);
		    if (strNewPlanStatus.equals(strPlanStatus)) {
			return true;
		} else
			return false;
	}
	
	
	
	public void seEditTemplate() { 
		try {
			
			//*[@id="verticalBarMenu"]/div[2]/ul//following::li/a[@title='Plan Level Benefits']
			WebElement objBenefits = getWebDriver().findElement(By.xpath("//*[@id='verticalBarMenu']/div[2]/ul//following::li/a[@title='Plan Level Benefits']"));
            ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objBenefits);
            System.out.println("Plan levle bene");
            waitForPageLoad();
            WebElement objOption = getWebDriver().findElement(By.xpath("//*[@id='verticalBarMenuDetails']//following::li/a[@attr-ref='OOPMax']"));
            ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objOption);
            waitForPageLoad();
            System.out.println("out of pocket");
            waitForPageLoad();
            WebElement objdropdown = getWebDriver().findElement(By.xpath("//*[@id='POA_Base-_-OOPMax-_-OOPMax-_-NA']/div/div/table/tbody/tr[2]/td[2]/div[1]/div[2]/span/span[1]/span/span[2]"));
            //((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objdropdown);
            seClick(objdropdown, "");
            waitForPageLoad();
            System.out.println("drp dwn");
            WebElement objinput = getWebDriver().findElement(By.xpath("//*[@id='POA_Base-_-OOPMax-_-OOPMax-_-NA']/div/div/table/tbody/tr[2]/td[2]/div[1]/span[2]/span/span[1]/input"));
            objinput.click();
            //seSetText(objinput,"6500", "Enter ");
            objinput.sendKeys("9500");
            waitForPageLoad();
            System.out.println("input");
            waitForPageLoad();
            WebElement objEnter = getWebDriver().findElement(By.xpath("//*[@id='POA_Base-_-OOPMax-_-OOPMax-_-NA']/div/div/table/tbody/tr[2]/td[2]/div[1]/span[2]/span/span[2]"));
            //((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objEnter);
            seClick(objEnter, "");
            waitForPageLoad();
            System.out.println("enter");
            waitForPageLoad();
			
	}catch (Exception e) {
		log(ERROR, "Error while executing  method.");
	}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void seMoveToProductionTemplate(){
		String strBaseURL = EnvHelper.getValue("pc.url");
		String strUserProfile = EnvHelper.getValue("user.profile");
		String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
		try{
	seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//a[text()='Request Audit']")), 5);
	seClick(getWebDriver().findElement(By.xpath("//a[text()='Request Audit']")), "request audit");
	waitForPageLoad();
	seClick(getWebDriver().findElement(By.xpath("//label[text()='Reason Code']/following::span[text()='- Please Select -'][1]")), "reason code");
	seSetText(getWebDriver().findElement(By.xpath("//label[text()='Reason Code']/following::span[text()='- Please Select -'][1]/following::input[@role='textbox'][1]")), "Other", "reason code");
	seClick(getWebDriver().findElement(By.xpath("//label[text()='Reason Code']/following::span[text()='- Please Select -'][1]/following::input[@role='textbox'][1]/following::span[@class='select2-match' and text()='Other']")), "Other");
	seSetText(getWebDriver().findElement(By.xpath("//label[text()='Comment']/../div/textarea")), "test", "comment");
	seClick(getWebDriver().findElement(By.xpath("//button[@class='workflowAction btn btn-primary pull-right']")), "request audit button");
	waitForPageLoad(45);				
	try{
		seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 180);}				
	catch(Exception e){
    seClick(PlanHeaderPage.get().close, "Close button");}
	
    seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
	waitForPageLoad();				
	seClick(PlanHeaderPage.get().userLogout, "Logout");
	waitForPageLoad();
	seCloseBrowser();
	seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
    waitForPageLoad();
    LoginPage.get().loginApplication(strUserProfileApprover);
    waitForPageLoad();
    seClick(HomePage.get().find, "Find");
	seClick(HomePage.get().findTemplate, "Find template");
	waitForPageLoad();
	String strPlanID = getCellValue("TemplateIDnew");
	waitForPageLoad();
	seClick(FindTemplatePage.get().templateVersionID, "template ID textbox");
	seSetText(page.planConfigurator.FindTemplatePage.get().templateVersionID, strPlanID,"in plan version id textbox");				
	seClick(page.planConfigurator.FindTemplatePage.get().templateSearch, "Search template");
	waitForPageLoad();

	((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);
	waitForPageLoad(45);
	seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 2);
	Boolean status= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
	 
	 if(status==true)
		{
			log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");												
		}
		else
		{
			log(FAIL, "plan takes more time to load","plan is still in 'process in progress' status,RESULT=FAIL");												
		}
	waitForPageLoad();
	seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 5);
	((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanHeaderPage.get().approveAudit);
	waitForPageLoad(185);
	seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "reason code");
	seClick(PlanTransitionPage.get().approved, "approved");
	seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
	waitForPageLoad(45);
	seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//a[text()='Finalize']")), 6);
	seClick(getWebDriver().findElement(By.xpath("//a[text()='Finalize']")), "finalize");
	waitForPageLoad();
	seClick(PlanTransitionPage.get().finalizeButtoninPT, "finalize");
	waitForPageLoad(45);
	seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//a[text()='Move to Production']")), 6);
	seClick(getWebDriver().findElement(By.xpath("//a[text()='Move to Production']")), "move to production");
	waitForPageLoad();

	seClick(getWebDriver().findElement(By.xpath("//button[@class='workflowAction btn btn-primary pull-right']")),"move to production");
	waitForPageLoad();
	
	
	}catch (Exception e) {
		log(ERROR, "Error while executing  method.");
	}
}
	
	
	public void SeMoveToProductionPlan(String strVersionID, int intMaxWaitTime)
	{
		String strBaseURL = EnvHelper.getValue("pc.url");
		
		String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
		System.out.println(strVersionID);
		waitForPageLoad(3, intMaxWaitTime);
		seClick(PlanHeaderPage.get().requestAudit, "Request Audit for Plan");
		waitForPageLoad(3, intMaxWaitTime);
		seClick(PlanTransitionPage.get().reasonCode, "Reason Code");
		waitForPageLoad(1, intMaxWaitTime);
		seClick(PlanTransitionPage.get().selectType("Other"), "Select Other from Reason Code");
		waitForPageLoad(intMaxWaitTime);
		seClick(PlanTransitionPage.get().requestAudit, "Request Audit");
		waitForPageLoad(intMaxWaitTime);
		sewaitForPlanStatus(strVersionID,"Pending Audit");
		waitForPageLoad(intMaxWaitTime);
		FindPlanPage.get().findPlan(strVersionID);
		waitForPageLoad(intMaxWaitTime);
		String completionStatus  =getWebDriver().findElement(By.className("plan-status-value")).getText().toString().trim();
		if(completionStatus.contains("Pending Audit"))
		{
			RESULT_STATUS = true;
			log(PASS,"Verify if status is pending Audit","Status is Pending Audit",true);
		}
		else
		{
			RESULT_STATUS = false;
			log(FAIL,"Verify if status is pending Audit","Status is not Pending Audit",true);
		}
		 seClick(PlanHeaderPage.get().close, "Close button");
		
		waitForPageLoad(600);				
		seClick(PlanHeaderPage.get().userLogout, "Logout");
		waitForPageLoad();
		seCloseBrowser();
		seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
	    waitForPageLoad();
	    LoginPage.get().loginApplication(strUserProfileApprover);
	    waitForPageLoad();
	    FindPlanPage.get().findPlan(strVersionID);
		waitForPageLoad(intMaxWaitTime);
		
		seClick(PlanHeaderPage.get().approveAudit, "approve");
	seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "reason code");
	seClick(PlanTransitionPage.get().approved, "approved");
	seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
	waitForPageLoad(45);
	
	seClick(PlanHeaderPage.get().moveT0Test, "moveToTest");
	seClick(PlanHeaderPage.get().moveToTestButton, "moveToTestButton");
	waitForPageLoad();
	seClick(PlanHeaderPage.get().approve, "approved");
	seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "reason code");
	seClick(PlanTransitionPage.get().approved, "approved");
	seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
	seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//a[text()='Finalize']")), 6);
	seClick(getWebDriver().findElement(By.xpath("//a[text()='Finalize']")), "finalize");
	waitForPageLoad();
	seClick(PlanTransitionPage.get().finalizeButtoninPT, "finalize");
	waitForPageLoad(45);
	waitForPageLoad(intMaxWaitTime);
	sewaitForPlanStatus(strVersionID,"Production");
	waitForPageLoad(intMaxWaitTime);
	FindPlanPage.get().findPlan(strVersionID);
	waitForPageLoad(intMaxWaitTime);
	String planStatus  =getWebDriver().findElement(By.className("plan-status-value")).getText().toString().trim();
	if(planStatus.contains("Production"))
	{
		RESULT_STATUS = true;
		log(PASS,"Verify if status is pending Audit","Status is Production",true);
	}
	else
	{
		RESULT_STATUS = false;
		log(FAIL,"Verify if status is pending Audit","Status is Production",true);
	}
	
	
	
	
	
	
}
	/**
	 * This method Requests audit for the plan and waits until the status is changed to 'Pending Audit'.
	 * @param strVersionID (required) Plan Version id which is being Requested for Audit
	 * @param intMaxWaitTime (required) Max time method will wait for condition
	 */
	public void requestAuditPlan(String strVersionID, int intMaxWaitTime)
	{
		waitForPageLoad(3, intMaxWaitTime);
		seClick(PlanHeaderPage.get().requestAudit, "Request Audit for Plan");
		waitForPageLoad(3, intMaxWaitTime);
		seClick(PlanTransitionPage.get().reasonCode, "Reason Code");
		waitForPageLoad(1, intMaxWaitTime);
		seClick(PlanTransitionPage.get().selectType("Other"), "Select Other from Reason Code");
		waitForPageLoad(intMaxWaitTime);
		seClick(PlanTransitionPage.get().requestAudit, "Request Audit");
		waitForPageLoad(intMaxWaitTime);
		sewaitForPlanStatus(strVersionID,"Pending Audit");
		waitForPageLoad(intMaxWaitTime);
		FindPlanPage.get().findPlan(strVersionID);
		waitForPageLoad(intMaxWaitTime);
		String completionStatus  =getWebDriver().findElement(By.className("plan-status-value")).getText().toString().trim();
		if(completionStatus.contains("Pending Audit"))
		{
			RESULT_STATUS = true;
			log(PASS,"Verify if status is pending Audit","Status is Pending Audit",true);
		}
		else
		{
			RESULT_STATUS = false;
			log(FAIL,"Verify if status is pending Audit","Status is not Pending Audit",true);
		}
		
		

	}
	
	public static void sewaitForPlanStatus(String strVersionID, String strStatus)
	{
		ExpectedCondition<Boolean> expectation = new  ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return FindPlanPage.get().findPlan(strVersionID, strStatus);
			}
		};

		WebDriverWait wait = new WebDriverWait(getWebDriver(), 600);
		wait.pollingEvery(5, TimeUnit.SECONDS);
		wait.until(expectation);

	}

	/**
	 * This method can be used to do a 'Reject Test' operation on a plan that is
	 * in 'Sent to Test' status. The Plan moves to 'Test Failed' status.
	 */
	public void seRejectTest() {
		try {
			seWaitForClickableWebElement(PlanHeaderPage.get().rejectTest, 60);
			seClick(PlanHeaderPage.get().rejectTest, "Reject Test");
			seWaitForClickableWebElement(PlanTransitionPage.get().reasonCode, 60);
			seClick(PlanTransitionPage.get().reasonCode, "Reason Code");
			seClick(PlanTransitionPage.get().selectType("Other"), "Select Other from Reason Code");
			seWaitForClickableWebElement(PlanTransitionPage.get().txtWorkflowComment, 60);
			seSetText(PlanTransitionPage.get().txtWorkflowComment, "Test Comment", "Comment");
			seClick(PlanTransitionPage.get().btnRejectedTest, "Rejected Test");
			waitForPageLoad();

			String strActualStatus = seGetElementValue(PlanHeaderPage.get().planStatus);
			if (strActualStatus.equalsIgnoreCase("Test Failed")) {
				RESULT_STATUS = true;
				log(PASS, "Verify if Plan Status is 'Test Failed'.",
						"Plan Status is '" + strActualStatus + "' as expected value 'Test Failed', RESULT=PASS");
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify if Plan Status is 'Test Failed'.",
						"Plan Status is '" + strActualStatus + "' NOT as expected value 'Test Failed', RESULT=FAIL");
			}
		} catch (Exception e) {
			log(ERROR, "Error while executing 'seRejectTest' method.");
		}
	}

	/**
	 * This method can be used to do a 'Request Audit' operation on a plan that
	 * is in 'Draft' status. The Plan moves to 'Processing in Progress' status
	 * and later to 'Pending Audit' status.
	 */
	public void seRequestAudit() {
		try {
			seWaitForClickableWebElement(PlanHeaderPage.get().requestAudit, 60);
			seClick(PlanHeaderPage.get().requestAudit, "Request Audit");
			seWaitForClickableWebElement(PlanTransitionPage.get().reasonCode, 60);
			seClick(PlanTransitionPage.get().reasonCode, "Reason Code");
			seClick(PlanTransitionPage.get().selectType("Other"), "Select Other from Reason Code");
			seWaitForClickableWebElement(PlanTransitionPage.get().txtWorkflowComment, 60);
			seSetText(PlanTransitionPage.get().txtWorkflowComment, "Test Comment", "Comment");
			seClick(PlanTransitionPage.get().btnRejectedTest, "Request Test");
			waitForPageLoad();

			String strActualStatus = seGetElementValue(PlanHeaderPage.get().planStatus);
			if (strActualStatus.equalsIgnoreCase("Processing in Progress")) {
				RESULT_STATUS = true;
				log(PASS, "Verify if Plan Status is 'Processing in Progress'.", "Plan Status is '" + strActualStatus
						+ "' as expected value 'Processing in Progress', RESULT=PASS");
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify if Plan Status is 'Processing in Progress'.", "Plan Status is '" + strActualStatus
						+ "' NOT as expected value 'Processing in Progress', RESULT=FAIL");
			}
		} catch (Exception e) {
			log(ERROR, "Error while executing 'seRequestAudit' method.");
		}
	}

	/**
	 * This method can be used to edit a plan that is 'Test Failed' status and
	 * create a new copy of plan in 'Draft' status.
	 */
	public void seEditPlan() {
		try {
			seWaitForClickableWebElement(PlanHeaderPage.get().editPlan, 60);
			seClick(PlanHeaderPage.get().editPlan, "Edit");
			seWaitForClickableWebElement(EditPlanInfo.get().btnSave, 60);
			seClick(EditPlanInfo.get().btnSave, "Save");
			waitForPageLoad();

			String strActualStatus = seGetElementValue(PlanHeaderPage.get().planStatus);
			if (strActualStatus.equalsIgnoreCase("Draft")) {
				RESULT_STATUS = true;
				log(PASS, "Verify if Plan Status is 'Draft'.",
						"Plan Status is '" + strActualStatus + "' as expected value 'Draft', RESULT=PASS");
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify if Plan Status is 'Draft'.",
						"Plan Status is '" + strActualStatus + "' NOT as expected value 'Draft', RESULT=FAIL");
			}
		} catch (Exception e) {
			log(ERROR, "Error while executing 'seEditPlan' method.");
		}
	}

	/**
	 * This method can be used to Close the plan and navigate back to 'Find
	 * Plan' screen.
	 */
	public void seClosePlan() {
		try {
			seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().closePlan, 60);
			seClick(PCPSPCBreakoutSetupPage.get().closePlan, "Close");
			waitForPageLoad();

			if (FindPlanPage.get().searchResults.isDisplayed() && FindPlanPage.get().searchResults.isEnabled()) {
				RESULT_STATUS = true;
				log(PASS, "Verify if Plan is Closed.", "Plan is Closed, RESULT=PASS");
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify if Plan is Closed.", "Plan is NOT Closed, RESULT=FAIL");
			}
		} catch (Exception e) {
			log(ERROR, "Error while executing 'seClosePlan' method.");
		}
	}
	 public void seReasonCode()
	   	{try{
	   		seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//*[@id='content-workflow']/form/div[3]/div[3]/div/span/span[1]/span/span[2]")), 10);
	   		waitForPageLoad();
	   		seClick(getWebDriver().findElement(By.xpath("//*[@id='content-workflow']/form/div[3]/div[3]/div/span/span[1]/span/span[2]")), "ReasonCode drop down");
	   		waitForPageLoad();
	   		seSetText(getWebDriver().findElement(By.xpath("//*[@id='content-workflow']/span/span/span[1]/input")),"Other","setting text");
	   		waitForPageLoad();
	   		seClick(getWebDriver().findElement(By.xpath("//*[@id='content-workflow']/span/span/span[2]")), "Reason Code option Select");
	   	} catch (Exception e) {
	   		e.printStackTrace();
	   		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
	   	}
	   }	
	
	public void seMovePlanToSentToTest(String PlanId) throws TimeoutException{
	    	FindPlanPage.seSearchByPlanProxyID(PlanId);
		    waitForPageLoad(45);
		    Boolean auditStatus= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit"); 
		    if(auditStatus==true){
				log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");
			}
			else { 
				throw new TimeoutException("Plan is not in Pending Audit status");
			}	
            seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 10);
		    seClick(PlanHeaderPage.get().approveAudit, "Approve Audit");
			waitForPageLoad(30);																	
			seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, 10);
			seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
			seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeText, 1);								
			seSetText(PlanTransitionPage.get().planTransitionReasonCodeText, "Approved", "as " + "Approved");
			seClick(PlanTransitionPage.get().approved, "approved reason code");
			seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
			waitForPageLoad(45);
			seWaitForClickableWebElement(PlanHeaderPage.get().moveToTestPHPage, 12);
			seClick(PlanHeaderPage.get().moveToTestPHPage, "Move to test button");
			waitForPageLoad();
			seClick(PlanTransitionPage.get().moveToTest, "Move to test ");
			waitForPageLoad(45);
			seWaitForClickableWebElement(PlanHeaderPage.get().approveTestForFinalize, 12);	
	}
	
	public String seMovePlanSentToTest_To_Production(String plan){
		FindPlanPage.seSearchByPlanProxyID(plan);
		waitForPageLoad(45);
	    seWaitForClickableWebElement(PlanHeaderPage.get().approveTestForFinalize, 15);
	    String planVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1].trim();
		waitForPageLoad(5,65);
		seClick(PlanHeaderPage.get().approveTestForFinalize, "Approve test button");
		waitForPageLoad();								
		seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "reason code");
		seClick(PlanTransitionPage.get().approved,"approved");
		seClick(PlanTransitionPage.get().approvedTest, "approve test");
		waitForPageLoad(45);
		seWaitForClickableWebElement(PlanHeaderPage.get().finalize, 12);
		seClick(PlanHeaderPage.get().finalize, "Finalize");
		waitForPageLoad();
		seClick(PlanTransitionPage.get().finalizeButtoninPT, "finalize");
		waitForPageLoad();
    	try{
    		seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 300);
    		}
		catch(org.openqa.selenium.TimeoutException e){
            seClick(PlanHeaderPage.get().close, "Close button");
			waitForPageLoad();
            }

		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);
		waitForPageLoad(45);								
        Boolean finalStatus= PlanHeaderPage.get().seVerifyPlanStatus("Production");							 
        if(finalStatus==true){
              	log(PASS, "plan takes correct time to load","plan is in Production status,RESULT=PASS");
                         }
        else { 
        	throw new org.openqa.selenium.TimeoutException("Plan is not in Production status");
              }	
        
        return planVersionID;
	}
	
	
}
