package page.planConfigurator;

import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;
import utility.ExcelUtility;

public class TemplatePlanOptionPage extends CoreSuperHelper{
	
	private static TemplatePlanOptionPage thisTestObj;	
	public synchronized static TemplatePlanOptionPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), TemplatePlanOptionPage.class);
		return thisTestObj;
	}
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"bulk-impact-sectionWrapper\"]/div/div/div[1]/button")
	@CacheLookup
	public WebElement refresh;
	
	@FindBy(how = How.XPATH, using = "//div[@id='verticalBarMenu']/div[2]/ul/li[@id=\"PlanOptions\"]/a")
	@CacheLookup
	public WebElement planOptionTab;
	
	
	@FindBy(how = How.ID, using = "POA_PlanOptions-_-InptFac-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares")
	@CacheLookup
	public WebElement 	inPatientFacilityInNetworkCostSharesBenefitSpecificCostShares;
	
	@FindBy(how = How.ID, using = "POA_PlanOptions-_-InptFac-_-CoveredINNOON-_-CostSharesINNT1-_-PaidAsPlanLevel")
	@CacheLookup
	public WebElement 	inPatientFacilityInNetworkCostSharesPaidAsPlanLevel;
	
	@FindBy(how = How.ID, using = "POA_PlanOptions-_-InptFac-_-CoveredINNOON-_-NA-_-NA-_-PREFApplies_-_choice")
	@CacheLookup
	public WebElement 	inPatientFacilityInNetworkCostSharesBenefitSpecificCostSharesApplyDeductible;
	
	
	
	//*[@id="verticalBarMenuDetails"]/div/nav/div[2]/ul/li[3]/a
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"verticalBarMenuDetails\"]/div/nav/div[2]/ul/li[3]/a")
	@CacheLookup
	public WebElement outPatientCare;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"verticalBarMenuDetails\"]/div/nav/div[2]/ul/li[2]/a")
	@CacheLookup
	public WebElement inPatientFacility;
	
	
	
	
	
	public WebElement planOption;
	
	public WebElement getPlanOption(String strPlanOption)
	{
		String strPlanOptionLocator = getPlanOptionHeader(strPlanOption);
		planOption = getWebDriver().findElement(By.xpath(strPlanOptionLocator));
		
		return planOption;
	}
	
	
	public String getPlanOptionHeader(String strPlanOption)
	{
		String strPlanOptionLocator = "";
		switch(strPlanOption.toUpperCase())
		{
		case "OFFICE EXAMS":
			strPlanOptionLocator = "//*[@id=\"OfficeExamsHeader\"]/span[2]/div/span[1]/input";
			break;
		case "OFFICE EXAMS PRIMARY CARE PHYSICIAN":
			strPlanOptionLocator = "//*[@id=\"OfficeExamsPCPHeader\"]/span[2]/div/span[1]/input";
			break;
		case "INPATIENT FACILITY":
			seClick(inPatientFacility, "InPatient Facility");
			strPlanOptionLocator = "//*[@id=\"InptFacHeader\"]/span[2]/div/span[1]/input";
			break;
		
		case "OUTPATIENT CARE":
			seClick(outPatientCare, "Out Patient Care");
			strPlanOptionLocator = "//*[@id=\"OutptCareHeader\"]/span[2]/div/span[1]/input";
			
			break;
		default:
			throw new IllegalArgumentException("Not a valid Plan Option");
		
		}
		return strPlanOptionLocator;
	}
	
	
	/**
	 * @author AF12450
	 * The below method is to add or remove a plan option from the Template
	 * @param strAddOrRemove: string value to indicate the add or remove the plan option
	 * @param strPlanOption: Plan option that need to be added or removed
	 * @return
	 * @throws Exception
	 */
	public boolean addOrRemovePlanOption(String strAddOrRemove, String strPlanOption) throws Exception
	{
		boolean addOrRemovePlanOptionStatus = false;
		try
		{
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",planOptionTab);
		waitForPageLoad(300);
		
		if(strAddOrRemove.equalsIgnoreCase("ADD"))
		{
			if(!TemplatePlanOptionPage.get().getPlanOption(strPlanOption).isSelected())
			{
				addOrRemovePlanOptionStatus = true;
				seClick(TemplatePlanOptionPage.get().getPlanOption(strPlanOption), strPlanOption);
			}
			else
			{
				RESULT_STATUS = false;
				log(FAIL, "Add or Remove Plan Option", "Not a valid test as the plan option is already selected");
			}
		}
		else if(strAddOrRemove.equalsIgnoreCase("REMOVE"))
		{
			if(TemplatePlanOptionPage.get().getPlanOption(strPlanOption).isSelected())
			{
				addOrRemovePlanOptionStatus = true;
				seClick(TemplatePlanOptionPage.get().getPlanOption(strPlanOption), strPlanOption);
			}
			else
			{
				RESULT_STATUS = false;
				log(FAIL, "Add or Remove Plan Option", "Not a valid test as the plan option is already removed");
			}
		}
		else
		{
			RESULT_STATUS = false;
		}
		
		waitForPageLoad(300);	
//		seClick(TemplateHeaderPage.get().save, "Save Button ");
		waitForPageLoad(300);	
		}
		catch(Exception e)
		{
			e.printStackTrace();
			log(FAIL, "Add or Remove Plan Option","Exceptio Occured in this method : "+e.getLocalizedMessage());
		}
		return addOrRemovePlanOptionStatus;
		
	}
	
	public Hashtable<String, String> editPlanOption(String strPlanOption)
	{
		Hashtable<String, String> updateStatus = new Hashtable<>();
		String strExistingApplyDeducticle = "";
		String strUpdatedApplyDeducticle = "";
		String booEditPlanOptionStatus = "FAIL";
		try{ 
			waitForPageLoad(300);
			 PlanOptionsPage.clickTab("Plan Options", "Inpatient Facility", 300);
			waitForPageLoad(2,300);
			strExistingApplyDeducticle = seGetDropDownValue(TemplatePlanOptionPage.get().inPatientFacilityInNetworkCostSharesBenefitSpecificCostSharesApplyDeductible);
			waitForPageLoad(2,300);
			if(strExistingApplyDeducticle.equalsIgnoreCase("Yes"))
			{
				seSelectText(TemplatePlanOptionPage.get().inPatientFacilityInNetworkCostSharesBenefitSpecificCostSharesApplyDeductible, "No", "Select \"No\" for Apply Deductible");
				waitForPageLoad(300);
				strUpdatedApplyDeducticle = seGetDropDownValue(TemplatePlanOptionPage.get().inPatientFacilityInNetworkCostSharesBenefitSpecificCostSharesApplyDeductible);
				booEditPlanOptionStatus = strUpdatedApplyDeducticle.equalsIgnoreCase("NO")?"PASS":"FAIL";
				log(booEditPlanOptionStatus.equalsIgnoreCase("PASS")?PASS:FAIL, "Update Apply Deductible", "Value updated value to No", true);
			}
			else
			{
				seSelectText(TemplatePlanOptionPage.get().inPatientFacilityInNetworkCostSharesBenefitSpecificCostSharesApplyDeductible, "Yes", "Select \"Yes\" for Apply Deductible");
				waitForPageLoad(300);
				strUpdatedApplyDeducticle = seGetDropDownValue(TemplatePlanOptionPage.get().inPatientFacilityInNetworkCostSharesBenefitSpecificCostSharesApplyDeductible);
				booEditPlanOptionStatus = strUpdatedApplyDeducticle.equalsIgnoreCase("YES")?"PASS":"FAIL";
				log(booEditPlanOptionStatus.equalsIgnoreCase("PASS")?PASS:FAIL, "Update Apply Deductible ", "Value updated value to Yes", true);
			}
			waitForPageLoad(360);
						
		}
		catch(Exception e)
		{
			e.printStackTrace();
			log(FAIL,"Unable to edit template","Unable to edit template",true);
		}
		updateStatus.put("Existing Apply Deductible", strExistingApplyDeducticle);
		updateStatus.put("Updated Apply Deductible", strUpdatedApplyDeducticle);
		updateStatus.put("Edit Plan Option Status", booEditPlanOptionStatus);
		return updateStatus;
	}

	public void validateEditPlanOption(String[] strPlanID, String strreportFolder,String strUpdateFolder,String strPlanOptionOldValue, String strPlanOptionNewValue, String  editPlanOptionStatus)
	{
		try
		{
		String strPlanID1 = strPlanID[0];
		String strPlanID2 = strPlanID[1];
        if(editPlanOptionStatus != null)
        {
        	if(editPlanOptionStatus.equals("PASS"))
        	{
        	log(INFO, "Started Validation  Edit Plan Option in Impact Analysis and Update Report","");
        	ExcelUtility.get().validatePlanOptionUpdateinIMpactReport(strPlanID1,strreportFolder, strPlanOptionOldValue, strPlanOptionNewValue);
        	ExcelUtility.get().validatePlanOptionUpdateinIMpactReport(strPlanID2, strreportFolder, strPlanOptionOldValue, strPlanOptionNewValue);
        	ExcelUtility.get().validatePlanOptionUpdateInUpdateReport(strPlanID1, strUpdateFolder, strPlanOptionOldValue, strPlanOptionNewValue);
        	ExcelUtility.get().validatePlanOptionUpdateInUpdateReport(strPlanID2, strUpdateFolder, strPlanOptionOldValue, strPlanOptionNewValue);
        	
        	
        	log(INFO, "Completed Validation Edit Plan Option in Impact Analysis and Update Report","");
        	}
        	else
        	{
        		log(FAIL, "Verify Edit Plan Option in Bulk Republish Process","Edit Plan Option in the template and perform bulk republish");
        	}
        	
        }
        else
        {
        	log(FAIL, "Verify Edit Plan Option in Bulk Republish Process","Edit Plan Option in the template and perform bulk republish");
        }
		}
		catch (Exception e) {
			e.printStackTrace();
			log(FAIL, "Validate Bulk Republish process after Editing plan options", "Exception Occured "+e.getLocalizedMessage());
		}
	}

}
