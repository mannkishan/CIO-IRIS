package page.planConfigurator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import utility.CoreSuperHelper;

public class PharmacyAccumAndBenefitsPage extends CoreSuperHelper{
	private static PharmacyAccumAndBenefitsPage thisIsTestObj;
	public  synchronized static PharmacyAccumAndBenefitsPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), PharmacyAccumAndBenefitsPage.class);
		return thisIsTestObj;
		}
	
	@FindBy(how = How.XPATH, using = "//*[@id='Base']/a")
	@CacheLookup
	public WebElement pharmacyPlanLevelBenefitsTab;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='verticalBarMenuDetails']/div/nav/div[3]/div")
	@CacheLookup
	public WebElement pharmacyPlanLevelBenefitsScroll;
	
	@FindBy(how = How.XPATH, using = "//a[@class='optionItem' and @data-target='#planOption_DrugUtilizationReview']")
	@CacheLookup
	public WebElement pharmacyPlanLevelBenefits_DrugUtilizationReview;
	
	@FindBy(how = How.XPATH, using = "//input[@id='POA_Base-_-DrugUtilizationReview-_-DrugUtilizationReview']")
	@CacheLookup
	public WebElement pharmacyPlanLevelBenefits_DrugUtilizationReview_RadioButton;
	
	@FindBy(how = How.XPATH, using = "//input[@id='POA_Base-_-DrugUtilizationReview-_-DURSpecialtyPackage']")
	@CacheLookup
	public WebElement pharmacyPlanLevelBenefits_DrugUtilizationReviewpecialtyPackage_RadioButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='BenefitOption']/a")
	@CacheLookup
	public WebElement pharmacyBenefitOptionsTab;
	
	@FindBy(how = How.XPATH, using = "//a[@class='optionItem' and @data-target='#planOption_AcneProds']")
	@CacheLookup
	public WebElement pharmacyBenefitsOptions_AcneProducts;
	
	@FindBy(how = How.XPATH, using = "//a[@class='optionItem' and @data-target='#planOption_ContraceptDevices']")
	@CacheLookup
	public WebElement pharmacyBenefitsOptions_Contraceptives;
	
	
	@FindBy(how = How.XPATH, using = "//input[@id='POA_BenefitOption-_-ContraceptDevices-_-CoveredRetailAndMail']")
	@CacheLookup
	public WebElement pharmacyBenefitsOptions_Contraceptives_CoveredRetailAndMail_RadioButton;
	
	@FindBy(how = How.XPATH, using = "//input[@id='POA_BenefitOption-_-ContraceptDevices-_-CoveredRetailOnly']")
	@CacheLookup
	public WebElement pharmacyBenefitsOptions_Contraceptives_CoveredRetailOnly_RadioButton;
	
	public void seIsPharmacyPlanOptionsVisible()
	{		
		String valueType="";
		seClick(pharmacyPlanLevelBenefitsTab, "Plan Level Benefits");
		JavascriptExecutor je = ((JavascriptExecutor) driver);
		je.executeScript("arguments[0].scrollIntoView(true);",PharmacyAccumAndBenefitsPage.get().pharmacyPlanLevelBenefits_DrugUtilizationReview);
		seClick(pharmacyPlanLevelBenefits_DrugUtilizationReview, "Drug Utilization Review");
		if(AllergySerumBenefitOptionPage.get().seCheckIsElementNotSelected(pharmacyPlanLevelBenefits_DrugUtilizationReview_RadioButton,"Drug Utilization Review"))
		{
			seClick(pharmacyPlanLevelBenefits_DrugUtilizationReview_RadioButton, "Drug Utilization Review");
			seWaitForPageLoad(20);
			valueType="DrugUtilizationReview-_-DrugUtilizationReview";
			for(int i=0;i<13;i++)
			{
				VisionAccumAndBenefitsPage.get().seIsElementAvailable(getCellValue("DrugUtilizationReviewAccumulatorValue"+i),valueType);
				
				
			}			
		}
		else
		{
			seClick(pharmacyPlanLevelBenefits_DrugUtilizationReviewpecialtyPackage_RadioButton, "Drug Utilization Review Speciality Package");
			valueType="DURSpecialtyPackage";
			for(int i=0;i<5;i++)
			{
				VisionAccumAndBenefitsPage.get().seIsElementAvailable(getCellValue("DURSpecialtyPackageAccumulatorValue"+i),valueType);
				
			}			
		}			
	}
	
	public void seIsPharmacyBenefitOptionsVisible()
	{	
		for(int i=0;i<2;i++)
		{
			seClick(VisionAccumAndBenefitsPage.get().visionBenefitScroll, "Benefit Scroll");
		}
		seClick(pharmacyBenefitOptionsTab, "Benefit Options");
		//seClick(pharmacyBenefitsOptions_AcneProducts,"Acne Products");
		seWaitForPageLoad(40);
		JavascriptExecutor je = ((JavascriptExecutor) driver);
		je.executeScript("arguments[0].scrollIntoView(true);",PharmacyAccumAndBenefitsPage.get().pharmacyBenefitsOptions_Contraceptives);
		seWaitForClickableWebElement(pharmacyBenefitsOptions_Contraceptives, 20);
		seClick(pharmacyBenefitsOptions_Contraceptives,"Contraceptives");
		seWaitForPageLoad(20);
		if(AllergySerumBenefitOptionPage.get().seCheckIsElementNotSelected(pharmacyBenefitsOptions_Contraceptives_CoveredRetailAndMail_RadioButton,"Covered Retail And Mail"))
		{
			seClick(pharmacyBenefitsOptions_Contraceptives_CoveredRetailAndMail_RadioButton, "Covered Retail And Mail");
			String chk1="";
			for(int i=1;i<5;i++)
			{
				System.out.println("Values are "+getCellValue("CRMMailCostSharesAccumulatorValue"+(i-1)));
				seWaitForPageLoad(40);
				chk1=seGetText(driver.findElement(By.xpath("//div[@id='POA_BenefitOption-_-ContraceptDevices-_-CoveredRetailAndMail-_-MailCostShares']/div/div["+i+"]/div/h4"))).trim();
				System.out.println("Check Value is "+chk1);				
				seVerifyFieldValue(driver.findElement(By.xpath("//div[@id='POA_BenefitOption-_-ContraceptDevices-_-CoveredRetailAndMail-_-MailCostShares']/div/div["+i+"]/div/h4")), chk1,getCellValue("CRMMailCostSharesAccumulatorValue"+(i-1)));
				
			}
			
			for(int i=1;i<5;i++)
			{
				System.out.println("Values are "+getCellValue("CRMRetailCostSharesAccumulatorValue"+(i-1)));
				seWaitForPageLoad(40);
				chk1=seGetText(driver.findElement(By.xpath("//div[@id='POA_BenefitOption-_-ContraceptDevices-_-CoveredRetailAndMail-_-RetailCostShares']/div/div["+i+"]/div/h4"))).trim();
				System.out.println("Check Value is "+chk1);				
				seVerifyFieldValue(driver.findElement(By.xpath("//div[@id='POA_BenefitOption-_-ContraceptDevices-_-CoveredRetailAndMail-_-RetailCostShares']/div/div["+i+"]/div/h4")), chk1,getCellValue("CRMMailCostSharesAccumulatorValue"+(i-1)));
				
			}
		}
		else
		{
			seClick(pharmacyBenefitsOptions_Contraceptives_CoveredRetailOnly_RadioButton, "Covered Retail Only");
			
		}
		
		
	}
	
}
