package page.planConfigurator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import utility.CoreSuperHelper;
//import utility.WebTable;

public class TemplateTransitionPage extends CoreSuperHelper{

	private static TemplateTransitionPage thisTestObj;	
	public synchronized static TemplateTransitionPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), TemplateTransitionPage.class);
		return thisTestObj;
	}
	
	//span[starts-with(@id,'select2-reasonCode')]
	@FindBy(how = How.XPATH, using = "//*[@id='content-workflow']/form/div[3]/div[3]/div/span/span[1]/span")
	@CacheLookup
	public WebElement reasonCode;   
	
	@FindBy(how = How.XPATH, using = "//div[@id='content-workflow']/form/div[3]/div[3]/div/span/span[1]/span/span[1]")
	@CacheLookup
	public WebElement reasonCode_Situation; 
	
	@FindBy(how = How.XPATH, using = "//textarea[@id='comment']")
	@CacheLookup
	public WebElement comment;
	
	@FindBy(how = How.XPATH, using = "//div[@class='bulkConfigureContent']/div/div[6]/button[2]")
	@CacheLookup
	public WebElement submit;
		
	public WebElement selectType(String type)   
    {
           WebElement valueType = getWebDriver().findElement(By.xpath("//span[@class='select2-results']/ul/li/span[text()='"+type+"']"));
           return valueType;
    } 
	
	public WebElement selectTypeSituation(String type) 
    {
           WebElement valueType = getWebDriver().findElement(By.xpath("//span[@class='select2-results']/ul/li[3]/span[text()='"+type+"']"));
           return valueType;
    } 
	
	@FindBy(how = How.XPATH, using = "//div[@id='content-workflow']/form/div[3]/div[5]/div/button[2]")
	@CacheLookup
	public WebElement requestAuditButton;  //div[@id='main']/div[1]/div[5]/form/div[3]/div[5]/div/button[2]
	
	@FindBy(how = How.XPATH, using = "//div[@id='content-workflow']/form/div[3]/div[5]/div/button[2]")
	@CacheLookup
	public WebElement approveAuditButton;
	
	@FindBy(how = How.XPATH, using = "//div[@id='content-workflow']/form/div[3]/div[5]/div/button[2]")
	@CacheLookup
	public WebElement finalizeButton;
	
	@FindBy(how = How.XPATH, using = "//div[@id='content-workflow']/form/div[3]/div[5]/div/button[2]")
	@CacheLookup
	public WebElement moveToProductionButton;
	
}
