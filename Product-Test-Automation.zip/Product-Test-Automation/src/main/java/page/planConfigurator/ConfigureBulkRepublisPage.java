package page.planConfigurator;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import utility.CoreSuperHelper;

public class ConfigureBulkRepublisPage extends CoreSuperHelper{
	
	private static ConfigureBulkRepublisPage thisIsTestObj;
	public  synchronized static ConfigureBulkRepublisPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), ConfigureBulkRepublisPage.class);
		return thisIsTestObj;
		}
	@FindBy(how = How.XPATH, using = "//span[starts-with(@id,'select2-reasonCode')]")
	@CacheLookup
	public WebElement reasonCode;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"bulk-configure-sectionWrapper\"]/div/div/div[3]/div/textarea")
	@CacheLookup
	public WebElement comment;
	
	public static void sewaitForTemplateStatus(String versionID, String Status)
	{
		ExpectedCondition<Boolean> expectation = new  ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
            	
            String	completionStatus  =getWebDriver().findElement(By.xpath("//div[@id='planHeaderWrapper']/div/div/div[2]/div[2]/div[1]/div[2]/span[2]")).getText().toString().trim();
        		if(completionStatus.equalsIgnoreCase(Status))
        		{			
        		   return true;
        		}
        		else
        		{
        			return false;
        		}
            	
            }
        };

        WebDriverWait wait = new WebDriverWait(getWebDriver(), 600);
        wait.pollingEvery(5, TimeUnit.SECONDS);
        wait.until(expectation);
    
	}

}
