package page.planConfigurator;


import java.util.HashMap;
import java.util.List;
import java.util.logging.Handler;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.constants.ApplicationConstants;
import com.anthem.selenium.utility.ExtentReportsUtility;

import utility.CoreSuperHelper;
import utility.PlanXMLParser;
import utility.WebTable;

public class BenefitsPage extends CoreSuperHelper{
	
	private static BenefitsPage thisTestObj;	
	public synchronized static BenefitsPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), BenefitsPage.class);
		return thisTestObj;
		
	}				

	//This Class contains webelements that are identified in the Benefits Tab
	@FindBy(how = How.XPATH, using = "//*[@id=\"verticalBarMenu\"]/div[3]/div")
	@CacheLookup
	public WebElement firstScroll;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"BenefitTree\"]/a")
	@CacheLookup
	public WebElement benefitTab;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-benefitSearchBar\"]/div[2]/div/input")
	@CacheLookup
	public WebElement searchBenefit;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-benefitSearchBar\"]/div[2]/button[2]")
	@CacheLookup
	public WebElement searchButtonBenefit;
	
	@FindBy(how = How.XPATH, using = "//a[@class='benefitTreeEntryElement  hasBenefitDetail jstree-search'][text()='Urgent Care Center']")
	@CacheLookup
	public WebElement urgentCareCenter;
	
	@FindBy(how = How.XPATH, using = "//a[@class='benefitTreeEntryElement  hasBenefitDetail jstree-search'][text()='Allergy Serum']")
	@CacheLookup
	public WebElement allergySerum;

	@FindBy(how = How.XPATH, using = "//a[@class='benefitTreeEntryElement  hasBenefitDetail jstree-search'][text()='Allergy Testing']")
	@CacheLookup
	public WebElement allergyTesting;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[1]")
	@CacheLookup
	public WebElement tier1Dropdown;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[1]/td[5]/span/span/span/div[2]/span/span")
	//@CacheLookup
	public WebElement copaymentText; 
	
	@FindBy(how = How.XPATH, using = "//*[@id='benefitDetailsHeaderWrapper']//*[@title='Expand All']")
	@CacheLookup
	public WebElement btnExpandAll; 
	
	@FindBy(how = How.XPATH, using = "//td[@class='value_Value'][contains(@fullpath,'BTC_UrgentCareFac-_-Tier1')]//span[@class='readOnly amount']")
	@CacheLookup
	public WebElement lblUrgentCareCenter_Tier1_InNtkUrgCareFacCopay;

	@FindBy(how = How.XPATH, using = "//td[@class='value_Value'][contains(@fullpath,'BTC_UrgentCareFac-_-Tier1')]//span[@class='readOnly percentage relative']")
	@CacheLookup
	public WebElement lblUrgentCareCenter_Tier1_InNtkUrgCareFacCoinsurance;

	@FindBy(how = How.XPATH, using = "//td[@class='value_Value'][contains(@fullpath,'BTC_AllergySerum-_-Tier1')]//span[@class='readOnly percentage relative']")
	@CacheLookup
	public WebElement lblAllergySerum_Tier1_InNtkAllergySerumFacCoinsurance; 

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'0_Participating')]//td[@class='value_Value'][contains(@fullpath,'BTC_UrgentCareFac-')]//span[@class='readOnly amount']")
	@CacheLookup
	public WebElement lblUrgentCareCenter_Particpating_InNtkUrgCareFacCopay;

	@FindBy(how = How.XPATH, using = "//div[contains(@class,'0_Participating')]//td[@class='value_Value'][contains(@fullpath,'BTC_Facility-_-BTC_OtherStudies-_-BTC_AllergyTesting')]//span[@class='readOnly percentage relative']")
	@CacheLookup
	public WebElement lblAllergyTesting_Participating_InNtkAllergyTestingCoinsurance;
	 

	public WebElement BenefitAccumValue(String accumName)
	{	
		WebElement LimitValue = getWebDriver().findElement(By.xpath("//span[text()='"+accumName+"']/ancestor::tr[1]/td[5]/span"));
		return LimitValue;
	}
	 

	
	public static void scroll()
	{
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,250)", "");
		
	}
	
	public void wbscrollDownBenefits()
	{
		JavascriptExecutor je = ((JavascriptExecutor) driver);
		je.executeScript("arguments[0].scrollIntoView(true);",benefitTab);
	} 
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"workingArea\"]")
	@CacheLookup
	public WebElement MainScrollDown;
	
	@FindBy(how = How.XPATH, using = "(//*[@class=\"select2-selection__rendered\"])[3]")
	@CacheLookup
	public WebElement coinsuranceText;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[2]/td[5]/span/span/span[1]")
	@CacheLookup
	public WebElement innDedFirst;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[2]/td[5]/span/span/span[2]")
	@CacheLookup
	public WebElement innDedSecond;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[1]/td[5]/span/span/span/div[2]/span/span")
	@CacheLookup
	public WebElement innUrgCareFacCopayTextBenefit;

	@FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[3]/td[5]/span/span/span/div[2]/span/span[1]/span[1]/span")
	@CacheLookup                      
	public WebElement innUrgCareFacCoinsurTextBenefit;
	
	@FindBy(how = How.XPATH, using = ".//*[@id='content-planBenefitDetails']/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div/table/tbody/tr[1]/td[5]/span/span/span")
	@CacheLookup
	public WebElement acupunctureValueBenefit ;
	
	@FindBy(how = How.XPATH, using = ".//*[@id='content-planBenefitDetails']/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div/table/tbody/tr[1]/td[5]/span/span/span")
	@CacheLookup
	public WebElement breastPumpBenefit ;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[1]/a")
	@CacheLookup
	public WebElement closeButton;
	
	@FindBy(how = How.LINK_TEXT, using = "Exam Visit")
	@CacheLookup
	public WebElement examVisit;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='content-planBenefitDetails']/div[2]/div/div[2]/div[1]/span[2]/span")
	@CacheLookup
	public WebElement situationType;
	
	//
	public WebElement situationType(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//div[@id='content-planBenefitDetails']/div[2]/div/div/div/span[2]/span[text()='"+type+"']"));
		return valueType;
	}

    public static void strcompare(String Expected,String Actual){
    
		
    	if(Expected.equals(Actual))
    	{
    		RESULT_STATUS=true;
    		log(PASS, "Comparison between Input value and value displayed in the Benefit Tab, once the edit is saved  ","Comparison As expected, RESULT=PASS");
		
    	}
    	
    	else
    	{
    		RESULT_STATUS=false;
    		log(FAIL, "Comparison between Input value and value displayed in the Benefit Tab, once the edit is saved  ","Comparison NOT as expected, RESULT=FAIL");
    		
    	}
    }
    @FindBy(how = How.XPATH, using = "//*[@id='content-planBenefitDetails']/div[2]/div/div")
	@CacheLookup
	public List<WebElement> situationGroups;



	public WebElement situationType(int row)
	{
		WebElement situation= getWebDriver().findElement(By.xpath("//*[@id='content-planBenefitDetails']/div[2]/div/div["+(row+1)+"]/div[1]/span[2]/span"));
		return situation;
	}

	public List<WebElement> listSituationTable(int row)
	{
		List<WebElement> situation= getWebDriver().findElements(By.xpath("//*[@id='content-planBenefitDetails']/div[2]/div/div["+(row+1)+"]/div[2]/div[2]/div"));
		return situation;
	}

	public WebElement situationTable(int row)
	{
		WebElement situation= getWebDriver().findElement(By.xpath("//*[@id='content-planBenefitDetails']/div[2]/div/div["+(row+1)+"]/div[2]/div[2]/div"));
		return situation;
	}


	public void clickBenefits(String strBenefitHierachy){
		try {

			String strBenefits[]=strBenefitHierachy.split(";");
			int a=0;
			int i=0;
			List<WebElement> Benefit=getWebDriver().findElements(By.xpath(".//*[@id='benefitsTree']/ul/li/div/div/div/a"));
			for (WebElement element : Benefit) {
				String benefit = element.getText();
				if(benefit.equalsIgnoreCase(strBenefits[i])){
					seClick(element,strBenefits[i] );
					i++;
					break;
				}
				a++;
			}
			int k=0;
			List<WebElement> child=getWebDriver().findElements(By.xpath("//*[@id='benefitsTree']/ul/li["+(a+1)+"]/ul/li/div/div/div/a"));
			if(child.size()>0){
				for (WebElement element : child){
					if(i<strBenefits.length&&element.getText().equalsIgnoreCase(strBenefits[i])){
						seClick(element,strBenefits[i] );
						i++;
						break;
					}
					k++;
				}
				int l=0;
				List<WebElement> lowerchild=getWebDriver().findElements(By.xpath("//*[@id='benefitsTree']/ul/li["+(a+1)+"]/ul["+(k+1)+"]/li/ul/li/div/div/div/a"));
				if(lowerchild.size()>0){
					for (WebElement element : lowerchild){
						if(i<strBenefits.length&&element.getText().equalsIgnoreCase(strBenefits[i])){
							seClick(element,strBenefits[i] );
							i++;
							break;
						}
						l++;
					}
				}
				int m=0;
				List<WebElement> fourLevel=getWebDriver().findElements(By.xpath("//*[@id='benefitsTree']/ul/li["+(a+1)+"]/ul["+(k+1)+"]/li/ul["+(l+1)+"]/li/ul/li/div/div/div/a"));
				if(fourLevel.size()>0){
					for (WebElement element : fourLevel){
						if(i<strBenefits.length&&element.getText().equalsIgnoreCase(strBenefits[i])){
							seClick(element,strBenefits[i] );
							i++;
							break;
						}
						m++;
					}
				}
				List<WebElement> fiveLevel=getWebDriver().findElements(By.xpath("//*[@id='benefitsTree']/ul/li["+(a+1)+"]/ul["+(k+1)+"]/li/ul["+(l+1)+"]/li/ul["+(m+1)+"]/li/ul/li/div/div/div/a"));
				if(fiveLevel.size()>0){
					for (WebElement element : fiveLevel){
						if(i<strBenefits.length&&element.getText().equalsIgnoreCase(strBenefits[i])){
							seClick(element,strBenefits[i] );
							i++;
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void clickBenefitstab(){
		WebElement optionsTab = BenefitsPage.get().benefitTab;
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",optionsTab);	

	}

	public String deductibleName(String AccumulatorName,boolean ind){
		String Accumulator="";
		try {
			if(AccumulatorName.equalsIgnoreCase("In Network Deductible")){
				if(ind)
					Accumulator="In Network Individual Deductible";
				else
					Accumulator="In Network Family Deductible";
			}
			else if(AccumulatorName.equalsIgnoreCase("Out of Network Deductible")){
				if(ind)
					Accumulator="Out of Network Individual Deductible";
				else
					Accumulator="Out of Network Family Deductible";
			}
		} catch (Exception e) {
			RESULT_STATUS = false;
			e.printStackTrace();
		}
		return Accumulator;
	}
	
	public void compareAccumulator(String accumvalue, String xmlAccumValue, String accumName){
		try {
			if(accumvalue.replace(",", "").contains(xmlAccumValue))
			{
				RESULT_STATUS = true;
				log(PASS, "Validate Accumulator Value"+accumName, "Accumulator Value is same in Both Benefit "+accumvalue+ " and XML "+xmlAccumValue, true);
			}
			else{
				RESULT_STATUS = false;
				log(FAIL, "Validate Accumulator Value"+accumName, "Accumulator Value is not same in Both Benefit "+accumvalue+ " and XML "+xmlAccumValue, true);
			}
		} catch (Exception e) {
			RESULT_STATUS = false;
			e.printStackTrace();
		}
	}
	
	public boolean validateSituation(String strBenefit,String xmlPath){
		String accumulatorValue="";
		String AccumulatorName = "";
		try{
			HashMap<String, String>strXMLsituationType=PlanXMLParser.getAllSituations(xmlPath, strBenefit);
			if(BenefitsPage.get().situationGroups.size()>0){
				HashMap<String, String>xmlAccumulator=PlanXMLParser.getAccumlatorValue(xmlPath, strBenefit);	
				for(int j =0; j< BenefitsPage.get().situationGroups.size();j++){
					String strSituationType = BenefitsPage.get().situationType(j).getText();
					String situationType=strXMLsituationType.get("situation "+j);
					if(strSituationType.equalsIgnoreCase(situationType)){
						RESULT_STATUS = true;
						log(PASS, "Validate Situation Type", "Situation Type is same in Both Benefit "+strSituationType+ " and XML "+situationType, true);
					}
					else{
						RESULT_STATUS = false;
						log(FAIL, "Validate Situation Type", "Situation Type is not same in Both Benefit "+strSituationType+ " and XML "+situationType, true);
					}
					if(RESULT_STATUS){
						seClick(BenefitsPage.get().situationType(j), strSituationType);
						waitForPageLoad(200);
						if(BenefitsPage.get().listSituationTable(j).size()>0){
							if(!BenefitsPage.get().situationTable(j).getText().contains("Not Covered")){
								WebTable tabledetails = new WebTable(BenefitsPage.get().situationTable(j), "Situation Table");
								int row=tabledetails.getRowsCount();
								for(int rows=1;rows<=row;rows++){
									String type=tabledetails.getCellData(rows, 3);
									accumulatorValue=tabledetails.getCellData(rows, 5);
									if(type.equalsIgnoreCase("Deductible")&&accumulatorValue.contains("/")){
										String straccumulatorValue[]=tabledetails.getCellData(rows, 5).split("/");
										String accumulatorIndValue=straccumulatorValue[0];
										AccumulatorName=tabledetails.getCellData(rows, 4);
										AccumulatorName=BenefitsPage.get().deductibleName(AccumulatorName,true);
										String strXMLAccumulatorValue[]=xmlAccumulator.get(AccumulatorName).split("\\.");
										BenefitsPage.get().compareAccumulator(accumulatorIndValue, strXMLAccumulatorValue[0],AccumulatorName);
										String accumulatorFamValue=straccumulatorValue[1];
										AccumulatorName=tabledetails.getCellData(rows, 4);
										AccumulatorName=BenefitsPage.get().deductibleName(AccumulatorName,false);
										strXMLAccumulatorValue=xmlAccumulator.get(AccumulatorName).split("\\.");
										BenefitsPage.get();
										BenefitsPage.get().compareAccumulator(accumulatorFamValue, strXMLAccumulatorValue[0],AccumulatorName);
									}
									else{
										AccumulatorName=tabledetails.getCellData(rows, 4);
										accumulatorValue=tabledetails.getCellData(rows, 5);
										String strXMLAccumulatorValue[]=xmlAccumulator.get(AccumulatorName).split("\\.");
										BenefitsPage.get();
										BenefitsPage.get().compareAccumulator(accumulatorValue, strXMLAccumulatorValue[0],AccumulatorName);
									}
								}

							}
							else{
								if(!(xmlAccumulator.size()>0)){
									RESULT_STATUS = true;
									log(PASS,"Validate Accumulator","There is no Accumulator for this Benefit",true);
								}
							}
						}
					}
				}
			}
			else{
				if(!(strXMLsituationType.size()>0))
					RESULT_STATUS = true;
				log(PASS,"Validate Situation Type","No benefit information to display",true);
			}
		}		
		catch(Exception e){
			e.printStackTrace();
		}
		return RESULT_STATUS;
	}

	//#########################################################################################################################################
	
    public  void validateBenefitChangeinPlan(String strPlanVersionID,String benefit,String strAddRemoveFlag)
	{
		try{
			waitForPageLoad(300);
			WebElement Benefits = getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenu']/div[2]/ul/li[@id=\"BenefitTree\"]/a")) ;
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",Benefits);
			
			waitForPageLoad(360);
			List<WebElement> urgentCare = getWebDriver().findElements(By.linkText(benefit));
			boolean urgentCarePresence = false;
			if(urgentCare.size()>0)
			{
				
				urgentCarePresence = true;
			}
			if(strAddRemoveFlag.equalsIgnoreCase("ADD"))
			{
				
				if(urgentCarePresence)
					log(PASS,"Benefit changes are reflecting successfully for plan","Verify if Benefit changes are reflecting successfully for plan",true);
				else
					log(FAIL,"Benefit changes are not reflecting successfully for plan","Verify if Benefit changes are reflecting successfully for plan",true);				
			}
			else if(strAddRemoveFlag.equalsIgnoreCase("REMOVE"))
			{
				if(!urgentCarePresence)
					log(PASS,"Benefit changes are reflecting successfully for plan","Verify if Benefit changes are reflecting successfully for plan",true);
				else
					log(FAIL,"Benefit changes are not reflecting successfully for plan","Verify if Benefit changes are reflecting successfully for plan",true);				
			}
			else
			{
				log(FAIL,"Not a valid test","Please check the test data",true);
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			log(FAIL,"Benefit is not present","Benefit is not present",true);
		}

	}
    
    public  void validateSituationTypeChangeinPlan(String strPlanVersionID,String situationType,String strAddRemoveFlag)
   	{
   		try{
   			waitForPageLoad(300);
   			WebElement Benefits = getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenu']/div[2]/ul/li[@id=\"BenefitTree\"]/a")) ;
   			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",Benefits);
   			waitForPageLoad(300);
   			seClick(BenefitsPage.get().examVisit, "Exam Visit");
   			waitForPageLoad(300);
   			boolean situationFound = false;
   			List<WebElement> situationGroups = getWebDriver().findElements(By.xpath("//*[@id='content-planBenefitDetails']/div[2]/div/div"));
   			if(situationGroups.size()>0)
   			{
   				for(int i =0; i< situationGroups.size();i++)
   				{
   					String text = getWebDriver().findElement(By.xpath("//*[@id='content-planBenefitDetails']/div[2]/div/div["+(i+1)+"]/div[1]/span[2]/span")).getText();
   					if(text.equalsIgnoreCase(situationType))
   					{
   						situationFound = true;
   						break;
   					}
   				}
   			}
   			if(strAddRemoveFlag.equalsIgnoreCase("ADD"))
   			{
   				
   				if(situationFound)
   					log(PASS,"Situation changes are reflecting successfully for plan","Verify if situation changes are reflecting successfully for plan",true);
   				else
   					log(FAIL,"Situation changes are not reflecting successfully for plan","Verify if situation changes are reflecting successfully for plan",true);				
   			}
   			else if(strAddRemoveFlag.equalsIgnoreCase("REMOVE"))
   			{
   				if(!situationFound)
   					log(PASS,"Situation changes are reflecting successfully for plan","Verify if situation changes are reflecting successfully for plan",true);
   				else
   					log(FAIL,"Situation changes are not reflecting successfully for plan","Verify if situation changes are reflecting successfully for plan",true);				
   			}
   			else
   			{
   				log(FAIL,"Not a valid test","Please check the test data",true);
   				
   			}
   		}
   		catch(Exception e)
   		{
   			e.printStackTrace();
   			log(FAIL,"Benefit is not present","Benefit is not present",true);
   		}

   	}

    /**
     * This Method opens the 'Benefits' tab, searches for 'Allergy Testing' and validates the Accumulator values
     * that were updated from the 'Allergy Testing' tab
     * @param strCoinsurance (required) value to be compared across the Coinsurance Percentage value in application
     */
	public void seVerifyAllergyTestingValuesInBenefits(String strCoinsurance) {
		try {
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", BenefitsPage.get().benefitTab);
			seWaitForClickableWebElement(BenefitsPage.get().searchBenefit, 60);
			seClick(BenefitsPage.get().searchBenefit, " benefits search text box");
			seSetText(BenefitsPage.get().searchBenefit, "Allergy Testing", "set AllergyTesting text ");
			seClick(BenefitsPage.get().searchButtonBenefit, " benefit search button");
			seWaitForClickableWebElement(BenefitsPage.get().btnExpandAll, 60);
			seClick(BenefitsPage.get().btnExpandAll, "Expand All");
			seWaitForClickableWebElement(BenefitsPage.get().lblAllergyTesting_Participating_InNtkAllergyTestingCoinsurance, 60);

			String strActualCoinsurancePerc = seGetElementValue(BenefitsPage.get().lblAllergyTesting_Participating_InNtkAllergyTestingCoinsurance);

			if (strActualCoinsurancePerc.contains(strCoinsurance)) {
				RESULT_STATUS = true;
				log(PASS, "Verify if Allergy Testing Coinsurance is displayed as expected value '" + strCoinsurance + "'.",
						"Allergy Testing Coinsurance '" + strActualCoinsurancePerc + "' is displayed as expected '" + strCoinsurance + "'. RESULT=PASS");
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify if Allergy Testing Coinsurance is displayed as expected value '" + strCoinsurance + "'.",
						"Allergy Testing Coinsurance '" + strActualCoinsurancePerc + "' is not displayed as expected '" + strCoinsurance + "'. RESULT=FAIL");
			}
		} catch (Exception e) {
			log(ERROR, "Error while executing the 'seVerifyAllergyTestingValuesInBenefits' method.");
		}
	}

	/**
	 * This Method opens the 'Benefits' tab, searches for 'Urgent Care Center' and validates the Accumulator values
	 * that were updated from the 'Urgent Care Facility' tab
	 * @param strCopayAmount (required) value to be compared across the copay $ Amount value in application
	 */
	public void seVerifyUrgentCareFacilityValuesInBenefits(String strCopayAmount) {
		try {
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", BenefitsPage.get().benefitTab);
			seWaitForClickableWebElement(BenefitsPage.get().searchBenefit, 60);
			seClick(BenefitsPage.get().searchBenefit, " benefits search text box");
			seSetText(BenefitsPage.get().searchBenefit, "Urgent Care Center", "set benefitsearch text ");
			seClick(BenefitsPage.get().searchButtonBenefit, " benefit search button");
			seWaitForClickableWebElement(BenefitsPage.get().btnExpandAll, 60);
			seClick(BenefitsPage.get().btnExpandAll, "Expand All");
			seWaitForClickableWebElement(BenefitsPage.get().lblUrgentCareCenter_Particpating_InNtkUrgCareFacCopay, 60);
			seVerifyFieldValue(BenefitsPage.get().lblUrgentCareCenter_Particpating_InNtkUrgCareFacCopay, strCopayAmount, "Urgent Care Copay");
		} catch (Exception e) {
			log(ERROR, "Error while executing the 'seVerifyUrgentCareFacilityValuesInBenefits' method.");
		}
	}

	/**
	 * This Method opens the 'Benefits' tab, searches for 'Allergy Serum' and validates the Accumulator values
	 * that were updated from the 'Allergy Serum' tab
	 * @param strCoinsurance (required) value to be compared across the Coinsurance Percentage value in application
	 */
	public void seVerifyAllergySerumValuesInBenefits(String strCoinsurance) {
		try {
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", BenefitsPage.get().benefitTab);
			seWaitForClickableWebElement(BenefitsPage.get().searchBenefit, 60);
			seClick(BenefitsPage.get().searchBenefit, " benefits search text box");
			seSetText(BenefitsPage.get().searchBenefit, "Allergy Serum", "set AllergySerum text ");
			seClick(BenefitsPage.get().searchButtonBenefit, " benefit search button");
			seWaitForClickableWebElement(BenefitsPage.get().tier1Dropdown, 60);
			seClick(BenefitsPage.get().tier1Dropdown, "Tier 1");
			seWaitForClickableWebElement(BenefitsPage.get().lblAllergySerum_Tier1_InNtkAllergySerumFacCoinsurance, 60);

			String strActualCoinsurancePerc = seGetElementValue(BenefitsPage.get().lblAllergySerum_Tier1_InNtkAllergySerumFacCoinsurance);

			if (strActualCoinsurancePerc.contains(strCoinsurance)) {
				RESULT_STATUS = true;
				log(PASS, "Verify if Allergy Serum Coinsurance is displayed as expected value '" + strCoinsurance + "'.",
						"Allergy Serum Coinsurance '" + strActualCoinsurancePerc + "' is displayed as expected '" + strCoinsurance + "'. RESULT=PASS");
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify if Allergy Serum Coinsurance is displayed as expected value '" + strCoinsurance + "'.",
						"Allergy Serum Coinsurance '" + strActualCoinsurancePerc + "' is not displayed as expected '" + strCoinsurance + "'. RESULT=FAIL");
			}
		} catch (Exception e) {
			log(ERROR, "Error while executing the 'seVerifyAllergySerumValuesInBenefits' method.");
		}
	}

	/**
	 * This Method opens the 'Benefits' tab, searches for 'Urgent Care Center' and validates the Accumulator values
	 * that were updated from the 'Urgent Care' tab
	 * @param strCopayAmount (required) value to be compared across the copay $ Amount value in application
	 * @param strCoinsurance (required) value to be compared across the Coinsurance Percentage value in application
	 */
	public void seVerifyUrgentCareValuesInBenefits(String strCopayAmount, String strCoinsurance) {
		try {
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", BenefitsPage.get().benefitTab);
			seWaitForClickableWebElement(BenefitsPage.get().searchBenefit, 60);
			seClick(BenefitsPage.get().searchBenefit, " benefits search text box");
			seSetText(BenefitsPage.get().searchBenefit, "Urgent Care Center", "set benefitsearch text ");
			seClick(BenefitsPage.get().searchButtonBenefit, " benefit search button");
			seWaitForClickableWebElement(BenefitsPage.get().tier1Dropdown, 60);
			seClick(BenefitsPage.get().tier1Dropdown, "Tier 1");
			seWaitForClickableWebElement(BenefitsPage.get().lblUrgentCareCenter_Tier1_InNtkUrgCareFacCopay, 60);
			seVerifyFieldValue(BenefitsPage.get().lblUrgentCareCenter_Tier1_InNtkUrgCareFacCopay, strCopayAmount, "Urgent Care Copay");
			seWaitForClickableWebElement(BenefitsPage.get().lblUrgentCareCenter_Tier1_InNtkUrgCareFacCoinsurance, 60);

			String strActualCoinsurancePerc = seGetElementValue(BenefitsPage.get().lblUrgentCareCenter_Tier1_InNtkUrgCareFacCoinsurance);

			if (strActualCoinsurancePerc.contains(strCoinsurance)) {
				RESULT_STATUS = true;
				log(PASS, "Verify if Urgent Care Coinsurance is displayed as expected value '" + strCoinsurance + "'.",
						"Urgent Care Coinsurance '" + strActualCoinsurancePerc + "' is displayed as expected '" + strCoinsurance + "'. RESULT=PASS");
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify if Urgent Care Coinsurance is displayed as expected value '" + strCoinsurance + "'.",
						"Urgent Care Coinsurance '" + strActualCoinsurancePerc + "' is not displayed as expected '" + strCoinsurance + "'. RESULT=FAIL");
			}
		} catch (Exception e) {
			log(ERROR, "Error while executing the 'seVerifyUrgentCareValuesInBenefits' method.");
		}
	}

}
