package page.planConfigurator;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import utility.CoreSuperHelper;

public class SwitchTemplatePage extends CoreSuperHelper{
	
	private static SwitchTemplatePage thisTestObj;	
	public synchronized static SwitchTemplatePage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), SwitchTemplatePage.class);
		return thisTestObj;
	}				
	
	
	
	public void seSwitchTemplate(){
		String strBaseURL = EnvHelper.getValue("pc.url");
		String strUserProfile = EnvHelper.getValue("user.profile");
		 String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
		
			try {
				

				for (iROW = 1; iROW <= getRowCount(); iROW++) {
					try {
						
						//create a plan
						/*logExtentReport("Validate the Cancel Button in Create Plan Page");
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL);

						LoginPage.get().loginApplication(strUserProfile);
						seWaitForElementLoad(CreatePlanPage.get().homepage);
						Boolean boolean1 = seIsElementDisplayed(CreatePlanPage.get().homepage, "Home page");*/
						CreatePlanPage.get().createPlan(true,10);waitForPageLoad();
						
					    //now the plan id , plan proxy id, template id is in the excel sheet :MasterProductPlanID;MP_PlanProxyID;TemplateIDoldV
						String planVersionIDOld = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];					
						waitForPageLoad(5, 10);
						String planProxyIDOld = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
						setCellValue("MasterProductPlanIDOld", planVersionIDOld);
						setCellValue("MP_PlanProxyIDOld", planProxyIDOld);waitForPageLoad();
						seClick(PlanHeaderPage.get().save, "Save button");
						waitForPageLoad(45);
						String strTemplateVersionIDold = seGetElementValue(PlanHeaderPage.get().templateVersionID);
	                    waitForPageLoad();
	                    setCellValue("TemplateIDoldV", strTemplateVersionIDold);
						//Check validation passed
	                    waitForPageLoad();
						seClick(PlanSetupPage.get().checkValidation, "Check validation");
						waitForPageLoad();
						seClick(PlanSetupPage.get().validationMsg, "Validtaion Passed Display");
						waitForPageLoad();
						seIsElementDisplayed(PlanSetupPage.get().validationMsg,"'Validation Passed' green band");
						waitForPageLoad();
					
						//get value of Planlevel benefits >> Adult Plan Lifetime Maximum>>In Network Vision Adult Lifetime Maximum Dollar Limit 
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", CreateTemplatePage.get().benefits);
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", CreateTemplatePage.get().benefitOption);
						String strAccumValueFrom_Old_Template = CreateTemplatePage.get().accumText.getText();
						System.out.println(strAccumValueFrom_Old_Template);
						
						//---------------------------------------------------------------------------------------------------------------------------
	                   //click on copy
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", CreateTemplatePage.get().copy);
						waitForPageLoad(4,10);
						
						//in the template selection select 1349470592 ----> 1350220064,  1352540394  	,1354340041 
						String strTemplate = "1503000132";//getCellValue("TemplateID");
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", CreateTemplatePage.get().searchTemplate);
						//seClick(CreateTemplatePage.get().searchTemplate	, "Select Template");
						waitForPageLoad(4,10);
						seSwitchFrame(FindTemplatePage.get().findTemplateFrame);
						seWaitForClickableWebElement(FindTemplatePage.get().searchCriteria, 60);
						seClick(FindTemplatePage.get().searchCriteria	, "Search Criteria");
						seWaitForClickableWebElement(FindTemplatePage.get().versionId, 120);
						seSetText(FindTemplatePage.get().versionId, strTemplate, "Template Version ID");
						seClick(FindTemplatePage.get().searchButton	, "Search Criteria");
						waitForPageLoad(10);
						FindTemplatePage.get().selectTemplate(strTemplate);
						waitForPageLoad(10);
						getWebDriver().switchTo().defaultContent();
						waitForPageLoad(10);
						seClick(CreatePlanPage.get().createPlan, "Create Plan");
						waitForPageLoad(5, 10);
						waitForPageLoad(5, 10);
						
						waitForPageLoad(45);
						//now check for plan id, proxy id, template id
						String planVersionIDNew = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];					
						waitForPageLoad(5, 10);
						String planProxyIDNew = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
						setCellValue("MasterProductPlanIDNew", planVersionIDNew);
						setCellValue("MP_PlanProxyIDNew", planProxyIDNew);
						seClick(PlanHeaderPage.get().save, "Save button");
						waitForPageLoad(45);
						String strTemplateVersionIDoldNew = seGetElementValue(PlanHeaderPage.get().templateVersionID);
	                    waitForPageLoad();
	                    setCellValue("TemplateIDN", strTemplateVersionIDoldNew);
						
						//remove***************************************************
						//compare both the plan id, proxy id , template id with the previous obtained one this should be different
						/*CreateTemplatePage.get().seCompareID(planVersionIDOld, planVersionIDNew, "Plan");
						CreateTemplatePage.get().seCompareID(planProxyIDOld, planProxyIDNew, "Proxy");
						CreateTemplatePage.get().seCompareID(strTemplateVersionIDold, strTemplateVersionIDoldNew, "Template");
	                    waitForPageLoad();
	                    CreateTemplatePage.get().seCompareID(planVersionIDOld, planVersionIDNew,planProxyIDOld, planProxyIDNew,strTemplateVersionIDold, strTemplateVersionIDoldNew,"Plan","Proxy", "Template Version") ;                                                  
	                    waitForPageLoad();*/
	                    //---------------------------------------------------------------------------------------------------------------------------------------------
						//get value of Planlevel benefits >> Adult Plan Lifetime Maximum>>In Network Vision Adult Lifetime Maximum Dollar Limit 
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", CreateTemplatePage.get().benefits); waitForPageLoad();
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", CreateTemplatePage.get().benefitOption); waitForPageLoad();
						String strAccumValueFrom_New_Template = CreateTemplatePage.get().accumText.getText(); waitForPageLoad();
						System.out.println(strAccumValueFrom_New_Template); waitForPageLoad();
						
						//compare the strAccumValueFrom_Old_Template and strAccumValueFrom_New_Template should not be same
						String strDraftStatus = getWebDriver().findElement(By.xpath("//*[@id='planHeaderWrapper']/div/div/div[2]/div[2]/div[1]/div[2]/span[2]")).getText(); waitForPageLoad();
						CreateTemplatePage.get().seCompareAccumlators(strAccumValueFrom_Old_Template, strAccumValueFrom_New_Template, strDraftStatus); waitForPageLoad();
						seClick(PlanHeaderPage.get().save, "Save button");
						waitForPageLoad(45);
						//request audit
						seClick(PlanHeaderPage.get().requestAudit, "request Audit button");
						waitForPageLoad();
						PlanTransitionPage.get().updateReasonCode("Other");
						seClick(PlanTransitionPage.get().requestAudit, "Request Audit button");
						waitForPageLoad();
						try {
							seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 360);
						}
						catch (TimeoutException e) {
							seClick(PlanHeaderPage.get().close, "Close button");
							waitForPageLoad();
						}
						seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
						waitForPageLoad();
						seClick(PlanHeaderPage.get().userLogout, "Logout");
						waitForPageLoad();
						seCloseBrowser();
						seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
						LoginPage.get().loginApplication(strUserProfileApprover);
						waitForPageLoad();
						FindPlanPage.seSearchPlanByPlanVersionID(getCellValue("MasterProductPlanIDNew"));
						
						Boolean blnAuditStatus = PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
						if (blnAuditStatus == true) {
							log(PASS, "plan takes correct time to load", "plan is in Pending Audit status,RESULT=PASS");
						} else {
							throw new TimeoutException("Plan is not in Pending Audit status");
						}
						waitForPageLoad();
						System.out.println("plan in pa stat");waitForPageLoad();
						//Validate the values are taken from  the switched template Pending Audit by comparing with strAccumValueFrom_New_Template
						
						String strPAStatus = getWebDriver().findElement(By.xpath("//*[@id='planHeaderWrapper']/div/div/div[2]/div[2]/div[1]/div[2]/span[2]")).getText(); waitForPageLoad();
						System.out.println("plan in pa stat"+strPAStatus);waitForPageLoad();
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", CreateTemplatePage.get().benefits); waitForPageLoad();
						WebElement objOption = getWebDriver().findElement(By.xpath("//*[@id='verticalBarMenuDetails']/div/nav/div[2]/ul/li[6]/a")); waitForPageLoad();
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objOption); waitForPageLoad();
						String strAccumValueFrom_New_TemplatePendingAudit = getWebDriver().findElement(By.xpath("//*[@id='POA_Base-_-PlanLifetimeMaxAdult-_-PlanLifetimeMax-_-NA-_-NA-_-DlrLmtINNAdultLifetimeMaxVis_-_indivMax']")).getText(); waitForPageLoad();
						CreateTemplatePage.get().seCompareAccumlators(strAccumValueFrom_Old_Template, strAccumValueFrom_New_TemplatePendingAudit, strPAStatus); waitForPageLoad();
						//approve audit, move to test code now plan in sent to test status
						
						seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 36);
						seClick(PlanHeaderPage.get().approveAudit, "Approve Audit");
						waitForPageLoad(45);
						seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
						PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ENTER);
						seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, 10);
						seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
						seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeText, 1);
						seSetText(PlanTransitionPage.get().planTransitionReasonCodeText, "Approved", "as " + "Approved");
						seClick(PlanTransitionPage.get().approved, "approved reason code");
						seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
						waitForPageLoad(45);//**********************
						seClick(PlanHeaderPage.get().moveToTestPHPage, "Move to test button");
						waitForPageLoad();
						seClick(PlanTransitionPage.get().moveToTest, "Move to test ");
						waitForPageLoad(45);
						System.out.println("plan in move to test stat");waitForPageLoad();
						//----------------------------------------------------------------------------------------------------
						//now plan in sent to test status
						//Validate the values are taken from  the switched template Sent to Test by comparing with strAccumValueFrom_New_Template
						String strSTTStatus = getWebDriver().findElement(By.xpath("//*[@id='planHeaderWrapper']/div/div/div[2]/div[2]/div[1]/div[2]/span[2]")).getText(); waitForPageLoad();
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", CreateTemplatePage.get().benefits); waitForPageLoad();
						System.out.println("plan in pa stat"+strSTTStatus);waitForPageLoad();
						WebElement objOptionSTT = getWebDriver().findElement(By.xpath("//*[@id='verticalBarMenuDetails']/div/nav/div[2]/ul/li[6]/a")); waitForPageLoad();
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objOptionSTT); waitForPageLoad();
						String strAccumValueFrom_New_TemplateSentToTest = getWebDriver().findElement(By.xpath("//*[@id='POA_Base-_-PlanLifetimeMaxAdult-_-PlanLifetimeMax-_-NA-_-NA-_-DlrLmtINNAdultLifetimeMaxVis_-_indivMax']")).getText(); waitForPageLoad();
						CreateTemplatePage.get().seCompareAccumlators(strAccumValueFrom_Old_Template, strAccumValueFrom_New_TemplateSentToTest, strSTTStatus); waitForPageLoad();
						//now approve test
						
						seClick(PlanHeaderPage.get().approveTestForFinalize, "Approve test button");
						waitForPageLoad();
						seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "test approval");
						seClick(PlanTransitionPage.get().approved, "approved");
						seClick(PlanTransitionPage.get().approvedTest, "approve test");
						waitForPageLoad(45);
						System.out.println("plan in approve tesgt stat");waitForPageLoad();
						
						
						
						
						
						
						//Validate the values are taken from  the switched template Test Passed by comparing with strAccumValueFrom_New_Template
						
						String strTPStatus = getWebDriver().findElement(By.xpath("//*[@id='planHeaderWrapper']/div/div/div[2]/div[2]/div[1]/div[2]/span[2]")).getText(); waitForPageLoad();
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", CreateTemplatePage.get().benefits); waitForPageLoad();
						System.out.println("plan in pa stat"+strTPStatus);waitForPageLoad();
						WebElement objOptionTP = getWebDriver().findElement(By.xpath("//*[@id='verticalBarMenuDetails']/div/nav/div[2]/ul/li[6]/a")); waitForPageLoad();
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objOptionTP); waitForPageLoad();
						String strAccumValueFrom_New_TemplateTestPassed = getWebDriver().findElement(By.xpath("//*[@id='POA_Base-_-PlanLifetimeMaxAdult-_-PlanLifetimeMax-_-NA-_-NA-_-DlrLmtINNAdultLifetimeMaxVis_-_indivMax']")).getText(); waitForPageLoad();
						CreateTemplatePage.get().seCompareAccumlators(strAccumValueFrom_Old_Template, strAccumValueFrom_New_TemplateTestPassed, strTPStatus); waitForPageLoad();
						
						//Validate the values are taken from  the switched template Production by comparing with strAccumValueFrom_New_Template
						
						seClick(PlanHeaderPage.get().finalize, "Finalize button");
						waitForPageLoad();
						seClick(PlanTransitionPage.get().finalizeButtoninPT, "finalize");
						waitForPageLoad();
						try {
							seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 300);
						}
						catch (TimeoutException e) {
							seClick(PlanHeaderPage.get().close, "Close button");
							waitForPageLoad();
						}
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",
								FindPlanPage.get().selectSearchedPlan);
						waitForPageLoad(45);
						Boolean blnFinalStatus = PlanHeaderPage.get().seVerifyPlanStatus("Production");
						if (blnFinalStatus == true) {
							log(PASS, "plan takes correct time to load", "plan is in Production status,RESULT=PASS");
						} else {
							throw new TimeoutException("Plan is not in Production status");
						}
						waitForPageLoad();
						//now finalize, now plan in pending finalization status, when moved to production check again
						String strPdnStatus = getWebDriver().findElement(By.xpath("//*[@id='planHeaderWrapper']/div/div/div[2]/div[2]/div[1]/div[2]/span[2]")).getText(); waitForPageLoad();
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", CreateTemplatePage.get().benefits); waitForPageLoad();
					System.out.println(strPdnStatus);
						WebElement objOptionPdn = getWebDriver().findElement(By.xpath("//*[@id='verticalBarMenuDetails']/div/nav/div[2]/ul/li[6]/a")); waitForPageLoad();
						((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objOptionPdn); waitForPageLoad();
						String strAccumValueFrom_New_TemplateProduction = getWebDriver().findElement(By.xpath("//*[@id='POA_Base-_-PlanLifetimeMaxAdult-_-PlanLifetimeMax-_-NA-_-NA-_-DlrLmtINNAdultLifetimeMaxVis_-_indivMax']")).getText(); waitForPageLoad();
						CreateTemplatePage.get().seCompareAccumlators(strAccumValueFrom_Old_Template, strAccumValueFrom_New_TemplateProduction, strPdnStatus);
						
						waitForPageLoad();
						System.out.println("test passed");
					} catch (Exception e) {
						e.printStackTrace();
						log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
					} finally {
						//seCloseBrowser();
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
				log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
			} finally {
				
			}
		
	}
	
			

}
	

