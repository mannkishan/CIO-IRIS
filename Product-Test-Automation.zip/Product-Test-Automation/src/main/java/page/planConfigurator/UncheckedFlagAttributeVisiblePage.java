package page.planConfigurator;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.groupConfigurator.LoginPage;
import utility.CoreSuperHelper;

public class UncheckedFlagAttributeVisiblePage extends CoreSuperHelper {
	private static UncheckedFlagAttributeVisiblePage thisIsTestObj;

	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	
	public synchronized static UncheckedFlagAttributeVisiblePage get() {
		thisIsTestObj = PageFactory.initElements(getWebDriver(), UncheckedFlagAttributeVisiblePage.class);
		return thisIsTestObj;
	}

	@FindBy(how = How.XPATH, using = "//li[@role='treeitem' and substring(@id,string-length(@id) - string-length('Vision') +1) = 'Vision']")
	@CacheLookup
	public WebElement visionLOB;
	/*Vision Benefit Options starts here*/	
	@FindBy(how = How.XPATH, using = "//a[@title='Benefit Options']")
	public WebElement visionBenefitOptions;	
	
	@FindBy(how = How.XPATH, using = "//*[@id='verticalBarMenu']/div[3]/div")
	public WebElement visionBenefitOptionsScroll;	
	
	@FindBy(how = How.XPATH, using = "//a[starts-with(normalize-space(text()),'Benefits')]")
	public WebElement visionBenefits;
	
	@FindBy(how = How.XPATH, using = "//*[@id='content-benefitSearchBar']/div[2]/div/input")
	public WebElement visionBenefitsSearchBox;
	
	@FindBy(how = How.XPATH, using = "//a[@class='optionItem' and @data-target='#planOption_RoutineEyeExamPediatric']")
	public WebElement visionPediatricRoutineEyeExams;
	
	@FindBy(how = How.XPATH, using = "//div[@data-path='POA_BenefitOption-_-RoutineEyeExamPediatric-_-CoveredINNOON']/div[@class='panel-heading']/h4/span[text()='Covered In Network & Out of Network']/following::span[contains(@title,'Changeable')][1]")
	public WebElement visionPediatricRoutineEyeExamsCoveredINOONUncheck;
		
	@FindBy(how = How.XPATH, using = "//div[@data-path='POA_BenefitOption-_-RoutineEyeExamPediatric-_-CoveredINNOON']//div[@id='POA_BenefitOption-_-RoutineEyeExamPediatric-_-CoveredINNOON-_-NA-_-NA-_-CoinINNPedRoutineEyeExam']/following::span[contains(@title,'Changeable')][1]/input")
	public WebElement visionPediatricRoutineEyeExamsCoveredINOON_INNRoutineEyeExamCoinsurance_Uncheck;
	
	@FindBy(how = How.XPATH, using = "//div[@data-path='POA_BenefitOption-_-RoutineEyeExamPediatric-_-CoveredINNOON']//div[@id='POA_BenefitOption-_-RoutineEyeExamPediatric-_-CoveredINNOON-_-NA-_-NA-_-UnitINNOONPedRoutineEyeExam']/following::span[contains(@title,'Changeable')][1]/input")
	public WebElement visionPediatricRoutineEyeExamsCoveredINOON_INOONPediatricRoutineEyeExamLimit_Uncheck;
	
	@FindBy(how = How.XPATH, using = "//a[@class='optionItem' and @data-target='#planOption_LensesPediatric']")
	public WebElement visionPediatricLenses;
	
	@FindBy(how = How.XPATH, using = "//div[@data-path='POA_BenefitOption-_-LensesPediatric-_-CoveredINNOON']/div[@class='panel-heading']/h4/span[text()='Covered In Network & Out of Network']/following::span[contains(@title,'Changeable')][1]/input")
	public WebElement visionPediatricLenses_CoveredINOON_Uncheck;
	
	@FindBy(how = How.XPATH, using = "//div[@data-path='POA_BenefitOption-_-LensesPediatric-_-CoveredINNOnly']/div[@class='panel-heading']/h4/span[text()='Covered In Network Only']/following::span[contains(@title,'Changeable')][1]/input")
	public WebElement visionPediatricLenses_CoveredINNOnly_Uncheck;
	
	@FindBy(how = How.XPATH, using = "//a[@class='optionItem' and @data-target='#planOption_SingleVisionPediatric']")
	public WebElement visionPediatricSingleVision;
	
	@FindBy(how = How.XPATH, using = "//span[@id='SingleVisionPediatricHeader']//span[contains(@title,'Changeable')]/input")
	public WebElement visionPediatricSingleVision_Uncheck;
	
	@FindBy(how = How.XPATH, using = "//div[@data-path='VisExam']")
	public WebElement visionBenefits_VisionExam;
	
	@FindBy(how = How.XPATH, using = "//div[@data-path='VisExam']//div/following::span[contains(@title,'Visible')][1]/input")
	public WebElement visionBenefits_VisionExam_Visible;
	
	@FindBy(how = How.XPATH, using = "//div[@data-path='VisExam']//div/following::span[contains(@title,'Changeable')][1]/input")
	public WebElement visionBenefits_VisionExam_Uncheck;
	
	@FindBy(how = How.XPATH, using = "//span[@data-fullidentifier='BTC_VisExam-_-Tier1']//span[@class='benDetailConfig']//div[@title='Visible'][1]/input")
	public WebElement visionBenefits_VisionExam_Tier1_Network_Visible_Check;
	
	@FindBy(how = How.XPATH, using = "//span[@data-fullidentifier='BTC_VisExam-_-Tier1']//span[@class='benDetailConfig']//div[@title='Changeable'][1]/input")
	public WebElement visionBenefits_VisionExam_Tier1_Network_Uncheck;
	
	@FindBy(how = How.XPATH, using = "//span[@data-fullidentifier='BTC_VisExam-_-Tier1-_-Adult']//span[@class='benDetailConfig']//div[@title='Visible'][1]/input")
	public WebElement visionBenefits_VisionExam_Adult_SituationType_Visible_Check;
	
	@FindBy(how = How.XPATH, using = "//span[@data-fullidentifier='BTC_VisExam-_-Tier1-_-Adult']//span[@class='benDetailConfig']//div[@title='Changeable'][1]/input")
	public WebElement visionBenefits_VisionExam_Adult_SituationType_Uncheck;

	/*Vision Plan starts here*/
	
	@FindBy(how = How.XPATH, using = "//span[@id='POA_BenefitOption-_-RoutineEyeExamPediatric-_-CoveredINNOON-_-NA-_-NA-_-CoinINNPedRoutineEyeExam_-_percentage' and contains(@class,'readOnly')]")
	public WebElement visionPediatricRoutineEyeExamsCoveredINOON_INNRoutineEyeExamCoinsurance_Amount;
	
	@FindBy(how = How.XPATH, using = "//span[@id='POA_BenefitOption-_-RoutineEyeExamPediatric-_-CoveredINNOON-_-NA-_-NA-_-UnitINNOONPedRoutineEyeExam_-_indUnitMax' and contains(@class,'readOnly')]")
	public WebElement visionPediatricRoutineEyeExamsCoveredINOON_INOONPediatricRoutineEyeExamLimit_Amount;
	

	
	@FindBy(how = How.XPATH, using = "//div[@data-path='POA_BenefitOption-_-LensesPediatric-_-CoveredINNOnly']/div[@class='panel-heading']/h4/input[@disabled and @dependents]")
	public WebElement visionPediatricLenses_CoveredINNOnly_Select;
	
	@FindBy(how = How.XPATH, using = "//div[@data-path='POA_BenefitOption-_-LensesPediatric-_-CoveredINNOnly']/div[@class='panel-heading']/h4/span")
	public WebElement visionPediatricLenses_CoveredINNOnly_Label;
	
	@FindBy(how = How.XPATH, using = "//a[@class='optionItem' and @data-target='#planOption_SingleVisionPediatric']/span[@title='Complete, Not Editable']")
	public WebElement visionPediatricSingleVision_Unchangeable;	
	
	@FindBy(how = How.XPATH, using = "//span[@id='POA_BenefitOption-_-SingleVisionPediatric-_-CoveredINNOON-_-NA-_-NA-_-CopayINNPedSingleVision_-_amount' and contains(@class,'readOnly')]")
	public WebElement visionPediatricSingleVision_CoveredINOON_INNPediatricSingleVisionCopay;
	
	@FindBy(how = How.XPATH, using = "//span[@id='POA_BenefitOption-_-SingleVisionPediatric-_-CoveredINNOON-_-NA-_-NA-_-DlrLmtINNOONPedSnglVisLens_-_indivMax' and contains(@class,'readOnly')]")
	public WebElement visionPediatricSingleVision_CoveredINOON_INNOONPedSnglVisLensDlrLmt;
	
	@FindBy(how = How.XPATH, using = "//span[@id='POA_BenefitOption-_-SingleVisionPediatric-_-CoveredINNOON-_-NA-_-NA-_-DlrLmtOONReimbMaxPedSingleVisionLenses_-_indivMax' and contains(@class,'readOnly')]")
	public WebElement visionPediatricSingleVision_CoveredINOON_OONReimbMaxPedSingleVisionLensesDlrLmt;
	
	@FindBy(how = How.XPATH, using = "//div[@data-path='POA_BenefitOption-_-SingleVisionPediatric-_-NotCovered']/div[@class='panel-heading']/h4/input[@disabled and @dependents]")
	public WebElement visionPediatricSingleVision_NotCovered_Uncheck;
		
	@FindBy(how = How.XPATH, using = "//span[@data-fullidentifier='BTC_VisExam-_-Tier1']")
	public WebElement visionBenefits_VisionExam_Tier1_Network_Visible;
	
	@FindBy(how = How.XPATH, using = "//span[@data-fullidentifier='BTC_VisExam-_-Tier1-_-Adult']")
	public WebElement visionBenefits_VisionExam_Adult_SituationType_Visible;
	
	/*Vision Plan ends here*/
	
	public void seUncheckTemplateLevelBenefitsVision()
	{
		try
		{			
			/*Benefit Options: Pediatric Routine Eye Exam*/
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", UncheckedFlagAttributeVisiblePage.get().visionBenefitOptions);						
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricRoutineEyeExamsCoveredINOON_INNRoutineEyeExamCoinsurance_Uncheck, 25);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionPediatricRoutineEyeExamsCoveredINOON_INNRoutineEyeExamCoinsurance_Uncheck, "In Network Pediatric Routine Eye Exam Coinsurance Checkbox");
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricRoutineEyeExamsCoveredINOON_INOONPediatricRoutineEyeExamLimit_Uncheck, 25);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionPediatricRoutineEyeExamsCoveredINOON_INOONPediatricRoutineEyeExamLimit_Uncheck, "In Network & Out of Network Pediatric Routine Eye Exam Limit Checkbox");
			seWaitForPageLoad(20);
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricLenses,25);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionPediatricLenses, "Pediatric Lenses");
			
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricLenses_CoveredINNOnly_Uncheck,25);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionPediatricLenses_CoveredINNOnly_Uncheck, "Covered In Network Only");
			seWaitForPageLoad(30);
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision,25);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision, "Single Vision");
			seWaitForPageLoad(30);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision_Uncheck);
			seWaitForPageLoad(30);		
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", UncheckedFlagAttributeVisiblePage.get().visionBenefits);
			seWaitForPageLoad(30);
			seSetText(UncheckedFlagAttributeVisiblePage.get().visionBenefitsSearchBox, "Vision Exam");
			seWaitForPageLoad(30);
			UncheckedFlagAttributeVisiblePage.get().visionBenefitsSearchBox.sendKeys(Keys.ENTER);
			seWaitForPageLoad(45);
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam, 50);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam, "Vision Exam");
			
			if(seIsElementDisplayed(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Visible, "Vision Exam Visible Checkbox"))
			{
				seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Visible);
			}
			if(seIsElementDisplayed(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Uncheck, "Vision Exam Changeable Checkbox"))
			{
				seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Uncheck);	
			}
			if(seIsElementDisplayed(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Tier1_Network_Visible, "Vision Exam Tier 1 Network Visible Checkbox"))
			{
				seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Tier1_Network_Visible);	
			}
			if(seIsElementDisplayed(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Tier1_Network_Uncheck, "Vision Exam Tier 1 Network Changeable Checkbox"))
			{
				seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Tier1_Network_Uncheck);
			}
			if(seIsElementDisplayed(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Adult_SituationType_Visible, "Vision Exam Adult Situation Type Visible Checkbox"))
			{
				seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Adult_SituationType_Visible);	
			}
			if(seIsElementDisplayed(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Adult_SituationType_Uncheck, "Vision Exam Adult Situation Type Changeable Checkbox"))
			{
				seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Adult_SituationType_Uncheck);	
			}		
			
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Uncheck, 25);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Uncheck, "Vision Exam Benefit Uncheck");
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Tier1_Network_Uncheck, 25);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Tier1_Network_Uncheck, "Vision Exam Benefit Tier1 Network Uncheck");
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Adult_SituationType_Uncheck, 25);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Adult_SituationType_Uncheck, "Vision Exam Benefit Adult Situation Type Uncheck");		
			
			seWaitForPageLoad(30);
			seWaitForClickableWebElement(PlanHeaderPage.get().save, 20);
			seClick(PlanHeaderPage.get().save, "Save button");
			seWaitForPageLoad(25);
			seWaitForClickableWebElement(PlanHeaderPage.get().close,20);
			seClick(PlanHeaderPage.get().close, "Close button");
			seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
			waitForPageLoad();				
			seClick(PlanHeaderPage.get().userLogout, "Logout");
			waitForPageLoad();
			seCloseBrowser();
			CreateVisionMasterProductTemplate.get().seMoveVisionTemplateToProduction(getCellValue("TemplateVersionID"));
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void seVisionAttributesVisibleNotChangeable()
	{
		try {
			
			seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
			waitForPageLoad();
			LoginPage.get().loginApplication(strUserProfile);
			waitForPageLoad();
			seClick(HomePage.get().create, "Clicking on create link");
			waitForPageLoad();
			seClick(HomePage.get().plan, "Plan");
			seWaitForPageLoad(30);
			waitForPageLoad();			
			CreateVisionMasterProductTemplate.get().seCreateVisionPlan(true, 30);
			
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", UncheckedFlagAttributeVisiblePage.get().visionBenefitOptions);
			if(seClick(UncheckedFlagAttributeVisiblePage.get().visionPediatricRoutineEyeExamsCoveredINOON_INNRoutineEyeExamCoinsurance_Amount, "In Network Pediatric Routine Eye Exam Coinsurance Amount"))
			{
				try
				{					
					UncheckedFlagAttributeVisiblePage.get().visionPediatricRoutineEyeExamsCoveredINOON_INNRoutineEyeExamCoinsurance_Amount.sendKeys(Keys.CLEAR);
				}
				catch (WebDriverException e) {					
					seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricRoutineEyeExamsCoveredINOON_INNRoutineEyeExamCoinsurance_Amount);
					log(PASS, "Accumulator In Network Pediatric Routine Eye Exam Coinsurance is Visible and Unchangeable");
				}				
			}
			else
			{
				log(FAIL, "Accumulator In Network Pediatric Routine Eye Exam Coinsurance is Changeable");
			}
			if(seClick(UncheckedFlagAttributeVisiblePage.get().visionPediatricRoutineEyeExamsCoveredINOON_INOONPediatricRoutineEyeExamLimit_Amount, "In Network & Out of Network Pediatric Routine Eye Exam Limit"))
			{
				try {
					UncheckedFlagAttributeVisiblePage.get().visionPediatricRoutineEyeExamsCoveredINOON_INOONPediatricRoutineEyeExamLimit_Amount.sendKeys(Keys.CLEAR);
				} catch (WebDriverException e) {
					seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricRoutineEyeExamsCoveredINOON_INOONPediatricRoutineEyeExamLimit_Amount);
					log(PASS, "Accumulator In Network & Out of Network Pediatric Routine Eye Exam Limit is Visible and Unchangeable");
				}			
				
			}
			else
			{
				log(FAIL, "Accumulator In Network & Out of Network Pediatric Routine Eye Exam Limit is Changeable");
			}
			
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricLenses,25);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionPediatricLenses, "Pediatric Lenses");			
			if(seClick(UncheckedFlagAttributeVisiblePage.get().visionPediatricLenses_CoveredINNOnly_Select, "Covered In Network Only"))
			{
				
				try {
					UncheckedFlagAttributeVisiblePage.get().visionPediatricLenses_CoveredINNOnly_Select.sendKeys(Keys.ENTER);
				} catch (WebDriverException e) {
					seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricLenses_CoveredINNOnly_Label);
					log(PASS, "Accumulator Group Type Covered In Network Only is Visible and Unchangeable");
				}
				
			}
			else
			{
				log(FAIL, "Accumulator Group Type Covered In Network Only is Changeable");
			}
			
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision,25);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision, "Single Vision");		
			if(seClick(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision_Unchangeable, "Pediatric Single Vision"))
			{
				try {
					UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision_CoveredINOON_INNPediatricSingleVisionCopay.sendKeys(Keys.ENTER);					
				} catch (WebDriverException e) {
					seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision_CoveredINOON_INNPediatricSingleVisionCopay);
					log(PASS, "Accumulator In Network Pediatric Single Vision Copay is Visible And Unchangeable");
				}
				
				try {
					UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision_CoveredINOON_INNOONPedSnglVisLensDlrLmt.sendKeys(Keys.ENTER);
				} catch (WebDriverException e) {
					seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision_CoveredINOON_INNOONPedSnglVisLensDlrLmt);
					log(PASS, "Accumulator In Network & Out of Network Pediatric Single Vision Lens Dollar Limit is Visible And Unchangeable");
				}
				
				try {
					UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision_CoveredINOON_OONReimbMaxPedSingleVisionLensesDlrLmt.sendKeys(Keys.ENTER);
				} catch (WebDriverException e) {
					seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision_CoveredINOON_OONReimbMaxPedSingleVisionLensesDlrLmt);
					log(PASS, "Accumulator Out of Network Pediatric Single Vision Lenses Reimbursement Maximum Dollar Limit is Visible And Unchangeable");
				}
				
				try {
					UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision_NotCovered_Uncheck.sendKeys(Keys.ENTER);
				} catch (WebDriverException e) {
					seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionPediatricSingleVision_Unchangeable);
					log(PASS, "Benefit Option Pediatric Single Vision is Visible and Unchangeable");
				}
				
			}
			else
			{
				log(FAIL, "Benefit Option Pediatric Single Vision is Changeable");
			}		
			seWaitForPageLoad(30);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionBenefitOptionsScroll,"Scroll");
			seClick(UncheckedFlagAttributeVisiblePage.get().visionBenefitOptionsScroll,"Scroll");
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits, 25);
			seClick(UncheckedFlagAttributeVisiblePage.get().visionBenefits, "Benefits");
			seSetText(UncheckedFlagAttributeVisiblePage.get().visionBenefitsSearchBox, "Vision Exam");
			UncheckedFlagAttributeVisiblePage.get().visionBenefitsSearchBox.sendKeys(Keys.ENTER);
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam, 50);
			if(seClick(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam, "Vision Exam"))
			{				
				seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam);
				log(PASS, "Benefit Vision Exam is Visible");
			}
			else
			{
				log(FAIL, "Benefit Vision Exam is not Visible");
			}			
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Tier1_Network_Visible,50);
			if(seClick(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Tier1_Network_Visible, "Tier 1 Network"))
			{
				
				seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Tier1_Network_Visible);
				log(PASS, "Network Tier1  is Visible");
			}
			else
			{
				log(FAIL, "Network Tier1  is not Visible");
			}
			seWaitForClickableWebElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Adult_SituationType_Visible,50);
			if(seClick(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Adult_SituationType_Visible, "Adult Situation Type"))
			{
				
				seHighlightElement(UncheckedFlagAttributeVisiblePage.get().visionBenefits_VisionExam_Adult_SituationType_Visible);
				log(PASS, "Situation Type Adult is Visible");
			}
			else
			{
				log(FAIL, "Situation Type Adult is not Visible");
			}
			CreateVisionMasterProductTemplate.get().seMoveVisionPlanToProduction(getCellValue("PlanProxyID"));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void seHighlightVisionAttribute(WebElement wbName,Boolean blnValue)
	{
		String strNew="//td//span[@id='POA_BenefitOption-_-RoutineEyeExamPediatric-_-CoveredINNOON-_-NA-_-NA-_-CoinINNPedRoutineEyeExam_-_percentage' and contains(@class,'readOnly')]/preceding::td[1]//div//span[1]";
		if(blnValue)
		{
			seHighlightElement(wbName);
			
		}
	}
}
