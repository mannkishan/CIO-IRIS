package page.planConfigurator;

import java.util.Hashtable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;
import utility.ExcelUtility;

public class TemplateBenefitOptionPage extends CoreSuperHelper{

	private static TemplateBenefitOptionPage thisTestObj;	
	public synchronized static TemplateBenefitOptionPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), TemplateBenefitOptionPage.class);
		return thisTestObj;
}
	
	@FindBy(how = How.XPATH, using = "//div[@id='verticalBarMenu']/div[2]/ul/li[@id='BenefitOption']/a[contains(text(),'Benefit Options')]")
	@CacheLookup
	public WebElement benefitOption;
	
	@FindBy(how = How.XPATH, using = "//div[@id='verticalBarMenuDetails']/div[@class='BenefitOption']/nav/div[2]/ul/li/a[@attr-ref='Acupuncture']")
	@CacheLookup
	public WebElement acupuncture;
	
	@FindBy(how = How.XPATH, using = "//div[@id='content-planOptionList']/div/div/span[@id='AcupunctureHeader']/span[@class='groupTemplateConfig']/div/span[@title='Visible']/input")
	@CacheLookup
	public WebElement checkBoxVisible;

	@FindBy(how = How.XPATH, using = "//div[@id='content-planOptionList']/div/div/span[@id='AcupunctureHeader']/span[@class='groupTemplateConfig']/div/span[@title='Changeable']/input")
	@CacheLookup
	public WebElement checkBoxChangeable;
	
	
	@FindBy(how = How.XPATH, using = "//ul[@id='actionsBar']/li[5]/a[text()='Save']")
	@CacheLookup
	public WebElement save;
	
	@FindBy(how = How.LINK_TEXT, using = "Allergy Serum")
	@CacheLookup
	public WebElement allergySerum;
	
	
	@FindBy(how = How.ID, using = "POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-NA-_-NA-_-PREFApplies_-_choice")
	@CacheLookup
	public WebElement allergySerumPrefernceApply;

	
	public boolean addOrRemoveBenefitOption(String strAddorRemoveFlag)
	{
		boolean addOrRemoveBenefitOption = false;
		try
		{
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",TemplateBenefitOptionPage.get().benefitOption);
		waitForPageLoad(420);
		seClick(TemplateBenefitOptionPage.get().acupuncture, "Acupuncture");
		waitForPageLoad(360);

		if(strAddorRemoveFlag.equalsIgnoreCase("ADD"))
		{
			if(!TemplateBenefitOptionPage.get().checkBoxChangeable.isSelected())
			{
				addOrRemoveBenefitOption= true;
				seClick(TemplateBenefitOptionPage.get().checkBoxVisible, "Visible CheckBox");
				
			}
			else
			{
				log(FAIL, "Add  Benefit option","Benefit Option is already selected ");	
			}
		}
		else if(strAddorRemoveFlag.equalsIgnoreCase("REMOVE"))
		{
			if(TemplateBenefitOptionPage.get().checkBoxChangeable.isSelected())
			{
				addOrRemoveBenefitOption= true;
				seClick(TemplateBenefitOptionPage.get().checkBoxVisible, "Visible CheckBox");
			}
			else
			{
				log(FAIL, "Add  Benefit option","Benefit Option is already removed ");	
			}
		}
		waitForPageLoad(350);
//		seClick(TemplateBenefitOptionPage.get().save, "Save");
			waitForPageLoad(350);
		}
		catch (Exception e) {
				e.printStackTrace();
			log(FAIL, "Add or Remove Benefit option","Exception Occured in add or remove benefit option");	
		}
		return addOrRemoveBenefitOption;
	}
	
	public  Hashtable<String, String> editBenefitOption(String strBenefitOption)
	{
		Hashtable<String, String> updateStatus = new Hashtable<>();
		try{ 
			waitForPageLoad(300);
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",TemplateBenefitOptionPage.get().benefitOption);
			waitForPageLoad(300);//300	
			seClick(TemplateBenefitOptionPage.get().allergySerum, "Allergy Serum");
			waitForPageLoad(300);//300
			String strCoveredForPainManagementOnly=seGetDropDownValue(TemplateBenefitOptionPage.get().allergySerumPrefernceApply);
			if(strCoveredForPainManagementOnly.equalsIgnoreCase("Yes")){
				waitForPageLoad(300);
				seSelectText(true,TemplateBenefitOptionPage.get().allergySerumPrefernceApply, "No", "Does Preference Apply in Allergy Serum");
			}
			else {
				waitForPageLoad(300);
				seSelectText(true,TemplateBenefitOptionPage.get().allergySerumPrefernceApply, "Yes", "Does Preference Apply in Allergy Serum");
			}
			waitForPageLoad(300);
			String updateCoverredForPairManagementOnly = seGetDropDownValue(TemplateBenefitOptionPage.get().allergySerumPrefernceApply);
			waitForPageLoad(300);
			
			updateStatus.put("Existing Value", strCoveredForPainManagementOnly);
			updateStatus.put("Updated Value", updateCoverredForPairManagementOnly);
			if(strCoveredForPainManagementOnly.equalsIgnoreCase(updateCoverredForPairManagementOnly))
			{
				updateStatus.put("Edit Benefit Option Status", "FAIL");
			}
			else
			{
				updateStatus.put("Edit Benefit Option Status", "PASS");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			log(FAIL,"Unable to edit template","Unable to edit template exception occured: "+e.getLocalizedMessage(),true);
		}		
		return updateStatus;
	}
	
	public void validateEditBenefitOption(String[] strPlanID, String strreportFolder,String strUpdateFolder,String strBenefitOptionOldValue, String strBenefitOptionNewValue, String  editBenefitOptionStatus)
	{
		try
		{
		String strPlanID1 = strPlanID[0];
		String strPlanID2 = strPlanID[1];
        if(editBenefitOptionStatus != null)
        {
        	if(editBenefitOptionStatus.equals("PASS"))
        	{
        	log(INFO, "Started Validation Edit Benefit Options in Impact Analysis and Update Report","");
        	ExcelUtility.get().validateBenefitOptionUpdateinImpactReport(strPlanID1,strreportFolder, strBenefitOptionOldValue, strBenefitOptionNewValue);
        	ExcelUtility.get().validateBenefitOptionUpdateinImpactReport(strPlanID2, strreportFolder, strBenefitOptionOldValue, strBenefitOptionNewValue);
        	ExcelUtility.get().validateBenefitOptionUpdateInUpdateReport(strPlanID1, strUpdateFolder, strBenefitOptionOldValue, strBenefitOptionNewValue);
        	ExcelUtility.get().validateBenefitOptionUpdateInUpdateReport(strPlanID2, strUpdateFolder, strBenefitOptionOldValue, strBenefitOptionNewValue);
        	log(INFO, "Completed Validation Edit Benefit Options in Impact Analysis and Update Report","");
        	}
        	else
        	{
        		log(FAIL, "Verify Edit Benefit Option in Bulk Republish Process","Not able to edit the Benefit option for template");
        	}
        	
        }
        else
        {
        	log(FAIL, "Verify Edit Benefit Option in Bulk Republish Process","Not able to edit in the template and perform bulk republish");
        }
		}
		catch (Exception e) {
			e.printStackTrace();
			log(FAIL, "Validate Bulk Republish process after Editing plan options", "Exception Occured "+e.getLocalizedMessage());
		}
	}
	


}
