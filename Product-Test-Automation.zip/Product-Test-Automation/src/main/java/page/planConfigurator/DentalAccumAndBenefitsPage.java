package page.planConfigurator;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class DentalAccumAndBenefitsPage extends CoreSuperHelper{
	private static DentalAccumAndBenefitsPage thisIsTestObj;
	public  synchronized static DentalAccumAndBenefitsPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), DentalAccumAndBenefitsPage.class);
		return thisIsTestObj;
		}
	
	@FindBy(how = How.XPATH, using = "//*[@id='Base']/a")
	@CacheLookup
	public WebElement dentalPlanLevelBenefitsTab;
	
	@FindBy(how = How.XPATH, using = "//*[@id='BenefitOption']/a")
	@CacheLookup
	public WebElement dentalBenefitOptionsTab;
	
	/*Pediatric Deductible starts here*/
	
	@FindBy(how = How.XPATH, using = "//a[@class='optionItem' and @data-target='#planOption_DeductiblePed']")
	@CacheLookup
	public WebElement dentalPlanLevelBenefits_PediatricDeductible;
	
	@FindBy(how = How.XPATH, using = "//input[@id='POA_Base-_-DeductiblePed-_-Deductible-_-INN-_-ComingledWithMed']")
	@CacheLookup
	public WebElement dentalPlanLevelBenefits_PediatricDeductible_ComingledWithMed_RadioButton;
	
	
	@FindBy(how = How.XPATH, using = "//input[@id='POA_Base-_-DeductiblePed-_-Deductible-_-INN-_-NotComingledWithMed']")
	@CacheLookup
	public WebElement dentalPlanLevelBenefits_PediatricDeductible_NotComingledWithMed_RadioButton;
	
	/*Pediatric Deductible ends here*/
	
	/*Pediatric Dental Anesthesia starts here*/
	
	@FindBy(how = How.XPATH, using = "//a[@class='optionItem' and @data-target='#planOption_AnesthesiaPed']")
	@CacheLookup
	public WebElement dentalBenefitOptions_PediatricDentalAnesthesia;
	
	
	@FindBy(how = How.XPATH, using = "//input[@id='POA_BenefitOption-_-AnesthesiaPed-_-Covered']")
	@CacheLookup
	public WebElement dentalBenefitOptions_PediatricDentalAnesthesia_Covered_RadioButton;
	
	@FindBy(how = How.XPATH, using = "//input[@id='POA_BenefitOption-_-AnesthesiaPed-_-NotCovered']")
	@CacheLookup
	public WebElement dentalBenefitOptions_PediatricDentalAnesthesia_NotCovered_RadioButton;
	
	/*Pediatric Dental Anesthesia ends here*/
	
/*Pediatric Deductible starts here*/
	
	public void seIsDentalPlanOptionsVisible()
	{		
		String valueType="";
		seClick(dentalPlanLevelBenefitsTab, "Plan Level Benefits");
		seWaitForClickableWebElement(dentalPlanLevelBenefits_PediatricDeductible, 30);
		seClick(dentalPlanLevelBenefits_PediatricDeductible, "Pediatric Deductible");
		seWaitForClickableWebElement(dentalPlanLevelBenefits_PediatricDeductible,30);
		if(AllergySerumBenefitOptionPage.get().seCheckIsElementNotSelected(dentalPlanLevelBenefits_PediatricDeductible_ComingledWithMed_RadioButton,"Comingled With Medical"))
		{
			seClick(dentalPlanLevelBenefits_PediatricDeductible_ComingledWithMed_RadioButton, "Comingled With Medical");
			valueType="INN-_-ComingledWithMed";
			for(int i=0;i<2;i++)
			{
				VisionAccumAndBenefitsPage.get().seIsElementAvailable(getCellValue("ComingledWithMedAccumulatorValue"+i),valueType);
				
			}			
		}
		else
		{
			seClick(dentalPlanLevelBenefits_PediatricDeductible_NotComingledWithMed_RadioButton, "Not Comingling With");
			seWaitForClickableWebElement(dentalPlanLevelBenefits_PediatricDeductible_NotComingledWithMed_RadioButton, 30);
			valueType="NotComingledWithMed";
			for(int i=0;i<2;i++)
			{
				VisionAccumAndBenefitsPage.get().seIsElementAvailable(getCellValue("NotComingledWithMedAccumulatorValue"+i),valueType);
				
			}			
		}			
	}
	/*Pediatric Deductible ends here*/
	
	
	
	public void seIsDentalBenefitOptionsVisible()
	{	
		for(int i=0;i<2;i++)
		{
			seClick(VisionAccumAndBenefitsPage.get().visionBenefitScroll, "Benefit Scroll");
		}
		
		seWaitForClickableWebElement(dentalBenefitOptionsTab, 20);
		seClick(dentalBenefitOptionsTab, "Benefit Options");
		seWaitForClickableWebElement(dentalBenefitOptions_PediatricDentalAnesthesia, 20);
		seClick(dentalBenefitOptions_PediatricDentalAnesthesia, "Pediatric Dental Anesthesia");
		String valueType="";
		if (AllergySerumBenefitOptionPage.get().seCheckIsElementNotSelected(dentalBenefitOptions_PediatricDentalAnesthesia_Covered_RadioButton,"Covered")) 
		{					
			seClick(dentalBenefitOptions_PediatricDentalAnesthesia_Covered_RadioButton, "Covered");
			seWaitForPageLoad(20);
			valueType="Covered";
			for (int i = 0; i < 4; i++)
			{	
				VisionAccumAndBenefitsPage.get().seIsElementAvailable(getCellValue("CoveredAccumulatorValue" + i),valueType);
			}
		}
		else
		{			
			seClick(dentalBenefitOptions_PediatricDentalAnesthesia_NotCovered_RadioButton, "Not Covered");
					
		}
		
	}
	
	
}
