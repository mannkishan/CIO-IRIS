package page.planConfigurator;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class CreatePlanPage extends CoreSuperHelper{
	
	private static CreatePlanPage thisTestObj;	
	public synchronized static CreatePlanPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), CreatePlanPage.class);
		return thisTestObj;
	}				
	@FindBy(how = How.NAME, using = "effectiveDate")
	@CacheLookup
	public WebElement enterEffectiveDate;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[1]/td[2]")
	@CacheLookup
	public WebElement date;
	
	@FindBy(how = How.NAME, using = "productDataModel")
	@CacheLookup
	public WebElement selectProductModelData;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	@CacheLookup
	public WebElement productModelDataOption;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[3]")
	@CacheLookup
	public WebElement masterProductOption;


	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[4]/div/span/span[1]/span")
	@CacheLookup
	public WebElement selectApprovalStatus;
	//*******************************************************************************************************************************
	@FindBy(how = How.NAME, using = "customizationLevel")
	@CacheLookup
	public WebElement customizationLevel;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[5]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectCustomizationLevel;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	@CacheLookup
	public WebElement customizationLevelInput;
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[4]")
	@CacheLookup
	public WebElement customizationLeveldropdown;
	//*******************************************************************************************************************************
	@FindBy(how = How.NAME, using = "state")
	@CacheLookup
	public WebElement state;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[6]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectState;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	@CacheLookup
	public WebElement stateInput;
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[12]")
	@CacheLookup
	public WebElement stateDropdown;
    //********************************************************************************************************************************
	@FindBy(how = How.NAME, using = "marketSegment")
	@CacheLookup
	public WebElement marketSegment;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[7]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectMarketSegment;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement marketSegmentInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[2]")
	@CacheLookup
	public WebElement marketSegmentDropdown;
    //********************************************************************************************************************************
	@FindBy(how = How.NAME, using = "marketUnit")
	@CacheLookup
	public WebElement marketUnit;
	@FindBy(how = How.NAME, using = "lob")
	@CacheLookup
	public WebElement lob;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[9]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectLob;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement lobInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[3]")
	@CacheLookup
	public WebElement lobDropdown;
	
	 //********************************************************************************************************************************
	@FindBy(how = How.NAME, using = "productType")
	@CacheLookup
	public WebElement productName;
	
	@FindBy(how = How.NAME, using = "productFamily")
	@CacheLookup
	public WebElement productFamily;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[11]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectPdtFam;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement pdtFamInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[5]")
	@CacheLookup
	public WebElement pdtFamDropdown;
	
	 //********************************************************************************************************************************
	
	@FindBy(how = How.NAME, using = "cdhpType")
	@CacheLookup
	public WebElement cdhType;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[12]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectcdhp;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement cdhpInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[4]")
	@CacheLookup
	public WebElement cdhpDropdown;
	
	 //********************************************************************************************************************************
	@FindBy(how = How.NAME, using = "benefitPeriod")
	@CacheLookup
	public WebElement benefitPeriod;

	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[14]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectBenefitPd;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement benfpdInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[2]")
	@CacheLookup
	public WebElement benfpdDropdown;
	
	 //********************************************************************************************************************************
	@FindBy(how = How.NAME, using = "claimSystem")
	@CacheLookup
	public WebElement claimSystem;
	
	@FindBy(how = How.NAME, using = "fundingCode")
	@CacheLookup
	public WebElement fundingArrangement;
	
	@FindBy(how = How.NAME, using = "businessUnit")
	@CacheLookup
	public WebElement businessUnit;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[18]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement selectBusiUnit;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
	//@CacheLookup
	public WebElement busiUnitInput;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]/ul/li[2]")
	@CacheLookup
	public WebElement buisunitDropdown;
	
	 //********************************************************************************************************************************
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[19]/div/div/button")
	@CacheLookup
	public WebElement searchTemplate;
	
	@FindBy(how = How.CSS, using = "button[class='selectTemplate btn btn-primary']")
	@CacheLookup
	public WebElement selectTemplate;
	
	
	
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"DataTables_Table_0\"]/tbody/tr/td[5]")
	@CacheLookup
	public WebElement selectAvailTemplate;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/form/div[2]/div[6]/div/button[1]")
	//@CacheLookup
	public WebElement cancelButton;
	//html/body/div[9]/div/div/div/div[3]/button[2]
	//*[@class="btn btn-primary withFocus dialog-action"][text()="Yes"]
	@FindBy(how = How.XPATH, using = "/html/body/div[9]/div/div/div/div[3]/button[2]")
	//@CacheLookup
	public WebElement yesToCancel;
	@FindBy(how = How.XPATH, using = "/html/body/div[9]/div/div/div")
	//@CacheLookup
	public WebElement popup;
	//Plan
	@FindBy(how = How.ID, using = "Plan")
	//@CacheLookup
	public WebElement homepage;
	
	public void strcomparebool(Boolean var1, Boolean var2) {
		   
		if(var1 == var2)
		{
			log(PASS, "Once Cancel confirmed, the Home page is displayed sucessfully","Hompage displayed as expected,RESULT=PASS");
			
			
		}
		else
		{
			log(FAIL, "Once Cancel confirmed, the Home page is NOT displayed sucessfully","Hompage NOT displayed as expected,RESULT=FAIL");
			
			
		}
		
		
		   }
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"header-wrapper\"]/ul/li[3]/ul/li[2]/a[@class='create-Template']")
	//@CacheLookup
	public WebElement findTemplate;
	
	@FindBy(how = How.NAME, using = "planName")
	//@CacheLookup
	public WebElement templateName;
	
	
	@FindBy(how = How.NAME, using = "planDescription")
	//@CacheLookup
	public WebElement templateDesc;
	
	
	//********************************************************************************************************************************** 
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[3]/div/span/span[1]/span/ul/li[2]/input")
	//@CacheLookup
	public WebElement templateState;
	
	//*[@id="content-create-customPlan"]/span/span/span
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span")
	//@CacheLookup
	public WebElement templateStateText;
	
	//********************************************************************************************************************************** 
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[4]/div/span/span[1]/span/ul/li[2]/input")
		//@CacheLookup
	public WebElement templateMarketSegment;
		
	//*[@id="content-create-customPlan"]/span/span/span
		@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span")
		//@CacheLookup
	public WebElement templateMSText;
	
//********************************************************************************************************************************** 
    @FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[5]/div/span/span[1]/span/span[2]")
		//@CacheLookup
	public WebElement templateLob;

	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
		//@CacheLookup
	public WebElement templateLobInput;	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]")
	//@CacheLookup
    public WebElement templateLobText;
	
	//********************************************************************************************************************************** 
    @FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[6]/div/span/span[1]/span/ul/li[2]/input")
		//@CacheLookup
	public WebElement templateProductFmly;

	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span")
		//@CacheLookup
	public WebElement templateProductfmlyinput;	

	//********************************************************************************************************************************** 
    @FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[8]/div/span/span[1]/span/span[2]")
		//@CacheLookup
	public WebElement templateNetwkTier;

	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")
		//@CacheLookup
	public WebElement templateNetwkInput;	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span[2]")
	//@CacheLookup
    public WebElement templateNetwrkText;
	//********************************************************************************************************************************** 
	//span[text()=\"Consumer Driven Health Plan \"]//following::li[@class=\"select2-search select2-search--inline\"])[1]

	@FindBy(how = How.XPATH, using = "//*[@id=\"customHeaderAttributesContainer\"]/div[9]/div/span/span[1]/span/ul/li[2]/input")
		//@CacheLookup
	public WebElement templateCDHPInput;	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/span/span/span")
	//@CacheLookup
    public WebElement templateCDHPText;
	
	
//	@FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/form/div[2]/div[6]/div/button[2]/span")
	@FindBy(how = How.CLASS_NAME, using = "doAction")
	//@CacheLookup
    public WebElement createPlan;
	
	
	public  void createPlan(boolean isMasterPlan,int maxWaitTime) throws Exception
	{
		String strEffectiveDate = getCellValue("EffectiveDate");
		String strProductModel = "";
		if(isMasterPlan)
		{
			strProductModel= "Master Product";
		}
		String strTemplateVersionID = getCellValue("TemplateVersionID");
		String strApprovalStatus = getCellValue("ApprovalStatus");
		String strCustomizationLevel = getCellValue("CustomizationLevel");
		String strState = getCellValue("State");
		String strMarketSegment = getCellValue("MarketSegment");
		String strMarketUnit = getCellValue("MarketUnit");
		String strProductFamily = getCellValue("ProductFamily");
		String strProductName = getCellValue("ProductName");
		String strCDHPType = getCellValue("CDHP");
		String strBenefitPeriod = getCellValue("BenefitPeriod");
		String strFundingArrangement = getCellValue("FundingArrangement");
		String strBusinessUnit	 = getCellValue("BusinessUnit");
		String strLineOfBusiness = getCellValue("LOB");
		
		waitForPageLoad(maxWaitTime);
		seClick(HomePage.get().create, "Create");
		seClick(HomePage.get().plan, "Plan");
		waitForPageLoad(4,maxWaitTime);
		seSetText(CreatePlanPage.get().enterEffectiveDate, strEffectiveDate, "Effective date");
		CreatePlanPage.get().enterEffectiveDate.sendKeys(Keys.TAB);
		waitForPageLoad(maxWaitTime);
		seSelectText(CreatePlanPage.get().selectProductModelData, strProductModel, "Product Model",maxWaitTime);
		if(strApprovalStatus.equalsIgnoreCase("Approved"))
		{
			
		}
		seSelectText(CreatePlanPage.get().customizationLevel, strCustomizationLevel, "Customization Level",maxWaitTime);
		seSelectText(CreatePlanPage.get().state, strState, "State",maxWaitTime);
		seSelectText(CreatePlanPage.get().marketSegment, strMarketSegment, "Market Segment",maxWaitTime);
		seSelectText(CreatePlanPage.get().marketUnit, strMarketUnit, "Market Unit",maxWaitTime);
		seSelectText(CreatePlanPage.get().lob, strLineOfBusiness, "Line of Business",maxWaitTime);
		seSelectText(CreatePlanPage.get().productName, strProductName, "Product Name",maxWaitTime);
		seSelectText(CreatePlanPage.get().productFamily, strProductFamily, "Product Family",maxWaitTime);
		seSelectText(CreatePlanPage.get().cdhType, strCDHPType, "Consumer Driven Health Plan",maxWaitTime);
		seSelectText(CreatePlanPage.get().benefitPeriod, strBenefitPeriod, "Benefit Period",maxWaitTime);
		seSelectText(CreatePlanPage.get().fundingArrangement,strFundingArrangement, "Funding Arrangement",maxWaitTime);
		seSelectText(CreatePlanPage.get().businessUnit, strBusinessUnit, "Business Unit",maxWaitTime);
		if(isMasterPlan)
		{
		seClick(CreatePlanPage.get().selectTemplate	, "Select Template");
		waitForPageLoad(4,maxWaitTime);
		seSwitchFrame(FindTemplatePage.get().findTemplateFrame);
		seWaitForClickableWebElement(FindTemplatePage.get().searchCriteria, 60);
		seClick(FindTemplatePage.get().searchCriteria	, "Search Criteria");
		seWaitForClickableWebElement(FindTemplatePage.get().versionId, 120);
		seSetText(FindTemplatePage.get().versionId, strTemplateVersionID, "Template Version ID");
		seClick(FindTemplatePage.get().searchButton	, "Search Criteria");
		waitForPageLoad(maxWaitTime);
		FindTemplatePage.get().selectTemplate(strTemplateVersionID);
		}
		waitForPageLoad(maxWaitTime);
		getWebDriver().switchTo().defaultContent();
		waitForPageLoad(maxWaitTime);
//		Actions act = new Actions(getWebDriver());
//		act.moveToElement(CreatePlanPage.get().createPlan).build().perform();
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",CreatePlanPage.get().createPlan);	
		
//		seClick(CreatePlanPage.get().createPlan, "Create Plan");
		waitForPageLoad(5,maxWaitTime);
		String planVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];
		waitForPageLoad(5,maxWaitTime);
		String planProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
		setCellValue("PlanVersionID", planVersionID);
		setCellValue("PlanProxyID", planProxyID);
	}
	
	public  void cancelPlan(boolean isMasterPlan,int maxWaitTime) throws Exception
	{
		String strEffectiveDate = getCellValue("EffectiveDate");
		String strProductModel = "";
		if(isMasterPlan)
		{
			strProductModel= "Master Product";
		}
		String strTemplateVersionID = getCellValue("TemplateVersionID");
		String strApprovalStatus = getCellValue("ApprovalStatus");
		String strCustomizationLevel = getCellValue("CustomizationLevel");
		String strState = getCellValue("State");
		String strMarketSegment = getCellValue("MarketSegment");
		String strMarketUnit = getCellValue("MarketUnit");
		String strProductFamily = getCellValue("ProductFamily");
		String strProductName = getCellValue("ProductName");
		String strCDHPType = getCellValue("CDHP");
		String strBenefitPeriod = getCellValue("BenefitPeriod");
		String strFundingArrangement = getCellValue("FundingArrangement");
		String strBusinessUnit	 = getCellValue("BusinessUnit");
		String strLineOfBusiness = getCellValue("LOB");
		
		waitForPageLoad(maxWaitTime);
		seClick(HomePage.get().create, "Create");
		seClick(HomePage.get().plan, "Plan");
		waitForPageLoad(4,maxWaitTime);
		seSetText(CreatePlanPage.get().enterEffectiveDate, strEffectiveDate, "Effective date");
		CreatePlanPage.get().enterEffectiveDate.sendKeys(Keys.TAB);
		waitForPageLoad(maxWaitTime);
		seSelectText(CreatePlanPage.get().selectProductModelData, strProductModel, "Product Model",maxWaitTime);
		if(strApprovalStatus.equalsIgnoreCase("Approved"))
		{
			
		}
		seSelectText(CreatePlanPage.get().customizationLevel, strCustomizationLevel, "Customization Level",maxWaitTime);
		seSelectText(CreatePlanPage.get().state, strState, "State",maxWaitTime);
		seSelectText(CreatePlanPage.get().marketSegment, strMarketSegment, "Market Segment",maxWaitTime);
		seSelectText(CreatePlanPage.get().marketUnit, strMarketUnit, "Market Unit",maxWaitTime);
		seSelectText(CreatePlanPage.get().lob, strLineOfBusiness, "Line of Business",maxWaitTime);
		seSelectText(CreatePlanPage.get().productName, strProductName, "Product Name",maxWaitTime);
		seSelectText(CreatePlanPage.get().productFamily, strProductFamily, "Product Family",maxWaitTime);
		seSelectText(CreatePlanPage.get().cdhType, strCDHPType, "Consumer Driven Health Plan",maxWaitTime);
		seSelectText(CreatePlanPage.get().benefitPeriod, strBenefitPeriod, "Benefit Period",maxWaitTime);
		seSelectText(CreatePlanPage.get().fundingArrangement,strFundingArrangement, "Funding Arrangement",maxWaitTime);
		seSelectText(CreatePlanPage.get().businessUnit, strBusinessUnit, "Business Unit",maxWaitTime);
		if(isMasterPlan)
		{
		seClick(CreatePlanPage.get().selectTemplate	, "Select Template");
		waitForPageLoad(4,maxWaitTime);
		seSwitchFrame(FindTemplatePage.get().findTemplateFrame);
		seWaitForClickableWebElement(FindTemplatePage.get().searchCriteria, 60);
		seClick(FindTemplatePage.get().searchCriteria	, "Search Criteria");
		seWaitForClickableWebElement(FindTemplatePage.get().versionId, 120);
		seSetText(FindTemplatePage.get().versionId, strTemplateVersionID, "Template Version ID");
		seClick(FindTemplatePage.get().searchButton	, "Search Criteria");
		waitForPageLoad(maxWaitTime);
		FindTemplatePage.get().selectTemplate(strTemplateVersionID);
		}
		waitForPageLoad(maxWaitTime);
		getWebDriver().switchTo().defaultContent();
		waitForPageLoad(5,maxWaitTime);
		seWaitForClickableWebElement(CreatePlanPage.get().cancelButton, 1);
		seClick(CreatePlanPage.get().cancelButton, "Cancel Button");
		waitForPageLoad(5,maxWaitTime); 
	}
	
	public static void createplan(){
		log(FAIL, "Validate Plan Design in XML", "Plan not moved to pending audit", true);
		log(FAIL, "Validate Plan Design in XML", "Plan not moved to pending audit", true);
	}
		}
	

