package page.planConfigurator;

import java.io.File;
import java.io.InputStream;
import java.util.NoSuchElementException;

import javax.naming.spi.DirStateFactory.Result;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;
//import utility.WebTable;

public class BenefitRetainsInProductionPage extends CoreSuperHelper{

                private static BenefitRetainsInProductionPage thisTestObj;         
                public synchronized static BenefitRetainsInProductionPage get() {
                                thisTestObj = PageFactory.initElements(getWebDriver(), BenefitRetainsInProductionPage.class);
                                return thisTestObj;
                }
                
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"DataTables_Table_1\"]/tbody/tr/td[4]")
                @CacheLookup
                public WebElement searchedPlanClick;
                

                @FindBy(how = How.XPATH, using = "//div[@title='Scroll Down']")
                @CacheLookup
                public WebElement scrollDownButton;

                @FindBy(how = How.XPATH, using = "//*[@id=\"BenefitTree\"]/a")
                @CacheLookup
                public WebElement benefitsTab;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-benefitSearchBar\"]/div[2]/div/input")
                @CacheLookup
                public WebElement searchBar;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[1]/i")
                @CacheLookup
                public WebElement tierIcon;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[6]/a")
                @CacheLookup
                public WebElement editButton;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-create-customPlan\"]/form/div[2]/div[6]/div/button[2]")
                @CacheLookup
                public WebElement saveButton;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[3]/a")
                @CacheLookup
                public WebElement deleteButton;
                
                @FindBy(how = How.XPATH, using = "//*[@class=\"btn btn-primary withFocus dialog-action\"][text()=\"Yes\"]")
                @CacheLookup
                public WebElement yesButton;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div/div[2]/div[1]/table/tbody/tr[1]/td[5]/span/span/span[1]")
                @CacheLookup
                public WebElement deductible1BeforeEdit;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div/div[2]/div[1]/table/tbody/tr[1]/td[5]/span/span/span[2]")
                @CacheLookup
                public WebElement deductible2BeforeEdit;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div/div[2]/div[1]/table/tbody/tr[2]/td[5]/span/span/span/span")
                @CacheLookup 
                public WebElement coInsuranceBeforeEdit;

                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[1]/td[5]/span/span/span[1]")
                @CacheLookup
                public WebElement deductible1AfterEdit;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[1]/td[5]/span/span/span[2]")
                @CacheLookup
                public WebElement deductible2AfterEdit;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[2]/td[5]/span/span/span/div[2]/span/span[1]/span[1]/span")
                @CacheLookup 
                public WebElement coInsuranceAfterEdit;
                
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[2]/td[5]/span/span/span/div[2]/span/span[2]")
                @CacheLookup 
                public WebElement coInsuranceTag;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"header-wrapper\"]/ul/li[7]/a")
                @CacheLookup
                public WebElement userNameIcon;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"action_logout\"]")
                @CacheLookup
                public WebElement logoutIcon;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-workflow\"]/form/div[1]/h1/span")
                @CacheLookup
                public WebElement planTransitionPage;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-workflow\"]/form/div[2]/h1/span")
                @CacheLookup
                public WebElement approveAuditInformation;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"planHeaderWrapper\"]/div/div/div[2]/div[1]/button[2]")
                @CacheLookup
                public WebElement debugButton;  
               
                @FindBy(how = How.XPATH, using = "/html/body/div[9]/div/div/div/div[2]/table/tbody/tr/td/div/div/div[1]/div/div[2]/button")
                @CacheLookup
                public WebElement downloadButton;
                
                @FindBy(how = How.XPATH, using = "/html/body/div[8]/div/div/div/div[1]/button")
                @CacheLookup
                public WebElement debugcloseButton;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-workflow\"]/form/div[2]/h1/span")
                @CacheLookup
                public WebElement moveToTestTransition;

                @FindBy(how = How.XPATH, using = "//*[@id=\"content-workflow\"]/form/div[3]/div[2]/label")
                @CacheLookup
                public WebElement effectiveDate;

                @FindBy(how = How.XPATH, using = "//*[@id=\"content-workflow\"]/form/div[3]/div[3]/label")
                @CacheLookup
                public WebElement reasoncode;

                @FindBy(how = How.XPATH, using = "//*[@id=\"commentLabel\"]")
                @CacheLookup
                public WebElement comments;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"header-criteria\"]/div/div[1]")
                @CacheLookup
                public WebElement headerCriteriaIcon;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"select2-3zuh-container\"]") 
                @CacheLookup
                public WebElement criteriaType;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"Find-header-criteria-collapse\"]/div/div[1]/div[1]/div[1]/span")
                @CacheLookup
                public WebElement criteriaStatus;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"Find-header-criteria-collapse\"]/div/div[1]/div[2]/div[1]/span/span[1]/span/ul")
                @CacheLookup
                public WebElement criteriaValue;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"findPlanSearch\"]/div[6]/button[3]")
                @CacheLookup
                public WebElement criteriaSearch;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[2]/a")
                @CacheLookup
                public WebElement copyCreateButton;
              
                @FindBy(how = How.XPATH, using = "//*[@id=\"planHeaderWrapper\"]/div/div/div[2]/div[2]/div[2]/div/div[2]")
                @CacheLookup
                public WebElement planId;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-workflow\"]/form/div[2]/h1/span")
                @CacheLookup
                public WebElement finalizationInformation;
                
                @FindBy(how = How.XPATH, using = "//*[@name=\"effectiveDate\"]") 
                @CacheLookup
                public WebElement effectiveDateValue;
                
                @FindBy(how = How.XPATH, using = "//*[@class=\"select2-selection__rendered\" and text()=\"Other\"]") 
                @CacheLookup
                public WebElement reasonCodeValue;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[4]/a") 
                @CacheLookup
                public WebElement rejectAuditButton;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[3]/a") 
                @CacheLookup
                public WebElement editButtonInFailed;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"BenefitOption\"]/a") 
                @CacheLookup
                public WebElement benefitsOptionTab;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"verticalBarMenuDetails\"]/div/nav/div[2]/ul/li[2]/a") 
                @CacheLookup
                public WebElement adultPhotoChromic;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AdultPhotochromic-_-AdultPhotochromicCovered\"]") 
                @CacheLookup
                public WebElement adultPhotochromicCovered;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"verticalBarMenuDetails\"]/div/nav/div[2]/ul/li[4]/a") 
                @CacheLookup
                public WebElement adultVision;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AdultVision-_-AdultVisionCovered\"]") 
                @CacheLookup
                public WebElement adultVisionCovered;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares\"]") 
                @CacheLookup
                public WebElement benefitSpecificCostShares;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-ApplyDed\"]/span[1]") 
                @CacheLookup
                public WebElement applyDeductible;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-CopayINNT1ExamVst\"]/span[1]") 
                @CacheLookup
                public WebElement examVisitCopay;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-UnitINNT1ExamVstLmt\"]/span[1]") 
                @CacheLookup
                public WebElement examVisitCopayLimit;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-ApplyDed_-_choice-container\"]") 
                @CacheLookup
                public WebElement applyDeductibleValue;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[1]/td[2]/div/span/span/span[1]/input") 
                @CacheLookup
                public WebElement applyDeductibleValueEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-UnitINNT1ExamVstLmt_-_indUnitMax-container\"]") 
                @CacheLookup
                public WebElement examVisitCopayLimitValue;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[3]/td[2]/div[1]/span/span/span[1]/input") 
                @CacheLookup
                public WebElement examVisitCopayLimitValueEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-CopayINNT1ExamVst_-_amount-container\"]") 
                @CacheLookup
                public WebElement examVisitCopayValue;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[2]/td[2]/div[2]/span/span/span[1]/input") 
                @CacheLookup
                public WebElement examVisitCopayValueEnter;
                
               
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesOON-_-BenefitSpecificCostShares-_-ApplyDed\"]/span[1]") 
                @CacheLookup
                public WebElement applyDeductibleOON;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesOON-_-BenefitSpecificCostShares-_-CopayOONExamVst\"]/span[1]") 
                @CacheLookup
                public WebElement examVisitCopayOON;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesOON-_-BenefitSpecificCostShares-_-CopayOONExamVst_-_amount-container\"]") 
                @CacheLookup
                public WebElement examVisitCopayOONValue;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse4\"]/table/tbody/tr[2]/td[2]/div[2]/span/span/span[1]/input") 
                @CacheLookup
                public WebElement examVisitCopayOONValueEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesOON-_-BenefitSpecificCostShares-_-EmergencyDiagnosisPaidAtINNLevelOffice\"]") 
                @CacheLookup
                public WebElement emergencyDiagnosisPaidAtINNLevelOffice;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesOON-_-BenefitSpecificCostShares-_-CoinOONExam\"]/span[1]") 
                @CacheLookup
                public WebElement coInsuranceOON;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesOON-_-BenefitSpecificCostShares-_-ApplyDed_-_choice-container\"]") 
                @CacheLookup
                public WebElement applyDeductibleOONValue;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse4\"]/table/tbody/tr[1]/td[2]/div/span/span/span[1]/input") 
                @CacheLookup
                public WebElement applyDeductibleOONValueEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesOON-_-BenefitSpecificCostShares\"]") 
                @CacheLookup
                public WebElement benefitSpecificCostSharesOON;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesOON-_-BenefitSpecificCostShares-_-EmergencyDiagnosisPaidAtINNLevelOffice_-_choice-container\"]") 
                @CacheLookup
                public WebElement emergencyDiagnosisPaidAtINNLevelOfficeValue;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse4\"]/table/tbody/tr[3]/td[2]/div/span/span/span[1]/input") 
                @CacheLookup
                public WebElement emergencyDiagnosisPaidAtINNLevelOfficeEnter;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExams-_-CoveredINNOON-_-CostSharesOON-_-BenefitSpecificCostShares-_-CoinOONExam_-_percentage-container\"]") 
                @CacheLookup
                public WebElement coInsuranceOONValue;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse4\"]/table/tbody/tr[4]/td[2]/div/span/span/span[1]/input") 
                @CacheLookup
                public WebElement coInsuranceOONValueEnter;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[1]/div/span[1]/input") 
                @CacheLookup
                public WebElement preAuthorizationButton;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[1]/div/span[3]/input") 
                @CacheLookup
                public WebElement autoAdjudicationButton;
               
                @FindBy(how = How.XPATH, using = "//*[@class=\"preAuthWrapper changed\"]") 
                @CacheLookup
                public WebElement preAuthorizationButtonWrapper;
               
                @FindBy(how = How.XPATH, using = "//*[@class=\"autoAdjudWrapper changed\"]") 
                @CacheLookup
                public WebElement autoAdjudicationButtonWrapper;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[2]/td[7]/span/span/input") 
                @CacheLookup
                public WebElement OOPButton;
               
                @FindBy(how = How.XPATH, using = "(//*[@class=\"changed\"])[3]") 
                @CacheLookup
                public WebElement OOPButtonWrapper;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[1]/td[1]/span/input") 
                @CacheLookup
                public WebElement appliesCheckBox;
               
                @FindBy(how = How.XPATH, using = "(//*[@class=\"changed\"])[1]") 
                @CacheLookup
                public WebElement appliesCheckBoxWrapper;
               
                @FindBy(how = How.XPATH, using = "(//*[@class=\"select2-selection__rendered\"])[3]") 
                @CacheLookup
                public WebElement dropdownBox;
               
                @FindBy(how = How.XPATH, using = "(//*[@class=\"changed\"])[2]") 
                @CacheLookup
                public WebElement dropdownBoxWrapper;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div/div[2]/div/table/tbody/tr[2]/td[5]/span/span/span/div[2]/span[2]/span/span[1]/input") 
                @CacheLookup
                public WebElement copayDropdownValueEnter;
               
                @FindBy(how = How.XPATH, using = "(//*[@class=\"select2-selection__rendered\"])[4]") 
                @CacheLookup
                public WebElement coinsuranceDropdownBox;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[3]/td[5]/span/span/span") 
                @CacheLookup
                public WebElement coinsuranceDropdownBoxWrapper;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[3]/td[5]/span/span/span/div[2]/span[2]/span/span[1]/input") 
                @CacheLookup
                public WebElement coinsuranceDropdownValueEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[2]/div[1]/i") 
                @CacheLookup
                public WebElement outOfNetworkTierIcon;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[2]/div[2]/div[2]/div[2]/div/span/input") 
                @CacheLookup
                public WebElement outOfnetworkNotCovered;
               
                @FindBy(how = How.XPATH, using = "(//*[@class=\"changed\"])[4]") 
                @CacheLookup
                public WebElement outOfnetworkNotCoveredWrapper;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"benefitsTree\"]/ul/li[22]/ul[1]/li/div/div/div/a/span") 
                @CacheLookup
                public WebElement benefitsTreeIndicator;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-benefitSearchBar\"]/div[1]/button[3]") 
                @CacheLookup
                public WebElement restoreButton;
               
                @FindBy(how = How.XPATH, using = "/html/body/div[9]/div/div/div/div[3]/button[1]") 
                @CacheLookup
                public WebElement restoreYesButton;
               
                @FindBy(how = How.XPATH, using = "/html/body/div[9]/div/div/div/div[3]/button[2]") 
                @CacheLookup
                public WebElement restoreNoButton;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"benefitsTree\"]/ul/li[2]/ul[2]/li/div/div/div/a") 
                @CacheLookup
                public WebElement bioFeedbackBenefit;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div/div[2]/div/table/tbody/tr[1]/td[5]/span/span/span/div[2]/span[2]/span/span[1]/input") 
                @CacheLookup
                public WebElement bioFeedbackCopayDropdownValueEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div/div[2]/div/table/tbody/tr[3]/td[5]/span/span/span/div[2]/span[2]/span/span[1]/input") 
                @CacheLookup
                public WebElement bioFeedbackCoinsuranceDropdownValueEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div/div[2]/div/table/tbody/tr[2]/td[1]/span/input") 
                @CacheLookup
                public WebElement calculationChoiceInCopay;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div/div[2]/div/table/tbody/tr[2]/td[1]/span") 
                @CacheLookup
                public WebElement calculationChoiceWrapperInCopay;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares\"]") 
                @CacheLookup
                public WebElement benefitSpecificCostSharesInUrgentCare;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-ApplyDed_-_choice-container\"]") 
                @CacheLookup
                public WebElement urgentCareValueDeductible;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[1]/td[2]/div/span/span/span[1]/input") 
                @CacheLookup
                public WebElement urgentCareValueDeductibleEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CoinINNT1UrgentCareFac_-_percentage-container\"]") 
                @CacheLookup
                public WebElement urgentCareCoinsurance;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[2]/td[2]/div/span/span/span[1]/input") 
                @CacheLookup
                public WebElement urgentCareCoinsuranceEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CopayINNT1UrgentCareFac_-_amount-container\"]") 
                @CacheLookup
                public WebElement urgentCareCopay;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[3]/td[2]/div[2]/span/span/span[1]/input") 
                @CacheLookup
                public WebElement urgentCareCopayEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[1]/td[5]/span/span/span/div[2]/span[2]/span/span[1]/input") 
                @CacheLookup
                public WebElement urgentCarebenefitsCopayEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"benefitDetailsHeaderWrapper\"]/div[1]/button[2]") 
                @CacheLookup
                public WebElement restoreButtonInBenefits;
               
                @FindBy(how = How.XPATH, using = "(//*[@class=\"select2-selection__rendered\"])[2]") 
                @CacheLookup
                public WebElement coinsuranDropdownBox;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"findPlanSearch\"]/div[1]/span[2]") 
                @CacheLookup
                public WebElement saveSearchCriteria;
               
                @FindBy(how = How.XPATH, using = "/html/body/div[9]/div/div/div/div[2]/table/tbody/tr/td/div/input") 
                @CacheLookup
                public WebElement saveSearchName;
               
                @FindBy(how = How.XPATH, using = "/html/body/div[9]/div/div/div/div[3]/button[2]") 
                @CacheLookup
                public WebElement saveSearchYes;
               
                @FindBy(how = How.XPATH, using = "(//*[@class=\"btn btn-sm btn-primary find pull-right\"])[1]") 
                @CacheLookup
                public WebElement searchButton;
               
                @FindBy(how = How.XPATH, using = "(//*[@class=\"select2-selection__rendered\"])[3]") 
                @CacheLookup
                public WebElement savedSearch;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span/span[1]/input") 
                @CacheLookup
                public WebElement savedSearchEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"findPlanSearch\"]/div[3]/div/div[12]/input[3]") 
                @CacheLookup
                public WebElement planDescription;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"findPlanSearch\"]/div[3]/div/div[13]/input[3]") 
                @CacheLookup
                public WebElement repositoryId;
               
                @FindBy(how = How.NAME, using = "criteria[effDateToString]") 
                @CacheLookup
                public WebElement effectiveThrough;
               
                @FindBy(how = How.NAME, using = "criteria[modDateFromString]") 
                @CacheLookup
                public WebElement modifiedFrom;
               
                @FindBy(how = How.NAME, using = "criteria[modDateToString]") 
                @CacheLookup
                public WebElement modifiedThrough;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"Find-header-criteria-collapse\"]/div/div[1]/div[2]/div[1]/span/span[1]/span/ul") 
                @CacheLookup
                public WebElement headerValue;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"Find-header-criteria-collapse\"]/div/div[1]/div[2]/div[1]/span[1]/span[1]/span/ul") 
                @CacheLookup
                public WebElement headerFieldValueEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"accumulator-criteria-collapse\"]/div/div/div/div[1]/div[2]/span[2]/span/span[1]/span/span[2]") 
                @CacheLookup
                public WebElement accumulatorName;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"accumulator-criteria-collapse\"]/div/div/div/div[2]/div[2]/span[3]/input") 
                @CacheLookup
                public WebElement accumulatorValue;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"Find-header-criteria-collapse\"]/div/div[1]/div[1]/div[1]/span[2]/span/span[1]/input") 
                @CacheLookup
                public WebElement headerValueEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span/span[1]/input") 
                @CacheLookup
                public WebElement accumTypeEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span/span[1]/input") 
                @CacheLookup
                public WebElement accumNameEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"benefit-criteria-collapse\"]/div/div/div/div/div[1]/div/div[2]/input") 
                @CacheLookup
                public WebElement exclude;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span/span[1]/input") 
                @CacheLookup
                public WebElement planOptionNameEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@class=\"select2-selection__placeholder\"]") 
                @CacheLookup
                public WebElement benefitSituationType;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span/span[1]/input") 
                @CacheLookup
                public WebElement benefitSituationTypeEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"header-wrapper\"]/ul/li[2]/a") 
                @CacheLookup
                public WebElement findButton;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"header-wrapper\"]/ul/li[2]/ul/li[1]/a") 
                @CacheLookup
                public WebElement findPlanButton;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"findPlanSearch\"]/div[1]/span[1]/span[1]/span/span[2]") 
                @CacheLookup
                public WebElement searchDropDown;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"find-plan-sectionWrapper\"]/div[2]/div[1]/span") 
                @CacheLookup
                public WebElement searchIcon;
               
                @FindBy(how = How.XPATH, using = "(//*[@class=\"select2-selection__rendered\"])[13]") 
                @CacheLookup
                public WebElement accumName;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"accumulator-criteria-collapse\"]/div/div[1]/div/div[2]/div[2]/span[3]/input") 
                @CacheLookup
                public WebElement dollarLimit;
               
                @FindBy(how = How.XPATH, using = "(//*[@class=\"select2-selection__rendered\"])[16]") 
                @CacheLookup
                public WebElement benefitName;
               
                @FindBy(how = How.XPATH, using = "(//*[@class=\"select2-selection__rendered\"])[17]") 
                @CacheLookup
                public WebElement situationGroup;
               
                @FindBy(how = How.XPATH, using = "(//*[@class=\"select2-selection__rendered\"])[18]") 
                @CacheLookup
                public WebElement situationType;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[1]/td[2]/a") 
                @CacheLookup
                public WebElement date;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"Find-header-criteria-collapse\"]/div/div[2]/div/div[1]/span") 
                @CacheLookup
                public WebElement headerTypeText;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"Find-header-criteria-collapse\"]/div/div[2]/div/div[2]/span/span") 
                @CacheLookup
                public WebElement headerValueText;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"header-wrapper\"]/ul/li[2]/ul/li[2]/a") 
                @CacheLookup
                public WebElement template;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"Find-header-criteria-collapse\"]/div/div[2]/div[2]/div[1]/span") 
                @CacheLookup
                public WebElement headerCriteriaType;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"Find-header-criteria-collapse\"]/div/div[2]/div[2]/div[2]/span/span") 
                @CacheLookup
                public WebElement headerCriteriaValue;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"planHeaderWrapper\"]/div/div/div[2]/div[1]/button[3]/i") 
                @CacheLookup
                public WebElement documentsTab;
                
                @FindBy(how = How.XPATH, using = "/html/body/div[8]/div/div/div/div[2]/table/tbody/tr/td/div/div/table/tbody/tr/td[2]/div/button/center/div") 
                @CacheLookup
                public WebElement excelReport;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span/span[1]/input") 
                @CacheLookup
                public WebElement planOptionArea;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"Find-header-criteria-collapse\"]/div/div[1]/div[2]/div[1]/span/span[1]/span/ul/li[1]/span") 
                @CacheLookup
                public WebElement cancelHeader;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"messageWrapper\"]/div[1]/ul") 
                @CacheLookup
                public WebElement warningMessage;
                
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span") 
                @CacheLookup
                public WebElement listOfOptions;
                
                @FindBy(how = How.XPATH, using = "//*[@class=\"select2-selection__placeholder\"]/following::span[text()='Select a value']") 
                @CacheLookup
                public WebElement accumulatorChoiceValue;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span/span[1]/input") 
                @CacheLookup
                public WebElement accumulatorChoiceValueEnter;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"findPlanSearch\"]/div[3]") 
                @CacheLookup
                public WebElement base;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"header-criteria\"]/div/div[1]") 
                @CacheLookup
                public WebElement header;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"planOption-criteria\"]/div[1]") 
                @CacheLookup
                public WebElement option;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"accumulator-criteria\"]/div[1]") 
                @CacheLookup
                public WebElement accumulator;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"benefit-criteria\"]/div[1]") 
                @CacheLookup
                public WebElement benefit;
               
                @FindBy(how = How.XPATH, using = "((//*[@class='badge single-criteria planOption-single-criteria ']/following::span[@class='select2-results'])[1]/ul/li/span)[text()='Mandate']") 
                @CacheLookup
                public WebElement mandate;
               
                @FindBy(how = How.XPATH, using = "((//*[@class='badge single-criteria planOption-single-criteria ']/following::span[@class='select2-results'])[1]/ul/li/span)[text()='Medical Policy']") 
                @CacheLookup
                public WebElement medicalPolicy;
               
                @FindBy(how = How.XPATH, using = "((//*[@class='badge single-criteria planOption-single-criteria ']/following::span[@class='select2-results'])[1]/ul/li/span)[text()='UM Rules']") 
                @CacheLookup
                public WebElement umRules;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span") 
                @CacheLookup
                public WebElement planSetupTypesForDental;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"planOption-criteria-collapse\"]/div/div/div/div/div[3]/a[1]/i") 
                @CacheLookup
                public WebElement deleteOptionCriteria;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span") 
                @CacheLookup
                public WebElement planSetupNameForDental;
               
              /*  @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span") 
                @CacheLookup
                public WebElement accumTypeForDental;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span") 
                @CacheLookup
                public WebElement accumNameForDental;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span") 
                @CacheLookup
                public WebElement accumNameForDental;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span") 
                @CacheLookup
                public WebElement accumNameForDental;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span") 
                @CacheLookup
                public WebElement accumNameForDental;
               
                @FindBy(how = How.XPATH, using = "//*[@id=\"content-find-plan\"]/span/span") 
                @CacheLookup
                public WebElement accumNameForDental;
               */
                
                public void seHeaderScrollDropdown()
                {
                       
                	WebElement objAvailableOptions = getWebDriver().findElement(By.xpath("//*[@class='select2-results__options']/li[text()='Line of Business']"));
                    JavascriptExecutor je = (JavascriptExecutor) driver;
                    je.executeScript("arguments[0].scrollIntoView(true);",objAvailableOptions);
                    WebElement objAvailableSelct = getWebDriver().findElement(By.xpath("//*[@class='select2-results__options']"));
                    seClick(objAvailableSelct,"On Type");
              WebElement objTextSelect = getWebDriver().findElement(By.xpath("(//span[@class='select2-selection__rendered'])[4]"));            
                    String strTextSelect = seGetText(objTextSelect);
                    System.out.println(strTextSelect);
                    if(!strTextSelect.equalsIgnoreCase("- Please Select -")){
                           log(PASS,"Validated that user is able scroll through to make a selection from dropdown box and select one","RESULT:PASS");
                           }else
                    {log(FAIL,"Error occured and User Not able to scroll into value to select one","RESULT:FAIL");}
                }
                
                public WebElement rowlabel(String label)
            	{
            		WebElement rowlabel= getWebDriver().findElement(By.xpath("//*[@class='table searchResultsTable fjaTable dataTable']/thead/tr/th[text()='"+label+"']"));
            		return rowlabel;
            	}
                
                
                @FindBy(how= How.XPATH, using="(//tr[@class='datatable filter']/td[@data-value='6']/div/ul/div)[2]/button[text()='Ok']")
            	public WebElement buttonOk;
                
                public void seCheckDropdownEmpty(){
                	String strOptionArea = seGetText(FindPlanPage.get().planOptionArea);
                	String strOptionType = seGetText(FindPlanPage.get().planOptionType);
                	String strOptionName = seGetText(FindPlanPage.get().planOptionName);
                	String strAccumType = seGetText(FindPlanPage.get().accumType);
                	String strAccumName = seGetText(BenefitRetainsInProductionPage.get().accumulatorName);
                	String strBenefitName = seGetText(FindPlanPage.get().selectTheBenefit);
                	String strsituationGroup = seGetText(FindPlanPage.get().situationGroup);
                	String strsituationType = seGetText(FindPlanPage.get().situationType);
                	
                	String strPlanOptionArea = getCellValue("PlanOptionAreaBox");
						String strPlanOptionType = getCellValue("PlanOptionTypeBox");
						String strPlanOptionName = getCellValue("PlanOptionNameBox");
						String strAccumulatorType = getCellValue("AccumulatorTypeBox");
						String strAccumulatorName = getCellValue("AccumulatorNameBox");
						String strBenefit = getCellValue("BenefitBox");
						String strSituationGroup = getCellValue("SituationGroupBox");
						String strSituationType = getCellValue("SituationTypeBox");
						
                	if(strOptionArea.equals(strPlanOptionArea))
                	{
                		RESULT_STATUS = true;
                		log(PASS, "Invalid criteria values are removed |Expected = "+strOptionArea+"","Actual = "+strPlanOptionArea+", RESULT=PASS");
        			} else {
        				RESULT_STATUS = false;
        				log(FAIL, "Invalid values still retains","Comparison NOT As expected, RESULT=FAIL");
        			}	
                	if(strOptionType.equals(strPlanOptionType))
                	{
                		RESULT_STATUS = true;
                		log(PASS, "Invalid criteria values are removed |Expected = "+strOptionType+"","Actual = "+strPlanOptionType+", RESULT=PASS");
        			} else {
        				RESULT_STATUS = false;
        				log(FAIL, "Invalid values still retains","Comparison NOT As expected, RESULT=FAIL");
        			}
                	if(strOptionName.equals(strPlanOptionName))
                	{
                		RESULT_STATUS = true;
                		log(PASS, "Invalid criteria values are removed |Expected = "+strOptionName+"","Actual = "+strPlanOptionName+", RESULT=PASS");
        			} else {
        				RESULT_STATUS = false;
        				log(FAIL, "Invalid values still retains","Comparison NOT As expected, RESULT=FAIL");
        			}
                	if(strAccumType.equals(strAccumulatorType))
                	{
                		RESULT_STATUS = true;
                		log(PASS, "Invalid criteria values are removed |Expected = "+strAccumType+"","Actual = "+strAccumulatorType+", RESULT=PASS");
        			} else {
        				RESULT_STATUS = false;
        				log(FAIL, "Invalid values still retains","Comparison NOT As expected, RESULT=FAIL");
        			}
                	if(strAccumName.equals(strAccumulatorName))
                	{
                		
                		RESULT_STATUS = true;
                		log(PASS, "Invalid criteria values are removed |Expected = "+strAccumName+"","Actual = "+strAccumulatorName+", RESULT=PASS");
        			} else {
        				RESULT_STATUS = false;
        				log(FAIL, "Invalid values are removed"+strAccumName+"not="+strAccumulatorName,"Comparison NOT As expected, RESULT=FAIL");
        			}
                	if(strBenefitName.equals(strBenefit))
                	{
                		
                		RESULT_STATUS = true;
                		log(PASS, "Invalid criteria values are removed |Expected = "+strBenefitName+"","Actual = "+strBenefit+", RESULT=PASS");
        			} else {
        				RESULT_STATUS = false;
        				log(FAIL, "Invalid values are removed"+strBenefitName+"not="+strBenefit,"Comparison NOT As expected, RESULT=FAIL");
        			}
                	if(strsituationGroup.equals(strSituationGroup))
                	{
                		
                		RESULT_STATUS = true;
                		log(PASS, "Invalid criteria values are removed |Expected = "+strsituationGroup+"","Actual = "+strSituationGroup+", RESULT=PASS");
        			} else {
        				RESULT_STATUS = false;
        				log(FAIL, "Invalid values are removed"+strsituationGroup+"not="+strSituationGroup,"Comparison NOT As expected, RESULT=FAIL");
        			}
                	if(strsituationType.equals(strSituationType))
                	{
                		
                		RESULT_STATUS = true;
                		log(PASS, "Invalid criteria values are removed |Expected = "+strsituationType+"","Actual = "+strSituationType+", RESULT=PASS");
        			} else {
        				RESULT_STATUS = false;
        				log(FAIL, "Invalid values are removed"+strsituationType+"not="+strSituationType,"Comparison NOT As expected, RESULT=FAIL");
        			}
               }
               
                public void seFieldValueCompare(String strExpected,String strActual){
                if(strExpected.equals(strActual))
		    	{
		    		RESULT_STATUS = false;
		    		log(FAIL, "Values does not Differs based on the header Criteria","Expected= "+strExpected+" and Actual="+strActual+"RESULT=FAIL");
		    		
				} else {
					RESULT_STATUS = true;
					log(PASS, "Values does not Differs based on the header Criteria","Expected= "+strExpected+" and Actual="+strActual+"RESULT=FAIL");
				}
                }
                public void seTypeComplete(String strTypeValue)
            	{
            		seClick(HomePage.get().find, "Find");
            		waitForPageLoad(300);
            		seClick(HomePage.get().findPlan, "Find Plan");
            		waitForPageLoad(300);
            		waitForPageLoad();
            		seClick(FindTemplatePage.get().headerCriteria,"Header criteria");
            		waitForPageLoad();
            		seClick(FindTemplatePage.get().headerCriteriaType,"Header criteria type");
            		waitForPageLoad();
            		WebElement objClickOnType = getWebDriver().findElement(By.xpath("//*[@class='select2-results__options']"));
            		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objClickOnType);
            		
            		WebElement objInputType = getWebDriver().findElement(By.xpath("//span[@class='select2-search select2-search--dropdown']/input"));		
            		seClick(objInputType, "Input Value");
            		seSetText(objInputType, strTypeValue, "Entering the complete values");
            		WebElement objAvailableSelct = getWebDriver().findElement(By.xpath("//*[@class='select2-results__options']"));
            		seClick(objAvailableSelct,"On Type");		
            		WebElement objTextSelect = getWebDriver().findElement(By.xpath("(//span[@class='select2-selection__rendered'])[4]"));		
            		String strTextSelect = seGetText(objTextSelect);
            		System.out.println(strTextSelect);
            		if(strTypeValue.equalsIgnoreCase(strTextSelect))
            		{
            			//ul[@class='select2-selection__rendered']
            			WebElement objValue = getWebDriver().findElement(By.xpath("//ul[@class='select2-selection__rendered']"));
            			seClick(objValue,"On Value");	
            			waitForPageLoad(360);
            			boolean blnValueSelect = seIsElementEnabled(objValue, "value");
            			if(blnValueSelect == true){
            			//true so click able to move on add that log.
            			if(!strTextSelect.equalsIgnoreCase("- Please Select -")){
            				log(PASS,"Validated that the user is able to type the complete value and move on to the next field","RESULT:PASS");
            				}else
            			{log(FAIL,"Error occured and User Not able to type the complete value and move on to the next field","RESULT:FAIL");}
            			
            			}
            			else{log(FAIL,"Error occured and User Not able to type the complete value ","RESULT:FAIL");}
            		
            			
            				
            		}	
            		
            		
            	}
            		
                
    public void seInvalidValueEnter(){
    	String strPlanOption = seGetText(FindPlanPage.get().planOptionArea);
    	String strPlanOptionArea = getCellValue("PlanOptionAreaBox");
    	if(strPlanOption.equals(strPlanOptionArea))
    	{
    		RESULT_STATUS = true;
    		log(PASS, "Invalid values are not accepted by the system","Value not entered, RESULT=PASS");
		} else {
			RESULT_STATUS = false;
			log(FAIL, "Invalid value accepted by the system","InValid Value entered, RESULT=FAIL");
		}
    }
                public void seRejectTestFunctionality() {
            		try {
            			seWaitForClickableWebElement(PlanHeaderPage.get().rejectTest, 60);
            			seClick(PlanHeaderPage.get().rejectTest, "Reject Test");
            			waitForPageLoad();
            			seIsElementDisplayed(BenefitRetainsInProductionPage.get().planTransitionPage,
								"Plan Transition page");
						seIsElementDisplayed(BenefitRetainsInProductionPage.get().approveAuditInformation,
								"Reject Test Information");
            			seWaitForClickableWebElement(PlanTransitionPage.get().reasonCode, 60);
            			seClick(PlanTransitionPage.get().reasonCode, "Reason Code");
            			seClick(PlanTransitionPage.get().selectType("Other"), "Select Other from Reason Code");
            			seWaitForClickableWebElement(PlanTransitionPage.get().txtWorkflowComment, 60);
            			seSetText(PlanTransitionPage.get().txtWorkflowComment, "Test Comment", "Comment");
            			seClick(PlanTransitionPage.get().btnRejectedTest, "Rejected Test");
            			waitForPageLoad();

            			String strActualStatus = seGetElementValue(PlanHeaderPage.get().planStatus);
            			if (strActualStatus.equalsIgnoreCase("Test Failed")) {
            				RESULT_STATUS = true;
            				log(PASS, "Verify if Plan Status is 'Test Failed'.",
            						"Plan Status is '" + strActualStatus + "' as expected value 'Test Failed', RESULT=PASS");
            			} else {
            				RESULT_STATUS = false;
            				log(FAIL, "Verify if Plan Status is 'Test Failed'.",
            						"Plan Status is '" + strActualStatus + "' NOT as expected value 'Test Failed', RESULT=FAIL");
            			}
            		} catch (Exception e) {
            			log(ERROR, "Error while executing 'seRejectTest' method.");
            		}
            	}

                
                
/**
 * @param strExpected:Benefit value before edit
 * @param strActual:Benefit value after edit
 */
public static void seBenefitValueCompare(String strExpected,String strActual){
                                
                if(strExpected!=strActual)
                {
                                RESULT_STATUS=true;
                                log(PASS, "New Plan Id " +strActual+ " is generated for copied plan","Comparison As expected, RESULT=PASS");
                                
                }
                else
                {
                                RESULT_STATUS=false;
                                log(FAIL, "New Plan Id is not generated for copied plan","Comparison NOT as expected, RESULT=FAIL");
                                
                }
}


/**
 * @ This method deletes the edited plan
 */
public static void seTearDown(){
	try{
	seClick(BenefitRetainsInProductionPage.get().deleteButton,"Delete Button");
	waitForPageLoad(30,10);
	seClick(BenefitRetainsInProductionPage.get().yesButton,"Yes");
	}catch (Exception e) {
		log(ERROR, "Exception while executing 'seVerifyUrgentCareValues' method");
	}
}
public static void seBenefitsTab(){
for(int i=0;i<16;i++)
{
seClick(BenefitRetainsInProductionPage.get().scrollDownButton, " Scroll down button");
}            
}

public static boolean seIsElementNotDisplayed(WebElement testObject, String strElementName) {
	boolean blnIsElementDisplayed = false;
	
	try {
		if (!testObject.isDisplayed()) {
			log(PASS, "Verify " + strElementName + " is NOT displayed", strElementName + " is NOT displayed", true);
			blnIsElementDisplayed = true;
		} else {
			RESULT_STATUS = false;
			log(FAIL, "Verify " + strElementName + " is NOT displayed", strElementName + " is displayed", true);
		}
	} catch (Exception e) {
		e.printStackTrace();
		RESULT_STATUS = true;
		log(PASS, "Verify " + strElementName + " is NOT displayed",  strElementName + " is NOT displayed", true);
	}
	
	return blnIsElementDisplayed;
}

public static boolean seIsElementNotDisplayedCheck(WebElement testObject, String strElementName) {
	boolean blnIsElementDisplayed = false;
	
	try {
		if (testObject.isDisplayed()&!driver.findElement(By.xpath("//*[@id=\"benefitsTree\"]/ul/li[21]/ul[1]/li/div/div/div/a/span")).isDisplayed()) {
			
			log(PASS, "Verify " + strElementName + " is NOT displayed", strElementName + " is NOT displayed", true);
			blnIsElementDisplayed = true;
		} else {
			RESULT_STATUS = false;
			log(FAIL, "Verify " + strElementName + " is NOT displayed", strElementName + " is displayed", true);
		}
	} catch (NoSuchElementException e) {
		e.printStackTrace();
		RESULT_STATUS = true;
		log(FAIL, "Verify " + strElementName + " is NOT displayed", "Exception while verifyng " + strElementName + " is NOT displayed", true);
	}
	
	return blnIsElementDisplayed;
}
public static boolean seCheckElement(){
	
if(!driver.findElement(By.xpath("//*[@id=\"benefitsTree\"]/ul/li[21]/ul[1]/li/div/div/div/a/span")).isDisplayed())
{
	   log(PASS, "Benefit tree indicator is NOT displayed","Benefit tree indicator", true);
	   return true;
}
else{
	   log(FAIL, "Benefit tree indicator is  displayed","Benefit tree indicator", false);
	   return false;
}
}  

public static void seBooleanCompare(boolean strExpected,boolean strActual){
    
    if(strExpected==strActual)
    {
                    RESULT_STATUS=true;
                    log(PASS, "values restored","Comparison As expected, RESULT=PASS");
                    
    }
    else
    {
                    RESULT_STATUS=false;
                    log(FAIL, "values not restored","Comparison NOT as expected, RESULT=FAIL");
                    
    }
}

public static void seStringCompare(String strExpected,String strActual){
    
    if(strExpected.equals(strActual))
    {
                    RESULT_STATUS=true;
                    log(PASS, "Expected = " + strExpected + " is displayed", strActual + " is  displayed", true);
                    
    }
    else
    {
                    RESULT_STATUS=false;
                    log(FAIL, "Expected = " + strExpected + " is displayed", strActual + " is  not displayed", true);                    
    }
}

public boolean seFileDownloadXMLFromUI(String strID, String strUserID) {
	try {
		String strXmlFileLocation = "C:\\Users\\"+strUserID+"\\Downloads\\Plan"+ "_" + strID + "_FrontEnd"+".xlsx";
		File xmlFileAvailable = new File(strXmlFileLocation);
		//System.out.println(strXmlFileLocation);
		String strXmlFileLocationSlash = strXmlFileLocation.replaceAll("[\\,]","\\"); 
		//System.out.println(strXmlFileLocationSlash);
		setCellValue("FileName", strXmlFileLocationSlash);
		if (!xmlFileAvailable.exists()) {
			RESULT_STATUS = false;
			
			log(FAIL, "XML file is not downloadable",
					"XML file unavailable for download");
			return false;
		}
		RESULT_STATUS = true;
		
		log(PASS, "XML file is downloadable",
				"Downloaded the XML file"+strXmlFileLocation);
		return true;
	} catch (Exception e) {
		RESULT_STATUS = false;
		log(FAIL, "XML file is not downloadable",
				"XML file unavailable for download ");
		return false;
	}
}

public void seCheckDropDown(WebElement wbField, String strElementName, String strValue) {
	
	try {
		seClick(wbField, strElementName);
		waitForPageLoad();
		seSetText(BenefitRetainsInProductionPage.get().planOptionArea, strValue, "Set text for " + strElementName);
		waitForPageLoad();
		seClick(PlanSetupPage.get().dropDownSelect, "Select " + strValue + " from " + strElementName);
		waitForPageLoad();
		String strValueOfField =seGetText(getWebDriver().findElement(By.xpath("//div[@id='planOption-criteria-collapse']/div/div/div/div/div[2]/span[1]/span/span/span/span[1]")));
		String strLOB = getCellValue("HeaderValue");
		if(strValueOfField.equals(strValue))
		{
			RESULT_STATUS=true;
			log(PASS, "Reason Code for LOB : Medical '"+strValue+" ' is present in the drop down","RESULT=PASS");
		}
		else
		{
			RESULT_STATUS=false;
			log(FAIL, "Reason Code for LOB : Medical '"+strValue+" ' is not present in the drop down","RESULT=FAIL");
		}
	} catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
	}
}


public void seFilter(String strRowHeader, String strTypeToBeFiltered)
{
	//filtering
	//seClick(CreateTemplatePage.get().filter("Status"),"Filtering column wise");
	switch (strRowHeader){
	
	case "Line of Business": 
		WebElement objLOB= getWebDriver().findElement(By.xpath("//*[@id=\"DataTables_Table_1\"]/thead/tr[2]/td[6]/div/a/i"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objLOB);
		WebElement objLOBSelectAll=getWebDriver().findElement(By.xpath("//*[@id=\"dropdown\"]/li[1]/a/input"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objLOBSelectAll);
		WebElement objFilter= getWebDriver().findElement(By.xpath("//*[@id=\"dropdown\"]/li[3]/a/input"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objFilter);
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",BenefitRetainsInProductionPage.get().buttonOk);
		WebElement objFilterCheck= getWebDriver().findElement(By.xpath("//*[@class='table searchResultsTable fjaTable dataTable']/thead/tr[@class='datatable filter']/td[@data-value='3']/div/a/span"));
		String strFilterCheck = seGetText(objFilterCheck);
		if(strFilterCheck .equalsIgnoreCase("Filtered")  && FindTemplatePage.get().templateResults.isDisplayed())
		{
			log(PASS, "Filter Action Sucessful","Templates are Filtered according to : "+strRowHeader+ "and" +strTypeToBeFiltered+"");				
		}
		else
		{
			log(FAIL, "Filter Action UnSucessful","Templates are not  Filtered according to : "+strRowHeader+ "and" +strTypeToBeFiltered+"");	
		}
		break;
		
	case "Market Segment": 	
		WebElement objMarketSegment= getWebDriver().findElement(By.xpath("//*[@class='table searchResultsTable fjaTable dataTable']/thead/tr[@class='datatable filter']/td[@data-value='4']/div/a/i"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objMarketSegment);
		WebElement objMarketSegmentSelectAll=getWebDriver().findElement(By.xpath("//*[@class='table searchResultsTable fjaTable dataTable']/thead/tr[@class='datatable filter']/td[@data-value='4']/div/ul/li/a/input"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objMarketSegmentSelectAll);
		WebElement objFilterMarketSegment= getWebDriver().findElement(By.xpath("//tr[@class='datatable filter']/td[@data-value='4']/div/ul/li[@data-value='"+strTypeToBeFiltered+"']/a/input"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objFilterMarketSegment);
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",BenefitRetainsInProductionPage.get().buttonOk);
		WebElement objSegmentCheck= getWebDriver().findElement(By.xpath("//*[@class='table searchResultsTable fjaTable dataTable']/thead/tr[@class='datatable filter']/td[@data-value='4']/div/a/span"));
		String strSegmentrCheck = seGetText(objSegmentCheck);System.out.println(objSegmentCheck);
		if(strSegmentrCheck .equalsIgnoreCase("Filtered")  && FindTemplatePage.get().templateResults.isDisplayed())
		{
			log(PASS, "Filter Action Sucessful","Templates are Filtered according to : "+strRowHeader+ "and" +strTypeToBeFiltered+"");				
		}
		else
		{
			log(FAIL, "Filter Action UnSucessful","Templates are not  Filtered according to : "+strRowHeader+ "and" +strTypeToBeFiltered+"");	
		}
		break;
		
	case "Eff. Date": 
		WebElement objDate= getWebDriver().findElement(By.xpath("//*[@class='table searchResultsTable fjaTable dataTable']/thead/tr[@class='datatable filter']/td[@data-value='5']/div/a/i"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objDate);
		WebElement objDateSelectAll=getWebDriver().findElement(By.xpath("//*[@class='table searchResultsTable fjaTable dataTable']/thead/tr[@class='datatable filter']/td[@data-value='5']/div/ul/li/a/input"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objDateSelectAll);
		WebElement objFilterDate= getWebDriver().findElement(By.xpath("//tr[@class='datatable filter']/td[@data-value='5']/div/ul/li[@data-value='"+strTypeToBeFiltered+"']/a/input"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objFilterDate);
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",BenefitRetainsInProductionPage.get().buttonOk);
		WebElement objDateCheck= getWebDriver().findElement(By.xpath("//*[@id=\"DataTables_Table_3\"]/thead/tr[2]/td[9]/div/a/span"));
		String strDateCheck = seGetText(objDateCheck);
		if(strDateCheck .equalsIgnoreCase("Filtered")  && FindTemplatePage.get().templateResults.isDisplayed())
		{
			log(PASS, "Filter Action Sucessful","Templates are Filtered according to : "+strRowHeader+ "and" +strTypeToBeFiltered+"");				
		}
		else
		{
			log(FAIL, "Filter Action UnSucessful","Templates are not  Filtered according to : "+strRowHeader+ "and" +strTypeToBeFiltered+"");	
		}
		break;
		
	case "Status": 
		WebElement objStatus= getWebDriver().findElement(By.xpath("//*[@id=\"DataTables_Table_1\"]/thead/tr[2]/td[9]/div/a/i"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objStatus);
		
		WebElement objStatusSelectAll=getWebDriver().findElement(By.xpath("(//*[@id=\"dropdown\"]/li[1]/a/input)[10]"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objStatusSelectAll);
		WebElement objFilterStatus= getWebDriver().findElement(By.xpath("(//*[@id=\"dropdown\"]/li[3]/a/input)[10]"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objFilterStatus);
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",BenefitRetainsInProductionPage.get().buttonOk);
		WebElement objStatusCheck= getWebDriver().findElement(By.xpath("//*[@id=\"DataTables_Table_1\"]/thead/tr[2]/td[9]/div/a/span"));
		String strStatusCheck = seGetText(objStatusCheck);
		if(strStatusCheck .equalsIgnoreCase("Filtered") && FindTemplatePage.get().templateResults.isDisplayed())
		{
			log(PASS, "Filter Action Sucessful","Plans are Filtered according to : "+strRowHeader+ "and" +strTypeToBeFiltered+"");				
		}
		else
		{
			log(FAIL, "Filter Action UnSucessful","plans are not  Filtered according to : "+strRowHeader+ "and" +strTypeToBeFiltered+"");	
		}
		break;
		
	case "Created By": 
		WebElement objCreatedBy= getWebDriver().findElement(By.xpath("//*[@class='table searchResultsTable fjaTable dataTable']/thead/tr[@class='datatable filter']/td[@data-value='7']/div/a/i"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objCreatedBy);
		
		WebElement objCreatedBySelectAll=getWebDriver().findElement(By.xpath("//*[@class='table searchResultsTable fjaTable dataTable']/thead/tr[@class='datatable filter']/td[@data-value='7']/div/ul/li/a/input"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objCreatedBySelectAll);
		WebElement objFilterCreated= getWebDriver().findElement(By.xpath("//tr[@class='datatable filter']/td[@data-value='7']/div/ul/li[@data-value='"+strTypeToBeFiltered+"']/a/input"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objFilterCreated);
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",BenefitRetainsInProductionPage.get().buttonOk);
		WebElement objCreatedtCheck= getWebDriver().findElement(By.xpath("//*[@class='table searchResultsTable fjaTable dataTable']/thead/tr[@class='datatable filter']/td[@data-value='7']/div/a/span"));
		String strCreatedCheck = seGetText(objCreatedtCheck);
		if(strCreatedCheck.equalsIgnoreCase("Filtered") && FindTemplatePage.get().templateResults.isDisplayed())
		{
			log(PASS, "Filter Action Sucessful","Templates are Filtered according to : "+strRowHeader+ "and" +strTypeToBeFiltered+"");				
		}
		else
		{
			log(FAIL, "Filter Action UnSucessful","Templates are not  Filtered according to : "+strRowHeader+ "and" +strTypeToBeFiltered+"");	
		}
		break;
		
	case "Modified":	
		WebElement objModified= getWebDriver().findElement(By.xpath("//*[@class='table searchResultsTable fjaTable dataTable']/thead/tr[@class='datatable filter']/td[@data-value='8']/div/a/i"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objModified);
		
		WebElement objModifiedSelectAll=getWebDriver().findElement(By.xpath("//*[@class='table searchResultsTable fjaTable dataTable']/thead/tr[@class='datatable filter']/td[@data-value='8']/div/ul/li/a/input"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objModifiedSelectAll);
		WebElement objFilterModified= getWebDriver().findElement(By.xpath("//tr[@class='datatable filter']/td[@data-value='8']/div/ul/li[@data-value='"+strTypeToBeFiltered+"']/a/input"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objFilterModified);
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",BenefitRetainsInProductionPage.get().buttonOk);
		WebElement objModifiedCheck= getWebDriver().findElement(By.xpath("//*[@class='table searchResultsTable fjaTable dataTable']/thead/tr[@class='datatable filter']/td[@data-value='8']/div/a/span"));
		String strModifiedCheck = seGetText(objModifiedCheck);
		if(strModifiedCheck .equalsIgnoreCase("Filtered") && FindTemplatePage.get().templateResults.isDisplayed())
		{
			log(PASS, "Filter Action Sucessful","Templates are Filtered according to : "+strRowHeader+ "and" +strTypeToBeFiltered+"");				
		}
		else
		{
			log(FAIL, "Filter Action UnSucessful","Templates are not  Filtered according to : "+strRowHeader+ "and" +strTypeToBeFiltered+"");	
		}
		break;
		
	default:
		System.out.println("failed");
	break;
	}
	
	

	
	
}

public void seComparePlan()
{
	for(int i=0;i<=4;i++)
	{
		if(i==1|| i==2||i==3)
		{
			WebElement objClickOnCheckBox = getWebDriver().findElement(By.xpath("((//tbody[@role='alert'])[2]/tr/td[@class='compare-section  '])["+i+"]/input"));
			seClick(objClickOnCheckBox, "Check Box");
		}
		else if (i==4)
		{
			WebElement objClickOnCheckBox = getWebDriver().findElement(By.xpath("((//tbody[@role='alert'])[2]/tr/td[@class='compare-section  '])["+i+"]/input"));
			boolean blnChecked = seIsElementDisabled(objClickOnCheckBox, ""+i+"CheckBox ");
			if(blnChecked == true){log(PASS, "Verified that the user can only select 3  plan in the table to be compared","RESULT=PASS");}
			else{log(FAIL, "Verified that the user can only select 3  plan in the table to be compared","RESULT=FAIL");}
				}
		}
	WebElement objCompareButton = getWebDriver().findElement(By.xpath("//button[@class='btn btn-sm btn-primary trigger-compare']"));
	boolean blnCompareButton = seIsElementDisplayed(objCompareButton, "Compare Button");
	System.out.println(blnCompareButton);
	if (blnCompareButton == true){
		seClick(objCompareButton,"Compare Button to compare seelcted plans");waitForPageLoad(55);
		WebElement objComparison = getWebDriver().findElement(By.xpath("//div[@id='content-compare-plan-find']"));
		boolean blnComparison = seIsElementDisplayed(objComparison, "Compare Plan Page displayed");
		System.out.println(blnComparison);
		if(blnComparison == true){log(PASS, "Verified that The user can select the check box to the left of the any plan in the table and can view  comparison of the selected Plans","RESULT=PASS");}
		else {log(FAIL, "Error Occured No plans are compared","RESULT=FAIL");}}
	else{log(FAIL, "Compare Button Not Present for Comparing","RESULT=FAIL");}
	
}


}	
/*public void seReadExcelFile(String strFilename){
	InputStream XlsxFileToRead = null;
	XSSWorkbook wb=null;
	
	
}
*/
/*public void selectPlanFromResults(String strplanID)
                {
                                waitForPageLoad();
                                seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(planSearchResults));
                                                WebTable tabledetails = new WebTable(planSearchResults, "Plan Search Results");
                                                int rowNum = tabledetails.getRowWithCellTextInColumn(1,3,strplanID);
                                                if(rowNum>0)
                                                {
                                                                getWebDriver().findElement(By.xpath("//table[starts-with(@id,'DataTables_Table']/tbody/tr["+rowNum+"]/td[2]")).click();;
                                                }
                                                else
                                                {
                                                                throw new IllegalArgumentException("Not able to find the value"+ strplanID+"in the table");
                                                }
                }*/
                

