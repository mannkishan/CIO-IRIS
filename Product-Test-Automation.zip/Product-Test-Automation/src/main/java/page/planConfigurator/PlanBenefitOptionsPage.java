package page.planConfigurator;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.constants.BrowserConstants;

import utility.CoreSuperHelper;

public class PlanBenefitOptionsPage extends CoreSuperHelper{

	private static PlanBenefitOptionsPage thisTestObj;	
	public synchronized static PlanBenefitOptionsPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), PlanBenefitOptionsPage.class);
		return thisTestObj;
	}

	@FindBy(how = How.XPATH, using = "//div[@id='verticalBarMenu']/div[2]/ul/li[@id='BenefitOption']/a[contains(text(),'Benefit Options')]")
	@CacheLookup
	public WebElement benefitOptionsTab;

	@FindBy(how = How.XPATH, using = "//div[@id='verticalBarMenuDetails']/div[@class='BenefitOption']/nav/div[2]/ul/li/a")
	@CacheLookup
	public List<WebElement> benefitOptionsValues; 

	@FindBy(how = How.XPATH, using = "//a[@attr-ref='AllergyTesting']")
	@CacheLookup
	public WebElement allergyTesting;
	//
	@FindBy(how = How.XPATH, using = "//div[@id='verticalBarMenuDetails']/div/nav/div[3]/div[@title='Scroll Down']")
	@CacheLookup
	public WebElement scrollBar;

	public WebElement accumMaxValue(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//table/tbody/tr/td/div/span[contains(text(),'"+type+"')]"));
		return valueType;
	}

	@FindBy(how = How.CSS, using = "span[id='POA_BenefitOption-_-Orthodontics-_-OrthoCovered-_-NA-_-NA-_-INNOONOrthoLifetimeMax_-_indivMax']")
	@CacheLookup
	public WebElement lifetimeMaxValue;

	@FindBy(how = How.CSS, using = "span[id='POA_BenefitOption-_-HomeHealthCare-_-CoveredINNOON-_-INNCostShares-_-ServiceDeductible-_-HomeHealthCareSvcDed_-_indivMax']")
	@CacheLookup
	public WebElement serviceDeductible;

	@FindBy(how = How.CSS, using = "span[id='POA_BenefitOption-_-Acupuncture-_-CoveredINNOON-_-Limitations-_-Lmt-_-UnitAcupunctureVstLmt_-_indUnitMax']")
	@CacheLookup
	public WebElement unit;
	
	@FindBy(how = How.XPATH, using = "//div[2]/div[contains(@id,'Limitations')]/div/div/div[2]/table/tbody/tr")
	@CacheLookup
	public List<WebElement> Limit; 
	
	public WebElement Limit(String accumName)
	{	
		WebElement LimitValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div[1]/div/span/span[@class='selection']/span/span"));
		return LimitValue;
	} 
	
	public WebElement selectLimit(String accumName)
	{	
		WebElement LimitValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div[1]/span/span/span[2]/ul/li"));
		return LimitValue;
	} 
	
	public WebElement enterLimit(String accumName)
	{	
		WebElement LimitValue = getWebDriver().findElement(By.xpath(" //span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div[1]/span/span/span[1]/input"));
		return LimitValue;
	} 
	
	public WebElement limitBenefitYear(String accumName)
	{	
		WebElement LimitValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div[2]/div/span/span[@class='selection']/span/span"));
		return LimitValue;
	} 
	
	public WebElement selectBenefitYear(String type,String strValue)
	{
		WebElement planOptionTypeValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+type+"')]/ancestor::tr[1]/td[2]/div[2]/span/span/span[2]/ul/li/span[text()='"+strValue+"']"));
		return planOptionTypeValue;
	}
	
	public WebElement enterlimitBenefitYear(String accumName)
	{	
		WebElement LimitValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div[2]/span/span/span[1]/input"));
		return LimitValue;
	}
	
	public WebElement accumValue(String value)
	{
		WebElement valueType=getWebDriver().findElement(By.xpath("//table/tbody/tr/td/div/span[contains(text(),'"+value+"')]/ancestor::tr[1]/td[2]/div/div/span"));
		return valueType;
	}

	public void verifyBeneiftOptionChangeInPlan(boolean strAddOrRemove, String strBenefitOption, String strPlanID, boolean booFoundPlan )
	{

		if(booFoundPlan)
		{
			boolean found = false;
			waitForPageLoad(300);
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",PlanBenefitOptionsPage.get().benefitOptionsTab);
			waitForPageLoad(300);
			System.out.println();
			for (WebElement element : PlanBenefitOptionsPage.get().benefitOptionsValues) {
				Actions act = new Actions(getWebDriver());
				act.moveToElement(element).build().perform();
				String strOptionValue = element.getText();
				if(strOptionValue.equalsIgnoreCase(strBenefitOption))
				{
					found = true;
					break;
				}
			}
			String strStepName = "Verify Benefit Option Change in the Plan";
			if(strAddOrRemove)
			{
				if(found)
				{
					RESULT_STATUS= true;
					log(PASS, strStepName, "Benefit Option added to the Plan : "+strPlanID);
				}
				else
				{
					RESULT_STATUS= false;
					log(FAIL, strStepName, "Benefit Option not added to the Plan : "+strPlanID);
				}
			}
			else
			{
				if(!found)
				{
					RESULT_STATUS= true;
					log(PASS, strStepName, " Benefit Option removed from the Plan : "+strPlanID);
				}
				else
				{
					RESULT_STATUS= false;
					log(FAIL, strStepName, " Benefit Option not removed from the Plan : "+strPlanID);
				}
			}
		}
		else
		{
			log(FAIL, "Verify Benefit Option change in Plan after Bulk Republish", "Not able to find in the application with version id"+strPlanID, true);
		}
	}

	public boolean verifyLifetimeMaximum(String accumValue,String expectedValue,String dollarMax,int expectedDollarMaxValue,int intMaxTime)
	{
		boolean result=false;
		String actualValue="";
		String actualDollarMax="";
		int actualDollarMaxValue=0;
		try
		{
			WebElement benefitOptions=getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenu']/div[2]/ul/li/a[@title='Benefit Options']"));
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",benefitOptions);
			waitForPageLoad(300);
			Actions actions=new Actions(getWebDriver());
			actions.moveToElement(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).build().perform();			
			actualValue=seGetElementValue(PlanBenefitOptionsPage.get().accumMaxValue(accumValue)).toString().trim();
			if(expectedValue.equalsIgnoreCase(actualValue))
			{
				log(PASS,"Expected Value "+expectedValue +"is equal to actual Value "+actualValue);				
				actualDollarMax=seGetElementValue(PlanBenefitOptionsPage.get().accumValue(accumValue)).replace("$", "").trim();
				if(actualDollarMax.contains(","))
				{
					actualDollarMax=actualDollarMax.replace(",", "");
				}
				actualDollarMaxValue=Integer.parseInt(actualDollarMax);
				result=PlanBenefitOptionsPage.get().acummDollarMaxComparision(dollarMax, expectedDollarMaxValue, actualDollarMaxValue);
			}       	
			else
			{
				log(FAIL,"Expected Value "+expectedValue +"is not equal to actual Value "+actualValue);
			}
		}
		catch(Exception e)
		{
			log(FAIL,"Data is incorrect","Data is incorrect"+e.getLocalizedMessage());
		}
		return result;
	}	

	public boolean verifyServiceDeductible(String accumValue,String expectedValue,String dollarMax,int expectedDollarMaxValue,int intMaxTime)
	{
		boolean result=false;
		String actualValue="";
		String actualDollarMax="";
		int actualDollarMaxValue=0;
		try
		{
			WebElement benefitOptions=getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenu']/div[2]/ul/li/a[@title='Benefit Options']"));
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",benefitOptions);
			waitForPageLoad(2,intMaxTime);
			Actions actions=new Actions(getWebDriver());
			actions.moveToElement(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).build().perform();		
			actualValue=seGetElementValue(PlanBenefitOptionsPage.get().accumMaxValue(accumValue)).toString().trim();
			if(expectedValue.equalsIgnoreCase(actualValue))
			{
				log(PASS,"Expected Value "+expectedValue +"is equal to actual Value "+actualValue);			
				actualDollarMax=seGetElementValue(PlanBenefitOptionsPage.get().accumValue(accumValue)).replace("$", "").trim();
				if(actualDollarMax.contains(","))
				{
					actualDollarMax=actualDollarMax.replace(",", "");
				}
				actualDollarMaxValue=Integer.parseInt(actualDollarMax);
				result=PlanBenefitOptionsPage.get().acummDollarMaxComparision(dollarMax, expectedDollarMaxValue, actualDollarMaxValue);

			}       	
			else
			{
				log(FAIL,"Expected Value "+expectedValue +"is not equal to actual Value "+actualValue);
			}
		}
		catch(Exception e)
		{
			log(FAIL,"Data is incorrect","Data is incorrect"+e.getLocalizedMessage());
		}
		return result;
	}

	public boolean verifyUnit(String accumValue,String expectedValue,String dollarMax,int expectedDollarMaxValue,int intMaxTime)
	{
		boolean result=false;
		String actualValue="";
		String actualDollarMax="";
		int actualDollarMaxValue=0;
		try
		{
			WebElement benefitOptions=getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenu']/div[2]/ul/li/a[@title='Benefit Options']"));
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",benefitOptions);
			waitForPageLoad(2,intMaxTime);
			Actions actions=new Actions(getWebDriver());
			actions.moveToElement(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).build().perform();			
			actualValue=seGetElementValue(PlanBenefitOptionsPage.get().accumMaxValue(accumValue)).toString().trim();
			if(expectedValue.equalsIgnoreCase(actualValue))
			{
				log(PASS,"Expected Value "+expectedValue +"is equal to actual Value "+actualValue);				
				actualDollarMax=seGetElementValue(PlanBenefitOptionsPage.get().accumValue(accumValue)).replace("Visit", "").trim();
				if(actualDollarMax.contains(","))
				{
					actualDollarMax=actualDollarMax.replace(",", "");
				}
				actualDollarMaxValue=Integer.parseInt(actualDollarMax);
				result=PlanBenefitOptionsPage.get().acummDollarMaxComparision(dollarMax, expectedDollarMaxValue, actualDollarMaxValue);
			}       	
			else
			{
				log(FAIL,"Expected Value "+expectedValue +"is not equal to actual Value "+actualValue);
			}
		}
		catch(Exception e)
		{
			log(FAIL,"Data is incorrect","Data is incorrect"+e.getLocalizedMessage());
		}
		return result;
	}	

	public  boolean acummDollarMaxComparision(String maximum,int expectedValue,int actualValue)
	{
		boolean result=false;
		try{
			switch (maximum) {
			case "=":
				if(expectedValue==actualValue)
				{
					log(PASS,"Expected Value is equal to actual Value "+expectedValue+"is equal to "+actualValue);
					result=true;
				}
				else
				{
					log(FAIL,"Expected Value is not equal to actual Value "+expectedValue+"is not equal to "+actualValue);
					result=false;
				}
				break;
			case ">":
				if(actualValue>expectedValue)
				{
					log(PASS,"Actual Value is greater than expected Value "+actualValue+"is > "+expectedValue);
					result=true;
				}
				else
				{
					log(FAIL,"Actual Value is not greater than expected Value"+actualValue+"is > "+expectedValue);
					result=false;
				}
				break;
			case "<":
				if(actualValue<expectedValue)
				{
					log(PASS,"Actual Value is less than expected Value"+actualValue+"is < "+expectedValue);
					result=true;
				}
				else
				{
					log(FAIL,"Actual Value is not less than expected Value"+actualValue+"is < "+expectedValue);
					result=false;
				}
				break;
			case ">=":
				if(actualValue>=expectedValue)
				{
					log(PASS,"Actual Value is greater than equal to expected Value"+actualValue+"is >= "+expectedValue);
					result=true;
				}
				else
				{
					log(FAIL,"Actual Value is not greater than equal expected Value"+actualValue+"is < "+expectedValue);
					result=false;
				}
				break;	
			case "<=":
				if(actualValue<=expectedValue)
				{
					log(PASS,"Actual Value is less than equal to expected Value"+actualValue+"is <= "+expectedValue);
					result=true;
				}
				else
				{
					log(FAIL,"Actual Value is not less than equal expected Value"+actualValue+"is < "+expectedValue);
					result=false;
				}
				break;
			default:
				break;	

			}
		}
		catch(Exception e)
		{
			log(ERROR,"Invalid maximum value","Invalid maximum value "+e.getLocalizedMessage());
		}
		return result;

	}
	
	public static ArrayList<String> getOptionsText_SpiderUI(String strBaseURL,String struserProfile,String strTestRegion,String strVersionID,String strOptionsTab) throws Exception
	{
		ArrayList<String> options = new ArrayList<String>();
		String optionsTypeText="";
		try
		{
			seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
			LoginPage.get().loginApplication(struserProfile);
			waitForPageLoad(2,360);
			FindPlanPage.get().findPlan(strVersionID);
			waitForPageLoad(2,360);
			PlanOptionsPage.get().clickAtObject(PlanOptionsPage.get().optionsTab(strOptionsTab));
			waitForPageLoad(2,360);
			List<WebElement> optionsType=getWebDriver().findElements(By.xpath("//div[@id='verticalBarMenuDetails']/div/nav/div[2]/ul/li/a[normalize-space()]"));
			for(int i=0;i<optionsType.size();i++){
				optionsTypeText=optionsType.get(i).getText().toString().trim();
				System.out.println(optionsTypeText);
				if(optionsTypeText.equals("") || optionsTypeText.isEmpty())
				{
					for(int j=0;j<=5;j++){
					seClick(PlanBenefitOptionsPage.get().scrollBar,"Scroll Bar");
					waitForPageLoad(2,360);
					}
					optionsTypeText=optionsType.get(i).getText().toString().trim();
					System.out.println(optionsTypeText);
				}
				options.add(optionsTypeText);
			}				
			seCloseBrowser();
		}
		catch(Exception e)
		{
			throw e;
		}

		return options;
	}

}
