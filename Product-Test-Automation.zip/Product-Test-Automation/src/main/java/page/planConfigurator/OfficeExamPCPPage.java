package page.planConfigurator;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class OfficeExamPCPPage  extends CoreSuperHelper{
	private static OfficeExamPCPPage thisIsTestObj;
	public  synchronized static OfficeExamPCPPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), OfficeExamPCPPage.class);
		return thisIsTestObj;
		}
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"verticalBarMenuDetails\"]/div/nav/div[2]/ul/li[1]/a")
	@CacheLookup
	public WebElement officeExamPCP;
	
		
	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExamsPCP-_-CoveredINNOON-_-NA-_-NA-_-PREFApplies_-_choice-container\"]")
	@CacheLookup
	public WebElement officeExamPCPPrefApply;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExamsPCP-_-CoveredINNOON-_-NA\"]/div/div/table/tbody/tr/td[2]/div/span/span/span[1]/input")
	@CacheLookup
	public WebElement officeExamPCPPrefApplySearchBar;	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExamsPCP-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-CopayINNT1PCP\"]")
	@CacheLookup
	public WebElement officeExamPCPName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExamsPCP-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares\"]")
	@CacheLookup
	public WebElement officeExamBenefitSpecificCostShares;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExamsPCP-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-ApplyDed_-_choice-container\"]")
	@CacheLookup
	public WebElement officeExamApplyDeductible;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[1]/td[2]/div/span/span/span[1]/input")
	@CacheLookup
	public WebElement officeExamApplyDeductibleSearchBar;
		
	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExamsPCP-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-CopayINNT1PCP_-_amount-container\"]")
	@CacheLookup
	public WebElement officeExamINNCostSharesAmount;
	

	@FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[2]/td[2]/div[2]/span/span/span[1]/input")
	@CacheLookup
	public WebElement officeExamINNCostSharesAmountSearchBar;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExamsPCP-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-UnitINNT1ExamVstLmt_-_indUnitMax-container\"]")
	@CacheLookup
	public WebElement officeExamINNExamVisitCopayLimit;

	@FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[3]/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement officeExamINNExamVisitCopayLimitSearchBar;	
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-OfficeExamsPCP-_-CoveredINNOON-_-CostSharesOON-_-BenefitSpecificCostShares\"]")
	@CacheLookup
	public WebElement officeExamOONCostSharesBenefitSpecificCostShares;
	
	
		
	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExamsPCP-_-CoveredINNOON-_-CostSharesOON-_-BenefitSpecificCostShares-_-EmergencyDiagnosisPaidAtINNLevelOfficePCP_-_choice-container\"]")
	@CacheLookup
	public WebElement officeExamOONCostSharesApplyDeductible;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse4\"]/table/tbody/tr[1]/td[2]/div/span/span/span[1]/input")
	@CacheLookup
	public WebElement officeExamOONCostSharesApplyDeductibleSearchBar;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExamsPCP-_-CoveredINNOON-_-CostSharesOON-_-BenefitSpecificCostShares-_-CopayOONExamVst_-_amount-container\"]")
	@CacheLookup
	public WebElement officeExamOONCostSharesOutOfNetworkExamVisitCopay;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse4\"]/table/tbody/tr[3]/td[2]/div[2]/span/span/span[1]/input")
	@CacheLookup
	public WebElement officeExamOONCostSharesOutOfNetworkExamVisitCopaySearchBar;
	

	
	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExamsPCP-_-CoveredINNOON-_-CostSharesOON-_-BenefitSpecificCostShares-_-ApplyDed_-_choice-container\"]")
	@CacheLookup
	public WebElement officeExamOONCostSharesApplyDed;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse4\"]/table/tbody/tr[3]/td[2]/div/span/span/span[1]/input")
	@CacheLookup
	public WebElement officeExamOONCostSharesApplyDedSearchBar;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExamsPCP-_-CoveredINNOON-_-CostSharesOON-_-BenefitSpecificCostShares-_-CoinOONExam_-_percentage-container\"]")
	@CacheLookup
	public WebElement officeExamOONExamCoin;
	
		
	@FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse4\"]/table/tbody/tr[4]/td[2]/div/span/span/span[1]/input")
	@CacheLookup
	public WebElement officeExamOONExamCoinSearchBar;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-OfficeExamsPCP-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-CopayINNT1PCP_-_choice-container\"]")
	@CacheLookup
	public WebElement officeExamPCPINNCostShares;
	
}