package page.planConfigurator;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.groupConfigurator.LoginPage;
import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.BenefitsPage;
import page.planConfigurator.CreatePlanLegacyHeaderPage;
import page.planConfigurator.CreatePlanExcelPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;

import page.groupConfigurator.LoginPage;

/**
 * @author AF47903
 *
 */

public class VisibilityChangeabilityPage extends CoreSuperHelper {

	private static VisibilityChangeabilityPage thisTestObj;

	public synchronized static VisibilityChangeabilityPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), VisibilityChangeabilityPage.class);
		return thisTestObj;
	} 
    public void seChangeabilityCheck(){
    	try{
    		//click on plan setup tab>> Pediatric Vision
			WebElement objPlansetup = getWebDriver().findElement(By.xpath("//a[contains(text(),'Plan Setup')]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			seClick(objPlansetup, "Option Tab :  Plan Setup");waitForPageLoad();
			WebElement objPlansetupBenefit = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Vision')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
			seClick(objPlansetupBenefit, "Option Tab :  Plan Setup");waitForPageLoad();
			//check In Network Pediatric Vision Coinsurance is not editable
			WebElement objPlansetupChangeable = getWebDriver().findElement(By.xpath("//h4[contains(text(),'Pediatric Vision')]/following::span[contains(text(),'Covered Exam And Hardware')][1]/following::span[contains(text(),'In Network Pediatric Vision Coinsurance')]/following::td/div/div[2]/span[text()='100%']"));
			objPlansetupChangeable.click();waitForPageLoad();
			try{objPlansetupChangeable.sendKeys("75");}catch(Exception e){System.out.println("Not editable");log(PASS, "Verified that 'In Network Pediatric Vision Coinsurance' Field is not Editable as Changeability check box has been unchecked while template creation ","RESULT=PASS");}
			
			//click on plan Level benefits>> Pediatric Deductible
			WebElement objPlanLevelBenefits = getWebDriver().findElement(By.xpath("//a[contains(text(),'Plan Level Benefits')]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			seClick(objPlanLevelBenefits, "Option Tab :  Plan Setup");waitForPageLoad();
			WebElement objPlanLevelBenefitsBenefit = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Deductible')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
			seClick(objPlanLevelBenefitsBenefit, "Option Tab :  Plan Setup");waitForPageLoad();
			//check In Network Pediatric Comingled With Medical Deductible is not editable
			WebElement objPlanLevelBenefitsChangeable = getWebDriver().findElement(By.xpath("//h4[contains(text(),'Pediatric Deductible')]/following::span[contains(text(),'Comingled With Medical')]/following::td/div/div/span[text()='Yes']"));
			objPlanLevelBenefitsChangeable.click();waitForPageLoad();
			try{objPlanLevelBenefitsChangeable.sendKeys("No");}catch(Exception e){System.out.println("Not editable");log(PASS, "Verified that 'In Network Pediatric Comingled With Medical Deductible' Field is not Editable as Changeability check box has been unchecked while template creation ","RESULT=PASS");}
			
			waitForPageLoad();seClick(BenefitsPage.get().firstScroll, "Scroll down");
			//click on plan Benefit Options>> In Network Pediatric Routine Eye Exam Coinsurance
			WebElement objBenefitOptions = getWebDriver().findElement(By.xpath("//*[@id='BenefitOption']/a"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objBenefitOptions);;waitForPageLoad();
			WebElement objBenefit = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Routine Eye Exam')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
			seClick(objBenefit, "Option Tab :  Plan Setup");waitForPageLoad();
			//check In Network Pediatric Comingled With Medical Deductible is not editable
			WebElement objBenefitsChangeable = getWebDriver().findElement(By.xpath("//h4[contains(text(),'Pediatric Routine Eye Exam')]/following::span[contains(text(),'Covered In Network & Out of Network')][1]/following::span[contains(text(),'In Network Pediatric Routine Eye Exam Coinsurance')]/following::td/div/div[2]/span[text()='55%']"));
			objBenefitsChangeable.click();waitForPageLoad();
			try{objPlanLevelBenefitsChangeable.sendKeys("85");}catch(Exception e){System.out.println("Not editable");log(PASS, "Verified that 'In Network Pediatric Routine Eye Exam Coinsurance' Field is not Editable as Changeability check box has been unchecked while template creation ","RESULT=PASS");}
			
    	}catch (Exception e){log(FAIL, "Exception while executing seChangeabilityCheck() mtd");}
    }

    
    
	public void seMoveToProductionTemplate(){
	String strBaseURL = EnvHelper.getValue("pc.url");
	String strUserProfile = EnvHelper.getValue("user.profile");
	String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	try{waitForPageLoad();
seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//a[text()='Request Audit']")), 5);
seClick(getWebDriver().findElement(By.xpath("//a[text()='Request Audit']")), "request audit");
waitForPageLoad();
seClick(getWebDriver().findElement(By.xpath("//label[text()='Reason Code']/following::span[text()='- Please Select -'][1]")), "reason code");
seSetText(getWebDriver().findElement(By.xpath("//label[text()='Reason Code']/following::span[text()='- Please Select -'][1]/following::input[@role='textbox'][1]")), "Other", "reason code");
seClick(getWebDriver().findElement(By.xpath("//label[text()='Reason Code']/following::span[text()='- Please Select -'][1]/following::input[@role='textbox'][1]/following::span[@class='select2-match' and text()='Other']")), "Other");
seSetText(getWebDriver().findElement(By.xpath("//label[text()='Comment']/../div/textarea")), "test", "comment");
seClick(getWebDriver().findElement(By.xpath("//button[@class='workflowAction btn btn-primary pull-right']")), "request audit button");
waitForPageLoad(45);				
try{
	seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 180);}				
catch(Exception e){
seClick(PlanHeaderPage.get().close, "Close button");}

/*
		seClick(PlanHeaderPage.get().userLogout, "Close button");
seClick(PlanHeaderPage.get().close, "Close button");*/
waitForPageLoad(45);	
seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
waitForPageLoad();				
seClick(PlanHeaderPage.get().userLogout, "Logout");
waitForPageLoad();
seCloseBrowser();//waitForPageLoad(20);
seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
waitForPageLoad(20);
LoginPage.get().loginApplication(strUserProfileApprover);
waitForPageLoad();
seClick(HomePage.get().find, "Find");
seClick(HomePage.get().findTemplate, "Find template");
waitForPageLoad();
String strPlanID = getCellValue("NewTemplateID");
//String strPlanID = "1340040407";
waitForPageLoad();
seClick(FindTemplatePage.get().templateVersionID, "template ID textbox");
seSetText(page.planConfigurator.FindTemplatePage.get().templateVersionID, strPlanID,"in plan version id textbox");				
seClick(page.planConfigurator.FindTemplatePage.get().templateSearch, "Search template");
waitForPageLoad();

((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);
waitForPageLoad(45);
seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 2);
Boolean status= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
 
 if(status==true)
	{
		log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");												
	}
	else
	{
		log(FAIL, "plan takes more time to load","plan is still in 'process in progress' status,RESULT=FAIL");												
	}
waitForPageLoad();
seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 5);
((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanHeaderPage.get().approveAudit);
waitForPageLoad(185);
seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "reason code");
seClick(PlanTransitionPage.get().approved, "approved");
seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
waitForPageLoad(45);
seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//a[text()='Finalize']")), 6);
seClick(getWebDriver().findElement(By.xpath("//a[text()='Finalize']")), "finalize");
waitForPageLoad();
seClick(PlanTransitionPage.get().finalizeButtoninPT, "finalize");
waitForPageLoad(45);
seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//a[text()='Move to Production']")), 6);
seClick(getWebDriver().findElement(By.xpath("//a[text()='Move to Production']")), "move to production");
waitForPageLoad();

seClick(getWebDriver().findElement(By.xpath("//button[@class='workflowAction btn btn-primary pull-right']")),"move to production");
waitForPageLoad();


}catch (Exception e) {
	log(ERROR, "Error while executing  method.seMoveToProductionTemplate");
}
}

    
	public  void createPlan(boolean isMasterPlan,int maxWaitTime) throws Exception
	{
		boolean blnIsMasterPlan = true;
		int intMaxWaitTime = 45;
		String strEffectiveDate = getCellValue("MP_EffectiveDate");
		String strProductModel = "";
		if (blnIsMasterPlan) {
			strProductModel = "Master Product";
		}
		String strTemplateVersionID = getCellValue("NewTemplateID");
		String strApprovalStatus = getCellValue("MP_ApprovalStatus");
		String strCustomizationLevel = getCellValue("MP_CustomizationLevel");
		String strState = getCellValue("MP_State");
		String strMarketSegment = getCellValue("MP_MarketSegment");
		String strMarketUnit = getCellValue("MP_MarketUnit");
		String strProductFamily = getCellValue("MP_ProductFamily");
		String strProductName = getCellValue("MP_ProductName");
		String strCDHPType = getCellValue("MP_CDHP");
		String strBenefitPeriod = getCellValue("MP_BenefitPeriod");
		String strFundingArrangement = getCellValue("MP_FundingArrangement");
		String strBusinessUnit = getCellValue("MP_BusinessUnit");
		String strLineOfBusiness = getCellValue("MP_LOB");

		waitForPageLoad(intMaxWaitTime);
		seClick(HomePage.get().create, "Create");
		seClick(HomePage.get().plan, "Plan");
		waitForPageLoad(4, intMaxWaitTime);
		seSetText(CreatePlanPage.get().enterEffectiveDate, strEffectiveDate, "Effective date");waitForPageLoad();
		CreatePlanPage.get().enterEffectiveDate.sendKeys(Keys.TAB);
		waitForPageLoad(intMaxWaitTime);
		seSelectText(CreatePlanPage.get().selectProductModelData, strProductModel, "Product Model",
				intMaxWaitTime);
		seSelectText(CreatePlanPage.get().customizationLevel, strCustomizationLevel, "Customization Level",
				intMaxWaitTime);
		seSelectText(CreatePlanPage.get().state, strState, "State", intMaxWaitTime);
		seSelectText(CreatePlanPage.get().marketSegment, strMarketSegment, "Market Segment", intMaxWaitTime);
		seSelectText(CreatePlanPage.get().marketUnit, strMarketUnit, "Market Unit", intMaxWaitTime);
		seSelectText(CreatePlanPage.get().lob, strLineOfBusiness, "Line of Business", intMaxWaitTime);
		seSelectText(CreatePlanPage.get().productName, strProductName, "Product Name", intMaxWaitTime);
		seSelectText(CreatePlanPage.get().productFamily, strProductFamily, "Product Family", intMaxWaitTime);
		seSelectText(CreatePlanPage.get().cdhType, strCDHPType, "Consumer Driven Health Plan", intMaxWaitTime);
		seSelectText(CreatePlanPage.get().benefitPeriod, strBenefitPeriod, "Benefit Period", intMaxWaitTime);
		seSelectText(CreatePlanPage.get().fundingArrangement, strFundingArrangement, "Funding Arrangement",
				intMaxWaitTime);
		seSelectText(CreatePlanPage.get().businessUnit, strBusinessUnit, "Business Unit", intMaxWaitTime);
		if (blnIsMasterPlan) {
			seClick(CreatePlanPage.get().selectTemplate, "Select Template");
			waitForPageLoad(4, intMaxWaitTime);
			seSwitchFrame(FindTemplatePage.get().findTemplateFrame);
			seWaitForClickableWebElement(FindTemplatePage.get().searchCriteria, 60);
			seClick(FindTemplatePage.get().searchCriteria, "Search Criteria");
			seWaitForClickableWebElement(FindTemplatePage.get().versionId, 120);
			seSetText(FindTemplatePage.get().versionId, strTemplateVersionID, "Template Version ID");
			seClick(FindTemplatePage.get().searchButton, "Search Criteria");
			waitForPageLoad(intMaxWaitTime);
			FindTemplatePage.get().selectTemplate(strTemplateVersionID);
		}
		waitForPageLoad(intMaxWaitTime);
		getWebDriver().switchTo().defaultContent();
		waitForPageLoad(intMaxWaitTime);
		seClick(CreatePlanPage.get().createPlan, "Create Plan");
		waitForPageLoad(5, intMaxWaitTime);
		waitForPageLoad(5, intMaxWaitTime);
		String planVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];					
		waitForPageLoad(5, intMaxWaitTime);
		String planProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
		setCellValue("MasterProductPlanID", planVersionID);
		setCellValue("MP_PlanProxyID", planProxyID);
		seClick(PlanHeaderPage.get().save, "Save button");
		waitForPageLoad(45);
	}   
    
  
	public void seRecheckVisibility() throws Exception{
		String strBaseURL = EnvHelper.getValue("pc.url");
		String strUserProfile = EnvHelper.getValue("user.profile");
		
		seOpenBrowser(BrowserConstants.Chrome, strBaseURL, "testscripts");
		LoginPage.get().loginApplication(strUserProfile);
		waitForPageLoad(65);
		seWaitForElementLoad(CreatePlanPage.get().homepage);
	
		
		//FIND TEMPLATE
		//search for the template trTemplateVersionIDold
		String strTemplateVersionID = getCellValue("TemplateVersionID");
		String strTemplateName = getCellValue("NewTemp_Name");
		seClick(HomePage.get().find, "Find");waitForPageLoad();
		seClick(HomePage.get().findTemplate, "Find Template");waitForPageLoad();
		seSetText(PlanTransitionPage.get().inputTemplate,strTemplateVersionID, "Enter Plan ID");waitForPageLoad();									
		seWaitForClickableWebElement(FindPlanPage.get().planSearch, 30);waitForPageLoad();
		seClick(FindPlanPage.get().planSearch, "Search Plan");waitForPageLoad();
		System.out.println("searched need to click");
		seWaitForClickableWebElement(PlanHeaderPage.get().searchTemplates, 10);waitForPageLoad();
		//seClick(PlanHeaderPage.get().searchTemplate, "Search");
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",PlanHeaderPage.get().searchTemplates);
		System.out.println("click sucess");
		waitForPageLoad(30,10);
  
		//copy template 
		WebElement objCopy = getWebDriver().findElement(By.xpath("//*[@id='actionsBar']/li[2]/a[text()='Copy']"));
		seClick(objCopy, "Copy Button");waitForPageLoad();
		
		//create new template NewTemplateID 
	
		WebElement objTemplatename = getWebDriver().findElement(By.xpath("//*[@id='planName']/div/div/textarea[@data-name='Template Name']"));
		seSetText(objTemplatename,strTemplateName, "Enter Unique template name");waitForPageLoad();	
		//*[@id='content-create-customPlan']/form/div[2]/div[6]/div/button[2]
		WebElement objCreate = getWebDriver().findElement(By.xpath("//*[@id='content-create-customPlan']/form/div[2]/div[6]/div/button[2]"));
		seClick(objCreate, "Create Button");waitForPageLoad(30);
		
		String strTemplateVersionIDold = seGetElementValue(PlanHeaderPage.get().templateVersion).split(":")[1];
        waitForPageLoad();
        setCellValue("NewTemplateID", strTemplateVersionIDold); waitForPageLoad();
		
		//recheck Visibility at POT level
 
		WebElement objPlansetup = getWebDriver().findElement(By.xpath("//a[contains(text(),'Plan Setup')]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
		seClick(objPlansetup, "Option Tab :  Plan Setup");waitForPageLoad();
		WebElement objPediatricVisionBenefits = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Vision')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
		seClick(objPediatricVisionBenefits, "Option Tab :  Plan Setup");waitForPageLoad();
		WebElement objPediatricVisionVisibles = getWebDriver().findElement(By.xpath("(//h4[contains(text(),'Pediatric Vision')]/following::span[@class='groupTemplateConfig']/div/span/input)[1]"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objPediatricVisionVisibles);waitForPageLoad();
		
		
		//verifing if visible checkboxes are still checked in the Template for associated (child) 
		WebElement objPediatricChangeable = getWebDriver().findElement(By.xpath("(//h4[contains(text(),'Pediatric Vision')]/following::span[text()='Covered Exam And Hardware']/following::span/div/span/input)[1]"));
		waitForPageLoad();boolean blnPediatricChangeable = seIsElementSelected(objPediatricChangeable, "Covered Exam And Hardware");waitForPageLoad();
		WebElement objPediatricVisible= getWebDriver().findElement(By.xpath("//h4[contains(text(),'Pediatric Vision')]/following::span[contains(text(),'Covered Exam And Hardware')][1]/following::span[contains(text(),'In Network Pediatric Vision Coinsurance')]/following::td/div/span/div/span/input[@class='visible']"));
		waitForPageLoad();boolean blnPediatricVisible = seIsElementSelected(objPediatricVisible, "In Network Pediatric Vision Coinsurance");waitForPageLoad();
		System.out.println(blnPediatricChangeable);waitForPageLoad();
		System.out.println(blnPediatricVisible);
		if (blnPediatricChangeable == true && blnPediatricVisible == true ){log(PASS, "Verified that, visible checkboxes are still checked in the Template for associated child accumulators","RESULT=PASS");}
		else{log(FAIL, "visible checkboxes  Behaviour not as expected","RESULT=FAIL");}

		waitForPageLoad();
		
		//click on plan Level benefits>> Adult Plan Lifetime Maximum
		WebElement objPlanLevelBenefits = getWebDriver().findElement(By.xpath("//a[contains(text(),'Plan Level Benefits')]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
		seClick(objPlanLevelBenefits, "Option Tab :  Plan Setup");waitForPageLoad();
		WebElement objPlanLevelBenefitsBenefit = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Adult Plan Lifetime Maximum')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
		seClick(objPlanLevelBenefitsBenefit, "Option Tab :  Plan Setup");waitForPageLoad();
		
		seClick(getWebDriver().findElement(By.xpath("(//h4[text()='Adult Plan Lifetime Maximum']/following::h4/span[text()='Plan Lifetime Maximum']/following::span[contains(text(),'In Network Vision Adult Lifetime Maximum Dollar Limit')]/following::td/div/div[2]/span/span/span/span)[1]")),"In Network Vision Adult Lifetime Maximum Dollar Limit");
      	waitForPageLoad();
      	seSetText(getWebDriver().findElement(By.xpath("//*[@id='POA_Base-_-PlanLifetimeMaxAdult-_-PlanLifetimeMax-_-NA']/div/div/table/tbody/tr[1]/td[2]/div[1]/span[2]/span/span[1]/input")),"85","setting text value for First Accumulator");
        waitForPageLoad();
        seClick(getWebDriver().findElement(By.xpath("//*[@id='POA_Base-_-PlanLifetimeMaxAdult-_-PlanLifetimeMax-_-NA']/div/div/table/tbody/tr[1]/td[2]/div[1]/span[2]/span/span[2]")), "Select the value from drop down");
        waitForPageLoad();
		
		
	
		
		
		seClick(PlanHeaderPage.get().save, "Save button");
		waitForPageLoad(45);
		//moving template to production
		VisibilityChangeabilityPage.get().seMoveToProductionTemplate();waitForPageLoad();
		System.out.println("Template moved to production");
		waitForPageLoad(45);
		seCloseBrowser();
		seOpenBrowser(BrowserConstants.Chrome, strBaseURL, "testscripts");
		LoginPage.get().loginApplication(strUserProfile);
		waitForPageLoad(65);
		seWaitForElementLoad(CreatePlanPage.get().homepage);
		//create plan
		VisibilityChangeabilityPage.get().createPlan(true,50);waitForPageLoad(45);
		
		try{
			 WebElement objPOTLevel = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Vision')])[1]/preceding::li[1]/following::li/a[1])[1]"));
			 ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objPOTLevel);waitForPageLoad();
			 WebElement objPOTLevelVisibility = getWebDriver().findElement(By.xpath("//h4[text()='Plan Type']"));
			 boolean blnPOTLevel = seIsElementDisplayed(objPOTLevelVisibility, "POT Level Element visibility Check in Plan");
			 if(blnPOTLevel == true){log(PASS, "Verified that after visible checkbox is rechecked at the Plan Option Type level in template, is also visible in the plan","RESULT=PASS");}
			 else {	log(FAIL, "Although the visibility checkbox is rechecked at Plan Option Type level, is still not visible in the plan","RESULT=FAIL");}
			 waitForPageLoad();} catch (Exception e){
			 log(FAIL, "Exception Occured while checking the visibility at Plan Option Type Level","RESULT=FAIL");}
			

		//Moving plan to production
		waitForPageLoad(35);
		
		seClick(PlanHeaderPage.get().save, "Save button");waitForPageLoad(15);
		VisibilityChangeabilityPage.get().seMoveMPlanToProduction();
		
		
	}
	
	
	public void seUncheckVisibility(){
		try{
			String strBaseURL = EnvHelper.getValue("pc.url");
			String strUserProfile = EnvHelper.getValue("user.profile");
			waitForPageLoad();
			//Limit>>PlanSetup>>Pediatric Vision>>Pediatric Vision Max Age Limit
			WebElement objPlansetup = getWebDriver().findElement(By.xpath("//a[contains(text(),'Plan Setup')]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			seClick(objPlansetup, "Option Tab :  Plan Setup");waitForPageLoad();
			
			WebElement objPlansetupBenefit = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Vision')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
			seClick(objPlansetupBenefit, "Option Tab :  Plan Setup");waitForPageLoad();
			
			WebElement objPlansetupVisible = getWebDriver().findElement(By.xpath("//h4[contains(text(),'Pediatric Vision')]/following::span[contains(text(),'Covered Exam And Hardware')][1]/following::span[contains(text(),'Pediatric Vision Maximum Age Limit')]/following::td/div/span/div/span/input[@class='visible']"));
			waitForPageLoad();seClick(objPlansetupVisible, "Option Tab :  Plan Setup");waitForPageLoad();
			
			//**********************For LIMIT******************************************
			WebElement objPlansetupChangeable = getWebDriver().findElement(By.xpath("//h4[contains(text(),'Pediatric Vision')]/following::span[contains(text(),'Covered Exam And Hardware')][1]/following::span[contains(text(),'Pediatric Vision Maximum Age Limit')]/following::td/div/span/div/span[2]/input[@class='changeable']"));
			waitForPageLoad(25);boolean blnChangeable = seIsElementNotSelected(objPlansetupChangeable, "Pediatric Vision Maximum Age Limit Changeablity Check Box");waitForPageLoad();
			System.out.println(blnChangeable);waitForPageLoad();
			if (blnChangeable == true){log(PASS, "Verified that, limit that are not visible in the Template, is also not changeable","RESULT=PASS");}
			else{log(FAIL, "The limit that are not visible in the Template, is Changeable. Behaviour not as expected","RESULT=FAIL");}

			
			//Accumulator>>Plan Setup>>Pediatric Vision>>INNPediatric Vision Coinsurance
			WebElement objPediatricCoinsuranceVisible = getWebDriver().findElement(By.xpath("//h4[contains(text(),'Pediatric Vision')]/following::span[contains(text(),'Covered Exam And Hardware')][1]/following::span[contains(text(),'In Network Pediatric Vision Coinsurance')]/following::td/div/span/div/span/input[@class='visible']"));
			waitForPageLoad();seClick(objPediatricCoinsuranceVisible, "Option Tab :  Plan Setup");waitForPageLoad();
			
			//**********************For Accumulator******************************************
			WebElement objPediatricCoinsuranceChangeable = getWebDriver().findElement(By.xpath("//h4[contains(text(),'Pediatric Vision')]/following::span[contains(text(),'Covered Exam And Hardware')][1]/following::span[contains(text(),'In Network Pediatric Vision Coinsurance')]/following::td/div/span/div/span[2]/input[@class='changeable']"));
			waitForPageLoad(25);boolean blnPediatricCoinsuranceChangeable = seIsElementNotSelected(objPediatricCoinsuranceChangeable, "Pediatric Vision Maximum Age Limit Changeablity Check Box");waitForPageLoad();
			System.out.println(blnPediatricCoinsuranceChangeable);waitForPageLoad();
			if (blnPediatricCoinsuranceChangeable == true){log(PASS, "Verified that, Accumulator that are not visible in the Template, is also not changeable","RESULT=PASS");}
			else{log(FAIL, "The limit that are not visible in the Template, is Changeable. Behaviour not as expected","RESULT=FAIL");}

			
			//Plan Option Type>>Plan Setup>>Adult Vision>>Covered exam and hardware
			WebElement objAdultVisionBenefit = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Adult Vision')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
			seClick(objAdultVisionBenefit, "Option Tab :  Plan Setup");waitForPageLoad();
			
			WebElement objAdultVisionVisible = getWebDriver().findElement(By.xpath("(//h4[contains(text(),'Pediatric Vision')]/following::span[contains(text(),'Covered Exam And Hardware')][2]/following::span[@class='groupTemplateConfig'][1]/div/span/input)[1]"));
			waitForPageLoad();seClick(objAdultVisionVisible, "Option Tab :  Plan Setup");waitForPageLoad();
			
			//**********************For Plan Option type******************************************
			WebElement objAdultVisionChangeable = getWebDriver().findElement(By.xpath("(//h4[contains(text(),'Pediatric Vision')]/following::span[contains(text(),'Covered Exam And Hardware')][2]/following::span[@class='groupTemplateConfig'][1]/div/span[2]/input)[1]"));
			waitForPageLoad(25);boolean blnAdultVisionChangeable = seIsElementNotSelected(objAdultVisionChangeable, "Pediatric Vision Maximum Age Limit Changeablity Check Box");waitForPageLoad();
			System.out.println(blnAdultVisionChangeable);waitForPageLoad();
			if (blnAdultVisionChangeable == true){log(PASS, "Verified that, Plan Option type that are not visible in the Template, is also not changeable","RESULT=PASS");}
			else{log(FAIL, "The limit that are not visible in the Template, is Changeable. Behaviour not as expected","RESULT=FAIL");}

			
			//Accumulator group >> Plan level benefits>>Pediatric Deductible>>Deductible In Network
			
			WebElement objPlanLevelBenefits = getWebDriver().findElement(By.xpath("//a[contains(text(),'Plan Level Benefits')]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			seClick(objPlanLevelBenefits, "Option Tab :  Plan Setup");waitForPageLoad();
			
			WebElement objPlanLevelBenefitsBenefit = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Deductible')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
			seClick(objPlanLevelBenefitsBenefit, "Option Tab :  Plan Setup");waitForPageLoad();
			
			WebElement objInNetwork = getWebDriver().findElement(By.xpath("//*[@id='POA_Base-_-DeductiblePed-_-Deductible-_-INN']/h4/span/div/span[1]/input"));
			waitForPageLoad();seClick(objInNetwork, "Option Tab :  Plan Setup");waitForPageLoad();
			
			//**********************For Accumulator Group******************************************
			WebElement objInNetworkChangeable = getWebDriver().findElement(By.xpath("//*[@id='POA_Base-_-DeductiblePed-_-Deductible-_-INN']/h4/span/div/span[2]/input"));
			waitForPageLoad(25);boolean blnInNetworkChangeable = seIsElementNotSelected(objInNetworkChangeable, "Pediatric Vision Maximum Age Limit Changeablity Check Box");waitForPageLoad();
			System.out.println(blnInNetworkChangeable);waitForPageLoad();
			if (blnInNetworkChangeable == true){log(PASS, "Verified that, Accumulator Group that are not visible in the Template, is also not changeable","RESULT=PASS");}
			else{log(FAIL, "The limit that are not visible in the Template, is Changeable. Behaviour not as expected","RESULT=FAIL");}

			
			
			//Plan Option Type>>Plan level benefits>>Pediatric Out of Pocket Maximum>>Out of Pocket Maximum
			WebElement objAdultVisionBenefits = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Out of Pocket Maximum')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
			seClick(objAdultVisionBenefits, "Option Tab :  Plan Setup");waitForPageLoad();
			
			WebElement objAdultVisionVisibles = getWebDriver().findElement(By.xpath("(//h4[contains(text(),'Pediatric Out of Pocket Maximum')]/following::span[contains(text(),'Out of Pocket Maximum')][1]/following::span/div/span/input)[1]"));
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objAdultVisionVisibles);waitForPageLoad();
			
			//**********************For Plan Option Type******************************************
			WebElement objPediatricChangeable = getWebDriver().findElement(By.xpath("(//h4[contains(text(),'Pediatric Out of Pocket Maximum')]/following::span[contains(text(),'Out of Pocket Maximum')][1]/following::span/div/span[2]/input)[1]"));
			waitForPageLoad(25);boolean blnPediatricChangeable = seIsElementNotSelected(objPediatricChangeable, "Pediatric Vision Maximum Age Limit Changeablity Check Box");waitForPageLoad();
			System.out.println(blnPediatricChangeable);waitForPageLoad();
			if (blnPediatricChangeable == true){log(PASS, "Verified that, Plan Option Type that are not visible in the Template, is also not changeable","RESULT=PASS");}
			else{log(FAIL, "The limit that are not visible in the Template, is Changeable. Behaviour not as expected","RESULT=FAIL");}

			
			
			//PlanOptionName >> Benefit Option>>Pediatric Factory>>ScrtchCoating
			waitForPageLoad();seClick(BenefitsPage.get().firstScroll, "Scroll down");
			waitForPageLoad();seClick(BenefitsPage.get().firstScroll, "Scroll down");
			
			WebElement objBenefitOptions = getWebDriver().findElement(By.xpath("//a[contains(text(),'Benefit Options')]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objBenefitOptions);waitForPageLoad();
		
			WebElement objScratchCoating = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Factory Scratch Coating')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objScratchCoating);waitForPageLoad();
			
			WebElement objPlanOptionName = getWebDriver().findElement(By.xpath("(//h4[contains(text(),'Pediatric Factory Scratch Coating')]/../following::span)[1]/div/span/input"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objPlanOptionName);waitForPageLoad();
			
			//**********************For PlanOptionName******************************************
			WebElement objPlanOptionNameChangeable = getWebDriver().findElement(By.xpath("(//h4[contains(text(),'Pediatric Factory Scratch Coating')]/../following::span)[1]/div/span[2]/input"));
			waitForPageLoad(25);boolean blnPlanOptionNameChangeable = seIsElementNotSelected(objPlanOptionNameChangeable, "Pediatric Vision Maximum Age Limit Changeablity Check Box");waitForPageLoad();
			System.out.println(blnPlanOptionNameChangeable);waitForPageLoad();
			if (blnPlanOptionNameChangeable == true){log(PASS, "Verified that, Plan Option Type that are not visible in the Template, is also not changeable","RESULT=PASS");}
			else{log(FAIL, "The limit that are not visible in the Template, is Changeable. Behaviour not as expected","RESULT=FAIL");}

			
			
			//benefit in Network>Eyeglass Frames tier1
			
			waitForPageLoad();seClick(BenefitsPage.get().firstScroll, "Scroll down");
			WebElement objBenefits = getWebDriver().findElement(By.xpath("(//a[contains(text(),'Benefits')])[2]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			seClick(objBenefits, "Option Tab :  Plan Setup");waitForPageLoad();
		
			WebElement objEyeglassFrames = getWebDriver().findElement(By.xpath("//*[@id='benefitsTree']/ul/li[2]/ul[1]/li/div/div/div/a"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			seClick(objEyeglassFrames, "Option Tab :  Plan Setup");waitForPageLoad();
			
			WebElement objBenefittree = getWebDriver().findElement(By.xpath("((//div[@class='situationGroupOptionHeader panel-heading'])[1]//span[2]/div/div[1]/input)[1]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			seClick(objBenefittree, "Option Tab :  Plan Setup");waitForPageLoad();
			
			//**********************For benefit******************************************
			WebElement objbenefitChangeable = getWebDriver().findElement(By.xpath("((//div[@class='situationGroupOptionHeader panel-heading'])[1]//span[2]/div/div[2]/input)[1]"));
			waitForPageLoad(25);boolean blnbenefitChangeable = seIsElementNotSelected(objbenefitChangeable, "Pediatric Vision Maximum Age Limit Changeablity Check Box");waitForPageLoad();
			System.out.println(blnbenefitChangeable);waitForPageLoad();
			if (blnbenefitChangeable == true){log(PASS, "Verified that, Benefit in Network that are not visible in the Template, is also not changeable","RESULT=PASS");}
			else{log(FAIL, "The limit that are not visible in the Template, is Changeable. Behaviour not as expected","RESULT=FAIL");}
			waitForPageLoad();
			seClick(PlanHeaderPage.get().save, "Save button");
			waitForPageLoad(45);
			//moving template to production
			PlanHeaderPage.get().seMoveToProductionTemplate();waitForPageLoad();
			System.out.println("Template moved to production");
			waitForPageLoad(45);
			seCloseBrowser();
			seOpenBrowser(BrowserConstants.Chrome, strBaseURL, "testscripts");
			LoginPage.get().loginApplication(strUserProfile);
			waitForPageLoad(65);
			seWaitForElementLoad(CreatePlanPage.get().homepage);
			//create plan
			CreatePlanPage.get().createPlan(true,50);waitForPageLoad(45);
			
			//In Plan
			//Limit>>PlanSetup>>Pediatric Vision>>Pediatric Vision Max Age Limit
			WebElement objPlansetupInPlan = getWebDriver().findElement(By.xpath("//a[contains(text(),'Plan Setup')]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			seClick(objPlansetupInPlan, "Option Tab :  Plan Setup");waitForPageLoad();
			
			WebElement objPlansetupBenefitInPlan = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Vision')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
			seClick(objPlansetupBenefitInPlan, "Option Tab :  Plan Setup");waitForPageLoad();
		
			try{
			 getWebDriver().findElement(By.xpath("//h4[contains(text(),'Pediatric Vision')]/following::span[contains(text(),'Covered Exam And Hardware')][1]/following::span[contains(text(),'Pediatric Vision Maximum Age Limit')]/following::td[1]/div/div/span[text()='19 Year(s)']"));
			waitForPageLoad();} catch (Exception e){
			log(PASS, "Verified that Limit which is  unchecked in template are not visible in the plan  ","RESULT=PASS");}
			
			//Accumulator>>PlanSetup>>Pediatric Vision>>In Network Pediatric Vision Coinsurance
			try{
			getWebDriver().findElement(By.xpath("//h4[contains(text(),'Pediatric Vision')]/following::span[contains(text(),'Covered Exam And Hardware')][1]/following::span[contains(text(),'In Network Pediatric Vision Coinsurance')]/following::td[1]/div/div[2]/span[text()='100%']"));
			waitForPageLoad();} catch (Exception e){
			log(PASS, "Verified that Accumulator which is  unchecked in template are not visible in the plan  ","RESULT=PASS");}
			
			//Plan Option Type>>Plan Setup>>Adult Vision>>Covered exam and hardware
			WebElement objAdultVisionsBenefits = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Adult Vision')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
			seClick(objAdultVisionsBenefits, "Option Tab :  Plan Setup");waitForPageLoad();
			
			try{
			getWebDriver().findElement(By.xpath("//h4[contains(text(),'Adult Vision')]/following::span[contains(text(),'Covered Exam And Hardware')]"));
			}catch (Exception e){log(PASS, "Verified that Plan Option Type which is  unchecked in template are not visible in the plan  ","RESULT=PASS");}
			
			//Accumulator group >> Plan level benefits>>Pediatric Deductible>>Deductible In Network
			
			WebElement objPlanLevelsBenefits = getWebDriver().findElement(By.xpath("//a[contains(text(),'Plan Level Benefits')]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			seClick(objPlanLevelsBenefits, "Option Tab :  Plan Setup");waitForPageLoad();
			
			WebElement objPlanLevelsBenefitsBenefit = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Deductible')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
			seClick(objPlanLevelsBenefitsBenefit, "Option Tab :  Plan Setup");waitForPageLoad();
			
			try{
			getWebDriver().findElement(By.xpath("(//h4[contains(text(),'Pediatric Deductible')]/following::span[contains(text(),'Deductible')][1]/following::div/div/h4[contains(text(),'In Network')])[1]"));
			waitForPageLoad();}catch (Exception e){
			log(PASS, "Verified that Accumulator Group which is  unchecked in template are not visible in the plan  ","RESULT=PASS");}
			
			
			//Plan Option Type>> Plan level benefits>>Pediatric Out Of Pocket maximum
		
			try{
				getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Out of Pocket Maximum')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
			}catch (Exception e){
			log(PASS, "Verified that Plan Option Type which is  unchecked in template are not visible in the plan  ","RESULT=PASS");}
			
			
			
			//PlanOptionName >> Benefit Option>>Pediatric Factory>>ScrtchCoating
			waitForPageLoad();seClick(BenefitsPage.get().firstScroll, "Scroll down");
			waitForPageLoad();seClick(BenefitsPage.get().firstScroll, "Scroll down");
			
			WebElement objBenefitOptionsVisible = getWebDriver().findElement(By.xpath("//a[contains(text(),'Benefit Options')]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objBenefitOptionsVisible);waitForPageLoad();
		
			try{
			getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Factory Scratch Coating')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			}catch (Exception e){log(PASS, "Verified that Plan Option Name which is  unchecked in template are not visible in the plan  ","RESULT=PASS");}
			
			
			//Benefit in Network>Eyeglass Frames tier1
			waitForPageLoad();seClick(BenefitsPage.get().firstScroll, "Scroll down");
			WebElement objBenefitsTab = getWebDriver().findElement(By.xpath("(//a[contains(text(),'Benefits')])[2]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			seClick(objBenefitsTab, "Option Tab :  Plan Setup");waitForPageLoad();
			
			WebElement objEyeglassesFrames = getWebDriver().findElement(By.xpath("//*[@id='benefitsTree']/ul/li[1]/ul[1]/li/div"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objEyeglassesFrames);waitForPageLoad();
			try{
				getWebDriver().findElement(By.xpath("//(//div[@class='situationGroupOptionHeader panel-heading'])[1]/span/span[text()='Tier 1']"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
				}catch (Exception e){log(PASS, "Verified that Benefits in Benefit tree and Network which is  unchecked in template are not visible in the plan  ","RESULT=PASS");}
			
			//Moving plan to production
			waitForPageLoad(35);
			
			seClick(PlanHeaderPage.get().save, "Save button");waitForPageLoad(15);
			VisibilityChangeabilityPage.get().seMoveMPlanToProduction();
			
			
			
			
			
			
			
			}catch (Exception e){
		log(FAIL,"Exception occured while executing seUncheckVisibility() mtd ","RESULT=FAIL");}}
	
	
    public void seUncheckChangeability(){
    	try{
    		
    		//uncheck the changeability checkboxes at Plan setup tab>>Pediatric vision
            waitForPageLoad();
			WebElement objPlansetup = getWebDriver().findElement(By.xpath("//a[contains(text(),'Plan Setup')]"));waitForPageLoad();//a[contains(text(),'" + strOptionTab + "')]waitForPageLoad();
			seClick(objPlansetup, "Option Tab :  Plan Setup");waitForPageLoad();
			
			WebElement objPlansetupBenefit = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Vision')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
			seClick(objPlansetupBenefit, "Option Tab :  Plan Setup");waitForPageLoad();
			
			//(//h4[contains(text(),'Pediatric Vision')]/following::span[contains(text(),'Covered Exam And Hardware')][1]/following::span[contains(text(),'In Network Pediatric Vision Coinsurance')]/following::td/div/span/div/span[@title='Changeable']/input[@class='changeable'])[1]
			WebElement objPlansetupChangeable = getWebDriver().findElement(By.xpath("(//h4[contains(text(),'Pediatric Vision')]/following::span[contains(text(),'Covered Exam And Hardware')][1]/following::span[contains(text(),'In Network Pediatric Vision Coinsurance')]/following::td/div/span/div/span[@title='Changeable']/input[@class='changeable'])[1]"));
			waitForPageLoad();seClick(objPlansetupChangeable, "Option Tab :  Plan Setup");waitForPageLoad();
			
			
			//uncheck the changeability checkboxes at Plan setup tab>>Pediatric vision
			waitForPageLoad();
			WebElement objPlanLevelBenefits = getWebDriver().findElement(By.xpath("//a[contains(text(),'Plan Level Benefits')]"));//a[contains(text(),'" + strOptionTab + "')]
			seClick(objPlanLevelBenefits, "Option Tab :  Plan Level Benefits");waitForPageLoad();
			
			WebElement objPlanLevelBenefit = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Deductible')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objPlanLevelBenefit);
			
			//(//h4[contains(text(),'Pediatric Deductible')]/following::span[contains(text(),'Comingled With Medical')][1]/following::span[contains(text(),' In')]/following::td/div/span/div/span[@title='Changeable']/input[@class='changeable'])[1]
			WebElement objPlanLevelBenefitsChangeable = getWebDriver().findElement(By.xpath("//*[@id='subCollapse1']/table/tbody/tr[1]/td[2]/div/span/div/span[2]/input"));
			waitForPageLoad();((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objPlanLevelBenefitsChangeable);waitForPageLoad();
			
			waitForPageLoad();seClick(BenefitsPage.get().firstScroll, "Scroll down");
			//uncheck the changeability checkboxes at Plan setup tab>>Pediatric vision
			waitForPageLoad();
			WebElement objBenefitOptions = getWebDriver().findElement(By.xpath("//*[@id='BenefitOption']/a"));//a[contains(text(),'" + strOptionTab + "')]
			waitForPageLoad();((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objBenefitOptions);waitForPageLoad();
			
			WebElement objBenefitBenefit = getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Pediatric Routine Eye Exam')])[1]/preceding::li[1]/following::li/a[1])[1]"));waitForPageLoad();//((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objBenefitBenefit);waitForPageLoad();
			
			WebElement objBenefitOptionsChangeable = getWebDriver().findElement(By.xpath("(//h4[contains(text(),'Pediatric Routine Eye Exam')]/following::span[contains(text(),'Covered In Network & Out of Network')][1]/following::span[contains(text(),'In Network Pediatric Routine Eye Exam Coinsurance')]/following::td/div/span/div/span[@title='Changeable']/input[@class='changeable'])[1]"));
			waitForPageLoad();((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objBenefitOptionsChangeable);waitForPageLoad();
			
			seClick(PlanHeaderPage.get().save, "Save button");
			waitForPageLoad(45);
    	}catch (Exception e){log(FAIL, "Exception while executing seUncheckChangeability() mtd");}
    	
    	
    }
  public void seMoveMPlanToProduction()
  {String strBaseURL = EnvHelper.getValue("pc.url");
	String strUserProfile = EnvHelper.getValue("user.profile");
	String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	  try{
		  waitForPageLoad(45);
		  seWaitForClickableWebElement(PlanHeaderPage.get().requestAudit,1);
			seClick(PlanHeaderPage.get().requestAudit, "request Audit button");
			waitForPageLoad();
			PlanTransitionPage.get().updateReasonCode("Other");
			seClick(PlanTransitionPage.get().requestAudit, "Request Audit button");
			waitForPageLoad();
			try{
				seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 360);
			    }
			catch(TimeoutException e){
	            seClick(PlanHeaderPage.get().close, "Close button");
	            }
			waitForPageLoad();
			
          ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",PlanHeaderPage.get().userNameHeader);
          waitForPageLoad();
          
          ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",PlanHeaderPage.get().userLogout);
         
          
			
			/*seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
			waitForPageLoad();
			seClick(PlanHeaderPage.get().userLogout, "Logout");*/
			waitForPageLoad(20,10); 
	        seOpenBrowser(BrowserConstants.Chrome, strBaseURL);
			LoginPage.get().loginApplication(strUserProfileApprover);
			waitForPageLoad();
			String strLegacy = getCellValue("MasterProductPlanID");
			seClick(HomePage.get().find, "Find");
          seClick(HomePage.get().findPlan, "Find Plan");
			seSetText(FindPlanPage.get().planVersionID,strLegacy, "Set text in plan version id");
			waitForPageLoad();
			seClick(FindPlanPage.get().planSearch, "Search");
			waitForPageLoad();
			WebElement objSearch = FindPlanPage.get().selectSearchedPlan;
          ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objSearch);
			Boolean blnPlanStatusPendingAudit= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
			if(blnPlanStatusPendingAudit==true){
					log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");
				}
			else { 
					new TimeoutException("Plan is not in Pending Audit status");
				}	
				seWaitForClickableWebElement(PlanHeaderPage.get().approveAudit, 36);
				seClick(PlanHeaderPage.get().approveAudit, "Approve Audit");
				waitForPageLoad(30);
				seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
				PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
				PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ARROW_DOWN);
				PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ENTER);
				seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, 10);
				seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
				seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeText, 1);
				seSetText(PlanTransitionPage.get().planTransitionReasonCodeText, "Approved", "as " + "Approved");
				seClick(PlanTransitionPage.get().approved, "approved reason code");
				seClick(PlanTransitionPage.get().approvedTest, "Approve test button");
				waitForPageLoad();
				seClick(PlanHeaderPage.get().moveToTestPHPage, "Move to test button");
				waitForPageLoad();
				seClick(PlanTransitionPage.get().moveToTest, "Move to test ");
				waitForPageLoad();
				seClick(PlanHeaderPage.get().approveTestForFinalize, "Approve test button");
				waitForPageLoad();
				seClick(PlanTransitionPage.get().approveTestReasonCodeClick, "");
				seClick(PlanTransitionPage.get().approved,"approved");
				seClick(PlanTransitionPage.get().approvedTest, "approve test");
				waitForPageLoad();
				seClick(PlanHeaderPage.get().finalize, "Finalize button");
				waitForPageLoad();
				seClick(PlanTransitionPage.get().finalizeButtoninPT, "");
				waitForPageLoad();
				try{
	        		seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 300);
	        		}
				
				catch(TimeoutException e){
		            seClick(PlanHeaderPage.get().close, "Close button");
					waitForPageLoad();

		            }
		       seClick(FindPlanPage.get().clickSearchedPlan,"Plan");
				waitForPageLoad();
				Boolean blnPlanStatusProduction= PlanHeaderPage.get().seVerifyPlanStatus("Production");
			    if(blnPlanStatusProduction==true){
	                  	log(PASS, "plan takes correct time to load","plan is in Production status,RESULT=PASS");
	                             }
	            else { 
	            	new TimeoutException("Plan is not in Production status");
	                  }	  
			     seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
			     seClick(PlanHeaderPage.get().userLogout, "Logout");
		  
	  }catch (Exception e){
		  log(FAIL, "Exception while moving plan to production");
	  }
  }

}
