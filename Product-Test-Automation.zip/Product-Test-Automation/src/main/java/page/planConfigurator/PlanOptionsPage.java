package page.planConfigurator;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

/**
 * @author AF17403
 *
 */
/**
 * @author AF17403
 *
 */
public class PlanOptionsPage extends CoreSuperHelper{

	private static PlanOptionsPage thisTestObj;	
	public synchronized static PlanOptionsPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), PlanOptionsPage.class);
		return thisTestObj;

	}				

	//This Class contains webelements that are identified in the PlanOptions Tab
	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CopayINNT1UrgentCareFac_-_amount-container\"]")
	@CacheLookup
	public WebElement innUrgCareFacCopay; 
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"DataTables_Table_1\"]/tbody/tr/td[4]")
	//@CacheLookup
	public WebElement planSearchSelect;

	@FindBy(how = How.XPATH, using = "//a[@title='Plan Options']")
	@CacheLookup
	public WebElement planOptions;

	//*[@id="verticalBarMenuDetails"]/div/nav/div[2]/ul/li/a

	@FindBy(how = How.XPATH, using = "//*[@id=\"verticalBarMenuDetails\"]/div/nav/div[2]/ul/li/a")
	@CacheLookup
	public List<WebElement> planOptionValues;

	@FindBy(how = How.XPATH, using = "//div[@id='verticalBarMenu']/div[2]/ul/li[@id=\"PlanOptions\"]/a")
	@CacheLookup
	public WebElement planOptionsTab;

	@FindBy(how = How.XPATH, using = "//a[@attr-ref='UrgentCare']")
	@CacheLookup
	public WebElement urgentCare;

	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares\"]")
	@CacheLookup
	public WebElement benefitSpecificINNRadioBtn;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-ApplyDed_-_choice-container\"]")
	@CacheLookup
	public WebElement applyDeductible;

	@FindBy(how = How.XPATH, using = "//*[@id=\"Diagnostics\"]/a")
	@CacheLookup
	public WebElement diagnostics;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-ApplyDed_-_choice-result-h6qg-Y\"]")
	//@CacheLookup
	public WebElement selectYesFromDed;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CoinINNT1UrgentCareFac_-_percentage-container\"]")
	//@CacheLookup
	public WebElement innUrgentCare;

	@FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[2]/td[2]/div/span/span/span[1]/input")
	//@CacheLookup
	public WebElement innUrgentCareText;

	@FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[1]/td[2]/div/span/span/span[1]/input")
	//@CacheLookup
	public WebElement applyDeductibleText;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-ApplyDed_-_choice-results\"]")
	//@CacheLookup
	public WebElement applyDeductibleYes;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CoinINNT1UrgentCareFac_-_percentage-results\"]")
	@CacheLookup
	public WebElement collapseInputField;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CoinINNT1UrgentCareFac_-_percentage-container\"]")
	@CacheLookup
	public WebElement percentageInputField;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-INNT1UrgentCareFac_-_amount-container\"]")
	@CacheLookup
	public WebElement innUrgCareFac; 

	@FindBy(how = How.XPATH, using = "//*[@id='select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CopayINNT1UrgentCareFac_-_amount-results']")
	@CacheLookup
	public WebElement innUrgCareFacCopayResult; 

	@FindBy(how = How.XPATH, using = "//*[@id='select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CopayINNT1UrgentCareFac_-_choice-container']")
	@CacheLookup
	public WebElement innUrgCareFacCopayChoice;

	@FindBy(how = How.XPATH, using = "//*[@id='select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CopayINNT1UrgentCareFac_-_accumulationBasis-container']")
	@CacheLookup
	public WebElement innUrgCareFacCopayBasis;

	@FindBy(how = How.XPATH, using = "//*[@id='subCollapse2']/table/tbody/tr[3]/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement innUrgCareFacCopayChoiceText;

	@FindBy(how = How.XPATH, using = "//*[@id='subCollapse2']/table/tbody/tr[3]/td[2]/div[4]/span/span/span[1]/input")
	@CacheLookup
	public WebElement innUrgCareFacCopayBasisText;

	@FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[3]/td[2]/div[2]/span/span/span[1]/input")
	@CacheLookup
	public WebElement innUrgCareFacCopayAmount;

	@FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[3]/td[2]/div[2]/span/span/span[2]")
	@CacheLookup
	public WebElement innUrgCareFacCopayEnter;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CopayINNT1UrgentCareFac_-_amount-container\"]")
	@CacheLookup
	public WebElement innUrgCareFacCopayText;

	@FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[7]/a")
	@CacheLookup
	public WebElement saveButton;
	

	@FindBy(how = How.XPATH, using = "//input[@id='POA_PlanOptions-_-ChiroExams-_-CoveredINNOON-_-CostSharesINNT1-_-FollowChiroSpinalManip']")
	@CacheLookup
	public WebElement followChiropracticSpinalManipulationRadioBtn ;


@FindBy(how = How.XPATH, using = "/*[@id='content-create-customPlan']/form/div[2]/div[6]/div/button[2]/span")
	@CacheLookup
	public WebElement save;


	///////////////////////////////////////////Banaja/////////////////////////

	public WebElement ele(String type)
	{
		WebElement value=getWebDriver().findElement(By.xpath("//span[contains(text(),'"+type+"')]/ancestor::tr[1]/td[2]/div[2]/div[2]/span/span[1]/span"));
		return value;
	}

	public static boolean override(WebElement ele)
	{
		boolean override=false;
		String domainOverride=ele.getAttribute("title").toString().trim();
		if(domainOverride.contains("Custom Value - "))
		{
			override=true;
		}
		else
		{
			override=false;
		}
		return override;
	}      

	
	public WebElement Acuum(String type)
	{
		WebElement value=getWebDriver().findElement(By.xpath("//span[text()='"+type+"']/ancestor::tr[1]/td[5]/span/span/span/div[2]/span/span/span/span"));
		return value;
	}
	/*@FindBy(how = How.XPATH, using = "")
	@CacheLookup
	public WebElement level1;*/

	@FindBy(how = How.XPATH, using = "//*[contains(text(),'In Network Primary Care Physician Copay')]/following::span[@class='select2-selection__arrow'][2]")
	@CacheLookup
	public WebElement Copayin;

	@FindBy(how = How.XPATH, using = "//span[@class='select2-search select2-search--dropdown']//input[@class='select2-search__field']")
	@CacheLookup
	public WebElement Copayset;




	////////
	@FindBy(how = How.XPATH, using = "//li[contains(text(),'No matches found')]")
	//@CacheLookup
	public WebElement selectMsg;
	@FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[2]/a")
	@CacheLookup
	public WebElement copyButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[6]/a")
	@CacheLookup
	public WebElement editButton;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='content-planBenefitDetails']/div[2]/div/div[1]/div[1]/i")

	//@CacheLookup
	public WebElement Tier1;

	public WebElement situationType(String Network, String SituationType)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//div[@id='content-planBenefitDetails']/div[2]/div/div[contains(@class,'"+Network+"')]/div[1]/span[2]/span[text()='"+SituationType+"']"));
		return valueType;
	} 

	@FindBy(how = How.XPATH, using = "//*[@id='content-planBenefitDetails']/div[2]/div/div[1]/div[2]/div[2]/div/div[2]/div/table/tbody/tr[4]/td[5]/span/span/span")
	//@CacheLookup
	public WebElement selectAccumName;


	
	
	public WebElement selectAccum(String value)
	{
		WebElement type=getWebDriver().findElement(By.xpath("//span[text()='"+value+"']/ancestor::tr[1]/td[5]/span/span/span/div[2]/span/span/span/span"));
		return type;
	}


	@FindBy(how = How.XPATH, using = "//*[@id='POA_PlanOptions-_-HomeHealthCare-_-CoveredINNOON-_-LimitationsDlr']/div/div/div[2]/table/tbody/tr[1]/td[2]/div[1]/div[2]/span/span[1]/span")
	//@CacheLookup
	public WebElement vistLimit;

	@FindBy(how = How.XPATH, using = "//*[@id='POA_PlanOptions-_-InptFac-_-CoveredINNOON-_-Limitations']/div/div/div[2]/table/tbody/tr[4]/td[2]/div[1]/div/span/span[1]/span")
	//@CacheLookup
	public WebElement unitLimit;

	@FindBy(how = How.XPATH, using = "//*[@id='POA_Base-_-Penalties-_-WithPenalty-_-NA']/div/div/table/tbody/tr[1]/td[2]/div[1]/div[2]/span/span[1]/span")
	//@CacheLookup
	public WebElement penaltyLimit;


	
	
	public WebElement visualIndicator(String value)
	{
		WebElement type=getWebDriver().findElement(By.xpath("//a[text()='"+value+"']/span[@title='Changed by user']"));
		return type;
	}

	public WebElement limit(String value)
	{
		WebElement type=getWebDriver().findElement(By.xpath("//span[contains(text(),'"+value+"')]/ancestor::tr[1]/td[2]/div[1]/div/span[1]/span/span"));
		return type;
	}

	public WebElement limitValue(String value)
	{
		WebElement type=getWebDriver().findElement(By.xpath("//span[contains(text(),'"+value+"')]/ancestor::tr[1]/td[2]/div/span/span/span/input"));
		return type;
	}


	@FindBy(how = How.XPATH, using = "//span[@class='optionHeaderDetailWrapper clearfix identifier ']/span[contains(text(),'Tier 1')]/span")
	//@CacheLookup
	public WebElement visualIndicatorTier;

	@FindBy(how = How.XPATH, using = "//span[text()='In Network Inpatient Care Copay']/ancestor::tr[1]/td[5]/span/span/span/div[2]/span/span/span/span")
	//@CacheLookup
	public WebElement Copayment;



	public static void validateNMF(WebElement containerSpan, String elementName, String strValue,
			int intMaxWaitTime) {
		String errormsg="No matches found";
		RESULT_STATUS = true;
		String stepName = "Select " + errormsg + " from " + elementName;
		try {
			seClick(containerSpan, elementName);
			waitForPageLoad(2, intMaxWaitTime);
			seSetText(PlanSetupPage.get().dropDownInput, strValue, "Set text for " + elementName);
			waitForPageLoad(2, intMaxWaitTime);
			String strselectmsg=seGetElementValue(PlanOptionsPage.get().selectMsg);

			if(strselectmsg.equalsIgnoreCase("No Matches Found")){
				log(PASS,stepName,"system displays a message of, �No matches found� for out of range values ",true);
			}
			else
			{
				log(FAIL,stepName,"system not displays a message of, �No matches found� for out of range values ",true);
			}
			waitForPageLoad(2, intMaxWaitTime);
		} catch (Exception e) {
			e.printStackTrace();
			processExceptions(stepName, e.getLocalizedMessage());
		}
	}    


	public static void clickBenefit() throws Exception
	{
		try
		{

			WebElement Benefits = getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenu']/div[2]/ul/li[@id=\"BenefitTree\"]/a")) ;
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",Benefits); 

			waitForPageLoad(5, 600);

		}
		catch(Exception e)
		{
			throw e;
		}
	}








	////////////////////////
	//#########################################################################################################################################
	@FindBy(how = How.XPATH, using = "//*[@id=\"DataTables_Table_1\"]/tbody/tr/td[4]")
	@CacheLookup
	public WebElement clickSearchedPlan;

	@FindBy(how = How.XPATH, using = "//a[@title='Plan Options']")
	@CacheLookup
	public WebElement clickPlanOptions;

	@FindBy(how = How.XPATH, using = "//*[@id='BenefitTree']/a")
	@CacheLookup
	public WebElement clickBenefits;

	@FindBy(how = How.XPATH, using = "//div[@title='Scroll Down']")
	@CacheLookup
	public WebElement clickScrollDown;

	@FindBy(how = How.XPATH, using = "//*[@id='benefitsTree']/ul/li[22]/ul[1]/li/div/div/div/a")
	@CacheLookup
	public WebElement clickUrgentCare;

	public void wbscrollDown()
	{
		JavascriptExecutor je = ((JavascriptExecutor) driver);
		je.executeScript("arguments[0].scrollIntoView(true);",clickUrgentCare);
	}

	@FindBy(how = How.XPATH, using = "//span[contains (text(), 'View Service Code')]")
	@CacheLookup
	public WebElement clickViewServiceCode;


	@FindBy(how = How.XPATH, using = "//*[@id='serviceCodeDetail']/div/table/tbody/tr/td[1]")
	@CacheLookup
	public WebElement getServiceCode;


	@FindBy(how = How.XPATH, using = "//*[@id='serviceCodeDetail']/div/table/tbody/tr/td[2]")
	@CacheLookup
	public WebElement getServiceCodeDescription;

	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Plan Options')]")
	@CacheLookup
	public WebElement planOptionButton;

	@FindBy(how = How.XPATH, using = "//*[@class=\"modal-content ui-draggable\"]")
	@CacheLookup
	public WebElement serviceCodePopup;

	@FindBy(how = How.XPATH, using = "//div[@id='verticalBarMenuDetails']/div/nav/div[2]/ul/li/a")
	@CacheLookup
	public List<WebElement> optionsTabvalues;

	public WebElement optionsTabValues(String type)
	{
		WebElement sideTab = getWebDriver().findElement(By.linkText(type));
		return sideTab;
	}

	public WebElement planCopayName(String accumName)
	{
		WebElement copayValue = getWebDriver().findElement(By.xpath("//td[@class='accumulator-label']/div/span[contains(text(),'"+accumName+"')]"));
		return copayValue;
	}	

	public WebElement clickPlanCopayMaxPerYear(String accumName)
	{	
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Amount')]/following-sibling::div/span/span/span[1]/span[contains(@title, '$')]"));
		return copayValue;
	}

	public WebElement enterPlanCopayMaxPerYear(String accumName)
	{
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Amount')]/following-sibling::span/span/span[1]/input"));
		return copayValue;
	}

	public WebElement clickPlanCopayAmountPerVisit(String accumName)
	{	
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Amount')]/following-sibling::div/span/span/span[1]/span[contains(@title, '$')]"));
		return copayValue;
	}

	public WebElement enterPlanCopayAmountPerVisit(String accumName)
	{
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Amount')]/following-sibling::span/span/span[1]/input"));
		return copayValue;
	}

	public WebElement clickPlanCopayAmountPerAdmission(String accumName)
	{	
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Amount')]/following-sibling::div/span/span/span[1]/span[contains(@title, '$')]"));
		return copayValue;
	}

	public WebElement enterPlanCopayAmountPerAdmission(String accumName)
	{
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Amount')]/following-sibling::span/span/span[1]/input"));
		return copayValue;
	}

	public WebElement clickPlanCopayAmountPerTrip(String accumName)
	{	
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Amount')]/following-sibling::div/span/span/span[1]/span[contains(@title, '$')]"));
		return copayValue;
	}

	public WebElement enterPlanCopayAmountPerTrip(String accumName)
	{
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Amount')]/following-sibling::span/span/span[1]/input"));
		return copayValue;
	}
	public WebElement clickPlanCopayAmountPerDay(String accumName)
	{	
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Amount')]/following-sibling::div/span/span/span[1]/span[contains(@title, '$')]"));
		return copayValue;
	}

	public WebElement enterPlanCopayAmountPerDay(String accumName)
	{
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Amount')]/following-sibling::span/span/span[1]/input"));
		return copayValue;
	}
	public WebElement clickPlanCopayAmountPerPregnancy(String accumName)
	{	
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Amount')]/following-sibling::div/span/span/span[1]/span[contains(@title, '$')]"));
		return copayValue;
	}

	public WebElement enterPlanCopayAmountPerPregnancy(String accumName)
	{
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Amount')]/following-sibling::span/span/span[1]/input"));
		return copayValue;
	}

	public WebElement selectPlanCopayMaxValue(String copayVal)
	{
		//WebElement copayValue = getWebDriver().findElement(By.xpath("span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Max')]/following-sibling::span/span/span[@class='select2-results']/ul/li/span[text()='"+copayVal+"']"));
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span/span/span[@class='select2-results']/ul/li[1]/span/span[text()='"+copayVal+"']"));
		return copayValue;
	}
	public WebElement planCopayBasisPaymentPerYear(String accumName)
	{
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Basis Code')]/following-sibling::div//span[contains(@title,'Per Year')]"));
		return copayValue;
	}

	public WebElement planCopayBasisPaymentPerVisit(String accumName)
	{
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Basis Code')]/following-sibling::div/span[contains(@class,'accumulatorAttribute')]"));
		return copayValue;
	}

	public WebElement planCopayBasisPaymentPerAdmission(String accumName)
	{
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Basis Code')]/following-sibling::div/span//span[contains(@title,'Per Admission')]"));
		return copayValue;
	}

	public WebElement planCopayBasisPaymentPerTrip(String accumName)
	{
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Basis Code')]/following-sibling::div/span[contains(@class,'accumulatorAttribute')]"));
		return copayValue;
	}
	public WebElement planCopayBasisPaymentPerDay(String accumName)
	{
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Basis Code')]/following-sibling::div/span//span[contains(@title,'Per Day')]"));
		return copayValue;
	}
	public WebElement planCopayBasisPaymentPerPregnancy(String accumName)
	{
		WebElement copayValue = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Basis Code')]/following-sibling::div/span//span[@title='Per Pregnancy']"));
		return copayValue;
	}
	public WebElement checkboxPaidAsPlanLevel(String planOptionValue, String accumGroupName)
	{
		WebElement copayValue = getWebDriver().findElement(By.xpath("//h4[text()='"+planOptionValue+"']/parent::span/parent::span/following-sibling::div/div//h4[text()[normalize-space()='"+accumGroupName+"']]/following-sibling::div//h4[contains(text()[normalize-space()],'Paid as')]/input"));
		return copayValue;
	}

	@FindBy(how = How.ID, using = "select2-POA_PlanOptions-_-InptFac-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-CopayINNT1InptCare_-_amount-container")
	public WebElement inNetInCareCopay;

	@FindBy(how = How.XPATH, using = "//input[@class='select2-search__field']")
	public WebElement inNetInCareCopayVal;

	@FindBy(how = How.XPATH, using = "//*[@id='content-planBenefitDetails']/div[2]/div/div[1]/div[1]/i")
	@CacheLookup
	public WebElement tierOneNetwork;

	@FindBy(how = How.LINK_TEXT, using = "Benefits")
	@CacheLookup
	public WebElement benefits;

	@FindBy(how = How.XPATH, using = "//*[@id='content-planBenefitDetails']/div[2]/div/div[1]/div[1]/i")
	@CacheLookup
	public WebElement coveredRadioButton;

	@FindBy(how = How.XPATH, using = "//select[@frontend-name='Apply Deductible']")
	@CacheLookup
	public WebElement applyDeductibleList;

	public WebElement applyDeductible(String accumGroupName)
	{
		WebElement dedvalue = getWebDriver().findElement(By.xpath("//div[h4[contains(text(),'"+accumGroupName+"')]]/div//td[div/span[contains(text(),'Apply Deductible')]]/following-sibling::td//span[contains(@id,'ApplyDed_-_choice-container')]"));
		return dedvalue;
	}

	public WebElement applyDeductibleList(String accumGroupName)
	{
		WebElement dedvalue = getWebDriver().findElement(By.xpath("//div[h4[contains(text(),'"+accumGroupName+"')]]/div//td[div/span[contains(text(),'Apply Deductible')]]/following-sibling::td//select[contains(@id,'ApplyDed_-_choice')]"));
		return dedvalue;
	}


	// This section has the elements under the
	// Urgent Care -> Covered In Network & Out of Network -> In Network Cost
	// Shares Facility -> Benefit Specific Cost Shares
	// in read-only mode. Refer plan with status as Production.

	@FindBy(how = How.XPATH, using = "//span[@id='POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-ApplyDed_-_choice']")
	// @CacheLookup
	public WebElement lblApplyDeductiblevalue;

	@FindBy(how = How.XPATH, using = "//span[@id='POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CoinINNT1UrgentCareFac_-_percentage']")
	// @CacheLookup
	public WebElement lblInnUrgentCareFacCoinsuranceValue;

	@FindBy(how = How.XPATH, using = "//span[@id='POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CopayINNT1UrgentCareFac_-_choice']")
	// @CacheLookup
	public WebElement lblInnUrgentCareFacCopayChoicevalue;

	@FindBy(how = How.XPATH, using = "//span[@id='POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CopayINNT1UrgentCareFac_-_amount']")
	// @CacheLookup
	public WebElement lblInnUrgentCareFacCopayAmountvalue;

	@FindBy(how = How.XPATH, using = "//span[@id='POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CopayINNT1UrgentCareFac_-_accumulationBasis']")
	// @CacheLookup
	public WebElement lblInnUrgentCareFacCopayBasisvalue;

	// End of section with elements in read-only mode for plans of status as
	// production.

	@FindBy(how = How.XPATH, using = "//span[@id='POA_Base-_-UrgentCareFac-_-CoveredINNOON-_-INNCostShares-_-Copay-_-INNUrgentCareFacCopay_-_amount']")
	// @CacheLookup
	public WebElement lblUrgentCareFacilityCoveredINOONInNtkCostSharesCopay;

	public WebElement optionsTab(String type)
	{
		WebElement sideTab = getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenu']/div[2]/ul/li/a[contains(text(),'"+type+"')]"));
		return sideTab;
	}

	@FindBy(how = How.XPATH, using = "//div[@class='panel-heading']/h4/span")
	@CacheLookup
	public List<WebElement> optionsTypeValues;

	@FindBy(how = How.XPATH, using = "//table/tbody/tr/td/div/span[1]")
	@CacheLookup
	public List<WebElement> optionsTypeTextValues;

	public WebElement OOP(String accumName)
	{	
		WebElement oopCheckBox = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[3]/span[2]/input"));
		return oopCheckBox;
	}  

	public WebElement coinsurance(String accumName)
	{	
		WebElement oopCheckBox = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div[1]/div/span/span[@class='selection']/span[1]/span[contains(@title,Percentage)]"));
		return oopCheckBox;
	}

	public WebElement setcoinsurance(String accumName)
	{	
		WebElement oopCheckBox = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div[1]/span/span/span[1]/input"));
		return oopCheckBox;
	}

	public WebElement optionsTabvalues(String type)
	{
		WebElement optionsTabvalues = getWebDriver().findElement(By.linkText(type));
		return optionsTabvalues;
	}

	public WebElement accumMaxValue(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//table/tbody/tr/td/div/span[contains(text(),'"+type+"')]"));
		return valueType;
	}

	@FindBy(how = How.CSS, using = "span[id='POA_PlanOptions-_-Ambulance-_-CoveredINNOON-_-Limitations-_-Combined-_-DlrLmtAmbulanceAir_-_indivMax']")
	@CacheLookup
	public WebElement dollarLimitValue;

	public WebElement CopayMax(String accumName)
	{	
		WebElement CopayMax =getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div[1]/div[2]/span/span/span[1]/span[1]"));
		return CopayMax;
	} 

	public WebElement CopayMaxValue(String accumName)
	{	
		WebElement CopayMax =  getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[2]/following-sibling::span/span/span[1]/input"));
		return CopayMax;
	} 

	public WebElement CopayMaxBenefitPeriod(String accumName)
	{	
		WebElement CopayMax = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div[2]/div[2]/span/span/span[1]/span[1]"));
		return CopayMax;
	}

	public WebElement CopayMaxBenefitPeriodValue(String accumName)
	{	
		WebElement CopayMax = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div[2]/span/span/span[1]/input"));
		return CopayMax;
	}

	@FindBy(how = How.XPATH, using = ".//*[@id='select2-POA_BenefitOption-_-Acupuncture-_-CoveredINNOON-_-Limitations-_-Lmt-_-UnitAcupunctureVstLmt_-_indUnitMax-container']")
	@CacheLookup
	public WebElement accVisitLimit;

	@FindBy(how = How.XPATH, using = ".//*[@id='POA_BenefitOption-_-Acupuncture-_-CoveredINNOON-_-Limitations']/div/div/div[2]/table/tbody/tr[2]/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement accVisitLimitTextBox;

	@FindBy(how = How.XPATH, using = ".//*[@id='select2-POA_BenefitOption-_-PrevCare-_-CoveredINNOON-_-Limitations-_-Lmt-_-UnitBreastPumpLmt_-_indUnitMax-container']")
	@CacheLookup
	public WebElement breastPumpLimit;

	@FindBy(how = How.XPATH, using = ".//*[@id='POA_BenefitOption-_-PrevCare-_-CoveredINNOON-_-Limitations']/div/div/div[2]/table/tbody/tr[9]/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement breastPumpLimitTextBox;

	@FindBy(how = How.CSS, using = ".select2-results__option.select2-results__option--highlighted>span>span")
	@CacheLookup
	public WebElement valueToBeSelected;


	@FindBy(how = How.XPATH, using = ".//*[@id='content-planBenefitDetails']/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[5]/td[5]/span/span/span[1]")
	@CacheLookup
	public WebElement DeductibleValueBenefit;

	@FindBy(how = How.XPATH, using = "//span[contains(@class,'select2-selection__rendered') and contains(@title,'$500')]")
	@CacheLookup
	public List<WebElement> CopayValueBenefit;

	@FindBy(how = How.XPATH, using = ".//*[@id='content-planBenefitDetails']/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[1]/td[5]/span/span/span[2]")
	@CacheLookup
	public WebElement PenaltyValueBenefit;


	@FindBy(how = How.XPATH, using = ".//*[@id='content-planBenefitDetails']/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/table/tbody/tr[6]/td[7]/span/span/input")
	@CacheLookup
	public WebElement OOPBenefitCheckbox;	

	@FindBy(how = How.XPATH, using = ".//*[@id='POA_PlanOptions-_-InptFac-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-CoinINNT1InptCare_-_applyToXrefAccum']")
	@CacheLookup
	public WebElement OOPCheckBox;

	@FindBy(how = How.XPATH, using = ".select2-results__option.select2-results__option--highlighted>span>span")
	@CacheLookup
	public WebElement CopayValue;

	public WebElement accumValue(String value)
	{
		WebElement valueType=getWebDriver().findElement(By.xpath("//table/tbody/tr/td/div/span[contains(text(),'"+value+"')]/ancestor::tr[1]/td[2]/div/div/span"));
		return valueType;
	}

	public WebElement accumType(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenuDetails']/div/nav/div[2]/ul/li/a[contains(text()[normalize-space()],'"+type+"')]"));
		return valueType;
	} 

	public WebElement Copay(String accumName)
	{	
		WebElement Copay= getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Amount')]/following-sibling::div/span/span/span[1]/span[contains(@title, '$')]"));
		return Copay;
	} 



	public WebElement CopayValue(String accumName)
	{	
		WebElement Copay = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Amount')]/following-sibling::span/span/span[1]/input"));
		return Copay;
	} 

	public WebElement Coinsurance(String accumName)
	{	
		WebElement Copay= getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Percentage')]/following-sibling::div/span/span/span[1]/span[contains(@title, '%')]"));
		return Copay;
	} 

	public WebElement CoinsuranceValue(String accumName)
	{	
		WebElement Copay = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+accumName+"')]/ancestor::tr[1]/td[2]/div/div[contains(text(),'Percentage')]/following-sibling::span/span/span[1]/input"));
		return Copay;
	} 
	public static void strcompareservicecode(String Expected,String Actual){
		if(Expected.equals(Actual))
		{
			RESULT_STATUS=true;
			log(PASS, "Service Code is displayed as expected","Upon Clicking 'View Service Code Button'Popup with Service code is displayed sucessfully, RESULT=PASS");
		}
		else
		{
			RESULT_STATUS=false;
			log(FAIL, "Service Code is NOT displayed ","Upon Clicking 'View Service Code Button'NO Popup with Service code is displayed, RESULT=FAIL");
		}
	}
	public static void strcompareservicecodedescription(String Expected,String Actual){
		if(Expected.equals(Actual))
		{
			RESULT_STATUS=true;
			log(PASS, "Service Code Description is displayed as expected","Upon Clicking 'View Service Code Button'Popup with Service code Description is displayed sucessfully, RESULT=PASS");
		}
		else
		{
			RESULT_STATUS=false;
			log(FAIL, "Service Code Description is NOT displayed ","Upon Clicking 'View Service Code Button'NO Popup with Service code Description is displayed, RESULT=FAIL");
		}
	}



	public void verifyChangeInPlanOption(boolean strAddOrRemove, String strPlanOption, String strPlanID, boolean booFoundPlan)
	{

		if(booFoundPlan)
		{
			boolean found = false;
			waitForPageLoad(300);
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",PlanOptionsPage.get().planOptionsTab);
			waitForPageLoad(300);
			System.out.println();
			for (WebElement element : PlanOptionsPage.get().planOptionValues) {
				Actions act = new Actions(getWebDriver());
				act.moveToElement(element).build().perform();
				String strOptionValue = element.getText();
				if(strOptionValue.equalsIgnoreCase(strPlanOption))
				{
					found = true;
					break;
				}
			}
			String strStepName = "Verify Plan Option Change in the Plan";
			if(strAddOrRemove)
			{
				if(found)
				{
					RESULT_STATUS= true;
					log(PASS, strStepName, "Plan Option added to the Plan : "+strPlanID);
				}
				else
				{
					RESULT_STATUS= false;
					log(FAIL, strStepName, "Plan Option not added to the Plan : "+strPlanID);
				}
			}
			else
			{
				if(!found)
				{
					RESULT_STATUS= true;
					log(PASS, strStepName, "Plan Option removed from the Plan : "+strPlanID);
				}
				else
				{
					RESULT_STATUS= false;
					log(FAIL, strStepName, "Plan Option not removed from the Plan : "+strPlanID);
				}
			}
		}
		else
		{
			log(FAIL, "Verify Plan Option change in Plan after Bulk Republish", "Not able to find in the application with version id"+strPlanID, true);
		}
	}

	public boolean verifyDollarLimit(String accumValue,String expectedValue,String dollarMax,int expectedDollarMaxValue,int intMaxTime)
	{
		boolean result=false;
		String actualValue="";
		String actualDollarMax="";
		int actualDollarMaxValue=0;
		try
		{
			WebElement planOptions=getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenu']/div[2]/ul/li/a[@title='Plan Options']"));
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",planOptions);
			waitForPageLoad(2,intMaxTime);
			Actions actions=new Actions(getWebDriver());
			actions.moveToElement(PlanLevelBenefitsPage.get().accumMaxValue(accumValue)).build().perform();
			actualValue=seGetElementValue(PlanOptionsPage.get().accumMaxValue(accumValue)).toString().trim();
			if(expectedValue.equalsIgnoreCase(actualValue))
			{
				log(PASS,"Expected Value "+expectedValue +"is equal to actual Value "+actualValue);			
				actualDollarMax=seGetElementValue(PlanOptionsPage.get().accumValue(accumValue)).replace("$", "").trim();
				if(actualDollarMax.contains(","))
				{
					actualDollarMax=actualDollarMax.replace(",", "");
				}
				actualDollarMaxValue=Integer.parseInt(actualDollarMax);
				result=PlanOptionsPage.get().acummDollarMaxComparision(dollarMax, expectedDollarMaxValue, actualDollarMaxValue);
			}       	
			else
			{
				log(FAIL,"Expected Value "+expectedValue +"is not equal to actual Value "+actualValue);
			}
		}
		catch(Exception e)
		{
			log(FAIL,"Data is incorrect","Data is incorrect"+e.getLocalizedMessage());
		}
		return result;
	}

	public  boolean acummDollarMaxComparision(String maximum,int expectedValue,int actualValue)
	{
		boolean result=false;
		try{
			switch (maximum) {
			case "=":
				if(expectedValue==actualValue)
				{
					log(PASS,"Expected Value is equal to actual Value "+expectedValue+"is equal to "+actualValue);
					result=true;
				}
				else
				{
					log(FAIL,"Expected Value is not equal to actual Value "+expectedValue+"is not equal to "+actualValue);
					result=false;
				}
				break;
			case ">":
				if(actualValue>expectedValue)
				{
					log(PASS,"Actual Value is greater than expected Value "+actualValue+"is > "+expectedValue);
					result=true;
				}
				else
				{
					log(FAIL,"Actual Value is not greater than expected Value"+actualValue+"is > "+expectedValue);
					result=false;
				}
				break;
			case "<":
				if(actualValue<expectedValue)
				{
					log(PASS,"Actual Value is less than expected Value"+actualValue+"is < "+expectedValue);
					result=true;
				}
				else
				{
					log(FAIL,"Actual Value is not less than expected Value"+actualValue+"is < "+expectedValue);
					result=false;
				}
				break;
			case ">=":
				if(actualValue>=expectedValue)
				{
					log(PASS,"Actual Value is greater than equal to expected Value"+actualValue+"is >= "+expectedValue);
					result=true;
				}
				else
				{
					log(FAIL,"Actual Value is not greater than equal expected Value"+actualValue+"is < "+expectedValue);
					result=false;
				}
				break;	
			case "<=":
				if(actualValue<=expectedValue)
				{
					log(PASS,"Actual Value is less than equal to expected Value"+actualValue+"is <= "+expectedValue);
					result=true;
				}
				else
				{
					log(FAIL,"Actual Value is not less than equal expected Value"+actualValue+"is < "+expectedValue);
					result=false;
				}
				break;
			default:
				break;	

			}
		}
		catch(Exception e)
		{
			log(ERROR,"Invalid maximum value","Invalid maximum value "+e.getLocalizedMessage());
		}
		return result;

	}

	/**
	 *  The below method is to click on options tab and accumulator type 
	 * @param strOptionsTab : The options tab to be clicked
	 * @param strAccumulatorType :The accumulator type to be clicked
	 * @param intMaxWaitTime
	 * @throws Exception
	 */
	public static void clickTab(String strOptionsTab,String strAccumulatorType,int intMaxWaitTime) throws Exception
	{
		try
		{
			WebElement optionsTab = PlanOptionsPage.get().optionsTab(strOptionsTab);
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",optionsTab);	
			waitForPageLoad(5, intMaxWaitTime);
			WebElement accumulatorType = PlanOptionsPage.get().accumType(strAccumulatorType);
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",accumulatorType);
			waitForPageLoad(5, intMaxWaitTime);
		}
		catch(Exception e)
		{
			throw e;
		}
	}

	/**
	 * The below method is to write the validate and write the logs statements for Admin Method: copay functionality 
	 * @param adminMethodType
	 * @param expadminMethodValue
	 * @param actadminMethodValue
	 * @param basisCode
	 */
	public void writeLogForAdminXMLCopayValidations(String adminMethodType, String expadminMethodValue,String actadminMethodValue, String basisCode)
	{
		if((adminMethodType.equalsIgnoreCase("Copay"))&&(expadminMethodValue.equalsIgnoreCase(actadminMethodValue)))
		{
			log(PASS, "Validate admin Method Copay value", "Admin Method copay value is displaying correctly for "+basisCode+" as "+actadminMethodValue);
		}
		else{
			log(FAIL, "Validate admin Method Copay value", "Admin Method copay value is not displaying correctly for "+basisCode);
		}
	}

	/**
	 * This Method is used to Update the OOP in Plans
	 * @param strOOPCheckBoxValue : To Check Or Uncheck the OOP Check Box
	 * @param strOptionsTypeTextValue : The Accumulator Type to be checked or unChecked
	 * @param strCoinsuranceValue : Value of Coinsurance to be upadated for the Accumulator Type
	 */
	public void updateOOP(String strOOPCheckBoxValue,String strOptionsTypeTextValue,String strCoinsuranceValue){
		if(strOOPCheckBoxValue.equalsIgnoreCase("UnCheck"))
		{
			if(PlanOptionsPage.get().OOP(strOptionsTypeTextValue).isSelected())
				seClick(PlanOptionsPage.get().OOP(strOptionsTypeTextValue),"OOP CheckBox");	
		}
		else if(strOOPCheckBoxValue.equalsIgnoreCase("Check"))
		{
			if(!PlanOptionsPage.get().OOP(strOptionsTypeTextValue).isSelected())
				seClick(PlanOptionsPage.get().OOP(strOptionsTypeTextValue),"OOP CheckBox");	
		}
		waitForPageLoad(5, 300);
		seClick(PlanOptionsPage.get().coinsurance(strOptionsTypeTextValue), "Coinsurance");
		waitForPageLoad(5, 300);
		seSetText(PlanOptionsPage.get().setcoinsurance(strOptionsTypeTextValue), strCoinsuranceValue, "Update Coinsurance value ");
		waitForPageLoad(5, 300);
		PlanOptionsPage.get().setcoinsurance(strOptionsTypeTextValue).sendKeys(Keys.ENTER);

	}

	/**This Method is used To Update the Limiations in Plan
	 * @param strAccumulatorName : The Accumulator which needs to be Edited
	 * @param strLimitValue : Limit Value for the Accumulator
	 * @param BenefitPeriod : Beneift Period-EG:Per Benefit Year
	 */
	public void updateLimitation(int intMaxWaitTime,String strAccumulatorName,String strLimitValue, String BenefitPeriod){
		try{
			waitForPageLoad(intMaxWaitTime);
			seClick(PlanBenefitOptionsPage.get().Limit(strAccumulatorName), strAccumulatorName+"Drop Down");
			waitForPageLoad(intMaxWaitTime);
			seSetText(PlanBenefitOptionsPage.get().enterLimit(strAccumulatorName), strLimitValue, "Enter Limit Value a "+strLimitValue);
			PlanBenefitOptionsPage.get().enterLimit(strAccumulatorName).sendKeys(Keys.ENTER);
			waitForPageLoad(intMaxWaitTime);
			seClick(PlanBenefitOptionsPage.get().limitBenefitYear(strAccumulatorName), "Limit Benefit Year");
			waitForPageLoad(intMaxWaitTime);
			seClick(PlanBenefitOptionsPage.get().selectBenefitYear(strAccumulatorName,BenefitPeriod),BenefitPeriod);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			log(ERROR, "Exception has occured While Updating Limitaion", e.getLocalizedMessage());
		}
	}
	/**
	 * The below method click at the required object using Javascriptexecutor
	 * @param obj
	 * @throws Exception
	 */
	public void clickAtObject(WebElement obj) throws Exception
	{
		try
		{
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",obj);
		}
		catch(Exception e)
		{
			throw e;
		}
	}
	
	public WebElement PlanLevelType(String Value)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+Value+"')]/ancestor::tr[1]/td[2]/div[1]/div[2]/span/span[1]/span/span[1]"));
		return valueType;
	} 
}
