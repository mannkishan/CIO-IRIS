package page.planConfigurator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


import utility.CoreSuperHelper;

public class PlanSetupPage extends CoreSuperHelper{

	private static PlanSetupPage thisTestObj;	
	public synchronized static PlanSetupPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), PlanSetupPage.class);
		return thisTestObj;

	}				

	//This Class contains webelements that are identified in the PlanSetup Tab

	@FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[6]/a")
	//@CacheLookup
	public WebElement checkValidation;

	@FindBy(how = How.XPATH, using = "//span[@class=\"message pull-left\"]")
	@CacheLookup
	public WebElement validationMsg;

	
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-MedicareCOB-_-MedicareCOB-_-NA-_-NA-_-MedicareCOBApplies_-_choice-container")
	public WebElement medicareCOBApplies;
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-MedicareCOB-_-MedicareCOB-_-NA-_-NA-_-MedicareCOBBenefitReserve_-_choice-container")
	public WebElement medicareCOBBenefitReserve;
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-MedicareCOB-_-MedicareCOB-_-NA-_-NA-_-MedicareCOBNonDup_-_choice-container")
	public WebElement medicareCOBNonDuplication;
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-MedicareCOB-_-MedicareCOB-_-NA-_-NA-_-MedicareCOBCarveOutApplies_-_choice-container")
	public WebElement medicareCOBCarveOutApplies;
	

	@FindBy(how = How.XPATH, using = "//*[@id=\"PlanSetup\"]/a")
	@CacheLookup
	public WebElement planSetUp;

	@FindBy(how = How.XPATH, using = "//*[@id=\"verticalBarMenuDetails\"]/div/nav/div[2]/ul/li[1]/a")
	@CacheLookup
	public WebElement planTierSetup;
	
	@FindBy(how = How.CSS, using = ".select2-results__option.select2-results__option--highlighted")
	public WebElement dropDownSelect;
	

	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanSetup-_-PlanTierSetup-_-TwoTier-_-NA\"]/div/div/table/tbody/tr[1]/td[2]/div/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement innTier1Network;

	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanSetup-_-PlanTierSetup-_-TwoTier-_-NA\"]/div/div/table/tbody/tr[1]/td[2]/div/span/span/span[1]/input")
	@CacheLookup
	public WebElement innTier1Networkinput;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanSetup-_-PlanTierSetup-_-TwoTier-_-NA-_-NA-_-NetworkINNT1_-_choice-results\"]/li[1]")
	//@CacheLookup
	public WebElement innTier1NetworkEnter;

	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanSetup-_-PlanTierSetup-_-TwoTier-_-NA-_-NA-_-NetworkINNT1_-_choice\"]")
	//@CacheLookup
	public WebElement errorMessage;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanSetup-_-PlanTierSetup-_-TwoTier-_-NA-_-NA-_-NetworkINNT1_-_choice-results\"]/li[3]")
	//@CacheLookup
	public WebElement innTier1NetworkEPO;

	@FindBy(how = How.XPATH, using = "//*[@id=\"header-wrapper\"]/ul/li[7]/a")
	//@CacheLookup
	public WebElement user;

	@FindBy(how = How.XPATH, using = "//*[@id=\"action_logout\"]")
	//@CacheLookup
	public WebElement logout;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CoinINNT1UrgentCareFac_-_percentage-results\"]")
	@CacheLookup
	public WebElement collapseInputField;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CoinINNT1UrgentCareFac_-_percentage-container\"]")
	@CacheLookup
	public WebElement percentageInputField;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CopayINNT1UrgentCareFac_-_amount-container\"]")
	@CacheLookup
	public WebElement innUrgCareFacCopay;

	@FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[3]/td[2]/div[2]/span/span/span[1]/input")
	@CacheLookup
	public WebElement innUrgCareFacCopayAmount;

	@FindBy(how = How.XPATH, using = "//*[@id=\"subCollapse2\"]/table/tbody/tr[3]/td[2]/div[2]/span/span/span[2]")
	@CacheLookup
	public WebElement innUrgCareFacCopayEnter;

	@FindBy(how = How.XPATH, using = "//*[@id=\"select2-POA_PlanOptions-_-UrgentCare-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CopayINNT1UrgentCareFac_-_amount-container\"]")
	@CacheLookup
	public WebElement innUrgCareFacCopayText;

	@FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[7]/a")
	@CacheLookup
	public WebElement saveButton;

	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-PlanTierSetup-_-TwoTier-_-NA-_-NA-_-NetworkOON_-_choice-container")
	@CacheLookup
	public WebElement outTier1Network;

	public WebElement outTier1NetworkEPO(String outOfNetworkName)
	{
		WebElement oonValue = getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-PlanTierSetup-_-TwoTier-_-NA-_-NA-_-NetworkOON_-_choice-results']/li/span[text()='"+outOfNetworkName+"']"));
		return oonValue;
	}
	
	@FindBy(how = How.XPATH, using = "//ul[@id='select2-POA_PlanSetup-_-PlanTierSetup-_-TwoTier-_-NA-_-NA-_-NetworkINNT1_-_choice-results']/li/span[text()='C']")
	//@CacheLookup
	public WebElement innTier1NetworkCovered;
	
	//#########################################################################################################################################
	@FindBy(how = How.XPATH, using = "//*[@id=\"DataTables_Table_1\"]/tbody/tr/td[4]")
	@CacheLookup
	public WebElement clickSearchedPlan;

	@FindBy(how = How.XPATH, using = "//a[@title='Plan Options']")
	@CacheLookup
	public WebElement clickPlanOptions;

	@FindBy(how = How.XPATH, using = "//*[@id='BenefitTree']/a")
	@CacheLookup
	public WebElement clickBenefits;

	@FindBy(how = How.XPATH, using = "//div[@title='Scroll Down']")
	@CacheLookup
	public WebElement clickScrollDown;

	@FindBy(how = How.XPATH, using = "//*[@id='benefitsTree']/ul/li[22]/ul[1]/li/div/div/div/a")
	@CacheLookup
	public WebElement clickUrgentCare;

	public void scrollDown()
	{
		JavascriptExecutor je = ((JavascriptExecutor) driver);
		je.executeScript("arguments[0].scrollIntoView(true);",clickUrgentCare);
	}

	@FindBy(how = How.XPATH, using = "//span[contains (text(), 'View Service Code')]")
	@CacheLookup
	public WebElement clickViewServiceCode;


	@FindBy(how = How.XPATH, using = "//*[@id='serviceCodeDetail']/div/table/tbody/tr/td[1]")
	@CacheLookup
	public WebElement getServiceCode;


	@FindBy(how = How.XPATH, using = "//*[@id='serviceCodeDetail']/div/table/tbody/tr/td[2]")
	@CacheLookup
	public WebElement getServiceCodeDescription;

	@FindBy(how = How.CSS, using = "span[id='POA_PlanSetup-_-PlanAdmin-_-PlanAdmin-_-NA-_-NA-_-UMRulePenaltyPlanDesign_-_choice']")
	@CacheLookup
	public WebElement umRulePenaltyPlanDesign;
	
	@FindBy(how = How.XPATH, using ="//*[@id='POA_PlanSetup-_-PlanAdmin-_-PlanAdmin-_-NA']/div/div/table/tbody/tr[2]/td[2]/div/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement umRulePenaltyPlanDesign1;
	
	@FindBy(how = How.XPATH, using ="//*[@id='POA_PlanSetup-_-PlanAdmin-_-PlanAdmin-_-NA']/div/div/table/tbody/tr[2]/td[2]/div/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement RulePenaltyPlan1;
	
	public WebElement getRulePenalty(String rulePenalty)
	{
		//WebElement ruleOption = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+rulePenalty+"')]"));
		WebElement ruleOption = getWebDriver().findElement(By.xpath("//*[@id='POA_PlanSetup-_-PlanAdmin-_-PlanAdmin-_-NA']/div/div/table/tbody/tr[2]/td[2]/div/span/span/span[1]/input"));
		return ruleOption;
	
	}
	
	@FindBy(how = How.XPATH, using ="//*[@id='POA_PlanSetup-_-PlanAdmin-_-PlanAdmin-_-NA']/div/div/table/tbody/tr[2]/td[2]/div/span/span/span[1]/input")
	@CacheLookup
	public WebElement RulePenaltyInput;
	
	@FindBy(how = How.CSS, using = ".select2-results__option.select2-results__option--highlighted>span>span")
	@CacheLookup
	public WebElement valueToBeSelected;

	@FindBy(how = How.XPATH, using = "//*[@id='actionsBar']/li[6]/a")
	@CacheLookup
	public WebElement editPlan;

	@FindBy(how = How.XPATH, using = "//*[@id='content-create-customPlan']/form/div[2]/div[6]/div/button[2]")
	@CacheLookup
	public WebElement savePlan;


	@FindBy(how = How.LINK_TEXT, using = "Plan Administration")
	@CacheLookup
	public WebElement planAdministration;

	@FindBy(how = How.XPATH, using = "//*[@id='POA_Base-_-Coinsurance-_-Coinsurance-_-NA-_-NA-_-CoinINNT1Med_-_percentage']")
	@CacheLookup
	public WebElement getCoinsValue;


	@FindBy(how = How.LINK_TEXT, using = "Pediatric Vision")
	@CacheLookup
	public WebElement pediatricVision;

	@FindBy(how = How.XPATH, using = "//*[@class=\"modal-content ui-draggable\"]")
	@CacheLookup
	public WebElement serviceCodePopup;

	@FindBy(how = How.ID, using = "POA_PlanSetup-_-PediatricVision-_-NotCovered")
	@CacheLookup
	public WebElement pediatricVisionNotCovered;

	@FindBy(how = How.ID, using = "POA_PlanSetup-_-PediatricVision-_-CoveredExamOnly")
	@CacheLookup
	public WebElement pediatricVisionCoveredExamOnly;

	@FindBy(how = How.ID, using = "POA_PlanSetup-_-PediatricVision-_-CoveredExamAndHardware")
	@CacheLookup
	public WebElement pediatricVisionCoveredExamAndHardware;


	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-PediatricVision-_-CoveredExamOnly-_-NA-_-NA-_-CoinINNVisPed_-_percentage-container")
	@CacheLookup
	public WebElement inNetworkPediatricVisionCoinsurance;

	@FindBy(how = How.CLASS_NAME, using = "select2-search__field")
	@CacheLookup
	public WebElement inNetworkPediatricVisionCoinsuranceInput;

	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-PediatricVision-_-CoveredExamOnly-_-NA-_-NA-_-UnitVisPedMaxAgeLmt_-_indUnitMax-container")
	@CacheLookup
	public WebElement PediatricVisionAgeLimit;



	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-PediatricVision-_-CoveredExamOnly-_-NA-_-NA-_-CoinOONVisPed_-_percentage-container")
	@CacheLookup
	public WebElement outOfNetworkPediatricVisionCoinsurance;

	@FindBy(how = How.LINK_TEXT, using = "Adult Vision")
	@CacheLookup
	public WebElement adultVision;

	@FindBy(how = How.ID, using = "POA_PlanSetup-_-AdultVision-_-NotCovered")
	@CacheLookup
	public WebElement adultVisionNotCovered;


	@FindBy(how = How.ID, using = "POA_PlanSetup-_-AdultVision-_-CoveredExamOnly")
	@CacheLookup
	public WebElement adultVisionCoveredExamOnly;

	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-AdultVision-_-CoveredExamOnly-_-NA-_-NA-_-CoinINNVisAdult_-_percentage-container")
	@CacheLookup
	public WebElement inNetworkAdultVisionCoinsurance;

	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_PlanSetup-_-AdultVision-_-CoveredExamOnly-_-NA\"]/div/div/table/tbody/tr[1]/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement inNetworkAdultVisionCoinsuranceInput;

	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-AdultVision-_-CoveredExamOnly-_-NA-_-NA-_-CoinOONVisAdult_-_percentage-container")
	@CacheLookup
	public WebElement outOfNetworkAdultVisionCoinsurance;

	@FindBy(how = How.XPATH, using = "//*[@id='POA_PlanSetup-_-AdultVision-_-CoveredExamOnly-_-NA']/div/div/table/tbody/tr[2]/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement outOfNetworkAdultVisionCoinsuranceInput;
	
	@FindBy(how = How.XPATH, using = "//input[@class='select2-search__field']")
	public WebElement dropDownInput;

	//#########################################################################################################################################

	@FindBy(how = How.LINK_TEXT, using = "Mail Setup")
	@CacheLookup
	public WebElement mailSetup;

	@FindBy(how = How.ID, using = "POA_PlanSetup-_-MailSetup-_-MailCovg")
	@CacheLookup
	public WebElement mailCoverage;

	@FindBy(how = How.ID, using = "POA_PlanSetup-_-MailSetup-_-NotCovered")
	@CacheLookup
	public WebElement mailCoverageNotCovered;

	@FindBy(how = How.XPATH, using = "//div[@id='MailCovg']/div/h4/span")
	@CacheLookup
	public WebElement mailCoverageText;

	@FindBy(how = How.XPATH, using = "//div[@id='MailSetupGroup']/div[2]/div/h4/span")
	@CacheLookup
	public WebElement mailCoverageNotCoveredText;

	@FindBy(how = How.LINK_TEXT, using = "Retail Setup")
	@CacheLookup
	public WebElement retailSetup;

	@FindBy(how = How.ID, using = "POA_PlanSetup-_-RetailSetup-_-RetailCovg")
	@CacheLookup
	public WebElement retailCoverage;
	
	@FindBy(how = How.ID, using = "POA_PlanSetup-_-RetailSetup-_-NotCovered")
	@CacheLookup
	public WebElement retailCoverageNotCovered;
	
	@FindBy(how = How.XPATH, using = "//div[@id='RetailSetupGroup']/div[2]/div/h4/span")
	@CacheLookup
	public WebElement retailCoverageNotCoveredText;

	@FindBy(how = How.XPATH, using = "//div[@id='RetailCovg']/div/h4/span")
	@CacheLookup
	public WebElement retailCoverageText;

	@FindBy(how = How.LINK_TEXT, using = "Network")
	@CacheLookup
	public WebElement network;

	@FindBy(how = How.LINK_TEXT, using = "Dental Network")
	@CacheLookup
	public WebElement dentalNetwork;

	@FindBy(how = How.ID, using = "POA_PlanSetup-_-Network-_-AnthemBaseNetwork")
	@CacheLookup
	public WebElement anthemBaseNetworkRadioButton;

	@FindBy(how = How.ID, using = "POA_PlanSetup-_-Network-_-AnthemBaseNetwork-_-NA-_-NA-_-NetworkType_-_choice")
	public WebElement anthemBaseNetwork;
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-Network-_-AnthemBaseNetwork-_-NA-_-NA-_-NetworkType_-_choice-container")
	@CacheLookup
	public WebElement anthemBaseNetworkValue;
	
	@FindBy(how = How.ID, using = "POA_PlanSetup-_-Network-_-R90Network")
	@CacheLookup
	public WebElement R90NetworkRadioButton;

	@FindBy(how = How.ID, using = "POA_PlanSetup-_-Network-_-R90Network-_-NA-_-NA-_-NetworkType_-_choice")
	public WebElement R90Network;
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-Network-_-R90Network-_-NA-_-NA-_-NetworkType_-_choice-container")
	@CacheLookup
	public WebElement R90NetworkValue;
	
	@FindBy(how = How.CSS, using = "span[id='select2-POA_PlanSetup-_-Network-_-R90Network-_-NA-_-NA-_-R90RetailDaySupplyMax_-_indUnitMax-container']")
	@CacheLookup
	public WebElement R90NetworkMaximum;

	@FindBy(how = How.XPATH, using = "//div[@id='POA_PlanSetup-_-Network-_-R90Network-_-NA']/div/div/table/tbody/tr[2]/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement R90NetworkMaximumText;


	@FindBy(how = How.ID, using = "POA_PlanSetup-_-Network-_-R90Network-_-NA-_-NA-_-R90RetailDaySupplyMax_-_benefitPeriod")
	public WebElement R90NetworkBenefitPeriod;
	

	@FindBy(how = How.ID, using = "POA_PlanSetup-_-Network-_-S90Network")
	@CacheLookup
	public WebElement S90NetworkRadioButton;

	@FindBy(how = How.ID, using = "POA_PlanSetup-_-Network-_-S90Network-_-NA-_-NA-_-NetworkType_-_choice")
	public WebElement S90NetworkType;
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-Network-_-S90Network-_-NA-_-NA-_-NetworkType_-_choice-container")
	@CacheLookup
	public WebElement S90NetworkValue;
	
	@FindBy(how = How.ID, using = "POA_PlanSetup-_-Network-_-S90Network-_-NA-_-NA-_-FillsExceed90_-_choice")
	public WebElement S90FillsExceed90;

	@FindBy(how = How.CSS, using = "span[id='select2-POA_PlanSetup-_-Network-_-S90Network-_-NA-_-NA-_-S90RetailDaySupplyMax_-_indUnitMax-container']")
	@CacheLookup
	public WebElement S90NetworkMaximum;

	@FindBy(how = How.XPATH, using = "//div[@id='POA_PlanSetup-_-Network-_-S90Network-_-NA']/div/div/table/tbody/tr[3]/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement S90NetworkMaximumText;


	@FindBy(how = How.ID, using = "POA_PlanSetup-_-Network-_-S90Network-_-NA-_-NA-_-S90RetailDaySupplyMax_-_benefitPeriod")
	public WebElement S90NetworkBenefitPeriod;


	@FindBy(how = How.CSS, using = "span[id='select2-POA_PlanSetup-_-Network-_-S90Network-_-NA-_-NA-_-NmbrOfFillsToForceToS90Retail_-_indUnitMax-container']")
	@CacheLookup
	public WebElement S90FillsToForceMaximum;

	@FindBy(how = How.XPATH, using = "//div[@id='POA_PlanSetup-_-Network-_-S90Network-_-NA']/div/div/table/tbody/tr[4]/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement S90FillsToForceMaximumText;


	@FindBy(how = How.ID, using = "POA_PlanSetup-_-Network-_-S90Network-_-NA-_-NA-_-NmbrOfFillsToForceToS90Retail_-_benefitPeriod")
	public WebElement S90FillsToForceBenefitPeriod;



	//#########################################################################################################################################
	/*@FindBy(how = How.CSS, using = "span[id='select2-POA_PlanSetup-_-DentalNetwork-_-DentalNetwork-_-NA-_-NA-_-DentalNetwork_-_choice-container']")
	@CacheLookup
	public WebElement dentalNetworkType;*/
	//
	@FindBy(how = How.ID, using = "POA_PlanSetup-_-DentalNetwork-_-DentalNetwork-_-NA-_-NA-_-DentalNetwork_-_choice")
	public WebElement dentalNetworkType;
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-DentalNetwork-_-DentalNetwork-_-NA-_-NA-_-DentalNetwork_-_choice-container")
	@CacheLookup
	public WebElement dentalNetworkValue;

	@FindBy(how = How.LINK_TEXT, using = "Plan Type")
	@CacheLookup
	public WebElement dentalPlanType;

	@FindBy(how = How.ID, using = "POA_PlanSetup-_-PlanType-_-Embedded")
	@CacheLookup
	public WebElement embeddedDental;

	@FindBy(how = How.ID, using = "POA_PlanSetup-_-PlanType-_-Standalone")
	@CacheLookup
	public WebElement standaloneDental;

	@FindBy(how = How.XPATH, using = "//div[@id='Embedded']/div/h4/span")
	@CacheLookup
	public WebElement embeddedDentalValue;

	@FindBy(how = How.XPATH, using = "//div[@id='Standalone']/div/h4/span")
	@CacheLookup
	public WebElement standaloneDentalValue;

	@FindBy(how = How.LINK_TEXT, using = "Pediatric Dental")
	@CacheLookup
	public WebElement pediatricDental;


	@FindBy(how = How.ID, using = "POA_PlanSetup-_-PediatricDental-_-Covered")
	@CacheLookup
	public WebElement pediatricDentalCovered;
	
	@FindBy(how = How.ID, using = "POA_PlanSetup-_-PediatricDental-_-NotCovered")
	@CacheLookup
	public WebElement pediatricDentalNotCovered;
	
	@FindBy(how = How.XPATH, using = "//div[@id='PediatricDentalGroup']/div[1]/div/h4/span")
	@CacheLookup
	public WebElement pediatricDentalCoveredValue;
	
	@FindBy(how = How.XPATH, using = "//div[@id='PediatricDentalGroup']/div[2]/div/h4/span")
	@CacheLookup
	public WebElement pediatricDentalNotCoveredValue;

	@FindBy(how = How.CSS, using = "span[id='select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-NA-_-NA-_-UnitPedMaxAge_-_indUnitMax-container']")
	@CacheLookup
	public WebElement pediatricDentalMaximum;

	@FindBy(how = How.XPATH, using = "//div[@id='POA_PlanSetup-_-PediatricDental-_-Covered-_-NA']/div/div/table/tbody/tr/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement pediatricDentalMaximumText;

	@FindBy(how = How.XPATH, using = "//ul[@id='select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-NA-_-NA-_-UnitPedMaxAge_-_indUnitMax-results']/li/span")
	@CacheLookup
	public WebElement pediatricDentalMaximumValue;

	
	
	@FindBy(how = How.LINK_TEXT, using = "Medicare COB")
	public WebElement medicareCOB;
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-PlanAdmin-_-PlanAdmin-_-NA-_-NA-_-COBAdmMtd_-_choice-container")
	public WebElement COBAdminMethod;
	
	@FindBy(how = How.ID, using = "POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply")
	public WebElement pediatricDentalWaitingPeriodsApply;

	@FindBy(how = How.ID, using = "POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-NoWaitingPeriods")
	public WebElement pediatricDentalNoWaitingPeriods;

	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricBasicWaitingPeriod_-_choice-container")
	public WebElement pediatricDentalBasicWaitingPeriod;

	public WebElement dentalPediatricBasicWaitingPeriod(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricBasicWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}

	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricDiagPrevWaitingPeriod_-_choice-container")
	public WebElement pediatricDentalPreventiveWaitingPeriod;

	public WebElement dentalPediatricPreventiveWaitingPeriod(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricDiagPrevWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}

	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricEndodonticWaitingPeriod_-_choice-container")
	public WebElement pediatricDentalEndodonticWaitingPeriod;


	public WebElement dentalPediatricEndodonticWaitingPeriod(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricEndodonticWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}

	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricMajorWaitingPeriod_-_choice-container")
	public WebElement pediatricDentalMajorWaitingPeriod;

	public WebElement dentalPediatricMajorWaitingPeriod(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricMajorWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricOralSurgeryWaitingPeriod_-_choice-container")
	public WebElement pediatricDentalOralSurgeryWaitingPeriod;

	public WebElement dentalPediatricOralSurgeryWaitingPeriod(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricOralSurgeryWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricOrthoWaitingPeriod_-_choice-container")
	public WebElement pediatricDentalOrthodonticWaitingPeriod;

	public WebElement dentalPediatricOrthodonticWaitingPeriod(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricOrthoWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricOrthoCosmeticWaitingPeriod_-_choice-container")
	public WebElement pediatricDentalOrthodonticCosmeticWaitingPeriod;

	public WebElement dentalPediatricOrthodonticCosmeticWaitingPeriod(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricOrthoCosmeticWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricPeriodontalWaitingPeriod_-_choice-container")
	public WebElement pediatricDentalPeriodontalWaitingPeriod;

	public WebElement dentalPediatricPeriodontalWaitingPeriod(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricPeriodontalWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricProsthoWaitingPeriod_-_choice-container")
	public WebElement pediatricDentalProstheticWaitingPeriod;

	public WebElement dentalPediatricProstheticWaitingPeriod(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-PediatricDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-PediatricProsthoWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}
		
	
	@FindBy(how = How.ID, using = "POA_PlanSetup-_-OONSetup-_-OONNotCovered")
	public WebElement dentalOONNotCovered;
	
	@FindBy(how = How.XPATH, using = "//div[@id='OONSetupGroup']/div[2]/div/h4/span")
	@CacheLookup
	public WebElement dentalOONNotCoveredText;
	
	@FindBy(how = How.ID, using = "POA_PlanSetup-_-OONSetup-_-OONCovered")
	@CacheLookup
	public WebElement dentalOONCovered;
	
	@FindBy(how = How.XPATH, using = "//div[@id='OONSetupGroup']/div[1]/div/h4/span")
	@CacheLookup
	public WebElement dentalOONCoveredText;
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-OONSetup-_-OONCovered-_-NA-_-NA-_-UnitOONReimbursementPercentile_-_indUnitMax-container")
	@CacheLookup
	public WebElement dentalOONPercentile;
	
	@FindBy(how = How.XPATH, using = "//div[@id='POA_PlanSetup-_-OONSetup-_-OONCovered-_-NA']/div/div/table/tbody/tr/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement dentalOONPercentileText;
	
	
	@FindBy(how = How.ID, using = "POA_PlanSetup-_-OONSetup-_-OONCovered-_-NA-_-NA-_-UnitOONReimbursementPercentile_-_benefitPeriod")
	public WebElement dentalOONBenefit;
		
	
	@FindBy(how = How.LINK_TEXT, using = "Adult Dental")
	@CacheLookup
	public WebElement adultDental;
	
	@FindBy(how = How.ID, using = "POA_PlanSetup-_-AdultDental-_-NotCovered")
	@CacheLookup
	public WebElement adultDentalNotCovered;
	
	@FindBy(how = How.XPATH, using = "//div[@id='AdultDentalGroup']/div[2]/div/h4/span")
	@CacheLookup
	public WebElement adultDentalNotCoveredValue;
	
	@FindBy(how = How.ID, using = "POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-NoWaitingPeriods")
	@CacheLookup
	public WebElement adultDentalNoWaitingPeriods;
	
	@FindBy(how = How.ID, using = "POA_PlanSetup-_-AdultDental-_-Covered")
	@CacheLookup
	public WebElement adultDentalCovered;
	
	@FindBy(how = How.XPATH, using = "//div[@id='AdultDentalGroup']/div[1]/div/h4/span")
	@CacheLookup
	public WebElement adultDentalCoveredValue;
		
	@FindBy(how = How.ID, using = "POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply")
	@CacheLookup
	public WebElement adultDentalWaitingPeriodsApply;
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-AdultBasicWaitingPeriod_-_choice-container")
	@CacheLookup
	public WebElement adultDentalBasicWaitingPeriod;
	
	public WebElement dentalAdultBasicWaitingPeriod(String type)
	{
		WebElement valueType=getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-AdultBasicWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-AdultDiagPrevWaitingPeriod_-_choice-container")
	@CacheLookup
	public WebElement adultDentalPreventiveWaitingPeriod;
	
	public WebElement dentalAdultPreventiveWaitingPeriod(String type)
	{
		WebElement valueType=getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-AdultDiagPrevWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-AdultEndodonticWaitingPeriod_-_choice-container")
	@CacheLookup
	public WebElement adultDentalEndodonticWaitingPeriod;
	
	public WebElement dentalAdultEndodonticWaitingPeriod(String type)
	{
		WebElement valueType=getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-AdultEndodonticWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-AdultMajorWaitingPeriod_-_choice-container")
	@CacheLookup
	public WebElement adultDentalMajorWaitingPeriod;
	
	public WebElement dentalAdultMajorWaitingPeriod(String type)
	{
		WebElement valueType=getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-AdultMajorWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-AdultOralSurgeryWaitingPeriod_-_choice-container")
	@CacheLookup
	public WebElement adultDentalOralSurgeryWaitingPeriod;
	
	public WebElement dentalAdultOralSurgeryWaitingPeriod(String type)
	{
		WebElement valueType=getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-AdultOralSurgeryWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-AdultPeriodontalWaitingPeriod_-_choice-container")
	@CacheLookup
	public WebElement adultDentalPeriodontalWaitingPeriod;
	
	public WebElement dentalAdultPeriodontalWaitingPeriod(String type)
	{
		WebElement valueType=getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-AdultPeriodontalWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}
	
	@FindBy(how = How.ID, using = "select2-POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-AdultProsthoWaitingPeriod_-_choice-container")
	@CacheLookup
	public WebElement adultDentalProsthodonticWaitingPeriod;
	
	public WebElement dentalAdultProsthodonticWaitingPeriod(String type)
	{
		WebElement valueType=getWebDriver().findElement(By.xpath("//ul[@id='select2-POA_PlanSetup-_-AdultDental-_-Covered-_-WaitingPeriods-_-WaitingPeriodsApply-_-AdultProsthoWaitingPeriod_-_choice-results']/li/span[text()='"+type+"']"));
		return valueType;
	}		
	
		

	//###############################################################################################################################################
	
	public static void compareservicecode(String Expected,String Actual){
		if(Expected.equals(Actual))
		{
			RESULT_STATUS=true;
			log(PASS, "Service Code is displayed as expected","Upon Clicking 'View Service Code Button'Popup with Service code is displayed sucessfully, RESULT=PASS");
		}
		else
		{
			RESULT_STATUS=false;
			log(FAIL, "Service Code is NOT displayed ","Upon Clicking 'View Service Code Button'NO Popup with Service code is displayed, RESULT=FAIL");
		}
	}
	public static void compareservicecodedescription(String Expected,String Actual){
		if(Expected.equals(Actual))
		{
			RESULT_STATUS=true;
			log(PASS, "Service Code Description is displayed as expected","Upon Clicking 'View Service Code Button'Popup with Service code Description is displayed sucessfully, RESULT=PASS");
		}
		else
		{
			RESULT_STATUS=false;
			log(FAIL, "Service Code Description is NOT displayed ","Upon Clicking 'View Service Code Button'NO Popup with Service code Description is displayed, RESULT=FAIL");
		}
	}
	public WebElement COB(String type)
    {
           WebElement valueType=getWebDriver().findElement(By.xpath("//span[contains(text(),'"+type+"')]/ancestor::tr[1]/td[2]/div/div/span/span[@class='selection']/span/span[@class='select2-selection__rendered']"));
           return valueType;
    }
    
    public WebElement setCOB(String type)
    {
           WebElement valueType=getWebDriver().findElement(By.xpath("//span[contains(text(),'"+type+"')]/ancestor::tr[1]/td[2]/div/span/span/span[1]/input"));
           return valueType;
    }

    /**This Method is used to Update COB in a Plan
     * @param strCOB : COB that needs to be Updaed-EG:COB Benefit Reserve
     * @param strCOBValue : Yes or No
     */
    public void updateCOB(String strCOB,String strCOBValue) {
    	try{
        seClick(PlanSetupPage.get().COB(strCOB), "COB");
        seSetText(PlanSetupPage.get().setCOB(strCOB), strCOBValue, "Update COB value ");
        PlanSetupPage.get().setCOB(strCOB).sendKeys(Keys.ENTER);
    	}
    	catch (Exception e) {

    		e.printStackTrace();
			log(ERROR, "Exception has occured While Updating CO", e.getLocalizedMessage());
		}
    	
 }



	/**
	 * This method will the set up  Pediatric Vision in the Plan Set Up page of a plan
	 * @param strPediatricVision
	 * @throws Exception
	 * Test data sheet should contain the below columns InNetworkPediatricCoinsurance,OutOfNetworkPediatricCoinsurance,PediatricVisionMaximumAge
	 */
	public void setPediatricVision(String strPediatricVision) throws Exception
	{
		try
		{
			waitForPageLoad(360);
			seClick(PlanSetupPage.get().pediatricVision, "Pediatric Vision");
			waitForPageLoad(360);
			switch (strPediatricVision.toUpperCase()) {
			case "NOT COVERED":
				seClick(PlanSetupPage.get().pediatricVisionNotCovered, "Pediatric Vision Not Covered");
				break;
			case "COVERED EXAM ONLY":
				String inNetworkCoinsurance = getCellValue("InNetworkPediatricCoinsurance");
				String outOFNetworkCoinsurance = getCellValue("OutOfNetworkPediatricCoinsurance");
				String pediatricVisionAgelimit = getCellValue("PediatricVisionMaximumAge");
				waitForPageLoad(2,360);
				seClick(PlanSetupPage.get().pediatricVisionCoveredExamOnly, "Pediatric Vision Covered Exam Only");
				waitForPageLoad(3, 360);
				seClick(PlanSetupPage.get().inNetworkPediatricVisionCoinsurance, "In Network Pediatric Coinsurance");
				waitForPageLoad(3, 360);
				seSetText(PlanSetupPage.get().inNetworkPediatricVisionCoinsuranceInput, inNetworkCoinsurance, "In Network Pediatric Coinsurance Input ");
				waitForPageLoad(3, 360);
				seClick(getWebDriver().findElement(By.cssSelector(".select2-results__option.select2-results__option--highlighted>span>span")), "In Network Pediatric Coinsurance");
				waitForPageLoad(3, 360);
				seClick(PlanSetupPage.get().outOfNetworkPediatricVisionCoinsurance, "Out of Network Pediatric Vision Coinsurance");
				waitForPageLoad(360);
				seSetText(PlanSetupPage.get().inNetworkPediatricVisionCoinsuranceInput, outOFNetworkCoinsurance, "Out Of Network Pediatric Vision Coinsurance Input ");
				waitForPageLoad(360);
				seClick(getWebDriver().findElement(By.cssSelector(".select2-results__option.select2-results__option--highlighted>span>span")), "Out of Network Pediatric Vision Coinsurance");
				waitForPageLoad(3,360);
				seClick(PlanSetupPage.get().PediatricVisionAgeLimit, "Pediatric Vision Age limit");
				waitForPageLoad(360);
				seSetText(PlanSetupPage.get().inNetworkPediatricVisionCoinsuranceInput, pediatricVisionAgelimit, "Pediatric Vision Age limit Input ");
				waitForPageLoad(360);
				seClick(getWebDriver().findElement(By.cssSelector(".select2-results__option.select2-results__option--highlighted>span>span")), "Pediatric Vision Age limit");

				break;
			case "COVERED EXAM AND HARDWARE":

				seClick(PlanSetupPage.get().pediatricVisionCoveredExamAndHardware, "Pediatric Vision Covered Exam and Hardware");
				break;

			default:
				log(FAIL, "Set value for Pediatric Vision", "Not a valid option", true);
				throw new IllegalArgumentException("Not a valid Option in the Pediatric Vision tab");
			}


		}
		catch (Exception e) {

			throw e;
		}
	}


	/**
	 * This method will set Adult Vision in the Plan Set Up tab of the Plan
	 * @param strAdultVision: Adult vision option that needs to be selected
	 * @throws Exception
	 * Test Data sheet should contain the columns , InNetworkAdultCoinsurance , OutOfNetworkAdultCoinsurance
	 */
	public void setAdultVision(String strAdultVision) throws Exception
	{
		try
		{
			waitForPageLoad(2,360);
			seClick(PlanSetupPage.get().adultVision, "Adult Vision");
			waitForPageLoad(3,360);
			switch (strAdultVision.toUpperCase()) {
			case "NOT COVERED":
				seClick(PlanSetupPage.get().adultVisionNotCovered, "Adult Vision Not Covered");
				break;
			case "COVERED EXAM ONLY":
				String inNetworkCoinsurance = getCellValue("InNetworkAdultCoinsurance");
				String outOFNetworkCoinsurance = getCellValue("OutOfNetworkAdultCoinsurance");
				seClick(PlanSetupPage.get().adultVisionCoveredExamOnly, "Adult Vision Covered Exam Only");
				waitForPageLoad(3, 360);
				seClick(PlanSetupPage.get().inNetworkAdultVisionCoinsurance, "In Network Adult Coinsurance");
				waitForPageLoad(1, 360);
				seSetText(PlanSetupPage.get().inNetworkAdultVisionCoinsuranceInput, inNetworkCoinsurance, "In Netweork Adult Vision Coinsurance");
				waitForPageLoad(1, 360);
				seClick(getWebDriver().findElement(By.cssSelector(".select2-results__option.select2-results__option--highlighted>span>span")), "In Network Adult Coinsurance");
				waitForPageLoad(2, 360);
				seWaitForClickableWebElement(PlanSetupPage.get().outOfNetworkAdultVisionCoinsurance, 120);
				seClick(PlanSetupPage.get().outOfNetworkAdultVisionCoinsurance, "Out of Network Adult Coinsurance");
				waitForPageLoad(2, 360);
				seSetText(PlanSetupPage.get().outOfNetworkAdultVisionCoinsuranceInput, outOFNetworkCoinsurance, "Out of  Netweork Adult Vision Coinsurance");
				waitForPageLoad(1, 360);
				seClick(getWebDriver().findElement(By.cssSelector(".select2-results__option.select2-results__option--highlighted>span>span")), "Out of Network Adult Coinsurance");
				break;
			case "COVERED EXAM AND HARDWARE":

				seClick(PlanSetupPage.get().pediatricVisionCoveredExamAndHardware, "Pediatric Vision Covered Exam and Hardware");
				break;

			default:
				log(FAIL, "Set value for Pediatric Vision", "Not a valid option", true);
				throw new IllegalArgumentException("Not a valid Option in the Pediatric Vision tab");
			}


		}
		catch (Exception e) {

			throw e;
		}
	}

	/**
	 * This method will select the mail coverage radio button based on input
	 * 
	 * @param strMailCoverageType : MailCoverageType option that needs to be selected
	 * @return
	 * @throws Exception
	 */
	public String setMailCoverage(String strMailCoverageType) throws Exception
	{
		String mailCoverageText="";
		try
		{
			waitForPageLoad(360);
			seClick(PlanSetupPage.get().mailSetup,"Mail Setup");
			waitForPageLoad(360);			
				if(strMailCoverageType.equalsIgnoreCase("Covered")){
					if(!PlanSetupPage.get().mailCoverage.isSelected())
					{
						seClick(PlanSetupPage.get().mailCoverage,"Mail Coverage");						
					}
					mailCoverageText=seGetElementValue(PlanSetupPage.get().mailCoverageText).toString().trim();
				}
				else
				{
					if(!PlanSetupPage.get().mailCoverageNotCovered.isSelected())
					{
						seClick(PlanSetupPage.get().mailCoverageNotCovered,"Not Covered");						
					}
					mailCoverageText=seGetElementValue(PlanSetupPage.get().mailCoverageNotCoveredText);
				}	
		}
		catch(Exception e)
		{
			log(ERROR,"Set Mail Coverage","Exception Occured " +e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
		return mailCoverageText;
	}

	/**
	 * This method will select the retail coverage radio button based on input
	 * 
	 * @param strRetailCoverageText :RetailCoverageText option that needs to be selected
	 * @return
	 * @throws Exception
	 */
	public String setRetailCoverage(String strRetailCoverageText) throws Exception
	{
		String retailCoverageText="";
		try
		{
			waitForPageLoad(360);
			seClick(PlanSetupPage.get().retailSetup,"Mail Setup");
			waitForPageLoad(360);
			if(strRetailCoverageText.equalsIgnoreCase("Covered"))
			{
				if(!PlanSetupPage.get().retailCoverage.isSelected())
				{
				seClick(PlanSetupPage.get().retailCoverage,"Retail Coverage");
				waitForPageLoad(360);
				}
				retailCoverageText=seGetElementValue(PlanSetupPage.get().retailCoverageText).toString().trim();
			}
			else{
				if(!PlanSetupPage.get().retailCoverageNotCovered.isSelected())
				{
					seClick(PlanSetupPage.get().retailCoverageNotCovered,"Not Covered");	
					waitForPageLoad(360);
				}
				retailCoverageText=seGetElementValue(PlanSetupPage.get().retailCoverageNotCoveredText);
			}
		}
		catch(Exception e)
		{
			log(ERROR,"Set Retail Coverage","Exception Occured " +e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
		return retailCoverageText;
	}

	/**
	 * This method will select the network type radio button and selects the values from drop down based on input passed 
	 * 
	 * @param strNetworkType : Network type option that need to be selected
	 * @return
	 * @throws Exception
	 * Test Data sheet should contain the columns:AnthemBaseNetworkValue,R90NetworkValue,R90MaximumValue,R90BenefitPeriodValue,S90NetworkType,S90FillsExceed90Value,
	 *                                            S90MaximumValue,S90BenefitPeriodValue,S90FillsToForceMaximumValue,S90FillsToForceBenefitPeriodValue
	 */
	public String setNetworkType(String strNetworkType) throws Exception
	{
		String networkValue="";
		try
		{
			waitForPageLoad(360);
			seClick(PlanSetupPage.get().network,"Network link");
			waitForPageLoad(2,360);
			switch (strNetworkType) {
			case "Anthem Base Network":
				String strAnthemBaseNetworkValue=getCellValue("AnthemBaseNetworkValue");
				if(!PlanSetupPage.get().anthemBaseNetworkRadioButton.isSelected())
				{
					seClick(PlanSetupPage.get().anthemBaseNetworkRadioButton,"anthemBaseNetworkRadioButton");					
					waitForPageLoad(2,360);	
				}
				waitForPageLoad(2,360);
				seSelectText(PlanSetupPage.get().anthemBaseNetwork,strAnthemBaseNetworkValue,"Anthem base network",500);											
				networkValue=seGetElementValue(PlanSetupPage.get().anthemBaseNetworkValue);
				break;
			case "R90 Network":
				String strR90Network=getCellValue("R90NetworkValue");
				String strR90MaximumValue=getCellValue("R90MaximumValue");
				String strR90BenefitPeriodValue=getCellValue("R90BenefitPeriodValue");
				if(!PlanSetupPage.get().R90NetworkRadioButton.isSelected())
				{
					seClick(PlanSetupPage.get().R90NetworkRadioButton,"R90NetworkRadioButton");
					waitForPageLoad(360);
				}
				waitForPageLoad(2,360);
				seSelectText(PlanSetupPage.get().R90Network,strR90Network,"R90 Network",500);
				waitForPageLoad(360);				
				networkValue=seGetElementValue(PlanSetupPage.get().R90NetworkValue);
				seClick(PlanSetupPage.get().R90NetworkMaximum,"R90NetworkMaximum");
				waitForPageLoad(360);
				seSetText(PlanSetupPage.get().R90NetworkMaximumText, strR90MaximumValue, "R90NetworkMaximumText");
				waitForPageLoad(360);
				seClick(getWebDriver().findElement(By.cssSelector(".select2-results__option.select2-results__option--highlighted>span>span")), "R90NetworkMaximumText");
				waitForPageLoad(2, 360);
				seSelectText(PlanSetupPage.get().R90NetworkBenefitPeriod,strR90BenefitPeriodValue, "R90NetworkBenefitPeriod",500);
				waitForPageLoad(360);				
				break;
			case "S90 Network":
				String strS90NetworkType=getCellValue("S90NetworkType");
				String strS90FillsExceed90Value=getCellValue("S90FillsExceed90Value");
				String strS90MaximumValue=getCellValue("S90MaximumValue");
				String strS90BenefitPeriodValue=getCellValue("S90BenefitPeriodValue");
				String strS90FillsToForceMaximumValue=getCellValue("S90FillsToForceMaximumValue");
				String strS90FillsToForceBenefitPeriodValue=getCellValue("S90FillsToForceBenefitPeriodValue");
				if(!PlanSetupPage.get().S90NetworkRadioButton.isSelected())
				{
					seClick(PlanSetupPage.get().S90NetworkRadioButton,"S90NetworkRadioButton");
					waitForPageLoad(360);
				}
				waitForPageLoad(2,360);
				seSelectText(PlanSetupPage.get().S90NetworkType,strS90NetworkType,"S90NetworkType",500);
				waitForPageLoad(360);				
				seSelectText(PlanSetupPage.get().S90FillsExceed90,strS90FillsExceed90Value,"S90FillsExceed90",500);
				waitForPageLoad(360);
				networkValue=seGetElementValue(PlanSetupPage.get().S90NetworkValue);
				seClick(PlanSetupPage.get().S90NetworkMaximum,"S90NetworkMaximum");
				waitForPageLoad(360);
				seSetText(PlanSetupPage.get().S90NetworkMaximumText, strS90MaximumValue, "S90NetworkMaximumText");
				waitForPageLoad(360);
				seClick(getWebDriver().findElement(By.cssSelector(".select2-results__option.select2-results__option--highlighted>span>span")), "S90NetworkMaximumText");
				waitForPageLoad(2, 360);
				seSelectText(PlanSetupPage.get().S90NetworkBenefitPeriod,strS90BenefitPeriodValue, "s90NetworkBenefitPeriod",500);
				waitForPageLoad(360);				
				seClick(PlanSetupPage.get().S90FillsToForceMaximum,"S90FillsToForceMaximum");
				waitForPageLoad(360);
				seSetText(PlanSetupPage.get().S90FillsToForceMaximumText, strS90FillsToForceMaximumValue, "S90FillsToForceMaximumText");
				waitForPageLoad(360);
				seClick(getWebDriver().findElement(By.cssSelector(".select2-results__option.select2-results__option--highlighted>span>span")), "S90FillsToForceMaximumText");
				waitForPageLoad(2, 360);
				seSelectText(PlanSetupPage.get().S90FillsToForceBenefitPeriod,strS90FillsToForceBenefitPeriodValue, "S90FillsToForceBenefitPeriod",500);
				waitForPageLoad(360);
				break;

			default:
				break;
			}
		}
		catch(Exception e)
		{
			log(ERROR,"Set NetworkType","Exception Occured " +e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
		return networkValue;
	}

	/**
	 * This method will select the network type drop down and selects the values based on input passed 
	 * 
	 * @param strDentalNetwork :  Network type option that need to be selected
	 * @return
	 * @throws Exception
	 */
	public String setDentalNetwork(String strDentalNetwork) throws Exception
	{
		String dentalNetwork="";
		try		
		{
			waitForPageLoad(360);
			seClick(PlanSetupPage.get().dentalNetwork,"Dental Network");
			waitForPageLoad(2,360);			
			seSelectText(PlanSetupPage.get().dentalNetworkType, strDentalNetwork, "DentalNetworkValue", 500);			
			dentalNetwork=seGetElementValue(PlanSetupPage.get().dentalNetworkValue);			
		}
		catch(Exception e)
		{
			log(ERROR,"Set Dental Ntwork","Exception Occured " +e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
		return dentalNetwork;
	}

	/**
	 * @param strDentalPlanType: Dental plan type that need to be selected
	 * @return
	 * @throws Exception
	 */
	public String setDentalPlanType(String strDentalPlanType) throws Exception
	{
		String dentalPlanType="";
		try		
		{
			waitForPageLoad(360);
			seClick(PlanSetupPage.get().dentalPlanType,"Plan Type");
			waitForPageLoad();
			if(strDentalPlanType.equalsIgnoreCase("Embedded"))				
			{	if(!PlanSetupPage.get().embeddedDental.isSelected())
				{
					seClick(PlanSetupPage.get().embeddedDental,"Embedded");
					waitForPageLoad();					
				}
				dentalPlanType=seGetElementValue(PlanSetupPage.get().embeddedDentalValue);
			}
			else{
				if(!PlanSetupPage.get().standaloneDental.isSelected())
				{
					seClick(PlanSetupPage.get().standaloneDental,"StandAlone");
					waitForPageLoad();					
				}	
				dentalPlanType=seGetElementValue(PlanSetupPage.get().standaloneDentalValue);
			}
		}
		catch(Exception e)
		{
			log(ERROR,"Set Dental plan Type","Exception Occured " +e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
		return dentalPlanType;
	}

	/**
	 * This method sets the pediatric dental value based on the inputs passed
	 * 
	 * @param strPediatricDentalType: Pediatric type that need to be selected
	 * @return
	 * @throws Exception
	 * 
	 * Test Data sheet should contain the columns:AgeLimit,WaitingPeriod,PediatricBasicWaitingPeriod,PediatricPreventiveWaitingPeriod,PediatricEndodonticWaitingPeriod,PediatricMajorWaitingPeriod
	 *                                            PediatricOralSurgeryWaitingPeriod,PediatricOrthodonticWaitingPeriod,PediatricOrthodonticCosmeticWaitingPeriod,PediatricPeriodontalWaitingPeriod
	 *                                            PediatricProstheticWaitingPeriod
	 */
	public String setPediatricDental(String strPediatricDentalType) throws Exception
	{
		String pediatricDentalValue="";
		
		try		
		{
			waitForPageLoad(360);
			seClick(PlanSetupPage.get().pediatricDental,"Pediatic dental");
			waitForPageLoad();
			if(strPediatricDentalType.equalsIgnoreCase("Covered")) {
				String strAgeLimit=getCellValue("AgeLimit");
				String waitingPeriodsApply=getCellValue("WaitingPeriod");
				String strPediatricBasicWaitingPeriod=getCellValue("PediatricBasicWaitingPeriod");
				String strPediatricPreventiveWaitingPeriod=getCellValue("PediatricPreventiveWaitingPeriod");
				String strPediatricEndodonticWaitingPeriod=getCellValue("PediatricEndodonticWaitingPeriod");
				String strPediatricMajorWaitingPeriod=getCellValue("PediatricMajorWaitingPeriod");
				String strPediatricOralSurgeryWaitingPeriod=getCellValue("PediatricOralSurgeryWaitingPeriod");
				String strPediatricOrthodonticWaitingPeriod=getCellValue("PediatricOrthodonticWaitingPeriod");
				String strPediatricOrthodonticCosmeticWaitingPeriod=getCellValue("PediatricOrthodonticCosmeticWaitingPeriod");
				String strPediatricPeriodontalWaitingPeriod=getCellValue("PediatricPeriodontalWaitingPeriod");
				String strPediatricProstheticWaitingPeriod=getCellValue("PediatricProstheticWaitingPeriod");
				if(!PlanSetupPage.get().pediatricDentalCovered.isSelected())
				{
					seClick(PlanSetupPage.get().pediatricDentalCovered,"Covered");
					waitForPageLoad();
				}
					seClick(PlanSetupPage.get().pediatricDentalMaximum,"DentalMaximum");
					waitForPageLoad();
					seSetText(PlanSetupPage.get().pediatricDentalMaximumText,strAgeLimit,"Age Limit");
					waitForPageLoad();
					seClick(PlanSetupPage.get().pediatricDentalMaximumValue,"Age limit value");
					waitForPageLoad();					
					if(waitingPeriodsApply.equalsIgnoreCase("Waiting Periods Apply")) {
						if(!PlanSetupPage.get().pediatricDentalWaitingPeriodsApply.isSelected())
						{
							seClick(PlanSetupPage.get().pediatricDentalWaitingPeriodsApply,"WaitingPeriodsApply");
							waitForPageLoad();							
						}
						seClick(PlanSetupPage.get().pediatricDentalBasicWaitingPeriod,"PediatricDentalBasicWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalPediatricBasicWaitingPeriod(strPediatricBasicWaitingPeriod),"BasicWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().pediatricDentalPreventiveWaitingPeriod,"PediatricDentalPreventiveWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalPediatricPreventiveWaitingPeriod(strPediatricPreventiveWaitingPeriod),"PreventiveWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().pediatricDentalEndodonticWaitingPeriod,"PediatricDentalEndodonticWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalPediatricEndodonticWaitingPeriod(strPediatricEndodonticWaitingPeriod),"EndodonticWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().pediatricDentalMajorWaitingPeriod,"PediatricDentalMajorWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalPediatricMajorWaitingPeriod(strPediatricMajorWaitingPeriod),"MajorWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().pediatricDentalOralSurgeryWaitingPeriod,"PediatricDentalOralSurgeryWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalPediatricOralSurgeryWaitingPeriod(strPediatricOralSurgeryWaitingPeriod),"OralSurgeryWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().pediatricDentalOrthodonticWaitingPeriod,"PediatricDentalOrthodonticWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalPediatricOrthodonticWaitingPeriod(strPediatricOrthodonticWaitingPeriod),"OrthodonticWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().pediatricDentalOrthodonticCosmeticWaitingPeriod,"PediatricDentalOrthodonticCosmeticWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalPediatricOrthodonticCosmeticWaitingPeriod(strPediatricOrthodonticCosmeticWaitingPeriod),"OrthodonticCosmeticWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().pediatricDentalPeriodontalWaitingPeriod,"PediatricDentalPeriodontalWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalPediatricPeriodontalWaitingPeriod(strPediatricPeriodontalWaitingPeriod),"PeriodontalWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().pediatricDentalProstheticWaitingPeriod,"PediatricDentalProstheticWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalPediatricProstheticWaitingPeriod(strPediatricProstheticWaitingPeriod),"ProstheticWaitingPeriod");
						waitForPageLoad();
					}
					else{
						if(!PlanSetupPage.get().pediatricDentalNoWaitingPeriods.isSelected())
						{
							seClick(PlanSetupPage.get().pediatricDentalNoWaitingPeriods,"NoWaitingPeriods");
							waitForPageLoad();
						}
						
				}
					pediatricDentalValue=seGetElementValue(PlanSetupPage.get().pediatricDentalCoveredValue);
			}
			else{				
				if(!PlanSetupPage.get().pediatricDentalNotCovered.isSelected())
				{
					seClick(PlanSetupPage.get().pediatricDentalNotCovered,"Covered radio button");
					waitForPageLoad();
				}
				pediatricDentalValue=seGetElementValue(PlanSetupPage.get().pediatricDentalNotCoveredValue);				
			}
		}
		catch(Exception e)
		{
			log(ERROR,"Set Pediatric Dental","Exception Occured " +e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
		return pediatricDentalValue;
	}
	
	/**
	 * This method will select the OON radio button and selects the values based on input passed 
	 * 
	 * @param strDentalOON:Dental Out of network that need to be selected
	 * @return
	 * @throws Exception
	 * 
	 * Test Data sheet should contain the columns:OONPercentileValue,OONBenefitValue
	 */
	public String setDentalOON(String strDentalOON) throws Exception
	{
		String strDentalOONValue="";
		try{
			waitForPageLoad(360);
			if(strDentalOON.equalsIgnoreCase("Covered")) {				
				String strOONPercentileValue=getCellValue("OONPercentileValue");
				String strOONBenefitValue=getCellValue("OONBenefitValue");
				if(!PlanSetupPage.get().dentalOONCovered.isSelected())
				{
					seClick(PlanSetupPage.get().dentalOONCovered,"OON Covered");
					waitForPageLoad();
				}
				seClick(PlanSetupPage.get().dentalOONPercentile,"OON Percentile ");
				waitForPageLoad();
				seSetText(PlanSetupPage.get().dentalOONPercentileText, strOONPercentileValue,"Percentile text");
				waitForPageLoad();
				seClick(getWebDriver().findElement(By.cssSelector(".select2-results__option.select2-results__option--highlighted>span>span")), "S90NetworkMaximumText");
				waitForPageLoad(2, 360);
				seSelectText(PlanSetupPage.get().dentalOONBenefit, strOONBenefitValue,"Benefit Period drop down",500);
				waitForPageLoad();				
				strDentalOONValue=seGetElementValue(PlanSetupPage.get().dentalOONCoveredText);
			}
			else{
				waitForPageLoad(360);
				if(!PlanSetupPage.get().dentalOONNotCovered.isSelected())
				{
					seClick(PlanSetupPage.get().dentalOONNotCovered, "OON Not Covered ");
					waitForPageLoad();
				}
				strDentalOONValue=seGetElementValue(PlanSetupPage.get().dentalOONNotCoveredText);
			}
			
		}
		catch(Exception e)
		{
			log(ERROR,"Set OON Coverage","Exception Occured " +e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
		return strDentalOONValue;
	}
	
	/**
	 * This method sets the Adult dental value based on the inputs passed
	 * 
	 * @param strAdultDentalType: Adult type that need to be selected
	 * @return
	 * @throws Exception
	 * 
	 * Test Data sheet should contain the columns:AdultWaitingPeriod,AdultBasicWaitingPeriod,AdultPreventiveWaitingPeriod,AdultEndodonticWaitingPeriod,AdultMajorWaitingPeriod
	 *                                            AdultOralSurgeryWaitingPeriod,AdultPeriodontalWaitingPeriod,AdultProsthodonticWaitingPeriod
	 */
	public String setAdultDental(String strAdultDentalType) throws Exception
	{
		String adultDentalValue="";
		try{
			waitForPageLoad(360);
			seClick(PlanSetupPage.get().adultDental,"Adult Dental");
			waitForPageLoad();
			if(strAdultDentalType.equalsIgnoreCase("Covered")) {
				String waitingPeriodsApply=getCellValue("AdultWaitingPeriod");
				String strAdultBasicWaitingPeriod=getCellValue("AdultBasicWaitingPeriod");
				String strAdultPreventiveWaitingPeriod=getCellValue("AdultPreventiveWaitingPeriod");
				String strAdultEndodonticWaitingPeriod=getCellValue("AdultEndodonticWaitingPeriod");
				String strAdultMajorWaitingPeriod=getCellValue("AdultMajorWaitingPeriod");
				String strAdultOralSurgeryWaitingPeriod=getCellValue("AdultOralSurgeryWaitingPeriod");				
				String strAdultPeriodontalWaitingPeriod=getCellValue("AdultPeriodontalWaitingPeriod");
				String strAdultProsthodonticWaitingPeriod=getCellValue("AdultProsthodonticWaitingPeriod");
				
				if(!PlanSetupPage.get().adultDentalCovered.isSelected())
				{
					seClick(PlanSetupPage.get().adultDentalCovered,"Covered radio button");
					waitForPageLoad();
				}
					
					if (waitingPeriodsApply.equalsIgnoreCase("Waiting Periods Apply")) {
						if(!PlanSetupPage.get().adultDentalWaitingPeriodsApply.isSelected())
						{
							seClick(PlanSetupPage.get().adultDentalWaitingPeriodsApply,"WaitingPeriodsApply");
							waitForPageLoad();							
						}
						seClick(PlanSetupPage.get().adultDentalBasicWaitingPeriod,"AdultDentalBasicWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalAdultBasicWaitingPeriod(strAdultBasicWaitingPeriod),"BasicWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().adultDentalPreventiveWaitingPeriod,"AdultDentalPreventiveWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalAdultPreventiveWaitingPeriod(strAdultPreventiveWaitingPeriod),"AdultPreventiveWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().adultDentalEndodonticWaitingPeriod,"AdultDentalEndodonticWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalAdultEndodonticWaitingPeriod(strAdultEndodonticWaitingPeriod),"EndodonticWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().adultDentalMajorWaitingPeriod,"AdultDentalMajorWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalAdultMajorWaitingPeriod(strAdultMajorWaitingPeriod),"MajorWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().adultDentalOralSurgeryWaitingPeriod,"AdultDentalOralSurgeryWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalAdultOralSurgeryWaitingPeriod(strAdultOralSurgeryWaitingPeriod),"OralSurgeryWaitingPeriod");
						waitForPageLoad();											
						seClick(PlanSetupPage.get().adultDentalPeriodontalWaitingPeriod,"AdultDentalPeriodontalWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalAdultPeriodontalWaitingPeriod(strAdultPeriodontalWaitingPeriod),"PeriodontalWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().adultDentalProsthodonticWaitingPeriod,"AdultDentalProstheticWaitingPeriod");
						waitForPageLoad();
						seClick(PlanSetupPage.get().dentalAdultProsthodonticWaitingPeriod(strAdultProsthodonticWaitingPeriod),"ProstheticWaitingPeriod");
						waitForPageLoad();
					}
					else{
						if(!PlanSetupPage.get().adultDentalNoWaitingPeriods.isSelected())
						{
							seClick(PlanSetupPage.get().adultDentalNoWaitingPeriods,"NoWaitingPeriods");
							waitForPageLoad();
						}					
				}
				adultDentalValue=seGetElementValue(PlanSetupPage.get().adultDentalCoveredValue);
			}
			else{
				
				if(!PlanSetupPage.get().adultDentalNotCovered.isSelected())
				{
					seClick(PlanSetupPage.get().adultDentalNotCovered,"Not Covered");
					waitForPageLoad();
				}
				adultDentalValue=seGetElementValue(PlanSetupPage.get().adultDentalNotCoveredValue);				
			}							
		}
		catch(Exception e)
		{
			log(ERROR,"Set Adult Dental","Exception Occured " +e.getLocalizedMessage());
			e.printStackTrace();
			throw e;
		}
		return adultDentalValue;
	}
	
	public void seCheckErrorMessage(String strErrorValueExpected){
		try{
			
			WebElement objErrorMessageUI = getWebDriver().findElement(By.xpath("//*[@class='messagesBox danger alert alert-danger']/ul/li/span[contains(text(),'"+strErrorValueExpected+"')]"));
			String strErrorMessageActual = objErrorMessageUI.getText();
			try{
			seCompareStrings(strErrorValueExpected, strErrorMessageActual,"=", "Validation PASSED that an error message is displayed if the required field  have not been populated");
			} catch(Exception exception)
			{
				log(FAIL,"Validation FAILED, No error message displayed if the required field  have not been populated");
			}
		}catch(Exception e)
		{
			log(ERROR,"Error while exxecuting this method seCheckErrorMessage");
			e.printStackTrace();
			throw e;
		}
	}
	
	public void seCheckErrorMessageLink(String strErrorValueOneExpected,String strErrorValueTwoExpected){
		try{
			WebElement objErrorMessageOneUI = getWebDriver().findElement(By.xpath("//*[@class='messagesBox danger alert alert-danger']/ul/li/span[contains(text(),'"+strErrorValueOneExpected+"')]"));waitForPageLoad();
			System.out.println("identified the link");
			Boolean blnWarningMessageOne = seIsElementDisplayed(objErrorMessageOneUI, "Warning Message");
			System.out.println("boolean true or false");
			waitForPageLoad();
			seClick(objErrorMessageOneUI,"Warning Message First Link");waitForPageLoad();
			if(blnWarningMessageOne == true){System.out.println("true block");
			waitForPageLoad(100);
			getWebDriver().findElement(By.xpath("//*[@id='POA_PlanSetup-_-PediatricVision-_-CoveredExamAndHardware-_-NA']/div/div/table/tbody/tr[1]/td[2]/div[1]/span/span/span[1]/input")).click();waitForPageLoad();
			getWebDriver().findElement(By.xpath("//*[@id='POA_PlanSetup-_-PediatricVision-_-CoveredExamAndHardware-_-NA']/div/div/table/tbody/tr[1]/td[2]/div[1]/span/span/span[1]/input")).sendKeys("51");waitForPageLoad();
			getWebDriver().findElement(By.xpath("//*[@id='POA_PlanSetup-_-PediatricVision-_-CoveredExamAndHardware-_-NA']/div/div/table/tbody/tr[1]/td[2]/div[1]/span/span/span[2]")).click();waitForPageLoad();
			log(PASS," Warning Message link Displayed in UI, Clicked on sucessfully which navigated directly to the field referenced in the message and entered value in the mandatory field");
			}
			else{
				log(ERROR,"No Warning Message link Displayed in UI");
			}
			waitForPageLoad(100);
			WebElement objErrorMessageUI = getWebDriver().findElement(By.xpath("//*[@class='messagesBox danger alert alert-danger']/ul/li/span[contains(text(),'"+strErrorValueTwoExpected+"')]"));waitForPageLoad();
			System.out.println("identified the link");
			Boolean blnWarningMessage = seIsElementDisplayed(objErrorMessageUI, "Warning Message");
			System.out.println("boolean true or false");
			waitForPageLoad();
			seClick(objErrorMessageUI,"Warning Message Second Link");waitForPageLoad();
			if(blnWarningMessage == true){System.out.println("true block");waitForPageLoad(100);
			getWebDriver().findElement(By.xpath("//*[@id='POA_PlanSetup-_-PediatricVision-_-CoveredExamAndHardware-_-NA']/div/div/table/tbody/tr[2]/td[2]/div[1]/span/span/span[1]/input")).click();waitForPageLoad();
			getWebDriver().findElement(By.xpath("//*[@id='POA_PlanSetup-_-PediatricVision-_-CoveredExamAndHardware-_-NA']/div/div/table/tbody/tr[2]/td[2]/div[1]/span/span/span[1]/input")).sendKeys("61");waitForPageLoad();
			getWebDriver().findElement(By.xpath("//*[@id='POA_PlanSetup-_-PediatricVision-_-CoveredExamAndHardware-_-NA']/div/div/table/tbody/tr[2]/td[2]/div[1]/span/span/span[2]")).click();waitForPageLoad();
			log(PASS," Warning Message link Displayed in UI,  Clicked on sucessfully which navigated directly to the field referenced in the message and entered value in the mandatory field");
			}
			else{
				log(ERROR,"No Warning Message link Displayed in UI");
			}
		
			
		}catch(Exception e)
		{
			log(ERROR,"Error while exxecuting this method seCheckErrorMessage");
			e.printStackTrace();
			throw e;
		}
	}
	
	@FindBy(how = How.XPATH, using = "//*[@class='messagesBox danger alert alert-danger']")
	@CacheLookup
	public WebElement errorDisplay;
	
	
	
	
	
	
	
	
	
}
