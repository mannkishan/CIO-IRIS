package page.planConfigurator;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class AllergySerumBenefitOptionPage extends CoreSuperHelper{
	private static AllergySerumBenefitOptionPage thisIsTestObj;
	public  synchronized static AllergySerumBenefitOptionPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), AllergySerumBenefitOptionPage.class);
		return thisIsTestObj;
		}
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"actionsBar\"]/li[1]/a")
	@CacheLookup
	public WebElement closePlan;
	
	@FindBy(how = How.XPATH, using = "//a[@attr-ref='AllergySerum']")
	@CacheLookup
	public WebElement allergySerum;
	
	/*Covered INOON starts here*/
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOON\"]")
	@CacheLookup
	public WebElement allergySerumCoveredINNOON;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"CoveredINNOON\"]/div[1]/h4/span")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONName;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesINNT1Fac\"]/h4")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONINNCostSharesFacilityName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesINNT1Fac\"]/div/div[1]/div")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONINNCostSharesFacilityPaidPlnLvlName;
		
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesINNT1Fac\"]/div/div[2]/div/h4")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONINNCostSharesFacilityBenSpecCoShareName;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesOONFac\"]/h4")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONOONCostSharesFacilityName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesOONFac\"]/div/div[1]/div/h4")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONOONCostSharesFacilityPaidPlnLvlName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesOONFac\"]/div/div[2]/div/h4")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONOONCostSharesFacilityBenSpecCoShareName;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesOONFac\"]/div/div[3]/div/h4")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONOONCostSharesFacilityNotCoveredName;

	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesINNT1Prof\"]/h4")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONINNCostSharesProfName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesINNT1Prof']/div/div[1]/div/h4")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONINNCostSharesProfPaidPlnLvlName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesINNT1Prof\"]/div/div[2]/div/h4")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONINNCostSharesProfFolwOffcAdminName;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesINNT1Prof\"]/div/div[3]/div/h4")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONINNCostSharesProfBenSpecCoShareName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesOONProf\"]/h4")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONOONCostSharesProfName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesOONProf\"]/div/div[1]/div/h4")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONOONCostSharesProfPaidPlnLvlName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesOONProf\"]/div/div[2]/div/h4")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONOONCostSharesProfBenSpecCoShareName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesOONProf\"]/div/div[3]/div/h4")
	@CacheLookup
	public WebElement allergySerumCoveredINNOONOONCostSharesProfNotCoveredName;
	
	
	/*Covered INOON ends here*/

	/*Covered INN Only starts here*/
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOnly\"]")
	@CacheLookup
	public WebElement allergySerumCoveredINNOnly;
	

	@FindBy(how = How.XPATH, using = "//*[@id=\"CoveredINNOnly\"]/div[1]/h4/span")
	@CacheLookup
	public WebElement allergySerumCoveredINNOnlyName;
	

	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOnly-_-CostSharesINNT1Fac\"]/h4")
	@CacheLookup
	public WebElement allergySerumINNOnlyINCostSharesFacName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOnly-_-CostSharesINNT1Fac\"]/div/div[1]/div/h4")
	@CacheLookup
	public WebElement allergySerumINNOnlyINCostSharesFacPaidPlnLvlName;
	
		
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOnly-_-CostSharesINNT1Fac\"]/div/div[2]/div/h4")
	@CacheLookup
	public WebElement allergySerumINNOnlyINCostSharesFacBenSpecCoShareName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOnly-_-CostSharesINNT1Prof\"]/h4")
	@CacheLookup
	public WebElement allergySerumINNOnlyINCostSharesProfName;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOnly-_-CostSharesINNT1Prof\"]/div/div[1]/div/h4")
	@CacheLookup
	public WebElement allergySerumINNOnlyINCostSharesProfPaidPlnLvlName;
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOnly-_-CostSharesINNT1Prof\"]/div/div[2]/div/h4")
	@CacheLookup
	public WebElement allergySerumINNOnlyINCostSharesProfFolwOffcAdminName;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"POA_BenefitOption-_-AllergySerum-_-CoveredINNOnly-_-CostSharesINNT1Prof\"]/div/div[3]/div/h4")
	@CacheLookup
	public WebElement allergySerumINNOnlyINCostSharesProfBenSpecCoShareName;
	/*Covered INN Only ends here*/
	 
	 @FindBy(how = How.XPATH, using = "//input[@id='POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares']")
	 @CacheLookup
	 public WebElement rBtnAllergySerumBenefitSpecificCostShares;

	 @FindBy(how = How.XPATH, using = "//span[@id='select2-POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-ApplyDed_-_choice-container']")
	 @CacheLookup
	 public WebElement txtAllergySerumApplyDeductibleContainer;

	 @FindBy(how = How.XPATH, using = "//*[@id='subCollapse2']/table/tbody/tr[1]/td[2]/div/span/span/span[1]/input")
	 @CacheLookup
	 public WebElement txtAllergySerumApplyDeductible;

	 @FindBy(how = How.XPATH, using = "//ul[@id='select2-POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-ApplyDed_-_choice-results']")
	 @CacheLookup
	 public WebElement txtAllergySerumApplyDeductibleResults;

	 @FindBy(how = How.XPATH, using = "//span[@id='select2-POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CoinINNT1AllergySerumFac_-_percentage-container']")
	 @CacheLookup
	 public WebElement txtAllergySerumCoinsurancePercentageContainer;

	 @FindBy(how = How.XPATH, using = "//*[@id='subCollapse2']/table/tbody/tr[2]/td[2]/div/span/span/span[1]/input")
	 @CacheLookup
	 public WebElement txtAllergySerumCoinsurancePercentage;

	 @FindBy(how = How.XPATH, using = "//ul[@id='select2-POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CoinINNT1AllergySerumFac_-_percentage-results']")
	 @CacheLookup
	 public WebElement txtAllergySerumCoinsurancePercentageResults;

	 @FindBy(how = How.XPATH, using = "//span[@id='POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-CoinINNT1AllergySerumFac_-_percentage']")
	 @CacheLookup
	 public WebElement lblAllergySerumCoinsurancePercentage;

	 @FindBy(how = How.XPATH, using = "//span[@id='POA_BenefitOption-_-AllergySerum-_-CoveredINNOON-_-CostSharesINNT1Fac-_-BenefitSpecificCostShares-_-ApplyDed_-_choice']")
	 @CacheLookup
	 public WebElement lblAllergySerumApplyDeductibleValue;
	 
	 /**
		 * Method to verify whether a Web Element name matches the expected name
		 * @param wbAccumulatorName: Web Element name
		 * @param strExpectedName:Expected name provided for verification
		 */
	 public static void seIsAccumulatorNameVisible(WebElement wbAccumulatorName,String strExpectedName)
	{
		 try{
			 if(seIsElementDisplayed(wbAccumulatorName,strExpectedName)&&(seGetText(wbAccumulatorName).equalsIgnoreCase(strExpectedName)))
				{
					RESULT_STATUS=true;				
					log(PASS, "Given Accumulator ["+seGetText(wbAccumulatorName)+"] is visible","RESULT_STATUS=PASS");
				}
				else
				{

					RESULT_STATUS=false;				
					log(FAIL, "Given Accumulator ["+seGetText(wbAccumulatorName)+"] is not visible","RESULT_STATUS=FAIL");				
				}
		 }
		 catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	 
	 /**
		 * Method to verify whether the Web Element selected matches the expected value
		 * @param testObject: The Web Element to be checked whether selected or not
		 * @param strElementName: The value which is expected
		 * @return blnIsElementNotSelectedSuccess: Boolean value if Web Element is selected or not
		 */
	public boolean seCheckIsElementNotSelected(WebElement testObject, String strElementName) {
		boolean blnIsElementNotSelectedSuccess = false;
		try {
			if (!testObject.isSelected()) {
				blnIsElementNotSelectedSuccess = true;

			} else {
				RESULT_STATUS = false;

			}
		} catch (Exception e) {
			e.printStackTrace();
			RESULT_STATUS = false;
		}
		return blnIsElementNotSelectedSuccess;
	}

	/**
	 * This Method opens the 'Allergy Serum' tab under 'Benefit Options' and updates the Accumulator values for 
	 * Covered in Network & Out of Network -> In Network Cost Shares Facility -> Benefit Specific Cost Shares 
	 * @param strApplyDeductible (required) Value to be set to 'Apply Deductible' pick list
	 * @param strCoinsurance (required) Coinsurance Percentage value
	 */
	 public void seUpdateAllergySerum(String strApplyDeductible, String strCoinsurance) {
		try {
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanBenefitOptionsPage.get().benefitOptionsTab);
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", AllergySerumBenefitOptionPage.get().allergySerum);
			seWaitForClickableWebElement(AllergySerumBenefitOptionPage.get().rBtnAllergySerumBenefitSpecificCostShares, 60);
			seClick(AllergySerumBenefitOptionPage.get().rBtnAllergySerumBenefitSpecificCostShares, "Benefit Specific Cost Shares");

			seWaitForClickableWebElement(AllergySerumBenefitOptionPage.get().txtAllergySerumApplyDeductibleContainer, 60);
			seClick(AllergySerumBenefitOptionPage.get().txtAllergySerumApplyDeductibleContainer, "Apply Deductible");
			seClick(AllergySerumBenefitOptionPage.get().txtAllergySerumApplyDeductible, "Input Field Apply Deductible");
			seSetText(AllergySerumBenefitOptionPage.get().txtAllergySerumApplyDeductible, strApplyDeductible, "Input value Apply deductible");
			seWaitForClickableWebElement(AllergySerumBenefitOptionPage.get().txtAllergySerumApplyDeductibleResults, 60);
			seClick(AllergySerumBenefitOptionPage.get().txtAllergySerumApplyDeductibleResults, "Apply Deductible Result");
			
			seWaitForClickableWebElement(AllergySerumBenefitOptionPage.get().txtAllergySerumCoinsurancePercentageContainer, 60);
			seClick(AllergySerumBenefitOptionPage.get().txtAllergySerumCoinsurancePercentageContainer, "INNUrgentCare Facility");
			seClick(AllergySerumBenefitOptionPage.get().txtAllergySerumCoinsurancePercentage, "Input Field INNUrgentCare Facility");
			seSetText(AllergySerumBenefitOptionPage.get().txtAllergySerumCoinsurancePercentage, strCoinsurance, "Set percentage in INNUrgentCare Facility");
			seWaitForClickableWebElement(AllergySerumBenefitOptionPage.get().txtAllergySerumCoinsurancePercentageResults, 60);
			seClick(AllergySerumBenefitOptionPage.get().txtAllergySerumCoinsurancePercentageResults, "Coinsurance Result");

			seWaitForClickableWebElement(PlanOptionsPage.get().saveButton, 60);
			seClick(PlanOptionsPage.get().saveButton, "Save");
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			
			log(INFO, "Provided the Allergy Serum accumulator values for Master Plan and saved the details.");
		} catch (Exception e) {
			log(ERROR, "Exception while executing 'seUpdateAllergySerum' method.");
		}
	}

	 /**
	 * This Method opens the 'Allergy Serum' tab under 'Benefit Options' and validates the Accumulator values for 
	 * Covered in Network & Out of Network -> In Network Cost Shares Facility -> Benefit Specific Cost Shares 
	 * after the 'Request Audit' option is selected for the plan i.e., Accumulator fields should be disabled
	 * @param strApplyDeductible (required) Value to be compared to 'Apply Deductible' pick list in application
	 * @param strCoinsurance (required) value to be compared across the Coinsurance Percentage value in application
	  */
	public void seVerifyAllergySerumValues(String strApplyDeductible, String strCoinsurance) {
		try {
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", PlanBenefitOptionsPage.get().benefitOptionsTab);
			seWaitForClickableWebElement(HomePageTabsPage.get().scrollDownButton, 60);
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", AllergySerumBenefitOptionPage.get().allergySerum);
			seWaitForClickableWebElement(AllergySerumBenefitOptionPage.get().lblAllergySerumApplyDeductibleValue, 60);
			seVerifyFieldValue(AllergySerumBenefitOptionPage.get().lblAllergySerumApplyDeductibleValue, strApplyDeductible, "Allergy Serum Apply Deductible");

			String strActualCoinsurancePerc = seGetElementValue(AllergySerumBenefitOptionPage.get().lblAllergySerumCoinsurancePercentage);

			if (strActualCoinsurancePerc.contains(strCoinsurance)) {
				RESULT_STATUS = true;
				log(PASS, "Verify if Allergy Serum Coinsurance is displayed as expected value '" + strCoinsurance + "'.",
						"Allergy Serum Coinsurance '" + strActualCoinsurancePerc + "' is displayed as expected '" + strCoinsurance + "'. RESULT=PASS");
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify if Allergy Serum Coinsurance is displayed as expected value '" + strCoinsurance + "'.",
						"Allergy Serum Coinsurance '" + strActualCoinsurancePerc + "' is not displayed as expected '" + strCoinsurance + "'. RESULT=FAIL");
			}
		} catch (Exception e) {
			log(ERROR, "Exception while executing 'seVerifyAllergySerumValues' method.");
		}
	}
	
}
