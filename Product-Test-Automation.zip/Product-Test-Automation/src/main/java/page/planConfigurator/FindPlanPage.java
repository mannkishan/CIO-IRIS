package page.planConfigurator;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import utility.CoreSuperHelper;
//import utility.WebTable;
import utility.WebTableWithHeader;
 
public class FindPlanPage extends CoreSuperHelper{

	private static FindPlanPage thisTestObj;	
	public synchronized static FindPlanPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), FindPlanPage.class);
		return thisTestObj;
	}
	
	@FindBy(how = How.XPATH, using = "//ul/li[@class='select2-search select2-search--inline']")
	@CacheLookup
	public WebElement selectStatus;
	
	@FindBy(how = How.NAME, using = "criteria[planId]")
	@CacheLookup
	public WebElement planVersionID;

	@FindBy(how = How.NAME, using = "criteria[proxyId]")
	@CacheLookup
	public WebElement planProxyID;

	@FindBy(how = How.NAME, using = "criteria[name]")
	@CacheLookup
	public WebElement planName;

	@FindBy(how = How.NAME, using = "criteria[headerCriterias][0][values][]")
	@CacheLookup
	public WebElement planDescription;

	@FindBy(how = How.NAME, using = "criteria[effDateFromString]")
	@CacheLookup
	public WebElement effectiveFrom;

	@FindBy(how = How.XPATH, using = "//*[@id=\"findPlanSearch\"]/div[2]/button[1]")
	@CacheLookup
	public WebElement planSearch;

	@FindBy(how = How.ID, using = "DataTables_Table_1")
	@CacheLookup
	public WebElement planSearchResults;

	@FindBy(how = How.XPATH, using = "//input[@name='effectiveDate']")
	@CacheLookup
	public WebElement planEffectiveDate;

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[1]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement productModelData;	

	@FindBy(how = How.XPATH, using = "html/body/div[1]/div[1]/div/div[1]/div[8]/span/span/span[1]/input")
	@CacheLookup
	public WebElement searchField;

	@CacheLookup
	@FindBy(how=How.XPATH,using="//div[@class='findPlanResults']/div/table")
	public WebElement searchResults;

	public WebElement selectType(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//span[@class='select2-results']/ul/li/span/span[text()='"+type+"']"));
		return valueType;
	}

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[4]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement approvalStatus;

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[5]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement customizationLevel;

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[6]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement state;

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[7]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement marketSegment;

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[8]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement marketUnit;

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[9]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement LOB;

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[10]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement productName;

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[11]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement productFamily;

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[12]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement consumerDrivenHealthPlan;

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[13]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement planDesign;

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[14]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement bemefitPeriod;

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[15]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement fundingArrangement;

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[16]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement claimSystem;

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[17]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement businessEntity;

	@FindBy(how = How.XPATH, using = "//div[@id='customHeaderAttributesContainer']/div[18]/div/span/span/span/span[@class='select2-selection__rendered']")
	@CacheLookup
	public WebElement businessUnit;

	@FindBy(how = How.XPATH, using = "//div[@class='form-group line']/div/button[2]")
	@CacheLookup
	public WebElement createButton;

	@FindBy(how = How.XPATH, using = "//button[@class='btn btn-sm reviewPlanHeader']")
	@CacheLookup
	public WebElement headerDetails;

	@FindBy(how = How.XPATH, using = "//div[@id='planHeaderWrapper']/div/div/div[1]/div[2]/div[1]")
	@CacheLookup
	public WebElement planHeader_PlanID;

	@FindBy(how = How.XPATH, using = "//span[@class='filterPO incomplete']")
	@CacheLookup
	public WebElement filter_Incomplete;	

	@FindBy(how = How.XPATH, using = "//span[@id='select2-POA_Base-_-ForeignTravel-_-NonERCareOutsideUSA-_-NA-_-NA-_-NonERCareOutsideUSAIndctr_-_choice-container']")
	@CacheLookup
	public WebElement nonERCareOutsideUs;

	@FindBy(how = How.XPATH, using = "//span[@id='select2-POA_Base-_-HealthInsExchg-_-HealthInsExchg-_-NA-_-NA-_-ExchgOnOffIndctr_-_choice-container']")
	@CacheLookup
	public WebElement exchangeIndicator;

	@FindBy(how = How.XPATH, using = "//input[@class='select2-search__field']")
	@CacheLookup
	public WebElement searchoption2;	

	@FindBy(how = How.XPATH, using = "//span[@id='select2-POA_Base-_-Coinsurance-_-Coinsurance-_-NA-_-NA-_-INNInptFacCoin_-_percentage-container']")
	@CacheLookup
	public WebElement inNetworkInpatFacCoin;

	@FindBy(how = How.XPATH, using = "//div[@class='findPlanResults']/div/table/tbody/tr/td[4]")
	@CacheLookup
	public WebElement selectSearchedPlan;


	@FindBy(how = How.XPATH, using = "//span[@id='select2-POA_Base-_-Coinsurance-_-Coinsurance-_-NA-_-NA-_-INNHMOCoin_-_percentage-container']")
	@CacheLookup
	public WebElement inNetworkHMOCoin;

	@FindBy(how = How.XPATH, using = "//span[@id='select2-POA_Base-_-Deductible-_-Deductible-_-NA-_-NA-_-INNHMODedFam_-_accumulationBasis-container']")
	@CacheLookup
	public WebElement inNetworkHMODedFam;

	@FindBy(how = How.XPATH, using = "//span[@id='select2-POA_Base-_-OOP-_-OOP-_-NA-_-NA-_-INNHMOOOPFam_-_accumulationBasis-container']")
	@CacheLookup
	public WebElement inNetworkHMOOOP;	

	@FindBy(how = How.XPATH, using = "//ul[@id='actionsBar']/li[4]/a")
	@CacheLookup
	public WebElement requestAuditLink;

	@FindBy(how = How.XPATH, using = "//span[@id='select2-POA_BenefitOption-_-AdvancedImaging-_-AdvancedImagingDedCopayCoin-_-NA-_-NA-_-INNHMOAdvImagingCoin_-_percentage-container']")
	@CacheLookup
	public WebElement inNetworkHMOAdvanImaCoins;

	@FindBy(how = How.XPATH, using = "//span[@id='select2-POA_BenefitOption-_-AdvancedImaging-_-AdvancedImagingDedCopayCoin-_-NA-_-NA-_-INNHMOAdvImagingCopay_-_amount-container']")
	@CacheLookup
	public WebElement inNetworkHMOAdvanImaCopay;

	@FindBy(how = How.XPATH, using = "//span[@id='select2-POA_BenefitOption-_-AppliedBehavAnalysis-_-AppliedBehavAnalysisCovered-_-NA-_-NA-_-INNHMOABADlrLmt1_-_indivMax-container']")
	@CacheLookup
	public WebElement ABA;	

	@FindBy(how = How.XPATH, using = "//span[starts-with(@id,'select2-benefitPeriod')]")
	@CacheLookup
	public WebElement benefitPeriod;

	@FindBy(how = How.XPATH, using = "//button[starts-with(@class,'selectTemplate')]")
	@CacheLookup
	public WebElement selectTemplate;

	@FindBy(how = How.XPATH, using = "//table/thead/tr[2]/td[2]/input")
	@CacheLookup
	public WebElement versionId;

	@FindBy(how = How.XPATH, using = "//table/tbody/tr[1]/td[1]")
	@CacheLookup
	public WebElement result;

	@FindBy(how = How.XPATH, using = "//div[@id='content-create-customPlan']/span/span/span[1]/input")
	@CacheLookup
	public WebElement planOptionCriteriaInput;

	@FindBy(how = How.XPATH, using = "//div[@id='benefitsTreeWrapper']/aside/ul/li[22]/ul[2]/li/ul[1]/li/div/div/div/a[text()='Urgent Care Advanced Imaging']")
	@CacheLookup
	public WebElement urgentCareAdvImg;

	@FindBy(how = How.XPATH, using = "//div[@id='header-wrapper']/div[4]/div[1]/ul/li/span")
	@CacheLookup
	public WebElement errorMsg;

	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Plan Level Benefits')]")
	@CacheLookup
	public WebElement clickPlanLevelBenefit;

	@FindBy(how = How.XPATH, using = "//*[@id=\"DataTables_Table_1\"]/tbody/tr/td[4]")
	@CacheLookup
	public WebElement clickSearchedPlan;


	@FindBy(how = How.XPATH, using = "//*[@id=\"verticalBarMenu\"]/div[3]/div")
	@CacheLookup
	public WebElement firstScroll;

	@FindBy(how = How.XPATH, using = "//*[@id='BenefitTree']/a")
	@CacheLookup
	public WebElement clickBenefits;

	@FindBy(how = How.XPATH, using = "//*[@id='findPlanSearch']/div[3]/div/div[1]/input")
	@CacheLookup
	public WebElement planProxyId;

	@FindBy(how = How.XPATH, using = "//div[@id='header-criteria']/div/div[1]")
	@CacheLookup
	public WebElement headerCriteria;

	@FindBy(how = How.XPATH, using = "//div[@id='findPlan']/form/div[5]/div[2]/div/div[1]")
	@CacheLookup
	public WebElement accumulatorCriteria;

	@FindBy(how = How.XPATH, using = "//div[@id='header-criteria']/div/div[2]/div/div[1]/div[1]/div[1]/span/span[1]/span/span[1]")
	@CacheLookup
	public WebElement headerCriteriaType;

	@FindBy(how = How.XPATH, using = "//div[@class='findPlanResults']/div/table/tbody/tr[1]/td[9]")
	@CacheLookup
	public WebElement status;

	@FindBy(how = How.XPATH, using = ".//*[@id='planOption-criteria']/div[1]")
	@CacheLookup
	public WebElement optionCriteria;

	@FindBy(how = How.XPATH, using = "//div[@id='planOption-criteria-collapse']/div/div/div/div/div[2]/span[1]/span/span/span/span[1]")
	@CacheLookup
	public WebElement planOptionArea;

	public WebElement planOptionAreaValue(String type)
	{
		WebElement planOptionAreaValue = getWebDriver().findElement(By.xpath("//div[@id='content-find-plan']/span/span/span[2]/ul/li/span[text()='"+type+"']"));
		return planOptionAreaValue;
	}

	@FindBy(how = How.XPATH, using = "//div[@id='planOption-criteria-collapse']/div/div/div/div/div[2]/span[2]/span/span[1]/span/span[1]")
	@CacheLookup
	public WebElement planOptionType;

	public WebElement planOptionTypeValue(String type)
	{
		WebElement planOptionTypeValue = getWebDriver().findElement(By.xpath("//div[@id='content-find-plan']/span/span/span[2]/ul/li/span[text()='"+type+"']"));
		return planOptionTypeValue;
	}

	@FindBy(how = How.XPATH, using = "//div[@id='planOption-criteria-collapse']/div/div/div/div/div[2]/span[3]/span/span[1]/span/span[1]")
	@CacheLookup
	public WebElement planOptionName;

	public WebElement planOptionNameValue(String type)
	{
		WebElement planOptionNameValue = getWebDriver().findElement(By.xpath("//div[@id='content-find-plan']/span/span/span[2]/ul/li/span[text()='"+type+"']"));
		return planOptionNameValue;
	}

	@FindBy(how = How.XPATH, using = ".//*[@id='message_frontEnd_message_NoPlansmeettheenteredcriteria_Pleaseeditthecriteriaandtryagain_warning']/span")
	@CacheLookup
	public WebElement searchPlanErrorMsg;

	public WebElement headerCritTypeValue(String type)
	{
		WebElement headerType = getWebDriver().findElement(By.xpath("//div[starts-with(@class,'typeAheadContainer main')]/span/span/span[2]/ul/li[text()='"+type+"']"));
		return headerType;
	}

	@FindBy(how = How.XPATH, using = "//div[@id='Find-header-criteria-collapse']/div/div[1]/div[2]/div[1]/span/span[1]/span/ul")
	@CacheLookup
	public WebElement value;

	public WebElement selectValueType(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//div[starts-with(@class,'typeAheadContainer sub no-scroll')]/span[2]/span/span/ul/li/span[contains(text(),'"+type+"')]"));
		return valueType;
	}

	@FindBy(how = How.XPATH, using = "//table/tbody/tr[1]/td[12]/i")
	@CacheLookup
	public WebElement planInfo;

	@FindBy(how = How.XPATH, using = "//div[@id='accumulator-criteria-collapse']/div/div/div/div/div[2]/span[1]/span/span[1]/span/span[1]")
	@CacheLookup
	public WebElement accumType;

	public WebElement selectAccumType(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//div[@id='content-find-plan']/span/span/span[2]/ul/li/span[text()='"+type+"']"));
		return valueType;
	}

	public WebElement selectAccumValue(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//span[text()='"+type+"']"));
		return valueType;
	}

	@FindBy(how = How.XPATH, using = "//div[@id='accumulator-criteria-collapse']/div/div/div/div/div[2]/span[2]/span/span[1]/span/span[1]")
	@CacheLookup
	public WebElement accumValue;

	@FindBy(how = How.XPATH, using = "//div[@id='accumulator-criteria-collapse']/div/div/div/div[2]/div/span[2]/select")
	@CacheLookup
	public WebElement dollarMax;

	public WebElement selectDollarMax(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//div[@id='accumulator-criteria-collapse']/div/div/div/div[2]/div/span[2]/select/option[contains(text(), ' "+type+" ')]"));
		return valueType;
	}

	@FindBy(how = How.XPATH, using = "//div[@id='accumulator-criteria-collapse']/div/div/div/div[3]/div/span[2]/select")
	@CacheLookup
	public WebElement percentage;

	public WebElement selectPercentageMax(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//div[@id='accumulator-criteria-collapse']/div/div/div/div[3]/div/span[2]/select/option[contains(text(), ' "+type+" ')]"));
		return valueType;
	}

	@FindBy(how = How.XPATH, using = "//div[@id='accumulator-criteria']/div[2]/div/div/div/div[2]/div[2]/span[2]/span/span[1]/span/span[1]")
	@CacheLookup
	public WebElement choice;

	@FindBy(how = How.XPATH, using = "//div[@id='accumulator-criteria-collapse']/div/div/div/div[2]/div/span[3]/input")
	@CacheLookup
	public WebElement dollarMaxValue;

	@FindBy(how = How.XPATH, using = "//div[@id='accumulator-criteria-collapse']/div/div/div/div[3]/div/span[3]/input")
	@CacheLookup
	public WebElement percentageValue;

	public String valueType(String valueType)
	{
		String selectedValue="";
		try
		{
			waitForPageLoad();
			seClick(FindPlanPage.get().value,"Clicking on value drop down");
			waitForPageLoad();
			seClick(FindPlanPage.get().selectValueType(valueType),"Selecting value type from value drop dowm"+valueType);
			waitForPageLoad(360);
			selectedValue=seGetElementValue(FindPlanPage.get().value).toString().trim().substring(1);
			if(valueType.equalsIgnoreCase(selectedValue))
			{
				log(PASS,"Value selected is:"+selectedValue,"Value type selected matches with given value :"+valueType);
			}
			else
			{
				log(FAIL,"Value selected is not :"+selectedValue,"Value type selected does not matches with given value :"+valueType);
			}
			waitForPageLoad();
		}
		catch(Exception e)
		{
			log(FAIL,"Value type drop dowm is empty","Exception occured while selecting value from drop down"+e.getMessage());
		}
		return selectedValue;
	}


	/*public void selectPlanFromResults(String strplanID)
	{
		waitForPageLoad();
		seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(planSearchResults));
			WebTable tabledetails = new WebTable(planSearchResults, "Plan Search Results");
			int rowNum = tabledetails.getRowWithCellTextInColumn(1,3,strplanID);
			if(rowNum>0)
			{
				getWebDriver().findElement(By.xpath("//table[starts-with(@id,'DataTables_Table']/tbody/tr["+rowNum+"]/td[2]")).click();;
			}
			else
			{
				throw new IllegalArgumentException("Not able to find the value"+ strplanID+"in the table");
			}
	}*/

	/**
	 * @author AF12450
	 * This method will search the plan with version ID as the filter
	 * @param strPlanVersionID: Plan Version id
	 * @return : boolean value which will indicate whether plan with version id is present or not
	 */
	public  boolean findPlan(String strPlanVersionID, String status)
	{
		boolean booFoundPlan = false;
		waitForPageLoad(300);
		seClick(HomePage.get().find, "Find link");
		waitForPageLoad(300);
		seClick(HomePage.get().findPlan, "Find Plan link");
		waitForPageLoad(300);
		seWaitForClickableWebElement(FindPlanPage.get().planVersionID, 120);
		seSetText(FindPlanPage.get().planVersionID, strPlanVersionID, "Plan ID");
		waitForPageLoad();
		seClick(FindPlanPage.get().planSearch, "Plan Search");
		waitForPageLoad(300);
		seWaitForClickableWebElement(FindPlanPage.get().searchResults, 120);
		WebTableWithHeader searchResults = new WebTableWithHeader(FindPlanPage.get().searchResults, "Plan Search Results");
		int intRowNum = searchResults.getRowWithCellTextInColumn(1, 9, status);
		if(intRowNum>0)
		{
			booFoundPlan = true;
		}


		return booFoundPlan;
	}

	/**
	 * @author AF12450
	 * This method will search the plan with version ID as the filter
	 * @param strPlanVersionID: Plan Version id
	 * @return : boolean value which will indicate whether plan with version id is present or not
	 */
	public  boolean findPlan(String strPlanVersionID)
	{
		boolean booFoundPlan = false;
		waitForPageLoad(300);
		seClick(HomePage.get().find, "Find link");
		waitForPageLoad(300);
		seClick(HomePage.get().findPlan, "Find Plan link");
		waitForPageLoad(500);
		seSetText(FindPlanPage.get().planVersionID, strPlanVersionID, "Plan ID");
		waitForPageLoad(300);
		seClick(FindPlanPage.get().planSearch, "Plan Search");
		waitForPageLoad(300);
		seWaitForClickableWebElement(FindPlanPage.get().searchResults, 130);
		WebTableWithHeader searchResults = new WebTableWithHeader(FindPlanPage.get().searchResults, "Plan Search Results");
		int intRowNum = searchResults.getRowWithCellTextInColumn(1, 3, strPlanVersionID);
		if(intRowNum>0)
		{
			RESULT_STATUS = true;
			booFoundPlan = true;
			log(PASS, "Find Plan","Plan found with Version ID: "+strPlanVersionID);
			seClick(searchResults.getCell(intRowNum, 3), "Plan Version ID");
		}
		else
		{
			RESULT_STATUS = false;
			log(FAIL, "Find Plan","Not able to find Plan with Version ID: "+strPlanVersionID);
		}

		return booFoundPlan;
	}

	/**
	 * @author AF17403
	 * This method will search the plan with Header SearchCriteria and validate the search results
	 * @param headerCriteria : Header Value with which plan need to be searched
	 * @param valueType : Header Value Type with which plan need to be searched 
	 * @return
	 */

	public boolean verifySearchUsingHeaderCriteria(String headerCriteria,String valueType,int intMaxTime)
	{
		boolean result=false;
		String expectedValue="";
		String actualValue="";
		try
		{			
			seClick(HomePage.get().find, "Find");
			waitForPageLoad(300);
			seClick(HomePage.get().findPlan, "Find Plan");
			waitForPageLoad(300);
			waitForPageLoad();
			seClick(FindPlanPage.get().headerCriteria,"Header criteria");
			waitForPageLoad();
			seClick(FindPlanPage.get().headerCriteriaType,"Header criteria type");
			waitForPageLoad();
			seClick(FindPlanPage.get().headerCritTypeValue(headerCriteria),"Benefit period value from header criteria drop dowm");
			waitForPageLoad();			
			expectedValue = FindPlanPage.get().valueType(valueType);
			waitForPageLoad(360);
			seClick(FindPlanPage.get().planSearch, "Search");
			waitForPageLoad(500);
			seWaitForClickableWebElement(FindPlanPage.get().searchResults, 120);
			if(FindPlanPage.get().searchResults.isDisplayed())
			{
				log(PASS, "Find Plan","Plan found with given header Criteria: "+headerCriteria);				
				for(int i=1;i<=5;i++)
				{					
					if (headerCriteria.equalsIgnoreCase("Status"))
					{
						waitForPageLoad();
						WebElement status=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div/table/tbody/tr["+i+"]/td[9]"));
						actualValue=status.getText().toString().trim();
						if(expectedValue.equalsIgnoreCase(actualValue))
						{
							result=true;
							log(PASS,"Validate search results using "+headerCriteria,"Expected Value "+expectedValue+"Actual Value "+actualValue);
						}
						else
						{
							log(FAIL,"Validate search results using "+headerCriteria,"Expected Value "+expectedValue+"Actual Value "+actualValue);
						}
					}
					else
					{						
						WebElement planInfo=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div/table/tbody/tr["+i+"]/td[12]/i"));
						seClick(planInfo,"Plan Info Option");
						waitForPageLoad();			
						Actions actions = new Actions(getWebDriver());
						actions.moveToElement(PlanHeaderPage.get().valueType(headerCriteria)).build().perform();;
						waitForPageLoad();
						actualValue=seGetElementValue(PlanHeaderPage.get().valueType(headerCriteria));
						if(expectedValue.equalsIgnoreCase(actualValue))
						{
							result=true;
							log(PASS,"Validate search results using "+headerCriteria,"Expected Value "+expectedValue+"Actual Value "+actualValue,true);
						}
						else
						{
							log(FAIL,"Validate search results using "+headerCriteria,"Expected Value "+expectedValue+"Actual Value "+actualValue,true);
						}
						seClick(PlanHeaderPage.get().closebutton,"Close button");
						waitForPageLoad();
					}
				}

			}
			else if(FindPlanPage.get().searchPlanErrorMsg.isDisplayed())
			{
				RESULT_STATUS = false;
				
				log(FAIL, "Find Plan","Plan not found with given header Criteria "+headerCriteria);
			}
			else
			{
				RESULT_STATUS = false;
				log(FAIL, "Find Plan","Plan not found with given header Criteria "+headerCriteria);
			}


		}
		catch(Exception e)
		{
			RESULT_STATUS = false;
			log(FAIL,"No Results fetched","No Results are fetched for given criteria "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * @author AF14735
	 * This method will search the plan with Base SearchCriteria and validate the search results
	 * @param strSearchCriteriaValue: value to be searched
	 * @param strSearchCriteria: Base SearchCriteria
	 * @return : boolean value which will indicate whether plan with version id is present or not
	 */
	public String validateBaseCriteriaSearch(String strSearchCriteriaValue,String strSearchCriteria ){
		String stractualSearchCriteriaValue="";
		int intcolumnNum=0;
		switch (strSearchCriteria) {
		case "Plan Name":
			seSetText(FindPlanPage.get().planName, strSearchCriteriaValue, "Plan Name");
			intcolumnNum=2;
			waitForPageLoad();
			seClick(FindPlanPage.get().planSearch, "Plan Search");
			waitForPageLoad(4,200);
			if(FindPlanPage.get().searchResults.isDisplayed()){
				WebTableWithHeader searchResults = new WebTableWithHeader(FindPlanPage.get().searchResults, "Plan Search Results");
				int intTotalRows = searchResults.getRowsCount();
				for (int i = 1; i <= intTotalRows; i++) {
					stractualSearchCriteriaValue=searchResults.getCellData(i, intcolumnNum);
					System.out.println(stractualSearchCriteriaValue);
					if(!stractualSearchCriteriaValue.equalsIgnoreCase(strSearchCriteriaValue))
						log(FAIL, "Verify Plan in search results","Plans do not match with "+strSearchCriteria+": " +strSearchCriteriaValue+" ActualVAlue: "+stractualSearchCriteriaValue);
					else
						log(PASS, "Verify Plan in search results","Plans match with "+strSearchCriteria+": " +strSearchCriteriaValue+" ActualVAlue: "+stractualSearchCriteriaValue);

				}
			}
			else if(FindPlanPage.get().searchPlanErrorMsg.isDisplayed()){
				log(FAIL, "Find Plan in search results","No Plan Match the search Criteria with "+strSearchCriteria+": " +strSearchCriteriaValue,true);
			}
			break;
		case "Plan Description":
			seSetText(FindPlanPage.get().planDescription, strSearchCriteriaValue, "Plan Description");
			seClick(FindPlanPage.get().planSearch, "Plan Search");
			waitForPageLoad(200);
			if(FindPlanPage.get().searchResults.isDisplayed()){
				WebTableWithHeader searchResults = new WebTableWithHeader(FindPlanPage.get().searchResults, "Plan Search Results");
				int intRowNum = searchResults.getRowWithCellTextInColumn(1, 9, "Production");
				seClick(searchResults.getCell(intRowNum, 9), "Plan");
				waitForPageLoad(200);
				stractualSearchCriteriaValue=seGetText(PlanHeaderPage.get().planDescription);
			}
			else if(FindPlanPage.get().searchPlanErrorMsg.isDisplayed()){
				log(FAIL, "Find Plan in search results","No Plan Match the search Criteria with "+strSearchCriteria+": " +strSearchCriteriaValue,true);
			}
			break;
		case "Plan Version Id":
			seSetText(FindPlanPage.get().planVersionID, strSearchCriteriaValue, "Plan Version Id");
			intcolumnNum=3;
			waitForPageLoad();
			seClick(FindPlanPage.get().planSearch, "Plan Search");
			waitForPageLoad(200);
			if(FindPlanPage.get().searchResults.isDisplayed()){
				WebTableWithHeader searchResults = new WebTableWithHeader(FindPlanPage.get().searchResults, "Plan Search Results");
				int intTotalRows = searchResults.getRowsCount();
				for (int i = 1; i <=intTotalRows; i++) {
					stractualSearchCriteriaValue=searchResults.getCellData(i, intcolumnNum);
					if(!stractualSearchCriteriaValue.equalsIgnoreCase(strSearchCriteriaValue))
						log(FAIL, "Verify Plan in search results","Plans do not match with "+strSearchCriteria+": " +strSearchCriteriaValue+" ActualVAlue: "+stractualSearchCriteriaValue);
					else
						log(PASS, "Verify Plan in search results","Plans match with "+strSearchCriteria+": " +strSearchCriteriaValue+" ActualVAlue: "+stractualSearchCriteriaValue);

				}
			}
			else if(FindPlanPage.get().searchPlanErrorMsg.isDisplayed()){
				log(FAIL, "Find Plan in search results","No Plan Match the search Criteria with "+strSearchCriteria+": " +strSearchCriteriaValue,true);
			}
			break;
		case "Proxy Plan ID":
			seSetText(FindPlanPage.get().planProxyId, strSearchCriteriaValue, "Proxy Plan ID");
			seClick(FindPlanPage.get().planSearch, "Plan Search");
			waitForPageLoad(200);
			if(FindPlanPage.get().searchResults.isDisplayed()){
				WebTableWithHeader searchResults = new WebTableWithHeader(FindPlanPage.get().searchResults, "Plan Search Results");
				int intRowNum = searchResults.getRowWithCellTextInColumn(1, 9, "Production");
				seClick(searchResults.getCell(intRowNum, 9), "Plan");
				waitForPageLoad(200);
				String[] temp=seGetText(PlanHeaderPage.get().planProxyID).split(":");
				stractualSearchCriteriaValue=temp[1].trim();
			}
			else if(FindPlanPage.get().searchPlanErrorMsg.isDisplayed()){
				log(FAIL, "Find Plan in search results","No Plan Match the search Criteria with "+strSearchCriteria+": " +strSearchCriteriaValue,true);
			}
			break;
		case "Effective Date":
			seSetText(FindPlanPage.get().effectiveFrom, strSearchCriteriaValue, "Effective Date");
			intcolumnNum=8;
			waitForPageLoad();
			seClick(FindPlanPage.get().planSearch, "Plan Search");
			waitForPageLoad(200);
			if(FindPlanPage.get().searchResults.isDisplayed()){
				WebTableWithHeader searchResults = new WebTableWithHeader(FindPlanPage.get().searchResults, "Plan Search Results");
				int intTotalRows = searchResults.getRowsCount();
				for (int i = 1; i < intTotalRows; i++) {
					stractualSearchCriteriaValue=searchResults.getCellData(i, intcolumnNum);
					if(!stractualSearchCriteriaValue.equalsIgnoreCase(strSearchCriteriaValue))
						log(FAIL, "Verify Plan in search results","Plans do not match with "+strSearchCriteria+": " +strSearchCriteriaValue+" ActualVAlue: "+stractualSearchCriteriaValue);
					else
						log(PASS, "Verify Plan in search results","Plans match with "+strSearchCriteria+": " +strSearchCriteriaValue+" ActualVAlue: "+stractualSearchCriteriaValue);

				}
			}
			else if(FindPlanPage.get().searchPlanErrorMsg.isDisplayed()){
				log(FAIL, "Find Plan in search results","No Plan Match the search Criteria with "+strSearchCriteria+": " +strSearchCriteriaValue,true);
			}
			break;

		default:
			break;
		}		
		return stractualSearchCriteriaValue;
	}


	public boolean verifySearchUsingAccumulatorCriteria(String accumType,String accumValue,String dollarMax,String dollarMaxValue,String expectedValue,int intMaxTime)
	{
		boolean result=false;
		int dollarValue=0;
		try
		{						
			switch (accumType) {
			case "Benefit Period Maximum":				
				seClick(FindPlanPage.get().dollarMax,"Dollar Maximum");
				waitForPageLoad(300);
				seClick(FindPlanPage.get().selectDollarMax(dollarMax),"Dollar Maximum");
				waitForPageLoad(300);			
				seSetText(FindPlanPage.get().dollarMaxValue,dollarMaxValue,"Dollar Maximum Value");
				waitForPageLoad(300);
				break;
			case "Choice":
				seClick(FindPlanPage.get().choice, "Choice");
				waitForPageLoad(300);
				seClick(FindPlanPage.get().selectAccumValue(dollarMax),"Choice value");
				waitForPageLoad(300);
				break;
			case "Coinsurance":
				seClick(FindPlanPage.get().percentage, "Dollar Maximum");
				waitForPageLoad(300);			
				seClick(FindPlanPage.get().selectPercentageMax(dollarMax),"Dollar Maximum");
				waitForPageLoad(300);
				seSetText(FindPlanPage.get().percentageValue,dollarMaxValue,"Dollar Maximum Value");
				waitForPageLoad(300);
				break;
			case "Copayment Maximum":
				seClick(FindPlanPage.get().dollarMax,"Dollar Maximum");
				waitForPageLoad(300);
				seClick(FindPlanPage.get().selectDollarMax(dollarMax),"Dollar Maximum");
				waitForPageLoad(300);	
				seSetText(FindPlanPage.get().dollarMaxValue,dollarMaxValue,"Dollar Maximum Value");
				waitForPageLoad(300);
				break;
			case "Deductible":
				seClick(FindPlanPage.get().dollarMax,"Dollar Maximum");
				waitForPageLoad(300);
				seClick(FindPlanPage.get().selectDollarMax(dollarMax),"Dollar Maximum");
				waitForPageLoad(300);	
				seSetText(FindPlanPage.get().dollarMaxValue,dollarMaxValue,"Dollar Maximum Value");
				waitForPageLoad(300);
				break;
			case "Dollar Limit":
				seClick(FindPlanPage.get().dollarMax,"Dollar Maximum ");
				waitForPageLoad();
				seClick(FindPlanPage.get().selectDollarMax(dollarMax),"Dollar Maximum");
				waitForPageLoad();	
				seSetText(FindPlanPage.get().dollarMaxValue,dollarMaxValue,"Dollar Maximum Value");
				waitForPageLoad();
				break;
			case "Lifetime Maximum":
				seClick(FindPlanPage.get().dollarMax,"Dollar Maximum");
				waitForPageLoad();
				seClick(FindPlanPage.get().selectDollarMax(dollarMax),"Dollar Maximum");
				waitForPageLoad();	
				seSetText(FindPlanPage.get().dollarMaxValue,dollarMaxValue,"Dollar Maximum Value");
				waitForPageLoad();
				break;
			case "Out of Pocket Maximum":
				seClick(FindPlanPage.get().dollarMax,"Dollar Maximum");
				waitForPageLoad();
				seClick(FindPlanPage.get().selectDollarMax(dollarMax),"Dollar Maximum");
				waitForPageLoad();	
				seSetText(FindPlanPage.get().dollarMaxValue,dollarMaxValue,"Dollar Maximum Value");
				waitForPageLoad();
				break;
			case "Penalty":
				seClick(FindPlanPage.get().dollarMax,"Dollar Maximum");
				waitForPageLoad();
				seClick(FindPlanPage.get().selectDollarMax(dollarMax),"Dollar Maximum");
				waitForPageLoad();	
				seSetText(FindPlanPage.get().dollarMaxValue,dollarMaxValue,"Dollar Maximum Value");
				waitForPageLoad();
				break;				
			case "Service Deductible":
				seClick(FindPlanPage.get().dollarMax,"Dollar Maximum");
				waitForPageLoad();
				seClick(FindPlanPage.get().selectDollarMax(dollarMax),"Dollar Maximum");
				waitForPageLoad();	
				seSetText(FindPlanPage.get().dollarMaxValue,dollarMaxValue,"Dollar Maximum Value");
				waitForPageLoad();
				break;	
			case "Unit":
				seClick(FindPlanPage.get().dollarMax,"Dollar Maximum");
				waitForPageLoad();
				seClick(FindPlanPage.get().selectDollarMax(dollarMax),"Dollar Maximum");
				waitForPageLoad();	
				seSetText(FindPlanPage.get().dollarMaxValue,dollarMaxValue,"Dollar Maximum Value");
				waitForPageLoad();
				break;
			case "Up Front Deductible":
				seClick(FindPlanPage.get().dollarMax,"Dollar Maximum");
				waitForPageLoad();
				seClick(FindPlanPage.get().selectDollarMax(dollarMax),"Dollar Maximum");
				waitForPageLoad();	
				seSetText(FindPlanPage.get().dollarMaxValue,dollarMaxValue,"Dollar Maximum Value");
				waitForPageLoad();
				break;
			default:
				break;
			}
			seClick(FindPlanPage.get().planSearch, "Search button");
			waitForPageLoad(700);
//			getWebDriver().manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
//			boolean blnIsElementDisplayed = seIsElementNotDisplayed(FindPlanPage.get().searchPlanErrorMsg, "Error message");
//			getWebDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//			if(blnIsElementDisplayed)
//			{
				seWaitForClickableWebElement(FindPlanPage.get().searchResults, 500);
			if(FindPlanPage.get().searchResults.isDisplayed())
			{
				log(PASS, "Find Plan","Plan found with given accum type "+accumType);
				List<WebElement> tableResults=getWebDriver().findElements(By.xpath("//div[@class='findPlanResults']/div/table/tbody/tr"));
				for(int i=1;i<tableResults.size();i++)
				{
					WebElement value=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div/table/tbody/tr["+i+"]/td[9]"));
					String status=value.getText().toString().trim();
					if(!status.equalsIgnoreCase("Draft"))
					{
						waitForPageLoad(200);
						getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div/table/tbody/tr["+i+"]/td[9]")).click();
						waitForPageLoad(300);
						switch (accumType) {
						case "Benefit Period Maximum":
							dollarValue=Integer.parseInt(dollarMaxValue);
							result=PlanLevelBenefitsPage.get().verifyBenefitPeriodMax(accumValue, expectedValue, dollarValue, dollarMax,intMaxTime);								
							break;
						case "Choice":
							result=PlanLevelBenefitsPage.get().verifyChoice(accumValue, expectedValue, dollarMax,intMaxTime);							
							break;
						case "Coinsurance":
							dollarValue=Integer.parseInt(dollarMaxValue);
							result=PlanLevelBenefitsPage.get().verifyCoinsuranceMax(accumValue, expectedValue,dollarMax, dollarValue,intMaxTime);							
							break;
						case "Copayment Maximum":
							dollarValue=Integer.parseInt(dollarMaxValue);
							result=PlanLevelBenefitsPage.get().verifyCopaymentMax(accumValue, expectedValue,dollarMax, dollarValue,intMaxTime);							
							break;
						case "Deductible":
							dollarValue=Integer.parseInt(dollarMaxValue);
							result=PlanLevelBenefitsPage.get().verifyDeductibleMax(accumValue, expectedValue,dollarMax, dollarValue,intMaxTime);								
							break;
						case "Dollar Limit":
							dollarValue=Integer.parseInt(dollarMaxValue);
							result=PlanOptionsPage.get().verifyDollarLimit(accumValue, expectedValue,dollarMax, dollarValue,intMaxTime);								
							break;							
						case "Lifetime Maximum":
							dollarValue=Integer.parseInt(dollarMaxValue);
							result=PlanBenefitOptionsPage.get().verifyLifetimeMaximum(accumValue, expectedValue,dollarMax, dollarValue,intMaxTime);							
							break;	
						case "Out of Pocket Maximum":
							dollarValue=Integer.parseInt(dollarMaxValue);
							result=PlanLevelBenefitsPage.get().verifyOutOfPocketMax(accumValue, expectedValue,dollarMax, dollarValue,intMaxTime);						
							break;
						case "Penalty":
							dollarValue=Integer.parseInt(dollarMaxValue);
							result=PlanLevelBenefitsPage.get().verifyPenalty(accumValue, expectedValue,dollarMax, dollarValue,intMaxTime);								
							break;
						case "Service Deductible":
							dollarValue=Integer.parseInt(dollarMaxValue);
							result=PlanBenefitOptionsPage.get().verifyServiceDeductible(accumValue, expectedValue,dollarMax, dollarValue,intMaxTime);							
							break;
						case "Unit":
							dollarValue=Integer.parseInt(dollarMaxValue);
							result=PlanBenefitOptionsPage.get().verifyUnit(accumValue, expectedValue,dollarMax, dollarValue,intMaxTime);								
							break;
						case "Up Front Deductible":
							dollarValue=Integer.parseInt(dollarMaxValue);
							result=PlanLevelBenefitsPage.get().verifyUpFrontDeductible(accumValue, expectedValue,dollarMax, dollarValue,intMaxTime);								
							break;
						default:
							break;
						}						
						break;						
					}
					else
					{
						continue;
					}
				}
			}
			
			else
			{
				RESULT_STATUS = false;
				log(FAIL, "Find Plan","Plan not found with given header Criteria "+headerCriteria);
			}
			
		}
		catch(Exception e)
		{
			RESULT_STATUS = false;
			log(FAIL,"Data is not correct","Data is not correct "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * @author AF14735
	 * This Function will find the plan with OPtion Search verifify the Option Creiteria search Results
	 * @param strPlanOptionArea-Eg: Benefit OPtion
	 * @param strPlanOptionType-Eg: Acupucnture
	 * @param strPlanOptionName-EG: Acupuncture Covered
	 * @return
	 */
	public String verifyOptionCriteriaSearch(String strPlanOptionArea,String strPlanOptionType, String strPlanOptionName){

		String actualoptionCriteria="";
		try{
			waitForPageLoad(400);
			seClick(FindPlanPage.get().optionCriteria, "optionCriteria");
			waitForPageLoad();
			seClick(FindPlanPage.get().planOptionArea, "Plan Option Area");
			seClick(FindPlanPage.get().planOptionAreaValue(strPlanOptionArea),"PlanOptionArea "+strPlanOptionArea);
			waitForPageLoad();

			seClick(FindPlanPage.get().planOptionType, "Plan Option Type");
			seClick(FindPlanPage.get().planOptionTypeValue(strPlanOptionType),"PlanOptionType "+strPlanOptionType);
			waitForPageLoad();
			seClick(FindPlanPage.get().planOptionName, "Plan Option Name");
			seClick(FindPlanPage.get().planOptionAreaValue(strPlanOptionName),"PlanOptionName "+strPlanOptionName);
			waitForPageLoad();
			seClick(FindPlanPage.get().planSearch, "Search button");
			waitForPageLoad(500);
			if(FindPlanPage.get().searchResults.isDisplayed()){
				WebTableWithHeader searchResults = new WebTableWithHeader(FindPlanPage.get().searchResults, "Plan Search Results ");
				int intRowNum = searchResults.getRowWithCellTextInColumn(1, 9, "Production");
				seClick(searchResults.getCell(intRowNum, 9), "Plan");
				waitForPageLoad(300);
				PlanOptionsPage.clickTab(strPlanOptionArea, strPlanOptionType, 600);
				/*seClick(PlanOptionsPage.get().optionsTab(strPlanOptionArea), strPlanOptionArea+" Tab");
				waitForPageLoad(200);
				for (WebElement element : PlanOptionsPage.get().optionsTabvalues) {
					Actions act = new Actions(getWebDriver());
					act.moveToElement(element).build().perform();
					String strOptionValue = element.getText();
					if(strOptionValue.equalsIgnoreCase(strPlanOptionType))
					{
						seWaitForElementLoad(PlanOptionsPage.get().optionsTabvalues(strPlanOptionType));
						seClick(PlanOptionsPage.get().optionsTabvalues(strPlanOptionType), strPlanOptionType);
						break;
					}
				}*/
				waitForPageLoad(500);
				for (WebElement element : PlanOptionsPage.get().optionsTypeValues) {
					String strOptionValue = element.getText();
					if(strOptionValue.equalsIgnoreCase(strPlanOptionName))
					{
						actualoptionCriteria=strOptionValue;
						break;
					}
				}

			}
			else if(FindPlanPage.get().searchPlanErrorMsg.isDisplayed())
			{
				log(SKIP, "Find Plan","Plan not found with given Optionr Criteria "+strPlanOptionType);
			}
		}
		catch(Exception e)
		{
			log(FAIL,"Data is not correct","Data is not correct",true);
		}
		return actualoptionCriteria;
	}


	public static void seSearchByPlanProxyID(String strPlanID) {
		seWaitForClickableWebElement(HomePage.get().find, 10);
		seClick(HomePage.get().find, "on Find Menu");
		seClick(HomePage.get().findPlan, "Find Plan Option");
        waitForPageLoad(75);
        seSetText(FindPlanPage.get().planProxyId, strPlanID, "Set Plan ID in plan version id text Box");	
        seWaitForClickableWebElement(FindPlanPage.get().planSearch, 12);
		seClick(FindPlanPage.get().planSearch, "on Search button");
		seWaitForClickableWebElement(FindPlanPage.get().selectSearchedPlan, 720);
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);
		waitForPageLoad();
	}

	public static void seSearchPlanByPlanVersionID(String strPlanID) {
		seWaitForClickableWebElement(HomePage.get().find, 10);
		seClick(HomePage.get().find, "on Find Menu");
		seClick(HomePage.get().findPlan, "Find Plan Option");
        waitForPageLoad();
		seSetText(FindPlanPage.get().planVersionID, strPlanID, "Set Plan ID in plan version id text Box");		
        seWaitForClickableWebElement(FindPlanPage.get().planSearch, 12);
		seClick(FindPlanPage.get().planSearch, "on Search button");
		seWaitForClickableWebElement(FindPlanPage.get().selectSearchedPlan, 720);
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);

		waitForPageLoad();
	}

	@FindBy(how = How.XPATH, using = "//div[@id='benefit-criteria']/div[1]")
	@CacheLookup
	public WebElement benefitCriteria;
	
	public void selectTheBenefit(String strBenefit){
		seClick(FindPlanPage.get().selectTheBenefit,"select Benefit");
	    WebElement listOfBenefits = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+strBenefit+"')]"));
	    listOfBenefits.click();
	    
	}
	
	@FindBy(how = How.XPATH, using = "//*[contains(text(),'Select the Benefit')]")
	@CacheLookup
	public WebElement selectTheBenefit;
	
	public void situationGroup(String strGroup){
		seClick(FindPlanPage.get().situationGroup,"Situation Group");
	    WebElement listOfBenefits =getWebDriver().findElement(By.xpath("//span[contains(text(),'"+strGroup+"')]"));
	    listOfBenefits.click();
	    
	}
	/*public void situationGroup(String strGroup){
	 seClick(FindPlanPage.get().situationGroup,"Situation Group");
	    WebElement listOfBenefits = driver.findElement(By.xpath("//li[@role='treeitem']/*[contains(text(),'"+strGroup+"')]"));
	    seClick(listOfBenefits, strGroup+" clicked");
	    
	    
	   Select drop =  new Select(driver.findElement(By.xpath("//select[@class='situationGroup select2-hidden-accessible']")));
	   drop.deselectByIndex(1);
	    
	}*/
	@FindBy(how = How.XPATH, using = "//*[contains(text(),'Select the Situation Group')]")
	@CacheLookup
	public WebElement situationGroup;
	
	@FindBy(how = How.XPATH, using = "//*[contains(text(),'Select the Situation Type')]")
	@CacheLookup
	public WebElement situationType;
	
	/*public void situationType(String strBenefit){
		seClick(FindPlanPage.get().situationType,"Situation Type");
	    WebElement listOfBenefits = driver.findElement(By.xpath("//li[@role='treeitem']/*[contains(text(),'"+strBenefit+"')]"));
	    listOfBenefits.click();
	    
	}*/
	
	public void situationType(String strBenefit){
		seClick(FindPlanPage.get().situationType,"Situation Type");
	    WebElement listOfBenefits = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+strBenefit+"')]"));
	    listOfBenefits.click();
	    
	}
	
	@FindBy(how = How.XPATH, using = "//form[@id='findPlanSearch']/div[2]/button[@class='btn btn-sm btn-primary find pull-right']")
	@CacheLookup
	public WebElement searchoption;
	
	@CacheLookup
	@FindBy(how=How.XPATH,using="//table[@class='table searchResultsTable fjaTable dataTable']//tr[@class='rowlink odd'][1]")
	public WebElement plandetails;
	
	public  void benefit(){
		   WebElement Benefits = getWebDriver().findElement(By.xpath("//*[contains(@id,'BenefitTree')]")) ;
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",Benefits); 
	   }
	
	@FindBy(how = How.XPATH, using = "//*[@id='benefitsTree']/ul/li[3]/ul[1]/li/div")
	@CacheLookup
	public WebElement completePlan;
	
	 public void verifyNetwork(String strNetwork){
		   String strPMO =FindPlanPage.get().participatingPMO.getText();
		   if(strPMO.contains(strNetwork)){
			   log(PASS, "Verify network  text", strNetwork+" present in Network", true);
		   }else{
			   log(FAIL, "Verify network  text", strNetwork+" present in Network", true);
		   }
		   
	   }
	 
	 @FindBy(how = How.XPATH, using = "//*[@id='content-planBenefitDetails']/div[2]/div/div[2]/div[1]/span[1]/span")
		@CacheLookup
		public WebElement participatingPMO;
	
	 public void verifySituation(String strNetwork){
		   String strUnless = FindPlanPage.get().unlessOtherwise.getText();
		
		   if(strUnless.contains(strNetwork)){
			   log(PASS, "Verify Situtaion  text", strNetwork+" present in Network", true);
		   }else{
			   log(PASS, "Verify Situtation  text", strNetwork+" present in Network", true);
		   }
	}
	 

		@FindBy(how = How.XPATH, using = "//*[@id='content-planBenefitDetails']/div[2]/div/div[2]/div[1]/span[2]/span")
		@CacheLookup
		public WebElement unlessOtherwise;
		
		
		public void createFormDate(String Date){
			seClick(createFrom, "clicked on the create form date field");
			FindPlanPage.get().createFrom.sendKeys(Date);
		}
		
		@FindBy(how = How.XPATH, using = "//input[@class='date datepicker masked createDateFrom validateDate hasDatepicker']")
		@CacheLookup
		public WebElement createFrom;
		
		@FindBy(how = How.XPATH, using = "//input[@class='date datepicker masked createDateTo validateDate hasDatepicker']")
		@CacheLookup
		public WebElement createThrough;

		public void createToDate(String Date){
			seClick(createThrough, "clicked on the create through date field");
			FindPlanPage.get().createThrough.sendKeys(Date);
		}
		
		public List<WebElement> createdtext(){
			List<WebElement> element = driver.findElements(By.xpath("//*[contains(@class,'actionTaken')][1]"));
			return element;
			}
		
		@FindBy(how = How.XPATH, using = "//*[contains(text(),'Copied')]/following-sibling::td[3]")
		@CacheLookup
		public WebElement createdValueCopied;

		@FindBy(how = How.XPATH, using = "//*[contains(text(),'Edited')]/following-sibling::td[3]")
		@CacheLookup
		public WebElement createdValueEdited;

		@FindBy(how = How.XPATH, using = "//*[contains(text(),'Created')]/following-sibling::td[3]")
		@CacheLookup
		public WebElement createdValueCreated;
		
		public boolean verifyDate(String dtmDateValue,int dtmValueTodate,int dtmValueFromDate){
			boolean result =false;
			try{
			String strDate =dtmDateValue.substring(3, 5);
			int intDate = Integer.parseInt(strDate); 
			waitForPageLoad(360);
			if(intDate<dtmValueTodate|| intDate>dtmValueFromDate){
				log(PASS, "Created Date is between "+dtmValueFromDate+" and "+dtmValueTodate);
			}else{
				log(FAIL, "Created Date is not between "+dtmValueFromDate+" and "+dtmValueTodate);
			}
			}
			catch(Exception e){
				RESULT_STATUS = false;
				logger.debug("Exception Occured: "+"Date is incorrect");
				log(ERROR,"Exception occured: "+"Date is incorrect");
				

			}
			return result;
		}
		
		public void modifiedToDate(String date){
			seClick(FindPlanPage.get().modifiedToDate, "Date is passed as"+date);
			FindPlanPage.get().modifiedToDate.sendKeys(date);
		}
		
		@FindBy(how = How.NAME, using = "criteria[modDateFromString]")
		@CacheLookup
		public WebElement modifiedToDate;
		

@FindBy(how = How.NAME, using = "criteria[modDateToString]")
@CacheLookup
public WebElement modifiedfromDate;

public void modifiedFromDate(String date){
	seClick(FindPlanPage.get().modifiedfromDate, "Date is passed as"+date);
	FindPlanPage.get().modifiedfromDate.sendKeys(date);
}

@FindBy(how = How.XPATH, using ="//*[contains(@id,'DataTables_Table')]/following::tr[3]/td[11]")
@CacheLookup
public WebElement modifiedFirstRow;

@FindBy(how = How.XPATH, using = "//button[@title='History']")
@CacheLookup
public WebElement history;

	/**
	 * This method can be used to search for plan using Plan Version Id provided the current screen is 'Find Plan' page.
	 * @param strPlanVersionId (required) Plan Version Id which is being searched for
	 */
	public void seSearchByPlanVersionID(String strPlanVersionId) {
		try {
			seSetText(FindPlanPage.get().planVersionID, strPlanVersionId, "Plan Version ID");
			seClick(FindPlanPage.get().planSearch, "Search");
			seWaitForClickableWebElement(FindPlanPage.get().selectSearchedPlan, 60);

			if (FindPlanPage.get().selectSearchedPlan.isDisplayed()
					&& FindPlanPage.get().selectSearchedPlan.isEnabled()) {
				RESULT_STATUS = true;
				log(PASS, "Verify if the Plan is displayed in results.",
						"The Plan '" + strPlanVersionId + "' is displayed in search results." + ". RESULT=PASS");
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify if the Plan is displayed in results.",
						"The Plan '" + strPlanVersionId + "' is NOT displayed in search results." + ". RESULT=FAIL");
			}
		} catch (Exception e) {
			log(ERROR, "Exception occurred while executing 'seSearchByPlanVersionID' method.");
		}
	}

	/**
	 * This method opens the first plan from the 'Find Plan' search results grid
	 */
	public void seOpenFirstPlanFromFindPlanResults() {
		try {
			seClick(FindPlanPage.get().selectSearchedPlan, "Searched Plan");
			seWaitForClickableWebElement(PCPSPCBreakoutSetupPage.get().planLevelBenefits, 60);

			if (PCPSPCBreakoutSetupPage.get().planLevelBenefits.isDisplayed()
					&& PCPSPCBreakoutSetupPage.get().planLevelBenefits.isEnabled()) {
				RESULT_STATUS = true;
				log(PASS, "Verify if the Plan is opened.", "The Plan is opened." + ". RESULT=PASS");
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify if the Plan is opened.", "The Plan is NOT opened." + ". RESULT=FAIL");
			}
		} catch (Exception e) {
			log(ERROR, "Exception occurred while executing 'seOpenFirstPlanFromFindPlanResults' method.");
		}
	}

	/**
	 * This method can be used to navigate to 'Find Plan' page.
	 */
	public void seNavigateToSearchPlanPage() {
		try {
			seWaitForClickableWebElement(HomePage.get().find, 60);
			seClick(HomePage.get().find, "Find");
			seWaitForClickableWebElement(HomePage.get().findPlan, 60);
			seClick(HomePage.get().findPlan, "Find Plan");
			seWaitForClickableWebElement(FindPlanPage.get().planVersionID, 60);

			if (FindPlanPage.get().planVersionID.isDisplayed() && FindPlanPage.get().planVersionID.isEnabled()) {
				RESULT_STATUS = true;
				log(PASS, "Verify if the current screen is 'Find Plan' Page.",
						"Current screen is 'Find Plan' page as expected" + ". RESULT=PASS");
			} else {
				RESULT_STATUS = false;
				log(FAIL, "Verify if the current screen is 'Find Plan' Page.",
						"Current screen is NOT 'Find Plan' page as expected" + ". RESULT=FAIL");
			}
		} catch (Exception e) {
			log(ERROR, "Exception occurred while executing 'seNavigateToSearchPlanPage' method.");
		}
	}

	

}
