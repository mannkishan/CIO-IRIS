package page.planConfigurator;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import utility.CoreSuperHelper;
import utility.ExcelUtility;

public class TemplatePlanSetUpPage extends CoreSuperHelper{
	
	private static TemplatePlanSetUpPage thisTestObj;	
	public synchronized static TemplatePlanSetUpPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), TemplatePlanSetUpPage.class);
		return thisTestObj;
	}
	
	@FindBy(how = How.LINK_TEXT, using = "Plan Administration")
	public WebElement planAdministration;
	
	@FindBy(how = How.ID, using = "POA_PlanSetup-_-PlanAdmin-_-PlanAdmin-_-NA-_-NA-_-UMRulePenaltyPlanDesign_-_choice")
	@CacheLookup
	public WebElement UMRulePenaltyPlanDesign;
	
	
	public String updateUMRule()
	{
		String newUMRule = "";
		try
		{
		waitForPageLoad();
		Select dropDown = new Select(UMRulePenaltyPlanDesign);
		List<WebElement> options = dropDown.getOptions();
		String selectedOption = seGetDropDownValue(TemplatePlanSetUpPage.get().UMRulePenaltyPlanDesign);
		for(int i=0; i< options.size();i++)
		{
			String optionText = options.get(i).getText();
		if(!(optionText.equalsIgnoreCase("- Please Select -") || optionText.equalsIgnoreCase(selectedOption)))
		{
			log(PASS, "Current UM Rule: "+ selectedOption+" Modified UM Rule"+ newUMRule);
			newUMRule = optionText;
			seSelectText(UMRulePenaltyPlanDesign, optionText, "Select "+optionText+" from the UM Rule Penalty Plan Design");
			break;
		}
		}
		waitForPageLoad(360);
//		seClick(FindTemplatePage.get().save, "Click Save Button ");
//		waitForPageLoad(360);
		waitForPageLoad();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			log(FAIL, "Update UM Rule","Exception occured in Update UM Rule"+e.getMessage());
		}
		return newUMRule;
	}
	
	
	
	

}
