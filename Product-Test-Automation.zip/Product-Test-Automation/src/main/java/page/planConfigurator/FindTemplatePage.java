package page.planConfigurator;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utility.CoreSuperHelper;
import utility.WebTable;
import utility.WebTableWithHeader;

public class FindTemplatePage extends CoreSuperHelper{


	private static FindTemplatePage thisTestObj;	
	public synchronized static FindTemplatePage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), FindTemplatePage.class);
		return thisTestObj;
	}

	@FindBy(how = How.XPATH, using = "//div[@id='findPlan']/form/div[3]/div/div[5]/input[@type='text']")
	@CacheLookup
	public WebElement effDate;

	@FindBy(how = How.NAME, using = "criteria[effDateFromString]")
	@CacheLookup
	public WebElement effFrom;


	@FindBy(how = How.XPATH, using = "//*[@id=\"findPlanSearch\"]/div[1]/button")
	@CacheLookup
	public WebElement searchButton; 

	@FindBy(how = How.NAME, using = "criteria[proxyId]")
	@CacheLookup
	public WebElement templateProxyId;  

	@FindBy(how = How.NAME, using = "criteria[planId]")
	@CacheLookup
	public WebElement versionId;  

	@FindBy(how = How.XPATH, using = "//div[@class='findPlanResults']/div/table/tbody/tr[1]/td[7]")
	@CacheLookup
	public WebElement templateSearchResults;

	@FindBy(how = How.XPATH, using = "//div[@id='findPlan']/form/div[5]/button[3]")
	@CacheLookup
	public WebElement templateSearch;

	@FindBy(how = How.CSS, using = "table[class='table searchResultsTable fjaTable dataTable']")
	@CacheLookup
	public WebElement templateResults;

	@FindBy(how = How.NAME, using = "criteria[createDateFromString]")
	@CacheLookup
	public WebElement createFrom;

	@FindBy(how = How.NAME, using = "criteria[createDateToString]")
	@CacheLookup
	public WebElement createThrough;

	@FindBy(how = How.NAME, using = "criteria[modDateFromString]")
	@CacheLookup
	public WebElement modifiedFrom;

	@FindBy(how = How.NAME, using = "criteria[modDateToString]")
	@CacheLookup
	public WebElement modifiedThrough;

	@FindBy(how = How.XPATH, using = ".//*[@id='message_frontEnd_message_NoPlansmeettheenteredcriteria_Pleaseeditthecriteriaandtryagain_warning']/span")
	@CacheLookup
	public WebElement searchPlanErrorMsg;


	public By findTemplateFrame = By.id("template-iframe-findPlan");

	@FindBy(how = How.XPATH, using = "//div[@id=\"find-plan-sectionWrapper\"]/div[2]/div[1]")
	@CacheLookup
	public WebElement searchCriteria;

	@FindBy(how = How.XPATH, using = "//div[@id='verticalBarMenu']/div[2]/ul/li[@id='PlanOptions']/a")
	@CacheLookup
	public WebElement planOption;

	@FindBy(how = How.XPATH, using = "//div[@id='verticalBarMenu']/div[2]/ul/li[9]/a[contains(text(),'Benefits')]")
	@CacheLookup
	public WebElement benefits; 

	@FindBy(how = How.XPATH, using = "//div[@id='content-benefitSearchBar']/div[2]/div/input")
	@CacheLookup
	public WebElement benefitsSearchField;

	@FindBy(how = How.XPATH, using = "//div[@id='content-benefitSearchBar']/div[2]/button[2]")
	@CacheLookup
	public WebElement benefitsSearch;

	@FindBy(how = How.XPATH, using = ".//*[@id='content-benefitSearchBar']/div[2]/button[1]")
	@CacheLookup
	public WebElement clearButton;

	@FindBy(how = How.XPATH, using = "//div[@id='actionsBarWrapper']/ul/li[5]/a[text()='Save']")
	@CacheLookup
	public WebElement save;   


	@FindBy(how = How.XPATH, using = "//div[@id='findPlan']/form/div[3]/div/div[2]/input")
	@CacheLookup
	public WebElement templateVersionID;

	@FindBy(how = How.XPATH, using = "//div[@id='benefitsTreeWrapper']/aside/ul/li[22]/ul[2]/li/ul[1]/li/div/div/span/div/span[@title='Visible']/input")
	@CacheLookup
	public WebElement urgentCareAdvImg;

	@FindBy(how = How.XPATH, using = "//*[@id=\"benefitsTree\"]/ul/li[22]/ul[2]/li/ul[1]/li/div/div/div/a")
	@CacheLookup
	public WebElement benefitValue;

	@FindBy(how = How.XPATH, using = "//div[@id='findPlan']/form/div[3]/div/div[11]/input[@type='text']")
	@CacheLookup
	public WebElement templateName;

	@FindBy(how = How.XPATH, using = "//div[@id='verticalBarMenu-wrapper']/div[1]/div/div[3]/div[@title='Scroll Down']")
	@CacheLookup                      
	public WebElement scrollDown;

	public String templateFrame = "template-iframe-findPlan";



	@FindBy(how = How.ID, using = "POA_PlanOptions-_-OfficeExamsPCP-_-CoveredINNOON-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-CopayINNT1PCP_-_amount")
	@CacheLookup
	public WebElement InNetworkPrimaryCarePhysicianCopay;

	@FindBy(how = How.XPATH, using = ".//*[@id='subCollapse2']/table/tbody/tr[2]/td[2]/div[2]/span[2]/span/span[1]/input")
	@CacheLookup
	public WebElement InNetworkPrimaryCarePhysicianCopayAmount;



	@FindBy(how = How.XPATH, using = ".//*[@id='POA_PlanOptions-_-OfficeExams-_-CoveredINNOnly-_-CostSharesINNT1-_-BenefitSpecificCostShares-_-ApplyDed']/span[1]")
	@CacheLookup
	public WebElement 	labelapplyDeductable   ;

	@FindBy(how = How.ID, using = "POA_BenefitOption-_-Acupuncture-_-CoveredINNOON-_-NA-_-NA-_-CoveredForPainManagementOnly_-_choice")
	@CacheLookup
	public WebElement 	CoveredForPainManagementOnly  ;

	@FindBy(how = How.NAME, using = "criteria[headerCriterias][0][values][]")
	@CacheLookup
	public WebElement templateDescription;

	@FindBy(how = How.XPATH, using = "//textarea[@name='planDescription']")
	@CacheLookup
	public WebElement templateInfoTempDesc;


	@FindBy(how = How.XPATH, using = ".//*[@id='message_frontEnd_message_NoPlansmeettheenteredcriteria_Pleaseeditthecriteriaandtryagain_warning']/span")
	@CacheLookup
	public WebElement searchTemplateErrorMsg;

	@FindBy(how = How.XPATH, using = "//div[@id='header-criteria']/div/div[1]")
	@CacheLookup
	public WebElement headerCriteria;

	@FindBy(how = How.XPATH, using = "//div[@id='header-criteria']/div/div[2]/div/div[1]/div[1]/div[1]/span/span[1]/span/span[1]")
	@CacheLookup
	public WebElement headerCriteriaType;

	@FindBy(how = How.XPATH, using = "//div[@id='Find-header-criteria-collapse']/div/div[1]/div[2]/div[1]/span/span[1]/span/ul")
	@CacheLookup
	public WebElement value;

	public WebElement selectValueType(String type)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//div[starts-with(@class,'typeAheadContainer sub no-scroll')]/span[2]/span/span/ul/li/span[contains(text(),'"+type+"')]"));
		return valueType;
	}


	public WebElement headerCritTypeValue(String type)
	{
		WebElement headerType = getWebDriver().findElement(By.xpath("//div[starts-with(@class,'typeAheadContainer main')]/span/span/span[2]/ul/li[text()='"+type+"']"));
		return headerType;
	}


	public static void findTemplate(String versionId)
	{
		waitForPageLoad(300);
		seClick(HomePage.get().find, "Find");
		seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(HomePage.get().findTemplate));
		seClick(HomePage.get().findTemplate, "Find Template");
		waitForPageLoad();
		seSetText(FindTemplatePage.get().templateVersionID, versionId,"Set text value in the Template version id field");
		seClick(FindTemplatePage.get().templateSearch, "Click Search Button");
		waitForPageLoad();
		seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(FindTemplatePage.get().templateSearchResults));
		if(FindTemplatePage.get().templateSearchResults.isDisplayed()){
			log(PASS,"Template with required status is found","Template with required status is found",true);
			seClick(FindTemplatePage.get().templateSearchResults, "Click Template from results displayed ");
			waitForPageLoad();			
		}
		else{
			log(FAIL," No Templates avaialable","No templates availabe",true);
		}		
	}

	public static boolean findTemplate(String versionId, String strPlanStatus)
	{
		waitForPageLoad(300);
		seWaitForWebElement(240, ExpectedConditions.elementToBeClickable(HomePage.get().find));
		seClick(HomePage.get().find, "Find");
		seWaitForWebElement(120, ExpectedConditions.elementToBeClickable(HomePage.get().findTemplate));
		seClick(HomePage.get().findTemplate, "Find Template");
		waitForPageLoad();
		seSetText(FindTemplatePage.get().templateVersionID, versionId,"Set text value in the Template version id field");
		seClick(FindTemplatePage.get().templateSearch, "Click Search Button");
		waitForPageLoad();
		seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(FindTemplatePage.get().templateSearchResults));
		if(FindTemplatePage.get().templateSearchResults.isDisplayed()){
			if(FindTemplatePage.get().templateSearchResults.getText().equalsIgnoreCase(strPlanStatus))
			{
				return true;
			}
			else
			{
				return false;
			}

		}
		else{
			return false;
		}		
	}


	public static void findTemplate_situation(String templateName)
	{
		seClick(HomePage.get().find, "Find");
		seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(HomePage.get().findTemplate));
		seClick(HomePage.get().findTemplate, "Find Template");
		waitForPageLoad();
		seSetText(FindTemplatePage.get().templateName, templateName,"Set text value in template name text field");
		seClick(FindTemplatePage.get().templateSearch, "Click Search Button");
		waitForPageLoad();
		seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(FindTemplatePage.get().templateSearchResults));
		if(FindTemplatePage.get().templateSearchResults.isDisplayed()){
			log(PASS,"Template with required status is found","Template with required status is found",true);
			seClick(FindTemplatePage.get().templateSearchResults, "Click Template from results displayed ");
			waitForPageLoad();			
		}
		else{
			log(FAIL," No Templates avaialable","No templates availabe",true);
		}		
	}

	public static String editBenefits(String strAddRemoveFlag)
	{
		String benefit=null;
		try{ 	
			seClick(TemplateHeaderPage.get().edit, "Click Edit Button ");
			waitForPageLoad(300);					
			seClick(EditTemplateInformationPage.get().save, "Click Save Button ");
			waitForPageLoad(300);
			WebElement Benefits = getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenu']/div[2]/ul/li[@id=\"BenefitTree\"]/a")) ;
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",Benefits);
			waitForPageLoad(400);	
			benefit=searchBenefit("Urgent Care Advanced Imaging",strAddRemoveFlag);										
			seClick(FindTemplatePage.get().save, "Click Save Button ");
			waitForPageLoad(360);			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			log(FAIL,"Unable to edit template","Unable to edit template",true);
		}		
		return benefit;

	}

	public static String removeSituationType()
	{
		String benefit=null;

		waitForPageLoad(300);
		seClick(TemplateHeaderPage.get().edit, "Edit Button ");
		waitForPageLoad(300);	
		seClick(EditTemplateInformationPage.get().save, "Save Button ");
		waitForPageLoad(300);
		WebElement Benefits = getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenu']/div[2]/ul/li[9]/a[contains(text(),'Benefits')]")) ;
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",Benefits);
		waitForPageLoad(300);				
		benefit=removeSituation();										
		seClick(TemplateHeaderPage.get().save, "Save Button ");
		waitForPageLoad(300);			
		return benefit;

	}

	public static String addSituationType()
	{
		String benefit=null;
		waitForPageLoad(300);	
		seClick(TemplateHeaderPage.get().edit, "Edit Button ");
		waitForPageLoad(300);					
		seClick(EditTemplateInformationPage.get().save, "Save Button ");
		waitForPageLoad(300);
		//div[@id='verticalBarMenu']/div[2]/ul/li[@id=\"PlanOptions\"]/a
		WebElement Benefits = getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenu']/div[2]/ul/li[@id=\"BenefitTree\"]/a")) ;
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",Benefits);

		waitForPageLoad(300);		
		benefit=addSituation();										
		seClick(TemplateHeaderPage.get().save, "Save Button ");
		waitForPageLoad(420);			
		return benefit;

	}
	public static void approveAuditTemplate()
	{
		try{
			waitForPageLoad(360);
			seClick(TemplateHeaderPage.get().approveAudit,"Clicking on approve audit button");
			waitForPageLoad();
			seClick(TemplateTransitionPage.get().reasonCode,"Clicking on reasonCode dropdown");
			seClick(TemplateTransitionPage.get().selectType("Approved"),"Selecting other and clicking on that");	
			seClick(TemplateTransitionPage.get().approveAuditButton,"Approve audit submit button");
			waitForPageLoad(100);
			seClick(TemplateHeaderPage.get().finalize,"finalize button");
			waitForPageLoad(80);
			seClick(TemplateTransitionPage.get().finalizeButton,"Finalize submit button");
			waitForPageLoad(100);	
			seWaitForClickableWebElement(TemplateHeaderPage.get().moveToProduction, 60);
			seClick(TemplateHeaderPage.get().moveToProduction,"Move to Production");
			waitForPageLoad();
			seWaitForClickableWebElement(TemplateTransitionPage.get().moveToProductionButton, 60);
			seClick(TemplateTransitionPage.get().moveToProductionButton,"Move To Production submit button");
			waitForPageLoad(300);
			String status=seGetText(TemplateHeaderPage.get().status("Production")).toString().trim();
			if(status.equalsIgnoreCase("Production"))
				log(PASS,"Status is Production","Template successfully moved to status :"+status,true);
			else
				log(FAIL,"Status is not Production","Template successfully not moved to status :"+status,true);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			log(FAIL,"Status is not Production","Template successfully not moved to status ",true);
		}
	}

	public static String searchBenefit(String benefit, String strAddRemoveFlag)
	{
		String benefitValue=null;	
		try{
			waitForPageLoad(200);
			seSetText(FindTemplatePage.get().benefitsSearchField, benefit, "Setting benefit value in search field");
			seClick(FindTemplatePage.get().benefitsSearch,"Clicking on benefit search button");
			waitForPageLoad(400);
			if(strAddRemoveFlag.equalsIgnoreCase("ADD"))
			{
				if(!FindTemplatePage.get().urgentCareAdvImg.isSelected())
				{
					log(PASS,"Benefit value is enabled","Benefit type urgent care advanced imaging is enabled",true);
					seClick(true,FindTemplatePage.get().urgentCareAdvImg, "Clicking urgent care advanced imaging checkbox");
					benefitValue=seGetText(FindTemplatePage.get().benefitValue);
					if(benefitValue.equalsIgnoreCase(benefit))
					{
						benefitValue="/UrgentCare/UrgentCareProfessional/UrgentCareAdvancedImaging";
					}
					else
					{
						log(FAIL,"Benefit not found","Expected benefit is not found");
					}
				}
				else
				{
					log(FAIL,"Benefit value is disabled","Benefit type urgent care advanced imaging is disabled",true);
				}
			}
			else if(strAddRemoveFlag.equalsIgnoreCase("REMOVE"))
			{
				if(FindTemplatePage.get().urgentCareAdvImg.isSelected())
				{
					log(PASS,"Benefit value is enabled","Benefit type urgent care advanced imaging is enabled",true);
					seClick(FindTemplatePage.get().urgentCareAdvImg, "Clicking urgent care advanced imaging checkbox");
					benefitValue=seGetText(FindTemplatePage.get().benefitValue);
					if(benefitValue.equalsIgnoreCase(benefit))
					{
						benefitValue="/UrgentCare/UrgentCareProfessional/UrgentCareAdvancedImaging";
					}
					else
					{
						log(FAIL,"Benefit not found","Expected benefit is not found");
					}
				}
				else
				{
					log(FAIL,"Not a valid test","Please check the test data",true);
					throw new IllegalArgumentException("Please check the test data");
				}

			}


		}
		catch(Exception e)
		{
			e.printStackTrace();
			log(FAIL,"Benefit is disabled","Benefit is disabled",true);
		}
		return benefitValue; 
	}





	public static String removeSituation()
	{
		String situationTypeValue=null;	
		int intSituationGroups = getWebDriver().findElements(By.xpath("//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div")).size();
		if(intSituationGroups>0)
		{
			System.out.println("Situations : "+intSituationGroups);
			for(int index = 1; index<= intSituationGroups; index++)
			{
				String strXPATH = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div["+index+"]/div[1]/span[2]/span[2]/div/div[1]/input";
				System.out.println("Situation index : "+index);
				if(getWebDriver().findElement(By.xpath(strXPATH)).isSelected())
				{
					getWebDriver().findElement(By.xpath(strXPATH)).click();
					waitForPageLoad(300);
					String strTypeXPATH = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div["+index+"]/div[1]/span[2]/span[1]";
					situationTypeValue=getWebDriver().findElement(By.xpath(strTypeXPATH))
							.getText().toString().trim();
					System.out.println(situationTypeValue);
					return situationTypeValue;
				}
			}
		}
		else
		{
			RESULT_STATUS = false;
			log(FAIL, "Not able to identify the situation groups","",true);
		}

		return situationTypeValue; 
	}



	public static String addSituation()
	{
		String situationTypeValue=null;	
		waitForPageLoad(300);
		//			seClick(TemplateHeaderPage.get().search,"Click on Search");
		//			waitForPageLoad(300);
		//			seSetText(TemplateHeaderPage.get().search,"Foot Care","Set Text on Search");
		//			waitForPageLoad(300);
		//			seClick(TemplateHeaderPage.get().search_Btn,"Click on Search Button");
		//			waitForPageLoad(360);
		int intSituationGroups = getWebDriver().findElements(By.xpath("//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div")).size();
		if(intSituationGroups>0)
		{
			System.out.println("Situations : "+intSituationGroups);
			for(int index = 1; index<= intSituationGroups; index++)
			{
				String strXPATH = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div["+index+"]/div[1]/span[2]/span[2]/div/div[1]/input";
				System.out.println("Situation index : "+index);
				if(!getWebDriver().findElement(By.xpath(strXPATH)).isSelected())
				{
					getWebDriver().findElement(By.xpath(strXPATH)).click();
					waitForPageLoad(300);
					String strTypeXPATH = "//*[@id=\"content-planBenefitDetails\"]/div[2]/div/div["+index+"]/div[1]/span[2]/span[1]";
					situationTypeValue=getWebDriver().findElement(By.xpath(strTypeXPATH))
							.getText().toString().trim();
					return situationTypeValue;
				}
			}
		}
		else
		{
			RESULT_STATUS = false;
			log(FAIL, "Not able to identify the situation groups","",true);
		}



		return situationTypeValue; 
	}

	public static void requestAuditTemplate(String versionID)
	{
		seWaitForClickableWebElement(TemplateHeaderPage.get().requestAudit, 120);
		seClick(TemplateHeaderPage.get().requestAudit,"Request Audit");
		waitForPageLoad();
		if(getWebDriver().findElements(By.xpath("//div[@id='actionsBarWrapper']/ul[@id='actionsBar']/li[4]/a")).size()>0)
		{
			TemplateHeaderPage.get().requestAudit.click();
		}
		seWaitForClickableWebElement(TemplateTransitionPage.get().reasonCode, 120);
		sePCSelectText(TemplateTransitionPage.get().reasonCode, "Reason Code", "Other", 120);
		seSetText(TemplateTransitionPage.get().comment,"Test","Setting text in comment field");
		seClick(TemplateTransitionPage.get().requestAuditButton,"Clikcing on submit button");
		waitForPageLoad(400);
		sewaitForTemplateStatus(versionID,"Pending Audit");
		findTemplate(versionID);
		waitForPageLoad(300);
		String completionStatus  =getWebDriver().findElement(By.xpath("//div[@id='planHeaderWrapper']/div/div/div[2]/div[2]/div[1]/div[2]/span[2]")).getText().toString().trim();


		completionStatus  =getWebDriver().findElement(By.xpath("//div[@id='planHeaderWrapper']/div/div/div[2]/div[2]/div[1]/div[2]/span[2]")).getText().toString().trim();
		if(completionStatus.equalsIgnoreCase("Pending Audit"))
		{			
			log(PASS,"Verify if status is pending Audit","Status is Pending Audit",true);
		}
		else
		{
			log(FAIL,"Verify if status is pending Audit","Status is not Pending Audit",true);
		}

	}


	public static void sewaitForTemplateStatus(String versionID, String Status)
	{
		ExpectedCondition<Boolean> expectation = new  ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return findTemplate(versionID, Status);
			}
		};

		WebDriverWait wait = new WebDriverWait(getWebDriver(), 600);
		wait.pollingEvery(5, TimeUnit.SECONDS);
		wait.until(expectation);

	}


	public void selectTemplate(String strTemplateVersionID) throws Exception
	{
		try
		{
			getWebDriver().manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
			By errorMessage = By.xpath("//*[@id=\"message_frontEnd_message_NoTemplatesmeettheenteredcriteria_Pleaseeditthecriteriaandtryagain_warning\"]/span");
			List<WebElement> templateNotFound  = getWebDriver().findElements(errorMessage);
			getWebDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			if(!(templateNotFound.size()>0))
			{
				WebTable resultsTable = new WebTable(FindTemplatePage.get().templateResults,"Template results table");
				int rowCount = resultsTable.getRowsCount();
				if(rowCount>0)
				{
					int versionID = resultsTable.getRowWithCellText(strTemplateVersionID);
					if(versionID>0)
					{
						seClick(getWebDriver().findElement(By.xpath("//table/tbody/tr/td["+versionID+"]/span/button/span")), 
								"Template selection");
					}
					else
					{
						log(FAIL, "Select template for template version id_ "+strTemplateVersionID, "Not able to find the template in the results table", true);
						throw new IllegalArgumentException("Not able to find the template in the applciation");
					}
				}


			}
			else
			{
				log(FAIL, "Select template for template version id_ "+strTemplateVersionID, "Not able to find the template in the results table", true);
				throw new IllegalArgumentException("Not able to find the template in the applciation");
			}
		}
		catch (NoSuchElementException e) {
			log(FAIL, "Select template", "No results were found", true);
			throw e;
		}
	}

	public boolean verifyDate(String strfromDate, String strtoDate, String stractualDate){
		boolean isfound=false;
		try{
			SimpleDateFormat formatter = new SimpleDateFormat("MMddyyyy");
			java.util.Date fromDate = formatter.parse(strfromDate.replace("/", ""));
			Date toDate = formatter.parse(strtoDate.replace("/", ""));
			Date actualDate = formatter.parse(stractualDate.replace("/", ""));
			if(actualDate.compareTo(fromDate)>=0&&actualDate.compareTo(toDate)<=0)
				isfound=true;
			else
				isfound=false;
		}
		catch(Exception e)
		{
			log(FAIL,"Verify Date","Exception occured While Verifying Date "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		return isfound;

	}


	/**
	 * @author AF14735
	 * This method will search the plan with Base SearchCriteria and validate the search results
	 * @param strSearchCriteriaValue: value to be searched
	 * @param strSearchCriteria: Base SearchCriteria
	 * @return : boolean value which will indicate whether plan with version id is present or not
	 */
	public String validateBaseCriteriaSearch(String strSearchCriteriaValue,String strSearchCriteria ){
		String stractualSearchCriteriaValue="";
		int intcolumnNum=0;
		switch (strSearchCriteria) {
		case "Template Name":
			seSetText(FindTemplatePage.get().templateName, strSearchCriteriaValue, "Template Name");
			intcolumnNum=2;
			waitForPageLoad();
			seClick(FindTemplatePage.get().templateSearch, "Template Search");
			waitForPageLoad(2,360);
			if(FindTemplatePage.get().templateResults.isDisplayed()){
				WebTableWithHeader searchResults = new WebTableWithHeader(FindTemplatePage.get().templateResults, "Template Search Results");
				int intTotalRows = searchResults.getRowsCount();
				for (int i = 1; i <= intTotalRows; i++) {
					stractualSearchCriteriaValue=searchResults.getCellData(i, intcolumnNum);
					if(!stractualSearchCriteriaValue.contains(strSearchCriteriaValue))
						log(FAIL, "Verify Template in search results","Template do not match with "+strSearchCriteria+": " +strSearchCriteriaValue+" ActualVAlue: "+stractualSearchCriteriaValue);
					else
						log(PASS, "Verify Template in search results","Template match with "+strSearchCriteria+": " +strSearchCriteriaValue+" ActualVAlue: "+stractualSearchCriteriaValue);

				}
			}
			else if(FindTemplatePage.get().searchTemplateErrorMsg.isDisplayed()){
				log(FAIL, "Find Template in search results","No Template Match the search Criteria with "+strSearchCriteria+": " +strSearchCriteriaValue,true);
			}
			break;
		case "Template Description":
			seSetText(FindTemplatePage.get().templateDescription, strSearchCriteriaValue, "Template Description");
			seClick(FindTemplatePage.get().templateSearch, "Template Search");
			waitForPageLoad(2,360);
			if(FindTemplatePage.get().templateResults.isDisplayed()){
				for(int i=1;i<=5;i++)
				{	
					waitForPageLoad();
					WebElement templateInfo=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div/table/tbody/tr["+i+"]/td[10]/i"));
					seClick(templateInfo,"Template Info Option");
					waitForPageLoad();
					stractualSearchCriteriaValue=seGetElementValue(FindTemplatePage.get().templateInfoTempDesc);
					if(!stractualSearchCriteriaValue.contains(strSearchCriteriaValue))
						log(FAIL, "Verify Template in search results","Template do not match with "+strSearchCriteria+": " +strSearchCriteriaValue+" ActualVAlue: "+stractualSearchCriteriaValue,true);
					else
						log(PASS, "Verify Template in search results","Template match with "+strSearchCriteria+": " +strSearchCriteriaValue+" ActualVAlue: "+stractualSearchCriteriaValue,true);
					seClick(PlanHeaderPage.get().closebutton,"Close button");
				}
			}
			else if(FindTemplatePage.get().searchTemplateErrorMsg.isDisplayed()){
				log(FAIL, "Find Plan in search results","No Plan Match the search Criteria with "+strSearchCriteria+": " +strSearchCriteriaValue,true);
			}
			break;
		case "Template Version Id":
			seSetText(FindTemplatePage.get().versionId, strSearchCriteriaValue, "Template Version Id");
			intcolumnNum=3;
			waitForPageLoad(2,360);
			seClick(FindTemplatePage.get().templateSearch, "Template Search");
			waitForPageLoad(2,360);
			if(FindTemplatePage.get().templateResults.isDisplayed()){
				WebTableWithHeader searchResults = new WebTableWithHeader(FindTemplatePage.get().templateResults, "Template Search Results");
				int intTotalRows = searchResults.getRowsCount();
				for (int i = 1; i <=intTotalRows; i++) {
					stractualSearchCriteriaValue=searchResults.getCellData(i, intcolumnNum);
					if(!stractualSearchCriteriaValue.equalsIgnoreCase(strSearchCriteriaValue))
						log(FAIL, "Verify Template in search results","Template do not match with "+strSearchCriteria+": " +strSearchCriteriaValue+" ActualVAlue: "+stractualSearchCriteriaValue);
					else
						log(PASS, "Verify Template in search results","Template match with "+strSearchCriteria+": " +strSearchCriteriaValue+" ActualVAlue: "+stractualSearchCriteriaValue);

				}
			}
			else if(FindTemplatePage.get().searchTemplateErrorMsg.isDisplayed()){
				log(FAIL, "Find Plan in search results","No Plan Match the search Criteria with "+strSearchCriteria+": " +strSearchCriteriaValue,true);
			}
			break;
		case "Proxy Template ID":
			seSetText(FindTemplatePage.get().templateProxyId, strSearchCriteriaValue, "Proxy Template ID");
			seClick(FindTemplatePage.get().templateSearch, "Template Search");
			waitForPageLoad(2,360);
			if(FindTemplatePage.get().templateResults.isDisplayed()){
				WebTableWithHeader searchResults = new WebTableWithHeader(FindTemplatePage.get().templateResults, "Template Search Results");
				int intRowNum = searchResults.getRowWithCellTextInColumn(1, 7, "Production");
				seClick(searchResults.getCell(intRowNum, 9), "Template");
				waitForPageLoad(2,360);
				String[] temp=seGetText(TemplateHeaderPage.get().templateProxyID).split(":");
				stractualSearchCriteriaValue=temp[1].trim();
			}
			else if(FindTemplatePage.get().searchTemplateErrorMsg.isDisplayed()){
				log(FAIL, "Find Plan in search results","No Plan Match the search Criteria with "+strSearchCriteria+": " +strSearchCriteriaValue,true);
			}
			break;
		case "Effective Date":
			seSetText(FindTemplatePage.get().effFrom, strSearchCriteriaValue, "Effective Date");
			intcolumnNum=6;
			waitForPageLoad();
			seClick(FindTemplatePage.get().templateSearch, "Template Search");
			waitForPageLoad(2,360);
			if(FindTemplatePage.get().templateResults.isDisplayed()){
				WebTableWithHeader searchResults = new WebTableWithHeader(FindTemplatePage.get().templateResults, "Template Search Results");
				int intTotalRows = searchResults.getRowsCount();
				for (int i = 1; i < intTotalRows; i++) {
					stractualSearchCriteriaValue=searchResults.getCellData(i, intcolumnNum);
					if(!stractualSearchCriteriaValue.equalsIgnoreCase(strSearchCriteriaValue))
						log(FAIL, "Verify Template in search results","Template do not match with "+strSearchCriteria+": " +strSearchCriteriaValue+" ActualVAlue: "+stractualSearchCriteriaValue);
					else
						log(PASS, "Verify Template in search results","Template match with "+strSearchCriteria+": " +strSearchCriteriaValue+" ActualVAlue: "+stractualSearchCriteriaValue);

				}
			}
			else if(FindTemplatePage.get().searchTemplateErrorMsg.isDisplayed()){
				log(FAIL, "Find Template in search results","No Template Match the search Criteria with "+strSearchCriteria+": " +strSearchCriteriaValue,true);
			}
			break;

		default:
			break;
		}		
		return stractualSearchCriteriaValue;
	}

	public String valueType(String valueType)
	{
		String selectedValue="";
		try
		{
			waitForPageLoad();
			seClick(FindTemplatePage.get().value,"value drop down");
			waitForPageLoad();
			seClick(FindTemplatePage.get().selectValueType(valueType),"value type from value drop dowm"+valueType);
			waitForPageLoad(360);
			selectedValue=seGetElementValue(FindTemplatePage.get().value).toString().trim().substring(1);
			if(valueType.equalsIgnoreCase(selectedValue))
			{
				log(PASS,"Value selected is:"+selectedValue,"Value type selected matches with given value :"+valueType);
			}
			else
			{
				log(FAIL,"Value selected is not :"+selectedValue,"Value type selected does not matches with given value :"+valueType);
			}
			waitForPageLoad();
		}
		catch(Exception e)
		{
			log(FAIL,"Value type drop dowm is empty","Exception occured while selecting value from drop down"+e.getMessage());
		}
		return selectedValue;
	}
	/**
	 * @author AF14735
	 * This method will search the Template with Header SearchCriteria and validate the search results
	 * @param headerCriteria : Header Value with which Template need to be searched
	 * @param valueType : Header Value Type with which Template need to be searched 
	 * @return
	 */

	public boolean verifySearchUsingHeaderCriteria(String headerCriteria,String valueType)
	{
		boolean result=false;
		String expectedValue="";
		String actualValue="";
		try
		{			
			seClick(HomePage.get().find, "Find");
			waitForPageLoad(300);
			seClick(HomePage.get().findTemplate, "Find Template link");
			waitForPageLoad(300);
			waitForPageLoad();
			seClick(FindTemplatePage.get().headerCriteria,"Header criteria");
			waitForPageLoad();
			seClick(FindTemplatePage.get().headerCriteriaType,"Header criteria type");
			waitForPageLoad();
			seClick(FindTemplatePage.get().headerCritTypeValue(headerCriteria),headerCriteria+" value from header criteria drop dowm");
			waitForPageLoad();			
			expectedValue = FindTemplatePage.get().valueType(valueType);
			waitForPageLoad(360);
			seClick(FindTemplatePage.get().templateSearch, "Search");
			waitForPageLoad(500);
			seWaitForClickableWebElement(FindTemplatePage.get().templateResults, 120);
			if(FindTemplatePage.get().templateResults.isDisplayed())
			{
				log(PASS, "Find Template","Templates found with given header Criteria: "+headerCriteria);				
				for(int i=1;i<=5;i++)
				{					
					if(headerCriteria.equalsIgnoreCase("Status"))
					{
						waitForPageLoad();
						WebElement status=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div/table/tbody/tr["+i+"]/td[7]"));
						actualValue=status.getText().toString().trim();
						if(actualValue.contains(expectedValue))
						{
							result=true;
							log(PASS,"Validate search results using "+headerCriteria,"Expected Value "+expectedValue+" Actual Value "+actualValue);
						}
						else
						{
							log(FAIL,"Validate search results using "+headerCriteria,"Expected Value "+expectedValue+" Actual Value "+actualValue);
						}
					}
					else
					{						
						WebElement templateInfo=getWebDriver().findElement(By.xpath("//div[@class='findPlanResults']/div/table/tbody/tr["+i+"]/td[10]/i"));
						seClick(templateInfo,"Template Info Option");
						waitForPageLoad();			
						actualValue=seGetElementValue(TemplateHeaderPage.get().tempInfoHeader(headerCriteria));
						if(actualValue.contains(expectedValue))
						{
							result=true;
							log(PASS,"Validate search results using "+headerCriteria,"Expected Value "+expectedValue+" Actual Value "+actualValue,true);
						}
						else
						{
							log(FAIL,"Validate search results using "+headerCriteria,"Expected Value "+expectedValue+" Actual Value "+actualValue,true);
						}
						seClick(PlanHeaderPage.get().closebutton,"Close button");
						waitForPageLoad();
					}
				}

			}
			else if(FindPlanPage.get().searchPlanErrorMsg.isDisplayed())
			{
				log(FAIL, "Find Plan","Plan not found with given header Criteria "+headerCriteria);
			}
			else
			{
				log(FAIL, "Find Plan","Plan not found with given header Criteria "+headerCriteria);
			}


		}
		catch(Exception e)
		{
			log(FAIL,"No Results fetched","No Results are fetched for given criteria "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		return result;
	}

	public void validateTransCriteriaSearchResults(String strCreateFormDate ,String strCreateToDate, String strCriteria){
		try{
			boolean datefound=false;
			String stractualSearchCriteriaValue="";
			String dateValue="";
			waitForPageLoad(200);
			seClick(FindTemplatePage.get().templateSearch, "Template Search");
			waitForPageLoad(200);
			if(FindTemplatePage.get().templateResults.isDisplayed()){
				WebTableWithHeader searchResults = new WebTableWithHeader(FindTemplatePage.get().templateResults, "Template Search Results");
				if(strCriteria.equalsIgnoreCase("Created From")){
					seClick(searchResults.getCell(1, 9), "Template");
					waitForPageLoad(360);
					seClick(TemplateHeaderPage.get().history, "History");
					waitForPageLoad(360);
					List<WebElement> arrCreatedMode = TemplateHeaderPage.get().createdtext();
					for(int i=0;i<arrCreatedMode.size();i++){
						switch (arrCreatedMode.get(i).getText()) {
						case "Created":
							dateValue=TemplateHeaderPage.get().createdValueCreated.getText().toString().trim();
							datefound=FindTemplatePage.get().verifyDate(strCreateFormDate, strCreateToDate, dateValue);
							break;
						case "Copied":
							dateValue=TemplateHeaderPage.get().createdValueCopied.getText().toString().trim();
							datefound=FindTemplatePage.get().verifyDate(strCreateFormDate, strCreateToDate, dateValue);
							break;
						case "Edited":
							dateValue=TemplateHeaderPage.get().createdValueEdited.getText().toString().trim();
							datefound=FindTemplatePage.get().verifyDate(strCreateFormDate, strCreateToDate, dateValue);
							break;

						default:
							//log(FAIL, "Searching for Created On Date","No Record Present",true);
							break;
						}

					}
					if(datefound){
						RESULT_STATUS=true;
						log(PASS,"Verify Date","CreatedOn Date is "+dateValue+" in Between "+strCreateFormDate+ " and "+strCreateToDate,true);
					}
					else{
						RESULT_STATUS=false;
						log(FAIL,"Verify Date","CreatedOn Date is Not "+dateValue+" in Between "+strCreateFormDate+ " and "+strCreateToDate,true);
					}
					seClick(HistoryPage.get().close,"Close");
				}
				else if(strCriteria.equalsIgnoreCase("Modified From")){
					int intTotalRows = searchResults.getRowsCount();
					for (int i = 1; i < intTotalRows; i++) {
						stractualSearchCriteriaValue=searchResults.getCellData(i, 9).trim();
						datefound=FindTemplatePage.get().verifyDate(strCreateFormDate, strCreateToDate, stractualSearchCriteriaValue);
						if(datefound){
							RESULT_STATUS=true;
							log(PASS,"Verify Date","LastModified On Date is "+stractualSearchCriteriaValue+" in Between "+strCreateFormDate+ " and "+strCreateToDate,true);
						}
						else{
							RESULT_STATUS=false;
							log(FAIL,"Verify Date","LastModified On Date is "+stractualSearchCriteriaValue+" not  in Between "+strCreateFormDate+ " and "+strCreateToDate,true);
						}

					}
				}
			}
		}catch(Exception e)
		{
			if(FindTemplatePage.get().searchPlanErrorMsg.isDisplayed())
				log(FAIL, "Find Plan","Plan not found with given Search Criteria "+strCriteria);
			else
				log(FAIL,"No Results fetched","Exception Occured while Searching the Template"+e.getLocalizedMessage());
			e.printStackTrace();
		}
	}




}