package page.planConfigurator;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class CreateTemplatePage extends CoreSuperHelper{
	
	private static CreateTemplatePage thisTestObj;	
	public synchronized static CreateTemplatePage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), CreateTemplatePage.class);
		return thisTestObj;
	}				
	@FindBy(how = How.NAME, using = "effectiveDate")
	@CacheLookup
	public WebElement enterEffectiveDate;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[1]/td[2]")
	@CacheLookup
	public WebElement date;
	
	@FindBy(how = How.NAME, using = "productDataModel")
	@CacheLookup
	public WebElement selectProductModelData;
	
	@FindBy(how = How.XPATH, using = "//li[@role='treeitem' and substring(@id,string-length(@id) - string-length('Vision') +1) = 'Vision']")
	@CacheLookup
	public WebElement visionlob;
	
	
	public void seCreateTemplatePartial(){
		try{
			
			seSetText(FindPlanPage.get().planEffectiveDate, getCellValue("Temp_EffectiveDate"),"Effective date");
			WebElement pressEnter = FindPlanPage.get().planEffectiveDate;
			pressEnter.sendKeys(Keys.ENTER);
			waitForPageLoad();
			seClick(TemplateCreation.get().templateNameBox, "template name text box");
			seSetText(TemplateCreation.get().templateNameBox, getCellValue("Temp_Name"), "Template name");
			waitForPageLoad();
			String strStates = getCellValue("Temp_state").trim();
			String[] strSplitStateValues = strStates.split(",");
			for (int j = 0; j < strSplitStateValues.length; j++) {
				seClick(TemplateCreation.get().templateState, "State");
				seSetText(TemplateCreation.get().templateState, strSplitStateValues[j], "state name");
				TemplateCreation.get().templateState.sendKeys(Keys.ENTER);
				waitForPageLoad();
			}
			seClick(TemplateCreation.get().templateMarketSegment, "Market segment");
			seSetText(TemplateCreation.get().templateMarketSegment, getCellValue("Temp_MarketSegment"),"Market segment");
			TemplateCreation.get().templateMarketSegment.sendKeys(Keys.ENTER);
			waitForPageLoad();
			seClick(TemplateCreation.get().templateLOB, "Line of Business");
			seClick(TemplateCreation.get().medicalLOB, "Line of Business");
			waitForPageLoad();
			
			WebElement objCancelTemp = getWebDriver().findElement(By.xpath("//*[@id='content-create-customPlan']/form/div[2]/div[6]/div/button[1]"));
			seWaitForClickableWebElement(objCancelTemp, 20);
			seClick(objCancelTemp, "Cancel Button in Create Template Header Page");
			waitForPageLoad();
			waitForPageLoad();
			
			
		}catch(TimeoutException e){
			log(FAIL, "Erroe happened while execution this method seCreateTemplate","RESULT=FAIL");	
		}
	}
	public void seCreateTemplate() throws Exception{
		try{
			
			seSetText(FindPlanPage.get().planEffectiveDate, getCellValue("Temp_EffectiveDate"),"Effective date");
			WebElement pressEnter = FindPlanPage.get().planEffectiveDate;
			pressEnter.sendKeys(Keys.ENTER);
			waitForPageLoad();
			seClick(TemplateCreation.get().templateNameBox, "template name text box");
			seSetText(TemplateCreation.get().templateNameBox, getCellValue("Temp_Name"), "Template name");
			waitForPageLoad();
			String strStates = getCellValue("Temp_state").trim();
			String[] strSplitStateValues = strStates.split(",");
			for (int j = 0; j < strSplitStateValues.length; j++) {
				seClick(TemplateCreation.get().templateState, "State");
				seSetText(TemplateCreation.get().templateState, strSplitStateValues[j], "state name");
				TemplateCreation.get().templateState.sendKeys(Keys.ENTER);
				waitForPageLoad();
			}
			seClick(TemplateCreation.get().templateMarketSegment, "Market segment");
			seSetText(TemplateCreation.get().templateMarketSegment, getCellValue("Temp_MarketSegment"),"Market segment");
			TemplateCreation.get().templateMarketSegment.sendKeys(Keys.ENTER);
			waitForPageLoad();
			seClick(TemplateCreation.get().templateLOB, "Line of Business");
			seClick(visionlob, "Line of Business");
			waitForPageLoad();
			
			waitForPageLoad();
			String strProductFamilies = getCellValue("Temp_Product_family").trim();
			String[] strSplitPfValues = strProductFamilies.split(",");
			for (int i = 0; i < strSplitPfValues.length; i++) {
				seClick(TemplateCreation.get().templateProductFamily, "Product family");
				seSetText(TemplateCreation.get().templateProductFamily, strSplitPfValues[i], "Product family");
				TemplateCreation.get().templateProductFamily.sendKeys(Keys.ENTER);
				waitForPageLoad();
			} 
			/*seClick(TemplateCreation.get().networkTier, "Network Tier");
			seClick(TemplateCreation.get().network2Tier, "Network tier");*/
			waitForPageLoad();
			String strCdhp = getCellValue("Temp_cdhp").trim();
			String[] strSplitCdhpValues = strCdhp.split(",");

			for (int i = 0; i < strSplitCdhpValues.length; i++) {
				seClick(TemplateCreation.get().Cdhp, "CDHP");
				seSetText(TemplateCreation.get().Cdhp, strSplitCdhpValues[i], "CDHP");
				TemplateCreation.get().Cdhp.sendKeys(Keys.ENTER);
				waitForPageLoad();
			}

			seClick(TemplateCreation.get().fundingArrangement, "Funding arrangement");
			seSetText(TemplateCreation.get().fundingArrangement, getCellValue("Temp_FundindArrangement"),"funding arrangement");
			TemplateCreation.get().fundingArrangement.sendKeys(Keys.ENTER);
			waitForPageLoad();
			seClick(TemplateCreation.get().create, "create");
			waitForPageLoad(105);
            seWaitForClickableWebElement(PlanHeaderPage.get().save, 45);   
			String strPlanID = TemplateCreation.get().getPlanId.getText();
			String strPlan = strPlanID.substring(strPlanID.lastIndexOf(" ") + 1);
			seClick(PlanHeaderPage.get().save, "Save button");
			waitForPageLoad();
			String strTemplateVersionIDold = seGetElementValue(PlanHeaderPage.get().templateVersion).split(":")[1];
            waitForPageLoad();
            setCellValue("TemplateIDold", strTemplateVersionIDold);
			
		}catch(TimeoutException e){
			log(FAIL, "Erroe happened while execution this method seCreateTemplate","RESULT=FAIL");	
		}

	}

	@FindBy(how = How.XPATH, using = "//*[@id='customHeaderAttributesContainer']/div[19]/div/div/button")
	
	public WebElement searchTemplate;
@FindBy(how = How.XPATH, using = "//*[@class='table searchResultsTable fjaTable dataTable']/tbody/tr/td[5]")
	
	public WebElement selectPlan;

	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Plan Level Benefits')]")
	@CacheLookup
	public WebElement benefits;
	
			
	@FindBy(how = How.XPATH, using = "(//div[@class='iscroll-wrapper'])[2]/ul/li[6]/a")
	public WebElement benefitOption;		
	////*[@id='POA_Base-_-PlanLifetimeMaxAdult-_-PlanLifetimeMax-_-NA']/div/div/table/tbody/tr[1]/td[2]/div[1]/div[2]/span/span[1]/span	
	
	@FindBy(how = How.XPATH, using = "//*[@id='POA_Base-_-PlanLifetimeMaxAdult-_-PlanLifetimeMax-_-NA']/div/div/table/tbody/tr[1]/td[2]/div[1]/div[2]/span")
	public WebElement accumText;		
			
	@FindBy(how = How.XPATH, using = "//*[@id='actionsBar']/li[2]/a")
	public WebElement copy;		
			
	public void seCompareAccumlators(String strOld, String strNew, String strPlanStatus)
	{try{
		if(strOld.equals(strNew))
    	{
    		
    		log(FAIL, "Template not switched, Hence have same values","RESULT=FAIL");
		
    	}
    	
    	else
    	{
    		log(PASS, "The Old accumulator value is "+strOld+" and the New accumulator value is "+strNew+ ".","Verified that The new plan takes the values from the switched template Sucessfully when Plan is in Status: "+strPlanStatus+", RESULT=PASS");
    		
    	}
		
	}catch(TimeoutException e){
		log(FAIL, "Error happened while execution this method seCreateplan","RESULT=FAIL");	
	}
	}
			
			
	public void seCompareID(String strOldPlan, String strNewPlan,String strOldProxy, String strNewProxy, String strOldTemplate, String strNewTemplate,String strPlanIDType, String strProxyType, String strTempateType)
	{try{
		if(!strOldPlan.equals(strNewPlan))
    	{
    		log(PASS, "The Old"+strPlanIDType+" ID is "+strOldPlan+" and the New"+strPlanIDType+" ID is "+strNewPlan+ "Verified that New" +strPlanIDType+ "is created. "+strPlanIDType+ " Sucessfully ","RESULT=PASS");
    		if(!strOldProxy.equals(strNewProxy))
    		{
        		log(PASS, "The Old"+strProxyType+" ID is "+strOldProxy+" and the New"+strProxyType+" ID is "+strNewProxy+ ". ","Verified that a plan is created with new Proxy ID and PlanID, RESULT=PASS");
        		if(!strOldTemplate.equals(strNewTemplate))
        		{
            		log(PASS, "The Old"+strTempateType+" ID is "+strOldTemplate+" and the switched "+strTempateType+" ID is "+strNewTemplate+ ".","Verified that a plan is created with new Proxy ID and PlanID with the switched template Version ID , RESULT=PASS");
        		}	
    			
    		}
    	}
		else
		{
			log(FAIL, "Copying of "+strPlanIDType+"was not sucessful","RESULT=FAIL");
		}
    	
		
	}catch(TimeoutException e){
		log(FAIL, "Error happened while execution this method seCreateplan","RESULT=FAIL");	
	}
	}
				
			
			
			

}
	

