package page.planConfigurator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.SendKeysAction;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.constants.BrowserConstants;

import utility.CoreSuperHelper;

public class PlanTransitionPage extends CoreSuperHelper {

	private static PlanTransitionPage thisTestObj;

	public synchronized static PlanTransitionPage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), PlanTransitionPage.class);
		return thisTestObj;
	}

	@FindBy(how = How.XPATH, using = "//button[@class='workflowAction btn btn-primary pull-right']")
	@CacheLookup
	public WebElement requestAudit;

	@FindBy(how = How.CSS, using = "span[id^='select2-reasonCode']")
	@CacheLookup
	public WebElement reasonCode;

	@FindBy(how = How.XPATH, using = "//div[@class='bulkConfigureContent']/div/div[3]/div/textarea[@name='comment']")
	@CacheLookup
	public WebElement comment;
	
	@FindBy(how = How.XPATH, using = "//div[@id='content-workflow']//textarea[@name='comment']")
	@CacheLookup
	public WebElement txtWorkflowComment;

	@FindBy(how = How.XPATH, using = "//div[@class='bulkConfigureContent']/div/div[6]/button[2]")
	@CacheLookup
	public WebElement submit;
	
	@FindBy(how = How.XPATH, using = "//*[@id='verticalBarMenuDetails']/div/nav/div[2]/ul/li[6]/a")
	@CacheLookup
	public WebElement deductible;
	
	@FindBy(how = How.XPATH, using = "//*[@id='POA_PlanSetup-_-OONSetup-_-OONNotCovered']")
	@CacheLookup
	public WebElement accumulator;
	
	@FindBy(how = How.XPATH, using = "//*[@id='actionsBar']/li[5]/a")
	@CacheLookup
	public WebElement saveTemplate;
	
	@FindBy(how = How.XPATH, using = "//*[@id='actionsBar']/li[1]/a")
	@CacheLookup
	public WebElement closeTemplate;
	
	@FindBy(how = How.XPATH, using = "//*[@id='findPlanSearch']/div[3]/div/div[2]/input")
	@CacheLookup
	public WebElement inputTemplate;
	
	@FindBy(how = How.XPATH, using = "//h4[contains(text(),'Deductible')]")
	@CacheLookup
	public WebElement deductibleText;
	
	@FindBy(how = How.XPATH, using = "//h4[contains(text(),'Deductible')]/following::*[contains(text(),'In Network Den Ded Fam')][1]")
	@CacheLookup
	public WebElement deductibleAccumulator;
	
	@FindBy(how = How.XPATH, using = "//*[@id='POA_Base-_-Deductible-_-Deductible-_-NA-_-NA-_-INNDenDedFam_-_indivMax']")
	@CacheLookup
	public WebElement deductibleAccumulatorValue;
	
	@FindBy(how = How.XPATH, using = "//*[@id='POA_Base-_-Deductible-_-Deductible-_-NA']/div/div/table/tbody/tr[1]/td[2]/div[1]/div[2]/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement deductibledropDown;
	
	@FindBy(how = How.XPATH, using = "//*[@id='POA_Base-_-Deductible-_-Deductible-_-NA']/div/div/table/tbody/tr[1]/td[2]/div[1]/span/span/span[1]/input")
	@CacheLookup
	public WebElement deductibleTextBox;
	
	@FindBy(how = How.XPATH, using = "//*[@id='POA_Base-_-Deductible-_-Deductible-_-NA']/div/div/table/tbody/tr[1]/td[2]/div[1]/span/span/span[2]")
	@CacheLookup
	public WebElement deductibleEnter;
	
	/*@FindBy(how = How.XPATH, using = "//*[@id='POA_Base-_-Deductible-_-Deductible-_-NA-_-NA-_-INNDenDedFam_-_indivMax']")
	@CacheLookup
	public WebElement deductibleAccumulatorValue;
	
	@FindBy(how = How.XPATH, using = "//*[@id='POA_Base-_-Deductible-_-Deductible-_-NA-_-NA-_-INNDenDedFam_-_indivMax']")
	@CacheLookup
	public WebElement deductibleAccumulatorValue;
	
	@FindBy(how = How.XPATH, using = "//*[@id='POA_Base-_-Deductible-_-Deductible-_-NA-_-NA-_-INNDenDedFam_-_indivMax']")
	@CacheLookup
	public WebElement deductibleAccumulatorValue;
	*/
	public void seDeductibleValue() {
		try{
			deductibledropDown.click();
			waitForPageLoad();//seSelectText(CreatePlanLegacyHeaderPage.get().marketSegment, strMarketSegment, "Market Segment",intMaxWaitTime);
			//WebElement objInput =getWebDriver().findElement(By.xpath("//*[@id='POA_Base-_-Deductible-_-Deductible-_-NA']/div/div/table/tbody/tr[1]/td[2]/div[1]/span/span/span[1]/input")); 
			//((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objInput);
			//seSelectText(objInput, "750", "Annual Maximum",10);
			/*Actions act = new Actions(driver);
			act.moveToElement(objInput).click().build().perform();
			waitForPageLoad();*/
			seSetText(deductibleTextBox, "75", "Deductible Value");
			//seInputKeys(getWebDriver().findElement(By.xpath("//*[@id='POA_Base-_-AnnualMax-_-AnnualMax-_-NA']/div/div/table/tbody/tr/td[2]/div[1]/span/span/span[1]/input")), "1500");
			waitForPageLoad();
			deductibleEnter.click();
			waitForPageLoad();
		}catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
		}
	}
	
	public void seRequestAudit() {
		try{
			seWaitForClickableWebElement(PlanHeaderPage.get().requestAudit,1);
			seClick(PlanHeaderPage.get().requestAudit, "request Audit button");
			waitForPageLoad();
			PlanTransitionPage.get().updateReasonCode("Other");
			seClick(PlanTransitionPage.get().requestAudit, "Request Audit button");
			waitForPageLoad();
			try{
				seWaitForClickableWebElement(PlanHeaderPage.get().userLogout, 360);
			    }
			catch(TimeoutException e){
	            seClick(PlanHeaderPage.get().close, "Close button");
	            }
			waitForPageLoad();
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",PlanHeaderPage.get().userNameHeader);
            waitForPageLoad();
            
            ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",PlanHeaderPage.get().userLogout);
           
		}catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
		}
	}
	
	
	
	public void seApproverLogin() {
		try{
			
			String strLegacy = getCellValue("LegacyPlanID");
			seClick(HomePage.get().find, "Find");
            seClick(HomePage.get().findPlan, "Find Plan");
			seSetText(FindPlanPage.get().planVersionID,strLegacy, "Set text in plan version id");
			waitForPageLoad();
			seClick(FindPlanPage.get().planSearch, "Search");
			waitForPageLoad();
			WebElement objSearch = FindPlanPage.get().selectSearchedPlan;
            ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objSearch);
			Boolean blnPlanStatusPendingAudit= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
			if(blnPlanStatusPendingAudit==true){
					log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");
				}
			else { 
					new TimeoutException("Plan is not in Pending Audit status");
				}	
			waitForPageLoad();
			//**********************************************************************************************************************
			
			
           
		}catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
		}
		
	}
	public void seApproverLoginNew() {
		try{	
	String strNewLegacy = getCellValue("NewLegacyPlanID");
	seClick(HomePage.get().find, "Find");
    seClick(HomePage.get().findPlan, "Find Plan");
	seSetText(FindPlanPage.get().planVersionID,strNewLegacy, "Set text in plan version id");
	waitForPageLoad();
	seClick(FindPlanPage.get().planSearch, "Search");
	waitForPageLoad();
	WebElement objSearchPlan = FindPlanPage.get().selectSearchedPlan;
    ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objSearchPlan);
	Boolean blnPlanStatusPendingAuditTwo= PlanHeaderPage.get().seVerifyPlanStatus("Pending Audit");
	if(blnPlanStatusPendingAuditTwo==true){
			log(PASS, "plan takes correct time to load","plan is in Pending Audit status,RESULT=PASS");
		}
	else { 
			new TimeoutException("Plan is not in Pending Audit status");
		}	
	waitForPageLoad();
	
		}catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
		}
		
	}
	
	
	
	
	public void seDebugButton() {
		try{
			
			waitForPageLoad();
			seClick(BenefitRetainsInProductionPage.get().debugButton,"debug button");
			waitForPageLoad(200);
			seClick(BenefitRetainsInProductionPage.get().downloadButton,"download button");
			waitForPageLoad(250);
			seClick(BenefitRetainsInProductionPage.get().debugcloseButton,"debug close button");
			waitForPageLoad(200);
           
		}catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
		}
	}	
	
	public void seRejectAudit() {
		try{
			
			seWaitForClickableWebElement(PlanHeaderPage.get().rejectAudit, 36);
			seClick(PlanHeaderPage.get().rejectAudit, "Reject Audit");
			waitForPageLoad(30);
			PlanHeaderPage.get().seReasonCode();
			seWaitForClickableWebElement(PlanTransitionPage.get().txtWorkflowComment, 60);
			seSetText(PlanTransitionPage.get().txtWorkflowComment, "Test Reject", "Comment");
			seClick(PlanTransitionPage.get().btnRejectedTest, "Rejected Test");
			Boolean blnPlanStatusRejectedAudit= PlanHeaderPage.get().seVerifyPlanStatus("Rejected Audit");
			if(blnPlanStatusRejectedAudit==true){
					log(PASS, "Plan Status is updated to Rejected Audit,RESULT=PASS");
				}
			else { 
					new TimeoutException("Plan is not in Rejected Audit status");
				}	
			waitForPageLoad();
           
		}catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
		}
	}
	
	
	public WebElement selectType(String type) {
		WebElement valueType = getWebDriver()
				.findElement(By.xpath("//span[@class='select2-results']/ul/li/span[text()='" + type + "']"));
		return valueType;
	}

	@FindBy(how = How.XPATH, using = "//div[@id='content-workflow']/form/div[3]/div[5]/div/button[2]")
	@CacheLookup
	public WebElement moveToTest;

	@FindBy(how = How.XPATH, using = "//div[@id='content-workflow']/form/div[3]/div[5]/div/button[2]")
	@CacheLookup
	public WebElement approvedTest;
	
	@FindBy(how = How.XPATH, using = "//div[@id='content-workflow']//button[contains(@class,'workflowAction')]")
	@CacheLookup
	public WebElement btnRejectedTest;
	
	@FindBy(how = How.XPATH, using = "//li[substring(@id,string-length(@id) - string-length('Approved') +1) = 'Approved']")
	@CacheLookup
	public WebElement approved;


	@FindBy(how = How.XPATH, using = "//div[@id='content-workflow']/form/div[3]/div[5]/div/button[2]")
	@CacheLookup
	public WebElement finalizeButton;

	@FindBy(how = How.XPATH, using = "//div[@id='content-workflow']/form/div[3]/div[5]/div/button[2]")
	@CacheLookup
	public WebElement moveToProductionButton;

	@FindBy(how = How.XPATH, using = "//*[@id='select2-reasonCode-r0-container']")
	@CacheLookup
	public WebElement planTransitionReasonCode;
	
	@FindBy(how = How.XPATH, using = "//*//*[@id='content-workflow']/form/div[3]/div[3]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement planTransitionReasonCodeListBoxClick;

	@FindBy(how = How.XPATH, using = "//*[@id='content-workflow']/span/span/span[1]/input")
	@CacheLookup
	public WebElement planTransitionReasonCodeText;

	@FindBy(how = How.XPATH, using = "//*[@id='content-workflow']/form/div[3]/div[3]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement approveTestReasonCodeClick;
	
	@FindBy(how = How.XPATH, using = "//*[@id='content-workflow']/form/div[3]/div[5]/div/button[2]")
	@CacheLookup
	public WebElement finalizeButtoninPT;
	
	
	@FindBy(how = How.NAME, using = "effectiveDateLabel")
	@CacheLookup
	public WebElement effectiveDateLabel;
	
	@FindBy(how = How.XPATH, using = "//ul[@id='actionsBar']//following::li/a[contains(text(),'Delete')]")
	@CacheLookup
	public WebElement delete;
	
	@FindBy(how = How.XPATH, using = "  //ul[@id='actionsBar']//following::li/a[contains(text(),'Move to Test')]")
	@CacheLookup
	public WebElement moveToTestButton;
	
	@FindBy(how = How.XPATH, using = "  //ul[@id='actionsBar']//following::li/a[contains(text(),'Copy')]")
	@CacheLookup
	public WebElement copy;
	
	
	@FindBy(how = How.XPATH, using = "//*[@id='actionsBar']/li[1]/a")
	@CacheLookup
	public WebElement close;
	
	
	
	@FindBy(how = How.XPATH, using = "//div[@name='effectiveDateGroup']/label")
	@CacheLookup
	public WebElement effectiveDateAvailable;
	
	@FindBy(how = How.XPATH, using = "//div[@name='reasonCodeGroup']/label")
	@CacheLookup
	public WebElement reasonCodeAvailable;
	
	
	@FindBy(how = How.NAME, using = "commentLabel")
	@CacheLookup
	public WebElement commentLabel;
	
	@FindBy(how = How.XPATH, using = "//*[@name='effectiveDateLabel']/span[@class='requiredStar masked']")
	@CacheLookup
	public WebElement effectiveDateRequiredField;
	
	@FindBy(how = How.XPATH, using = "//div[@name='reasonCodeGroup']/label/span[@class='requiredStar']")
	@CacheLookup
	public WebElement reasonCodeRequiredField;
	
	public void seRequiredField()
	{try{
		String strEffectivedate = seGetText(PlanTransitionPage.get().effectiveDateRequiredField);
		if (strEffectivedate.equals("*"))
		{
			RESULT_STATUS=true;
			log(PASS, "Effective Date field is a REQUIRED FIELD","Confirmed, Effective Date field is a required field");
		}
		else
		{
			RESULT_STATUS=false;
			log(FAIL, "Effective Date field is NOT A REQUIRED FIELD","Confirmed, Effective Date field is not a required field");
		}
		
		String strReasonCode = seGetText(PlanTransitionPage.get().reasonCodeRequiredField);
		if (strReasonCode.equals("*"))
		{
			RESULT_STATUS=true;
			log(PASS, "Reason Code field is a REQUIRED FIELD","Confirmed, Reason Code field is a required field");
		}
		else
		{
			RESULT_STATUS=false;
			log(FAIL, "Reason Code field is NOT A REQUIRED FIELD","Confirmed, Reason Code field is not a required field");
		}
	}
	catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
	}
	}
	

	@FindBy(how = How.XPATH, using = "//*[@id='message_frontEnd_message_reasonCodeisrequireddanger']/span")
	@CacheLookup
	public WebElement reasonCodeRequired;
	//this is wbField : -----//*[@id='message_frontEnd_message_reasonCodeisrequireddanger']/span
	@FindBy(how = How.XPATH, using = "//*[@id='content-workflow']/form/div[3]/div[3]/div/span/span[1]/span/span[2]")
	@CacheLookup
	public WebElement reasonCodeDropDown;
	
	//seSelectDropDown(wbf, ReasonCode, Other)
	public void seCheckDropDown(WebElement wbField, String strElementName, String strValue) {
		
		try {
			seClick(wbField, strElementName);
			waitForPageLoad();
			seSetText(PlanSetupPage.get().dropDownInput, strValue, "Set text for " + strElementName);
			waitForPageLoad();
			seClick(PlanSetupPage.get().dropDownSelect, "Select " + strValue + " from " + strElementName);
			waitForPageLoad();
			String strValueOfField =seGetText(getWebDriver().findElement(By.xpath("//*[@class='select2 select2-container select2-container--default select2-container--below']")));
			
			if(strValueOfField.equals(strValue))
			{
				RESULT_STATUS=true;
				log(PASS, "Reason Code for LOB : Medical '"+strValue+" ' is present in the drop down","RESULT=PASS");
			}
			else
			{
				RESULT_STATUS=false;
				log(FAIL, "Reason Code for LOB : Medical '"+strValue+" ' is not present in the drop down","RESULT=FAIL");
			}
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
		}
	}
	
   public  void seAvailabilityCheck(Boolean blnDisplay, String strLabel)
   {try{
	   
	   if(blnDisplay == true)
		{
			RESULT_STATUS=true;
			log(PASS, "Request Audit Information screen displays '"+strLabel+"'","RESULT=PASS");
		}
	   
	   else
		{
			RESULT_STATUS=false;
			log(PASS, "Request Audit Information screen displays '"+strLabel+"'","RESULT=FAIL");
		}
   } catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
		} 
	   
   }
   
   public  void seCompare(String Expected,String Actual){
		if(Expected.equals(Actual))
		{
			RESULT_STATUS=true;
			log(PASS, "Service Code is displayed as expected","Upon Clicking 'View Service Code Button'Popup with Service code is displayed sucessfully, RESULT=PASS");
		}
		else
		{
			RESULT_STATUS=false;
			log(FAIL, "Service Code is NOT displayed ","Upon Clicking 'View Service Code Button'NO Popup with Service code is displayed, RESULT=FAIL");
		}
	}
   
   
   
   public static boolean seCompareAccumulator(String strOldValue , String strNewValue) {
		try {
			if (strOldValue.equalsIgnoreCase(strNewValue))
					{
				log(FAIL,"New Plan Xml Generation was not Successful","RESULT =FAIL");
					}
			else{log(PASS,"Validated that original plan XML that was generated on initial �Request Audit� is discarded and new replacement plan XML is created","RESULT =PASS");}
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
   
   public void seGetTextFromAccumulator() {
	   try{
	   getWebDriver().findElement(By.xpath("//*[@id='verticalBarMenuDetails']/div/nav/div[2]/ul/li[6]/a")).click();
		waitForPageLoad();
		String strBenefit = getWebDriver().findElement(By.xpath("//h4[contains(text(),'Deductible')]")).getText();
		waitForPageLoad();
		System.out.println(strBenefit);
		String strAccumName = getWebDriver().findElement(By.xpath("//h4[contains(text(),'Deductible')]/following::*[contains(text(),'In Network Den Ded Fam')][1]")).getText();
		waitForPageLoad();
		System.out.println(strAccumName);
		// replaceAll("[$,]", ""))
		String strIndMax = getWebDriver().findElement(By.xpath("//*[@id='POA_Base-_-Deductible-_-Deductible-_-NA-_-NA-_-INNDenDedFam_-_indivMax']")).getText().replaceAll("[$,]", "");
		waitForPageLoad();
		String strIndvidualMax = strIndMax+".0";
		System.out.println(strIndvidualMax);
		return ;}catch (NumberFormatException nfe) {
			log(FAIL,"Iteration error occured","RESULT =FAIL");
		}
	   log(FAIL,"Iteration error occured","RESULT =FAIL");
	}
   
   public  void seButtonAvailability(Boolean blnDisplay, String strLabel)
   {try{
	   
	   if(blnDisplay == true)
		{
			RESULT_STATUS=true;
			log(PASS, "'"+strLabel+"' is Enabled and have User action Rights","RESULT=PASS");
		}
	   
	   else
		{
			RESULT_STATUS=false;
			log(PASS, "'"+strLabel+"' is NOT Found for User action","RESULT=FAIL");
		}
   } catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
		} 
	   
   }
   
   
   
   
   
	public void updateReasonCode(String strReasonCode) {
		seClick(PlanTransitionPage.get().planTransitionReasonCodeListBoxClick, "Reason Code");
		seWaitForClickableWebElement(PlanTransitionPage.get().planTransitionReasonCodeText, 1);
		seSetText(PlanTransitionPage.get().planTransitionReasonCodeText, strReasonCode, "as " + strReasonCode);
		PlanTransitionPage.get().planTransitionReasonCodeText.sendKeys(Keys.ENTER);
	}
}