package page.planConfigurator;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import utility.CoreSuperHelper;
//import utility.WebTable;
import utility.WebTableWithHeader;
 
public class PlanAgainstTemplatePage extends CoreSuperHelper{

	private static PlanAgainstTemplatePage thisTestObj;	
	public synchronized static PlanAgainstTemplatePage get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), PlanAgainstTemplatePage.class);
		return thisTestObj;
	}
	
	static String strBaseURL = EnvHelper.getValue("pc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	
	@FindBy(how = How.XPATH, using = "//a[text()='Delete'][1]")
	@CacheLookup
	public WebElement Delete;
	
	@FindBy(how = How.XPATH, using = "//div[@class='modal-footer']/button[text()='Yes']")
	@CacheLookup
	public WebElement DeleteConfirmation;
	
	public void seGetPlanOptionDetails(String strBenefit,String strPlanOptionIdentifier){
		int i=0;
		String strAccumulatorName;
    	String strAccumulatorValue;
    	String strAccumulatorGroup;
    	String strAccumulatorStep;
		try{for( i=2;i<13;i++){
        strAccumulatorGroup=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::input[@checked and contains(@id,'"+strPlanOptionIdentifier+"')])["+i+"]/preceding::h4[text()][1]")).getText();  
        strAccumulatorStep=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::input[@checked and contains(@id,'"+strPlanOptionIdentifier+"')])["+i+"]/..")).getText();  
        log(PASS,strAccumulatorGroup,strAccumulatorStep);
   }}catch(NoSuchElementException e){
	   log(PASS, i-1+" selected checkbox value is present");}
	
	int j=0;
	try{
		  for(j=1;j<13;j++){
		  strAccumulatorName=driver.findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::tr[@dependents]/td/div[contains(@id,'"+strPlanOptionIdentifier+"')])["+j+"]/span[1]")).getText();
		  strAccumulatorValue=driver.findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::tr[@dependents]/td/div[contains(@data-path,'"+strPlanOptionIdentifier+"')]/div/select)["+j+"]/option[@selected or 1][1]")).getText();
		  log(PASS,strAccumulatorName,strAccumulatorValue);
		  }}catch(NoSuchElementException e){
			log(PASS,""+(j-1)+" dropdown box found in PC", strBenefit);
			}	}
	
	public void seCheckAccumulatorVisibility(String strOptionTab,String strPlanId,String strBenefit){
		
    	String strPlanOptionIdentifier;
    	String strPlanOptionType;
		seWaitForClickableWebElement(FindPlanPage.get().clickPlanLevelBenefit, 22);					
		WebElement wbOptionTab = getWebDriver().findElement(By.xpath("//a[contains(text(),'" + strOptionTab + "')]"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", wbOptionTab);				
		waitForPageLoad(45);
		waitForPageLoad();
		WebElement wbBenefits= getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", wbBenefits);				
		waitForPageLoad();
		seWaitForClickableWebElement(wbBenefits, 30);
		String id1=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')])/../..")).getAttribute("id").split("Header")[0];					  
        WebElement wbPlanOptionType=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::div[@id='"+id1+"Group'])/div[1]/div/h4/input"));
        
        seWaitForClickableWebElement(wbPlanOptionType, 30);
         if(wbPlanOptionType.isSelected()==true){
	        WebElement wb=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::div[@id='"+id1+"Group'])/div[2]/div/h4/input"));
	    	new Actions(driver).moveToElement(wb).click().build().perform();
	        waitForPageLoad();
	    	waitForPageLoad(45);
			seClick(PlanHeaderPage.get().save, "Save button");
			waitForPageLoad(45);
	        strPlanOptionIdentifier=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::div[contains(@class,'poSelected')])[1]")).getAttribute("data-path");
	    	strPlanOptionType=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::input[@checked and contains(@id,'"+strPlanOptionIdentifier+"')])[1]/..")).getText(); 
            log(PASS, strBenefit,strPlanOptionType);
	    	seGetPlanOptionDetails(strBenefit, strPlanOptionIdentifier);
	        }
	        else{
	        	  new Actions(driver).moveToElement(wbPlanOptionType).click(wbPlanOptionType).build().perform();
	        	   waitForPageLoad(13,35);
	        	   seClick(PlanHeaderPage.get().save, "Save button");
	        	   waitForPageLoad(12,35);
	        	   strPlanOptionIdentifier=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::div[contains(@class,'poSelected')])[1]")).getAttribute("data-path");
	        	   strPlanOptionType=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::input[@checked and contains(@id,'"+strPlanOptionIdentifier+"')])[1]/..")).getText();
	        	   log(PASS, strBenefit,strPlanOptionType);
	   	    	   seGetPlanOptionDetails(strBenefit, strPlanOptionIdentifier);

	    }
	


	}
	
	
	public void seValidatePlanAndTemplate(String strBenefit,String strOptionTab,String strTemplateId,String strPlanId){
		
	WebElement wbOptionTab = getWebDriver().findElement(By.xpath("//a[contains(text(),'" + strOptionTab + "')]"));
	((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", wbOptionTab);				
	waitForPageLoad(45);
	waitForPageLoad();
	WebElement Benefits= getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]"));
	((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", Benefits);				
	waitForPageLoad();
	String[] strRadioButtonId=new String[20];
  
    String [] strTextBoxId = new String[20];
    String [] strTextBoxPc=new String[20];
    String [] strTextValuePc=new String[20];
    String [] strAccumulatorStepPc=new String[20];
	String [] strAccumulatorPC=new String[20];
	String id=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::div[contains(@class,'poSelected')])[1]")).getAttribute("data-path");

	int j=1;
	try{
	for( j=1;j<=30;j++){
	strTextBoxPc[j]=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::tr[@dependents])["+j+"]/td/div[contains(@id,'"+strBenefit.replaceAll("\\s", "")+"')]/span[1]")).getText();
	strTextBoxId[j]=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::tr[@dependents])["+j+"]")).getAttribute("name");
	strTextValuePc[j]=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::tr[@dependents])["+j+"]/td/div[contains(@data-path,'"+strBenefit.replaceAll("\\s", "")+"')]/div/select/option[@selected]")).getText();
	}}catch(NoSuchElementException e){
		log(PASS,""+(j-1)+" Accumulators values found in Plan=", strPlanId+" in benefit="+ strBenefit);
	}
	int i=1;
	try{for( i=1;i<=30;i++){
	 strRadioButtonId[i]=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::input[@checked])[contains(text(),'')]["+i+"]")).getAttribute("id");
	 strAccumulatorStepPc[i]=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::input[@checked and contains(@id,'"+id+"')])["+i+"]/preceding::h4[text()][1]")).getText();
	 strAccumulatorPC[i]=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::input[@checked and contains(@id,'"+id+"')])["+i+"]/..")).getText();
	}	}catch(NoSuchElementException e){
		log(PASS,""+(i-1)+" Accumulator Groups found in Plan", strPlanId+" in benefit="+ strBenefit);
	}						
	seCloseBrowser();
	seOpenBrowser(BrowserConstants.Chrome, strBaseURL);					
	LoginPage.get().loginApplication(strUserProfile);
	waitForPageLoad(90);
	seClick(HomePage.get().find, "Find");
	seClick(HomePage.get().findTemplate, "Find template");
	waitForPageLoad(45);
	seSetText(page.planConfigurator.FindTemplatePage.get().templateVersionID, strTemplateId, "text in plan version id textbox");
    seWaitForClickableWebElement(page.planConfigurator.FindTemplatePage.get().templateSearch, 12);
	seClick(page.planConfigurator.FindTemplatePage.get().templateSearch, "Search plan");
	waitForPageLoad(45);
	seWaitForClickableWebElement(page.planConfigurator.FindPlanPage.get().selectSearchedPlan, 12);
	seClick(page.planConfigurator.FindPlanPage.get().selectSearchedPlan, " search result");
	waitForPageLoad(45);
	
	seWaitForClickableWebElement(FindPlanPage.get().clickPlanLevelBenefit, 22);					
	WebElement wbOptionTab1 = getWebDriver().findElement(By.xpath("//a[contains(text(),'" + strOptionTab + "')]"));
	((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", wbOptionTab1);				
	waitForPageLoad(45);
	waitForPageLoad();
	WebElement Benefits1= getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefit+"')])[1]/preceding::li[1]/following::li/a[1])[1]"));
	((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", Benefits1);				
	waitForPageLoad();
	String [] strTextBoxTemplate=new String[10];
	String [] strTextValueTemplate=new String[10];
	String [] strAccumulatorStepTemplate=new String[10];
	String [] strAccumulatorTemplate=new String[10];
	try{
	for(j=1;j<strTextBoxPc.length-1;j++){
	 strTextBoxTemplate[j]=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::div[contains(@id,'"+strTextBoxId[j]+"') and contains(@id,'-_-"+strBenefit.replaceAll("\\s", "")+"-_-')]/span)[1]")).getText();
     strTextValueTemplate[j]=getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::div[contains(@data-path,'"+strTextBoxId[j]+"') and contains(@data-path,'-_-"+strBenefit.replaceAll("\\s", "")+"-_-')])/div/span")).getText();	
	}}catch(NoSuchElementException e){
		log(PASS,""+(j-1)+" Accumulator values found in template", strTemplateId+" in benefit="+strBenefit);
	}int k=0;
	try{for( k=1;k<strAccumulatorPC.length-1;k++){
		 getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::input[contains(@id,'"+id+"') and @checked])["+k+"]/../span[1]/..")).getText();
		 strAccumulatorStepTemplate[k]= getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::input[@id='"+strRadioButtonId[k]+"' and @checked])/preceding::h4[@dependents or contains(@class,'title') and not(contains(@class,'phantom'))][1][string(1)]")).getText();
		 strAccumulatorTemplate[k]= getWebDriver().findElement(By.xpath("(//h4[contains(text(),'"+strBenefit+"')]/following::input[@id='"+strRadioButtonId[k]+"' and @checked])/../span[1]/..")).getText();
		}}catch(NoSuchElementException e){
			log(PASS,""+(k-1)+" Accumulator groups found in Template", strTemplateId+" in benefit="+strBenefit);
		}
	 k=0;
	try{for( k=1;k<=30;k++){
		if(strTextBoxPc[k].equals(strTextBoxTemplate[k])&&strTextValuePc[k].equals(strTextValueTemplate[k])){
			log(PASS, "Accumulators and Accumulator Values are Same between Plan and Template", strTextBoxPc[k]+" :"+strTextValuePc[k]);
		}
		else{
			log(FAIL, "Accumulators and Accumulator Values are NOT Same between Plan and Template", strTextBoxPc[k]+" :"+strTextValuePc[k]);
		}}}catch(Exception e){
	
		}
	try{for(k=1;k<=30;k++){
		if(strAccumulatorStepTemplate[k].replaceAll("\\s", "").replaceAll("VC", "").equals(strAccumulatorStepPc[k].replaceAll("\\s", ""))&&strAccumulatorTemplate[k].replaceAll("\\s", "").replaceAll("VC", "").equals(strAccumulatorPC[k].replaceAll("\\s", ""))){
			log(PASS, "Radio buttons are Same between Plan and Template", strAccumulatorStepPc[k]+" :"+strAccumulatorPC[k] );
		}
		else{			log(FAIL, "Accumulator groups and Accumulator steps are NOT Same between Plan and Template", strAccumulatorStepPc[k]+" :"+strAccumulatorPC[k] );
        }
	}}catch(Exception e){
		
		}
	}
}
