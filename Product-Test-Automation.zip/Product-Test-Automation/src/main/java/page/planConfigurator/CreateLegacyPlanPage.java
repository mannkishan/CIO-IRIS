package page.planConfigurator;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.constants.KeyConstants;
import com.anthem.selenium.utility.EnvHelper;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.groupConfigurator.LoginPage;
import page.planConfigurator.BenefitRetainsInProductionPage;
import page.planConfigurator.BenefitsPage;
import page.planConfigurator.CreatePlanLegacyHeaderPage;
import page.planConfigurator.CreatePlanExcelPage;
import page.planConfigurator.CreatePlanPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.PlanHeaderPage;
import page.planConfigurator.PlanLevelBenefitsPage;
import page.planConfigurator.PlanOptionsPage;
import page.planConfigurator.PlanSetupPage;
import page.planConfigurator.PlanTransitionPage;
import utility.CoreSuperHelper;

import page.groupConfigurator.LoginPage;

/**
 * @author AF47903
 *
 */

public class CreateLegacyPlanPage extends CoreSuperHelper {

       static String strBaseURL = EnvHelper.getValue("pc.url");
       static String strUserProfile = EnvHelper.getValue("user.profile");
       static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
       /**
     * This method fetches data from the excel sheet LegacyPlanXML.xlsx and fills all the Mandatory fields in the UI and generates a Legacy Plan 
     */
    public static void seCreateLegacyPlan (){
              try {
                     try {
                           Boolean blnFirstLevelAccumulatorPresent;
                           Boolean blnSecondLevelAccumulatorPresent;
                           Boolean blnFirstAccumulatorValuePresent;
                           Boolean blnSecondAccumulatorValuePresent;
                           Boolean blnThirdAccumulatorValuePresent;
                           String strFilePath = getCellValue("LegacyExcelPath");
                           File fileName = new File(strFilePath);
                           FileInputStream fis = null;
                           List<String> sheetNames = new LinkedList<String>();
                           fis = new FileInputStream(fileName);
                           XSSFWorkbook workBook = new XSSFWorkbook(fis);
                           for (int i = 0; i < workBook.getNumberOfSheets(); i++) {
                                  sheetNames.add(workBook.getSheetName(i));
                           }
                           for (String temp : sheetNames) {
                                  String sheetName = temp;
                                  XSSFSheet sheet = workBook.getSheet(sheetName);

                                  int rows = sheet.getPhysicalNumberOfRows();
                                  //System.out.println(temp);
                                  HashMap<String, LinkedHashMap<Integer, LinkedList<String>>> mp = CreatePlanExcelPage.get().loadExcelLines(fileName, sheetName);
                                   //System.out.println(mp);
                                  LinkedHashMap<Integer, LinkedList<String>> map = mp.get(sheetName);

                                  for (int i = 1; i <= rows - 1; i++)

                                  {
                                         LinkedList<String> list = map.get(i);
                                         //System.out.println(list);
                                         String strOptionTab = sheetName;
                                         String strBenefits = list.get(0).trim();
                                         String strAccumulatorGroupName = list.get(1).trim();
                                         String strAccumulatorGroupNameClicked=list.get(2).trim();
                                         String strAccSubType = list.get(3).trim();
                                         String strAccSubButton = list.get(5).trim(); 
                                         String strAccumulatorGroupNameSecondClicked=list.get(6).trim();
                                         String strAccumulatorName = list.get(7).trim();
                                         String strAccumulatorFirstValue = list.get(8).trim();
                                         String strAccumulatorSecondValue = list.get(9).trim();
                                         String strAccumulatorThirdValue = list.get(10).trim(); 
                                         if (strAccumulatorGroupName.contains("NIL")) {
                                        	 blnFirstLevelAccumulatorPresent = false;
                                         } else {
                                        	 blnFirstLevelAccumulatorPresent = true;
                                         }
                                         if (strAccSubType.contains("NIL")) {
                                        	 blnSecondLevelAccumulatorPresent = false;
                                         } else {
                                        	 blnSecondLevelAccumulatorPresent = true;
                                         }

                                         if (strAccumulatorFirstValue.contains("NIL")) {
                                        	 blnFirstAccumulatorValuePresent = false;
                                         } else {
                                        	 blnFirstAccumulatorValuePresent = true;
                                         }
                                         if (strAccumulatorSecondValue.contains("NIL")) {
                                        	 blnSecondAccumulatorValuePresent = false;
                                         } else {
                                        	 blnSecondAccumulatorValuePresent = true;
                                         }
                                         if (strAccumulatorThirdValue.contains("NIL")) {
                                        	 blnThirdAccumulatorValuePresent = false;
                                         } else {
                                        	 blnThirdAccumulatorValuePresent = true;
                                         }
                                         if(i==1){
                                         WebElement objOptionTab = getWebDriver().findElement(By.xpath("//a[contains(text(),'" + strOptionTab + "')]"));
                                         ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objOptionTab);
                                         waitForPageLoad();}
                                         //System.out.println(strOptionTab); 
                                         //System.out.println(strBenefits);
                                         WebElement objBenefits= getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'"+strBenefits+"')])[1]/preceding::li[1]/following::li/a[1])[1]"));
                                         ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", objBenefits);
                                         waitForPageLoad();
                                         if(strBenefits == "Durable Medical Equipment")
                                         {
                                        	 seClick(getWebDriver().findElement(By.xpath("((//div[@class='filterContainer']/following::text()[contains(.,'Durable Medical Equipment ')])[1]/preceding::li[1]/following::li/a[1])[2]")),"click");
                                         }
                                         if (blnFirstLevelAccumulatorPresent==true &&blnSecondLevelAccumulatorPresent==false)
                                          {
                                    	  CreatePlanLegacyHeaderPage.seAccumulatorValueFillTrueFalse(strBenefits, strAccumulatorGroupName, strAccumulatorName, strAccumulatorFirstValue, strAccumulatorSecondValue, strAccumulatorThirdValue, blnFirstAccumulatorValuePresent, blnSecondAccumulatorValuePresent, blnThirdAccumulatorValuePresent);
                                    	  
                                          }
                                         else if (blnFirstLevelAccumulatorPresent==true &&blnSecondLevelAccumulatorPresent==true) 
                                          {
                                    	  CreatePlanLegacyHeaderPage.seAccumulatorValueFillTrueTrue(strAccumulatorGroupNameClicked, strAccumulatorGroupNameSecondClicked, strBenefits, strAccumulatorGroupName, strAccSubType, strAccSubButton, strAccumulatorName, strAccumulatorFirstValue, blnFirstAccumulatorValuePresent, blnSecondAccumulatorValuePresent, blnThirdAccumulatorValuePresent, strAccumulatorSecondValue, strAccumulatorThirdValue);
                                          }
                                         else if (blnFirstLevelAccumulatorPresent==false &&blnSecondLevelAccumulatorPresent==false) {
                                                	seClick(objBenefits,strBenefits);
                                                    waitForPageLoad();
                                          CreatePlanLegacyHeaderPage.seAccumulatorValueFillFalseFalse(blnFirstAccumulatorValuePresent, blnSecondAccumulatorValuePresent, blnThirdAccumulatorValuePresent, strBenefits, strAccumulatorName, strAccumulatorFirstValue, strAccumulatorSecondValue, strAccumulatorThirdValue);          
                                      
                                      }
                                         else if (blnFirstLevelAccumulatorPresent==false &&blnSecondLevelAccumulatorPresent==true) {
                                            CreatePlanLegacyHeaderPage.seAccumulatorValueFillFalseTrue(strBenefits, strAccSubType, strAccSubButton, strAccumulatorName, strAccumulatorGroupNameSecondClicked, strAccumulatorFirstValue, strAccumulatorSecondValue, strAccumulatorThirdValue, blnFirstAccumulatorValuePresent, blnSecondAccumulatorValuePresent, blnThirdAccumulatorValuePresent);
                                            }}}
                         
                     } catch (Exception e) {
                           e.printStackTrace();
                           log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
                     } 

                    
              } catch (Exception e) {
                     e.printStackTrace();
                     log(ERROR, "Exception has occured for the script execution", e.getLocalizedMessage());
              } finally {
                 
              }
       }
       
     /**
     * @ This method populates Header page values for Master product Plan/ Legacy Plan
     * @param isMasterPlan: Input if Maaster Plan or BI Product
     * @param intMaxWaitTime: Time to wait
     * @throws Exception
     */
   
    public  static void seCreatePlan(boolean isMasterPlan,int intMaxWaitTime) throws Exception{
    try
   	 {
    	String strEffectiveDate = getCellValue("EffectiveDate");
   		String strProductModel = "";
   		if(isMasterPlan == true)
   		{
   			
   			strProductModel= "Master Product";
   			String strTemplateVersionID = getCellValue("TemplateVersionID");
   			String strApprovalStatus = getCellValue("ApprovalStatus");
   			String strCustomizationLevel = getCellValue("CustomizationLevel");
   			String strState = getCellValue("State");
   			String strMarketSegment = getCellValue("MarketSegment");
   			String strMarketUnit = getCellValue("MarketUnit");
   			String strProductFamily = getCellValue("ProductFamily");
   			String strProductName = getCellValue("ProductName");
   			String strCDHPType = getCellValue("CDHP");
   			String strBenefitPeriod = getCellValue("BenefitPeriod");
   			String strFundingArrangement = getCellValue("FundingArrangement");
   			String strBusinessUnit	 = getCellValue("BusinessUnit");
   			String strLineOfBusiness = getCellValue("LOB");
   			waitForPageLoad(intMaxWaitTime);
   			seClick(HomePage.get().create, "Create");
   			seClick(HomePage.get().plan, "Plan");
   			waitForPageLoad(4,intMaxWaitTime);
   			seSetText(CreatePlanLegacyHeaderPage.get().enterEffectiveDate, strEffectiveDate, "Effective date");
   			CreatePlanLegacyHeaderPage.get().enterEffectiveDate.sendKeys(Keys.TAB);
   			waitForPageLoad(intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().selectProductModelData, strProductModel, "Product Model",intMaxWaitTime);
   			if(strApprovalStatus.equalsIgnoreCase("Approved"))
   			{
   				
   			}
   			seSelectText(CreatePlanLegacyHeaderPage.get().customizationLevel, strCustomizationLevel, "Customization Level",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().state, strState, "State",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().marketSegment, strMarketSegment, "Market Segment",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().marketUnit, strMarketUnit, "Market Unit",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().lob, strLineOfBusiness, "Line of Business",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().productName, strProductName, "Product Name",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().productFamily, strProductFamily, "Product Family",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().cdhType, strCDHPType, "Consumer Driven Health Plan",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().benefitPeriod, strBenefitPeriod, "Benefit Period",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().fundingArrangement,strFundingArrangement, "Funding Arrangement",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().businessUnit, strBusinessUnit, "Business Unit",intMaxWaitTime);
   			if(isMasterPlan)
   			{
   			seClick(CreatePlanLegacyHeaderPage.get().selectTemplate	, "Select Template");
   			waitForPageLoad(4,intMaxWaitTime);
   			seSwitchFrame(FindTemplatePage.get().findTemplateFrame);
   			seWaitForClickableWebElement(FindTemplatePage.get().searchCriteria, 60);
   			seClick(FindTemplatePage.get().searchCriteria	, "Search Criteria");
   			seWaitForClickableWebElement(FindTemplatePage.get().versionId, 120);
   			seSetText(FindTemplatePage.get().versionId, strTemplateVersionID, "Template Version ID");
   			seClick(FindTemplatePage.get().searchButton	, "Search Criteria");
   			waitForPageLoad(intMaxWaitTime);
   			FindTemplatePage.get().selectTemplate(strTemplateVersionID);
   			}
   			waitForPageLoad(intMaxWaitTime);
   			getWebDriver().switchTo().defaultContent();
   			waitForPageLoad(intMaxWaitTime);
   			seClick(CreatePlanLegacyHeaderPage.get().createPlan, "Create Plan");
   			waitForPageLoad(5,intMaxWaitTime);
   			String planVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];;
   			String planProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
   			setCellValue("PlanVersionID", planVersionID);
   			setCellValue("PlanProxyID", planProxyID);
   		}
   		else
   		{	
   		
   	    strProductModel= "BI Product";
   	    String strClaimSystem = null;
   		String strCustomizationLevel = getCellValue("Level");
   		String strState = getCellValue("State");
   		String strMarketSegment = getCellValue("Market Segment");
   		String strMarketUnit = getCellValue("Market Unit");
   		String strPlanDesign = getCellValue("Plan Design");
   		String strBenefitPeriod = getCellValue("Benefit Period");
   		String strFundingArrangement = getCellValue("Funding");
   		String strBusinessUnit	 = getCellValue("Unit");
   		String strBusinessEntity = getCellValue("Entity");
   		String strLineOfBusiness = getCellValue("LOB");
   		String strProductName = getCellValue("Product Name");
   		String strCDHPType = getCellValue("CDHP");
   		String strProductFamily = getCellValue("ProductFamily");
   		if(strLineOfBusiness.equals("Dental")){	
   		strClaimSystem = getCellValue("ClaimSystem");
   		
   		}
   		else{
   		}
   		waitForPageLoad(intMaxWaitTime);
   		seClick(HomePage.get().create, "Create");
   		seClick(HomePage.get().plan, "Plan");
   		waitForPageLoad(4,intMaxWaitTime);
   		seSetText(CreatePlanLegacyHeaderPage.get().enterEffectiveDate, strEffectiveDate, "Effective date");
   		CreatePlanLegacyHeaderPage.get().enterEffectiveDate.sendKeys(Keys.ENTER);
   		CreatePlanLegacyHeaderPage.get().enterEffectiveDate.sendKeys(Keys.TAB);
   		waitForPageLoad(intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().selectProductModelData, strProductModel, "Product Model",intMaxWaitTime);
   		String strCustlvl = "Customization Level";
   		seCustomizationLevel(strCustlvl,strCustomizationLevel,10);
   		seSelectText(CreatePlanLegacyHeaderPage.get().state, strState, "State",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().marketSegment, strMarketSegment, "Market Segment",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().marketUnit, strMarketUnit, "Market Unit",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().lob, strLineOfBusiness, "Line of Business",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().productName, strProductName, "Product Name",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().cdhType, strCDHPType, "Consumer Driven Health Plan",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().planDesign, strPlanDesign, "Plan Design",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().benefitPeriod, strBenefitPeriod, "Benefit Period",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().fundingArrangement,strFundingArrangement, "Funding Arrangement",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().businessEntity, strBusinessEntity, "Business Entity",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().businessUnit, strBusinessUnit, "Business Unit",intMaxWaitTime);
   		seSelectText(CreatePlanPage.get().productFamily, strProductFamily, "Product Family",intMaxWaitTime);
   		if(strLineOfBusiness.equals("Dental")){	
   			seSelectText(CreatePlanPage.get().claimSystem, strClaimSystem, "Claim Syatem",intMaxWaitTime);
      		}
      		else{
      		}

   		waitForPageLoad(intMaxWaitTime);
   		seClick(CreatePlanLegacyHeaderPage.get().createPlan, "Create Plan");
   		waitForPageLoad(5,intMaxWaitTime);
   		}
   	} catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
	} 
   	}
   //	**************
   	public  static void seCreatePlanVision(boolean isMasterPlan,int intMaxWaitTime) throws Exception
   	{try{
   		String strEffectiveDate = getCellValue("EffectiveDate");
   		
   		String strProductModel = "";
   		if(isMasterPlan == true)
   		{
   			strProductModel= "Master Product";
   			String strTemplateVersionID = getCellValue("TemplateVersionID");
   			String strApprovalStatus = getCellValue("ApprovalStatus");
   			String strCustomizationLevel = getCellValue("CustomizationLevel");
   			String strState = getCellValue("State");
   			String strMarketSegment = getCellValue("MarketSegment");
   			String strMarketUnit = getCellValue("MarketUnit");
   			String strProductFamily = getCellValue("ProductFamily");
   			String strProductName = getCellValue("ProductName");
   			String strCDHPType = getCellValue("CDHP");
   			String strBenefitPeriod = getCellValue("BenefitPeriod");
   			String strFundingArrangement = getCellValue("FundingArrangement");
   			String strBusinessUnit	 = getCellValue("BusinessUnit");
   			String strLineOfBusiness = getCellValue("LOB");
   			waitForPageLoad(intMaxWaitTime);
   			seClick(HomePage.get().create, "Create");
   			seClick(HomePage.get().plan, "Plan");
   			waitForPageLoad(4,intMaxWaitTime);
   			seSetText(CreatePlanLegacyHeaderPage.get().enterEffectiveDate, strEffectiveDate, "Effective date");
   			CreatePlanLegacyHeaderPage.get().enterEffectiveDate.sendKeys(Keys.TAB);
   			waitForPageLoad(intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().selectProductModelData, strProductModel, "Product Model",intMaxWaitTime);
   			if(strApprovalStatus.equalsIgnoreCase("Approved"))
   			{
   				
   			}
   			seSelectText(CreatePlanLegacyHeaderPage.get().customizationLevel, strCustomizationLevel, "Customization Level",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().state, strState, "State",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().marketSegment, strMarketSegment, "Market Segment",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().marketUnit, strMarketUnit, "Market Unit",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().lob, strLineOfBusiness, "Line of Business",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().productName, strProductName, "Product Name",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().productFamily, strProductFamily, "Product Family",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().cdhType, strCDHPType, "Consumer Driven Health Plan",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().benefitPeriod, strBenefitPeriod, "Benefit Period",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().fundingArrangement,strFundingArrangement, "Funding Arrangement",intMaxWaitTime);
   			seSelectText(CreatePlanLegacyHeaderPage.get().businessUnit, strBusinessUnit, "Business Unit",intMaxWaitTime);
   			if(isMasterPlan)
   			{
   			seClick(CreatePlanLegacyHeaderPage.get().selectTemplate	, "Select Template");
   			waitForPageLoad(4,intMaxWaitTime);
   			seSwitchFrame(FindTemplatePage.get().findTemplateFrame);
   			seWaitForClickableWebElement(FindTemplatePage.get().searchCriteria, 60);
   			seClick(FindTemplatePage.get().searchCriteria	, "Search Criteria");
   			seWaitForClickableWebElement(FindTemplatePage.get().versionId, 120);
   			seSetText(FindTemplatePage.get().versionId, strTemplateVersionID, "Template Version ID");
   			seClick(FindTemplatePage.get().searchButton	, "Search Criteria");
   			waitForPageLoad(intMaxWaitTime);
   			FindTemplatePage.get().selectTemplate(strTemplateVersionID);
   			}
   			waitForPageLoad(intMaxWaitTime);
   			getWebDriver().switchTo().defaultContent();
   			waitForPageLoad(intMaxWaitTime);
   			seClick(CreatePlanLegacyHeaderPage.get().createPlan, "Create Plan");
   			waitForPageLoad(5,intMaxWaitTime);
   			String planVersionID = seGetElementValue(PlanHeaderPage.get().planVersionID).split(":")[1];;
   			String planProxyID = seGetElementValue(PlanHeaderPage.get().planProxyID).split(":")[1];
   			setCellValue("PlanVersionID", planVersionID);
   			setCellValue("PlanProxyID", planProxyID);
   		}
   		else
   		{	
   	    strProductModel= "BI Product";
   		String strCustomizationLevel = getCellValue("Level");
   		String strState = getCellValue("State");
   		String strMarketSegment = getCellValue("Market Segment");
   		String strMarketUnit = getCellValue("Market Unit");
   		String strPlanDesign = getCellValue("Plan Design");
   		String strBenefitPeriod = getCellValue("Benefit Period");
   		String strFundingArrangement = getCellValue("Funding");
   		String strBusinessUnit	 = getCellValue("Unit");
   		String strBusinessEntity = getCellValue("Entity");
   		String strLineOfBusiness = getCellValue("LOB");
   		waitForPageLoad(intMaxWaitTime);
   		seClick(HomePage.get().create, "Create");
   		seClick(HomePage.get().plan, "Plan");
   		waitForPageLoad(4,intMaxWaitTime);
   		seSetText(CreatePlanLegacyHeaderPage.get().enterEffectiveDate, strEffectiveDate, "Effective date");
   		CreatePlanLegacyHeaderPage.get().enterEffectiveDate.sendKeys(Keys.ENTER);
   		CreatePlanLegacyHeaderPage.get().enterEffectiveDate.sendKeys(Keys.TAB);
   		waitForPageLoad(intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().selectProductModelData, strProductModel, "Product Model",intMaxWaitTime);
   		String strCustlvl = "Customization Level";
   		seCustomizationLevel(strCustlvl,strCustomizationLevel,10);
   		seSelectText(CreatePlanLegacyHeaderPage.get().state, strState, "State",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().marketSegment, strMarketSegment, "Market Segment",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().marketUnit, strMarketUnit, "Market Unit",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().lob, strLineOfBusiness, "Line of Business",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().planDesign, strPlanDesign, "Plan Design",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().benefitPeriod, strBenefitPeriod, "Benefit Period",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().fundingArrangement,strFundingArrangement, "Funding Arrangement",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().businessEntity, strBusinessEntity, "Business Entity",intMaxWaitTime);
   		seSelectText(CreatePlanLegacyHeaderPage.get().businessUnit, strBusinessUnit, "Business Unit",intMaxWaitTime);
   		waitForPageLoad(intMaxWaitTime);
   		seClick(CreatePlanLegacyHeaderPage.get().createPlan, "Create Plan");
   		waitForPageLoad(5,intMaxWaitTime);
   		}
   	} catch (Exception e) {
		e.printStackTrace();
		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
	} 
   	}
       /**
     * Populates value for the customizationLevel header field.
     * @param strAccumName: Accumulator Name
     * @param strAccumValue: Accumulator Value
     * @param intWaitTime: Wait time
     */
    public static void seCustomizationLevel(String strAccumName, String strAccumValue, int intWaitTime)
   	{try{
   		seWaitForClickableWebElement(driver.findElement(By.xpath("(//span[contains(text(),'"+strAccumName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]")), 10);
   		waitForPageLoad(intWaitTime);
   		seClick(driver.findElement(By.xpath("(//span[contains(text(),'"+strAccumName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]")), "CustomizationLevel drop down");
   		waitForPageLoad(intWaitTime);
   		seSetText(driver.findElement(By.xpath("//*[@id=\"content-create-customPlan\"]/span/span/span[1]/input")),strAccumValue,"setting text");
   		waitForPageLoad(intWaitTime);
   		seClick(driver.findElement(By.xpath("(//span[contains(text(),'"+strAccumName+"')])[1]/following::span[contains(text(),'- Please Select -')][1]/following::input[3]/following::span[contains(text(),'"+strAccumValue+"')]")), "Customization Level option Select");
   	} catch (Exception e) {
   		e.printStackTrace();
   		log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
   	}
   }	

}
