package page.planConfigurator;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import utility.CoreSuperHelper;

public class EditPlanInfo extends CoreSuperHelper{
	
	private static EditPlanInfo thisTestObj;	
	public synchronized static EditPlanInfo get() {
		thisTestObj = PageFactory.initElements(getWebDriver(), EditPlanInfo.class);
		return thisTestObj;
	}
	
	@FindBy(how = How.XPATH, using = "//div[@id='content-create-customPlan']//button[contains(@class,'doAction')]")
	@CacheLookup
	public WebElement btnSave;
	 	
	/*@FindBy(how = How.XPATH, using = "//div[@id='content-plan']/div/div[2]")
	@CacheLookup
	public WebElement umRules;*/
	
	@FindBy(how = How.XPATH, using = "//div[@id='PlanAdminGroup']/div/div[2]/div/div/div/table/tbody/tr[2]/td[2]")
	@CacheLookup
	public WebElement umRules;
	
	public String getumRules()
	{
		return seGetElementValue(umRules);
	}
	
	@FindBy(how = How.XPATH, using = "//*[@id='verticalBarMenuDetails']/div/nav/div[2]/ul/li[6]/a")
	@CacheLookup
	public WebElement plan_planAdministration;
	
	public static void validateUmRules(String umrule)
	{
		
		seWaitForClickableWebElement(EditPlanInfo.get().plan_planAdministration,60);
		seClick(EditPlanInfo.get().plan_planAdministration, "Plan Administration");
		waitForPageLoad();
		
		
		
		/*WebElement Umrules = getWebDriver().findElement(By.xpath("//div[@id='verticalBarMenu']/div[2]/ul/li[@id='UMRules']/a")) ;
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",Umrules);
		waitForPageLoad(300);*/
		
		
		if(FindPlanPage.get().planSearchResults.isDisplayed()){
			log(PASS,"Plan with required status is found","Plan with required status is found",true);
			seClick(FindPlanPage.get().planSearchResults, "Click Plan from results displayed ");
			waitForPageLoad();			
		}
		else{
			log(FAIL," No Plans avaialable","No Plans availabe",true);
		}		
	}

}
