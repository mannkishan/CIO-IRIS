package page.planInheritance;

/*
 * @author af54545
 * 
 */
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import page.planInheritance.PlanInheritancePage;
import utility.CoreSuperHelper;

public class PlanInheritancePage extends CoreSuperHelper {
	
	private static PlanInheritancePage thisIsTestObj;
	public  synchronized static PlanInheritancePage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), PlanInheritancePage.class);
		return thisIsTestObj;
		}
		
	@FindBy(how=How.XPATH,using="//div[@id='verticalBarMenuDetails']//li[3]")
	public WebElement level1NetworkCoverage;
	
	@FindBy(how=How.XPATH,using="//select[@id='POA_Base-_-FormCovg-_-FourTier-_-NA-_-NA-_-FormTier2RetailCoin_-_percentage']//following-sibling::span[1]/span[1]/span/span[2]")
	public WebElement formularyTier2RetailCoinsurance ;
	
	@FindBy(how=How.XPATH,using="//span[@class='select2-search select2-search--dropdown']//input[@class='select2-search__field']")
	public WebElement textFormularyTier2RetailCoinsurance ;
	
	@FindBy(how=How.XPATH,using="//ul[@id='actionsBar']/li[7]/a")
	public WebElement selectSave;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Biologicals')]")
	@CacheLookup
	public WebElement selectBenefit;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Acupuncture')]")
	@CacheLookup
	public WebElement selectAcupuncture;
	
	@FindBy(how = How.XPATH, using = "//div[@class='benefitDetailsWrapper']/div[2]")
	@CacheLookup
	public WebElement selectFormularyTier2Retail;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Hospital / Facility Care')]")
	@CacheLookup
	public WebElement selectParentBenefitHFC;
	
	@FindBy(how = How.XPATH, using = "//div[@class='benefitDetailsWrapper']/div[1]")
	@CacheLookup
	public WebElement  selectFirstRow;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'In Network Inpatient Care Copay')]//following::span[@class='select2-selection__arrow'][1]")
	public WebElement HFCParentcopayment;
	
	@FindBy(how=How.XPATH,using="//span[@class='select2-search select2-search--dropdown']//input[@class='select2-search__field']")
	public WebElement textHFCParentcopayment;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'In Network Inpatient Care Copay')]//following::span[@class='select2-selection__arrow'][2]")
	public WebElement HFCParentcoinsurance;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'In Network Coinsurance')]//following::span[@class='select2-selection__arrow'][1]")
	public WebElement childcoinsurance;
	
	@FindBy(how=How.XPATH,using="//span[@class='select2-search select2-search--dropdown']/input[@class='select2-search__field']")
	public WebElement textHFCParentcoinsurance;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Hospital / Facility Care')]//following::a[contains(text(),'Bariatric')][1]")
	@CacheLookup
	public WebElement selectChildBenefitBariatric;
	
	@FindBy(how = How.XPATH, using = "//div[@class='benefitDetailsWrapper']/div[1]")
	@CacheLookup
	public WebElement  selectChildInpatientPlaceofService;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Filling')]")
	@CacheLookup
	public WebElement selectBenefitFilling;
	
	@FindBy(how = How.XPATH, using = "//div[@class='benefitDetailsWrapper']/div[2]")
	@CacheLookup
	public WebElement selectAdultTire1;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Pediatric Basic Services Copay')]//following::span[@class='select2-selection__arrow'][1]")
	@CacheLookup
	public WebElement selectParentFillingCopayment;
	
	@FindBy(how = How.XPATH, using = "//span[@class='select2-search select2-search--dropdown']/input[@class='select2-search__field']")
	@CacheLookup
	public WebElement textParentFillingCopayment;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Pediatric Basic Services Copay')]//following::span[@class='select2-selection__arrow'][2]")
	@CacheLookup
	public WebElement selectParentFillingCoinsurance;
	
	@FindBy(how = How.XPATH, using = "//span[@class='select2-search select2-search--dropdown']/input[@class='select2-search__field']")
	@CacheLookup
	public WebElement textParentFillingCoinsurance;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Amalgam')]")
	@CacheLookup
	public WebElement selectChildBenefitAmalgam;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Vision Exam')]")
	@CacheLookup
	public WebElement selectBenefitVisionExam;
	
	@FindBy(how = How.XPATH, using = "//div[@class='benefitDetailsWrapper']/div[1]")
	@CacheLookup
	public WebElement selectParticipating;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Vision Exam Copay')]//following::span[@class='select2-selection__arrow'][1]")
	@CacheLookup
	public WebElement selectParentVisionCoinsurance;
	
	@FindBy(how = How.XPATH, using = "//span[@class='select2-search select2-search--dropdown']/input[@class='select2-search__field']")
	@CacheLookup
	public WebElement textParentVisionCoinsurance;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Vision Exam Copay')]//following::span[@class='select2-selection__arrow'][2]")
	@CacheLookup
	public WebElement selectParentVisionCopayment;
	
	@FindBy(how = How.XPATH, using = "//span[@class='select2-search select2-search--dropdown']/input[@class='select2-search__field']")
	@CacheLookup
	public WebElement textParentVisionCopayment;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Contact Lens Exam')]")
	@CacheLookup
	public WebElement selectChildBenefitOfVisionExam;
	
	@FindBy(how = How.XPATH, using = "//div[@class='benefitDetailsWrapper']/div[1]")
	@CacheLookup
	public WebElement selectFormularyTier1Mail;
	
	@FindBy(how = How.XPATH, using = "//div[@class='benefitDetailsWrapper']/div[1]")
	@CacheLookup
	public WebElement selectParentInpatientPlaceofService;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Covered Override')]//preceding::input[@name='BTC_Biologicals-_-Tier1-_-FormMail'][3]")
	@CacheLookup
	public WebElement selectParentCoveredOverride;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Covered Override')]//preceding::input[@name='BTC_Biologicals-_-Tier1-_-FormRetail'][3]")
	@CacheLookup
	public WebElement selectParentCoveredOverrideRetail;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Rx Mail Coinsurance')]//following::span[@class='select2-selection__arrow'][1]")
	@CacheLookup
	public WebElement selectParentBiologicalsCoinsurance;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Rx Retail Coinsurance')]//following::span[@class='select2-selection__arrow'][1]")
	@CacheLookup
	public WebElement selectParentBiologicalsCoinsuranceRetail;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Formulary Tier 1 Retail Coinsurance')]//following::span[@class='select2-selection__arrow'][1]")
	@CacheLookup
	public WebElement selectParentBenefitCoinsurance;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Formulary Tier 1 Mail Copay')]//following::span[@class='select2-selection__arrow'][1]")
	@CacheLookup
	public WebElement selectBenefitCopayMail;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Formulary Tier 1 Retail Copay')]//following::span[@class='select2-selection__arrow'][1]")
	@CacheLookup
	public WebElement selectBenefitCopayRetail;
	
	@FindBy(how = How.XPATH, using = "//span[@class='select2-search select2-search--dropdown']/input[@class='select2-search__field']")
	@CacheLookup
	public WebElement textParentBiologicalsCoinsurance;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Allergens')]")
	@CacheLookup
	public WebElement selectChildBenefitAllergens;
	
	@FindBy(how = How.XPATH, using = "//div[@class='benefitDetailsWrapper']/div[2]")
	@CacheLookup
	public WebElement selectFormularyTier1Retail;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Covered Override')]//preceding::input[@name='BTC_Biologicals-_-Tier1-_-FormMail'][3]")
	@CacheLookup
	public WebElement selectChildCoveredOverride;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Covered Override')]//preceding::input[@name='BTC_Biologicals-_-Tier1-_-FormRetail'][3]")
	@CacheLookup
	public WebElement selectCoveredOverride;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Covered - Standard Calculation')]//preceding::input[@name='BTC_Biologicals-_-BTC_Allergens-_-C-_-FormTier2Retail'][2]")
	@CacheLookup
	public WebElement selectCoveredStandardCalculation;
	
	@FindBy(how = How.XPATH, using = "//label[contains(text(),'Covered - Standard Calculation')]//preceding::input[@name='BTC_Biologicals-_-BTC_Allergens-_-C-_-FormTier1Retail'][2]")
	@CacheLookup
	public WebElement selectCoveredStandardCal;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Biologicals')]/span")
	@CacheLookup
	public WebElement parentOverriddenIndicator;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Allergens')]/span")
	@CacheLookup
	public WebElement childOverriddenIndicator;
	
	@FindBy(how = How.XPATH, using = "//div[@id='verticalBarMenuDetails']//li[2]/a[1]")
	@CacheLookup
	public WebElement selectBasic;
	
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Basic Coinsurance')]//following::span[@class='select2-selection__arrow'][1]")
	@CacheLookup
	public WebElement selectDentalParentCoins;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Anti-Reflective Lenses')]")
	@CacheLookup
	public WebElement selectAntiReflectiveLenses;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Anti-Reflective Coating')]")
	@CacheLookup
	public WebElement selectAntReflectiveCoating;
	
	@FindBy(how = How.XPATH, using = "//div[@class='benefitDetailsWrapper']/div[1]")
	@CacheLookup
	public WebElement selectAdultTire11;
		
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'In Network Adult Vision Coinsurance')]//following::span[@class='select2-selection__arrow'][1]")
	@CacheLookup
	public WebElement selectParentEyeglassesCoinsurance;
	
	public WebElement selectDropdown1(String Value)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+Value+"')]//following::span[@class='select2-selection__arrow'][1]"));
		return valueType;
	}
	
	public WebElement selectDropdown2(String Value)
	{
		WebElement valueType = getWebDriver().findElement(By.xpath("//span[contains(text(),'"+Value+"')]//following::span[@class='select2-selection__arrow'][1]"));
		return valueType;
	}
	public boolean coinsuranceValue (String PlanLevelCoinsValue){
	WebElement element = getWebDriver().findElement(By.xpath("//*[contains(@title,'"+ PlanLevelCoinsValue +"')]"));
	return element.isDisplayed();
	}
		
	public boolean copaymentValue (String PlanLevelCopayValue){
	WebElement element = getWebDriver().findElement(By.xpath("//*[contains(@title,'"+ PlanLevelCopayValue +"')]"));
	return element.isDisplayed();
	}
		
	public void planLevelbenefit(){
		   WebElement Planlevelbenefit = getWebDriver().findElement(By.xpath("//a[@title='Plan Level Benefits']")) ;
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",Planlevelbenefit); 
	   }
	
	public void BenefitOption(){
		   WebElement benefitOption = getWebDriver().findElement(By.xpath("//a[@title='Benefit Options']")) ;
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",benefitOption); 
	   }
	
	@FindBy(how=How.XPATH,using="//div[@id='verticalBarMenuDetails']//li[3]/a[1]")
	public WebElement mailCoverage;
	
	@FindBy(how=How.XPATH,using="//select[@id='POA_Base-_-MailCovg-_-MailCovg-_-Tier2-_-Tier2-_-CoinFormTier2MailRx_-_percentage']//following-sibling::span[1]/span[1]/span/span[2]")
	public WebElement formularyTier2MailCoinsurance ;
	
	@FindBy(how=How.XPATH,using="//select[@id='POA_Base-_-MailCovg-_-MailCovg-_-Tier1NotSplit-_-Tier1NotSplit-_-CoinFormTier1MailRx_-_percentage']//following-sibling::span[1]/span[1]/span/span[2]")
	public WebElement formularyTier1MailCoinsurance ;

	@FindBy(how=How.XPATH,using="//span[@class='select2-search select2-search--dropdown']//input[@class='select2-search__field']")
	public WebElement textFormularyTier2MailCoinsurance ;
	
	@FindBy(how=How.XPATH,using="//select[@id='POA_Base-_-Coinsurance-_-Coinsurance-_-NA-_-NA-_-CoinINNT1Med_-_percentage']/option[2]")
	public WebElement InNetworkCoinsValue ;
	
	@FindBy(how=How.XPATH,using="//select[@id='POA_Base-_-FormCovg-_-FourTier-_-NA-_-NA-_-FormTier1RetailCoin_-_percentage']/option[2]")
	public WebElement Tire1RetailCoins ;
	
	@FindBy(how=How.XPATH,using="//select[@class='planOptionField percentage continuous MODIFIED_BY_USER select2-hidden-accessible large-continuous']/option[1]")
	public WebElement InNetworkCoinsuranceValue ;
	
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Antidiabetics - Amylin Analogs')]//preceding::a[contains(text(),'Antidiabetics')][1]")
	@CacheLookup
	public WebElement selectAntidiabetics;
		
	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Antidiabetics - Amylin Analogs')]")
	@CacheLookup
	public WebElement selectAntidiabeticsAmylinAnalogs;
	
	@FindBy(how = How.XPATH, using = "//div[@id='verticalBarMenuDetails']//li[7]")
	@CacheLookup
	public WebElement selectAntidiabeticsBenefitoption;
	
	@FindBy(how = How.XPATH, using = "//div[@id='verticalBarMenuDetails']//li[8]")
	@CacheLookup
	public WebElement selectAntidiabeticsAmylinAnalogsBenefitoption;
	
	@FindBy(how = How.ID, using = "POA_BenefitOption-_-Antidiabetics-_-CoveredRetailAndMail-_-MailCostShares-_-CostShareOverrideTier1")
	@CacheLookup
	public WebElement selectOptionOfAntidiabetics;
	
	@FindBy(how = How.ID, using = "POA_BenefitOption-_-AntidiabeticsAmylinAnalogs-_-CoveredRetailAndMail-_-MailCostShares-_-CostShareOverrideTier1")
	@CacheLookup
	public WebElement selectOptionOfAntidiabeticsAmylinAnalogsBenefitoption;
	
}
	
	
