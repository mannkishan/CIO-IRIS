package page.xmlValidation;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import page.planConfigurator.BenefitsPage;
import page.planConfigurator.ExamVisitsBenefitsPage;
import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.OfficeExamPCPPage;
import page.planConfigurator.OfficeExamSpecPage;
import page.planConfigurator.PlanOptionsPage;

import com.anthem.selenium.constants.BrowserConstants;

import utility.CoreSuperHelper;

public class MasterProductAndLegacyPlanOptionsXMLPage extends CoreSuperHelper {
	private static MasterProductAndLegacyPlanOptionsXMLPage thisIsTestObj;

	public synchronized static MasterProductAndLegacyPlanOptionsXMLPage get() {
		thisIsTestObj = PageFactory.initElements(getWebDriver(), MasterProductAndLegacyPlanOptionsXMLPage.class);
		return thisIsTestObj;
	}

	/* Finding Status of a Plan */
	@FindBy(how = How.XPATH, using = "//table[@class=\"table searchResultsTable fjaTable dataTable\"]//tr[@class=\"rowlink odd\"]//td[contains(text(),'Production')]")
	@CacheLookup
	public WebElement planStatus;

	@FindBy(how = How.XPATH, using = "//*[@id=\"planHeaderWrapper\"]/div/div/div[2]/div[1]/button[2]")
	@CacheLookup
	public WebElement xmlButton;

	@FindBy(how = How.XPATH, using = "/html/body/div[9]/div/div/div/div[2]/table/tbody/tr/td/div/div/div[1]/div/div[2]/button")
	@CacheLookup
	public WebElement xmlFileDownload;

	@FindBy(how = How.XPATH, using = "/html/body/div[9]/div/div/div/div[1]/button")
	@CacheLookup
	public WebElement xmlFileDownloadClose;

	public HashMap<String, LinkedHashMap<Integer, LinkedList<String>>> loadExcelLines(File filename, String sheetName) {
		HashMap<String, LinkedHashMap<Integer, LinkedList<String>>> map = new HashMap<>();
		LinkedHashMap<Integer, LinkedList<String>> hashMap = new LinkedHashMap<Integer, LinkedList<String>>();
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(filename);
			XSSFWorkbook workBook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workBook.getSheet(sheetName);
			Iterator rows = sheet.rowIterator();
			while (rows.hasNext()) {
				XSSFRow row = (XSSFRow) rows.next();
				Iterator cells = row.cellIterator();
				LinkedList<String> data = new LinkedList();
				while (cells.hasNext()) {
					XSSFCell cell = (XSSFCell) cells.next();
					cell.setCellType(Cell.CELL_TYPE_STRING);
					data.add(cell.getRichStringCellValue().getString().trim());
				}
				hashMap.put(row.getRowNum(), data);
			}
			map.put(sheetName, hashMap);
			workBook.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		return map;
	}

	public boolean checkPlanInProductionStatus(String planID) {
		seWaitForClickableWebElement(HomePage.get().find, 10);
		seClick(HomePage.get().find, "Find");
		seClick(HomePage.get().findPlan, "Find Plan");
		seSetText(FindPlanPage.get().planVersionID, planID, "Enter Plan ID");
		seWaitForClickableWebElement(FindPlanPage.get().planSearch, 30);
		seClick(FindPlanPage.get().planSearch, "Search Plan");
		if ((seGetText(MasterProductAndLegacyPlanOptionsXMLPage.get().planStatus).toString()).equalsIgnoreCase("Production")) {
			seWaitForClickableWebElement(PlanOptionsPage.get().clickSearchedPlan, 30);
			seClick(PlanOptionsPage.get().clickSearchedPlan, "Click the plan from Search Result");
			seWaitForClickableWebElement(MasterProductAndLegacyPlanOptionsXMLPage.get().xmlButton, 30);
			seClick(MasterProductAndLegacyPlanOptionsXMLPage.get().xmlButton, "XML Button");
			seWaitForClickableWebElement(MasterProductAndLegacyPlanOptionsXMLPage.get().xmlFileDownload, 30);
			seClick(MasterProductAndLegacyPlanOptionsXMLPage.get().xmlFileDownload, "XML Download");
			seWaitForClickableWebElement(MasterProductAndLegacyPlanOptionsXMLPage.get().xmlFileDownloadClose, 30);
			seClick(MasterProductAndLegacyPlanOptionsXMLPage.get().xmlFileDownloadClose, "Close XML");
			return true;
		} else {
			log(INFO, "Plan [" + planID + "] unavailable in Production");
		}
		return false;
	}

	public void readTabContents(String fileFeed, String xmlFileName) {
		try {
			File fileName = new File(fileFeed);
			FileInputStream fis = null;
			java.util.List<String> sheetNames = new LinkedList<String>();
			fis = new FileInputStream(fileName);
			XSSFWorkbook workBook = new XSSFWorkbook(fis);
			for (int i = 0; i < workBook.getNumberOfSheets(); i++) {
				sheetNames.add(workBook.getSheetName(i));
			}
			for (String temp : sheetNames) {
				String sheetName = temp;
				XSSFSheet sheet = workBook.getSheet(sheetName);
				int rows = sheet.getPhysicalNumberOfRows();
				HashMap<String, LinkedHashMap<Integer, LinkedList<String>>> mp = MasterProductAndLegacyPlanOptionsXMLPage.get()
						.loadExcelLines(fileName, sheetName);
				LinkedHashMap<Integer, LinkedList<String>> map = mp.get(sheetName);
				try {
					for (int i = 1; i <= rows - 1; i++) {
						LinkedList<String> list = map.get(i);
						String planOptionType = list.get(0).trim();
						String planOptionName = list.get(1).trim();
						String groupType = list.get(3).trim();
						String accumulatorGroupType = list.get(4).trim();
						String accumulatorName = list.get(7).trim();
						String accumulatorValue1 = list.get(8).trim();
						String accumulatorValue2 = list.get(9).trim();
						String accumulatorValue3 = list.get(10).trim();
						MasterProductAndLegacyPlanOptionsXMLPage.get().planOptionsAccumulatorValidation(xmlFileName, planOptionType,
								groupType, accumulatorName, accumulatorValue1, accumulatorValue2, accumulatorValue3);

					}
				} catch (IndexOutOfBoundsException e) {
					e.printStackTrace();
				}
			}
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			workBook.close();
		} catch (Exception e) {
			e.printStackTrace();
			log(ERROR, "Exception has occured for the iteration", e.getLocalizedMessage());
		}
	}

	public void planOptionsAccumulatorValidation(String xmlFileName, String reqdPlanOptionType, String reqdGroupType,
			String reqdAccumulatorName, String reqdAccumulatorValue1, String reqdAccumulatorValue2,
			String reqdAccumulatorValue3) {
		try {
			File inputFile = new File(xmlFileName);
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);

			if (!reqdGroupType.equalsIgnoreCase("NIL") || !reqdAccumulatorName.equalsIgnoreCase("NIL")) {
				List<Node> nodes = document.selectNodes("//planOptionGroup/planOption");
				for (Node node : nodes) {

					String planOptionType = ((Element) (node.selectSingleNode("planOptionType")))
							.attributeValue("text");
					if (planOptionType.equalsIgnoreCase(reqdPlanOptionType)) {
						String planOptionName = ((Element) (node.selectSingleNode("planOptionName")))
								.attributeValue("text");
						List<Node> accumulatorListNode = node.selectSingleNode("accumulatorGroups")
								.selectNodes("accumulatorGroup");
						for (Node accumulatorGroupNode : accumulatorListNode) {
							String accumulatorGroupName = ((Element) (accumulatorGroupNode
									.selectSingleNode("accumulatorList"))).getName();
							if (!reqdGroupType.equalsIgnoreCase("NIL")) {

								try {
									String groupType = null;
									groupType = ((Element) (accumulatorGroupNode.selectSingleNode("accumulatorList")
											.selectSingleNode("groupType"))).attributeValue("text");
									if (groupType != null) {

										if (groupType.equalsIgnoreCase(reqdGroupType)) {

											List<Node> accumulatorNodes = accumulatorGroupNode
													.selectSingleNode("accumulatorList")
													.selectSingleNode("accumulators").selectNodes("accumulator");
											checkIfNIL(accumulatorNodes, reqdPlanOptionType, reqdGroupType,
													reqdAccumulatorName, reqdAccumulatorValue1, reqdAccumulatorValue2,
													reqdAccumulatorValue3);
										}
									}
								} catch (ClassCastException e) {
									RESULT_STATUS = false;
									log(FAIL, "Given Accumulator " + reqdAccumulatorName
											+ " values are not available in XML", "RESULT_STATUS=FAIL");

								} catch (NullPointerException e) {

									log(INFO, "Throws Null Pointer Exception As Group Type Not Applicable");
								}
							} else if (reqdGroupType.equalsIgnoreCase("NIL")
									&& (!reqdAccumulatorName.equalsIgnoreCase("NIL"))) {
								List<Node> accumulatorNodes = accumulatorGroupNode.selectSingleNode("accumulatorList")
										.selectSingleNode("accumulators").selectNodes("accumulator");
								checkIfNIL(accumulatorNodes, reqdPlanOptionType, reqdGroupType, reqdAccumulatorName,
										reqdAccumulatorValue1, reqdAccumulatorValue2, reqdAccumulatorValue3);
							}
						}
					}
				}
			} else {
				log(INFO, "Plan Option " + reqdPlanOptionType + " does not have Accumulator " + reqdAccumulatorName);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void checkIfNIL(List<Node> accumulatorNodes, String reqdPlanOptionType, String reqdGroupType,
			String reqdAccumulatorName, String reqdAccumulatorValue1, String reqdAccumulatorValue2,
			String reqdAccumulatorValue3) {
		boolean checkValidAccumValues = false;
		for (Node accumulator : accumulatorNodes) {
			String accumulatorName = ((Element) (accumulator.selectSingleNode("accumulatorName")))
					.attributeValue("text");
			String accumulatorTypeValue = ((Element) (accumulator.selectSingleNode("accumulatorType")))
					.attributeValue("text");
			if (accumulatorName.equalsIgnoreCase(reqdAccumulatorName)) {
				switch (accumulatorTypeValue) {
				case "Choice":
					if (!reqdAccumulatorValue1.equalsIgnoreCase("NIL")) {

						String choiceValue = ((Element) (accumulator.selectSingleNode("choiceValue")))
								.attributeValue("text");
						if (reqdAccumulatorName.equalsIgnoreCase("Pursue Strategy")) {
							if (choiceValue.equalsIgnoreCase("Yes")) {
								reqdAccumulatorValue1 = "Yes";
							} else {
								break;
							}
						}
						checkValidAccumValues = choiceValue.equalsIgnoreCase(reqdAccumulatorValue1) ? true : false;
						registerAccumulatorValueStatus(checkValidAccumValues, reqdPlanOptionType,accumulatorName, reqdAccumulatorValue1,
								choiceValue);
					}
					break;

				case "Copayment":
					if (!reqdAccumulatorValue1.equalsIgnoreCase("NIL")
							|| !reqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
						String amountValue = ((Element) (accumulator.selectSingleNode("amount"))).getText();
						String modifiedAmountValue = amountValue.substring(0, amountValue.indexOf("."));
						if (!isAccumNumeric(reqdAccumulatorValue1) && !reqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
							String copayChoiceValue = ((Element) (accumulator.selectSingleNode("choiceValue")))
									.attributeValue("text");
							checkValidAccumValues = copayChoiceValue.equalsIgnoreCase(reqdAccumulatorValue1) ? true
									: false;
							registerAccumulatorValueStatus(checkValidAccumValues, reqdPlanOptionType,accumulatorName,
									reqdAccumulatorValue1, copayChoiceValue);
						}

						if (!reqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
							checkValidAccumValues = modifiedAmountValue
									.equalsIgnoreCase(reqdAccumulatorValue2.replaceAll("[$,]", "")) ? true : false;
							registerAccumulatorValueStatus(checkValidAccumValues, reqdPlanOptionType,accumulatorName,
									reqdAccumulatorValue2, modifiedAmountValue);
						}
					}
					break;

				case "Coinsurance":
					if (!reqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
						String percentValue = ((Element) (accumulator.selectSingleNode("percentage"))).getText();
						String modifiedPercentValue = percentValue.substring(0, percentValue.indexOf("."));
						checkValidAccumValues = modifiedPercentValue
								.equalsIgnoreCase(reqdAccumulatorValue1.replaceAll("[$,]", "")) ? true : false;
						registerAccumulatorValueStatus(checkValidAccumValues,reqdPlanOptionType, accumulatorName, reqdAccumulatorValue1,
								modifiedPercentValue);
					}
					break;

				case "Unit":
					if (!reqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
						String indivUnitsValue = ((Element) (accumulator.selectSingleNode("individualUnits")))
								.getText();
						String modifiedIndivUnitsValue = indivUnitsValue.substring(0, indivUnitsValue.indexOf("."));
						if (reqdAccumulatorValue1.equalsIgnoreCase("Unlimited")) {
							reqdAccumulatorValue1 = "-1";
						}
						checkValidAccumValues = modifiedIndivUnitsValue.equalsIgnoreCase(reqdAccumulatorValue1) ? true
								: false;
						registerAccumulatorValueStatus(checkValidAccumValues,reqdPlanOptionType, accumulatorName, reqdAccumulatorValue1,
								modifiedIndivUnitsValue);
					}
					if (!reqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
						String unitBenefitPeriod = ((Element) (accumulator.selectSingleNode("benefitPeriod")))
								.attributeValue("text");
						checkValidAccumValues = unitBenefitPeriod.equalsIgnoreCase(reqdAccumulatorValue2) ? true
								: false;
						registerAccumulatorValueStatus(checkValidAccumValues,reqdPlanOptionType, accumulatorName, reqdAccumulatorValue2,
								unitBenefitPeriod);
					}
					break;

				case "Dollar Limit":
					if (!reqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
						String dollarLimitValue = ((Element) (accumulator.selectSingleNode("individualMax"))).getText();
						String modifiedDollarLimitValue = dollarLimitValue.substring(0, dollarLimitValue.indexOf("."));
						checkValidAccumValues = modifiedDollarLimitValue
								.equalsIgnoreCase(reqdAccumulatorValue1.replaceAll("[$,]", "")) ? true : false;
						registerAccumulatorValueStatus(checkValidAccumValues, reqdPlanOptionType,accumulatorName, reqdAccumulatorValue1,
								modifiedDollarLimitValue);
					}
					if (!reqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
						String dollarBenefitPeriod = ((Element) (accumulator.selectSingleNode("benefitPeriod")))
								.attributeValue("text");
						checkValidAccumValues = dollarBenefitPeriod.equalsIgnoreCase(reqdAccumulatorValue2) ? true
								: false;
						registerAccumulatorValueStatus(checkValidAccumValues,reqdPlanOptionType, accumulatorName, reqdAccumulatorValue2,
								dollarBenefitPeriod);
					}
					break;

				case "Penalty":
					if (!reqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
						String penaltyPercentValue = ((Element) (accumulator.selectSingleNode("percentage"))).getText();
						String modifiedPenaltyPercentValue = penaltyPercentValue.substring(0,
								penaltyPercentValue.indexOf("."));
						checkValidAccumValues = modifiedPenaltyPercentValue.equalsIgnoreCase(reqdAccumulatorValue1)
								? true : false;
						registerAccumulatorValueStatus(checkValidAccumValues,reqdPlanOptionType, accumulatorName, reqdAccumulatorValue1,
								modifiedPenaltyPercentValue);
					}
					if (!reqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
						String indivMaxValue = ((Element) (accumulator.selectSingleNode("individualMax"))).getText();
						String modifiedIndivMaxValue = indivMaxValue.substring(0, indivMaxValue.indexOf("."));
						checkValidAccumValues = modifiedIndivMaxValue.equalsIgnoreCase(reqdAccumulatorValue2) ? true
								: false;
						registerAccumulatorValueStatus(checkValidAccumValues, reqdPlanOptionType,accumulatorName, reqdAccumulatorValue2,
								modifiedIndivMaxValue);
					}
					break;

				case "Deductible":
					if (!reqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
						String dedIndivMaxValue = ((Element) (accumulator.selectSingleNode("individualMax"))).getText();
						String modifiedDedIndivMaxValue = dedIndivMaxValue.substring(0, dedIndivMaxValue.indexOf("."));
						checkValidAccumValues = modifiedDedIndivMaxValue
								.equalsIgnoreCase(reqdAccumulatorValue1.replaceAll("[$,]", "")) ? true : false;
						registerAccumulatorValueStatus(checkValidAccumValues, reqdPlanOptionType,accumulatorName, reqdAccumulatorValue1,
								modifiedDedIndivMaxValue);
					}
					if (!reqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
						String dedBenefitPeriod = ((Element) (accumulator.selectSingleNode("benefitPeriod")))
								.attributeValue("text");
						checkValidAccumValues = dedBenefitPeriod.equalsIgnoreCase(reqdAccumulatorValue2) ? true : false;
						registerAccumulatorValueStatus(checkValidAccumValues,reqdPlanOptionType, accumulatorName, reqdAccumulatorValue2,
								dedBenefitPeriod);
					}
					break;

				case "Out of Pocket Maximum":
					if (!reqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
						String oOPMaxindivMaxValue = ((Element) (accumulator.selectSingleNode("individualMax")))
								.getText();
						String modifiedOOPMaxIndivMaxValue = oOPMaxindivMaxValue.substring(0,
								oOPMaxindivMaxValue.indexOf("."));
						checkValidAccumValues = modifiedOOPMaxIndivMaxValue
								.equalsIgnoreCase(reqdAccumulatorValue1.replaceAll("[$,]", "")) ? true : false;
						registerAccumulatorValueStatus(checkValidAccumValues,reqdPlanOptionType, accumulatorName, reqdAccumulatorValue1,
								modifiedOOPMaxIndivMaxValue);
					}
					if (!reqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
						String oopBenefitPeriod = ((Element) (accumulator.selectSingleNode("benefitPeriod")))
								.attributeValue("text");
						checkValidAccumValues = oopBenefitPeriod.equalsIgnoreCase(reqdAccumulatorValue2) ? true : false;
						registerAccumulatorValueStatus(checkValidAccumValues, reqdPlanOptionType,accumulatorName, reqdAccumulatorValue2,
								oopBenefitPeriod);
					}
					break;

				case "Copayment Maximum":
					if (!reqdAccumulatorValue1.equalsIgnoreCase("NIL")) {
						String copayMaxindivMaxValue = ((Element) (accumulator.selectSingleNode("individualMax")))
								.getText();
						String modifiedCopayMaxIndivMaxValue = copayMaxindivMaxValue.substring(0,
								copayMaxindivMaxValue.indexOf("."));
						checkValidAccumValues = modifiedCopayMaxIndivMaxValue
								.equalsIgnoreCase(reqdAccumulatorValue1.replaceAll("[$,]", "")) ? true : false;
						registerAccumulatorValueStatus(checkValidAccumValues,reqdPlanOptionType, accumulatorName, reqdAccumulatorValue1,
								modifiedCopayMaxIndivMaxValue);
					}
					if (!reqdAccumulatorValue2.equalsIgnoreCase("NIL")) {
						String copayMaxBenefitPeriod = ((Element) (accumulator.selectSingleNode("benefitPeriod")))
								.attributeValue("text");
						checkValidAccumValues = copayMaxBenefitPeriod.equalsIgnoreCase(reqdAccumulatorValue2) ? true
								: false;
						registerAccumulatorValueStatus(checkValidAccumValues, reqdPlanOptionType,accumulatorName, reqdAccumulatorValue2,
								copayMaxBenefitPeriod);
					}
					break;
				}
			}

		}

	}

	public void registerAccumulatorValueStatus(boolean accStatus, String planOptionTypeName, String accumulatorName, String expectedAccValue,
			String fetchedAccValue) {
		if (accStatus) {
			RESULT_STATUS = true;
			log(PASS, "Plan Option Type "+planOptionTypeName+" with Accumulator " + accumulatorName + " having Given value [" + expectedAccValue
					+ "] and Expected value [" + fetchedAccValue + "] are available in XML", "RESULT_STATUS=PASS");
		} else {

			RESULT_STATUS = false;
			log(FAIL,
					"Plan Option Type "+planOptionTypeName+" with Accumulator " + accumulatorName + " having Given value [" + expectedAccValue
							+ "] and Expected value [" + fetchedAccValue + "] are not available in XML",
					"RESULT_STATUS=FAIL");
		}
	}

	public static boolean isAccumNumeric(String str) {
		try {
			double d = Double.parseDouble(str);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}

}
