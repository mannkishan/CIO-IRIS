package page.benefitQuery;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import page.benefitQuery.FindOptionPage;
import page.benefitQuery.FindPlanPage;

import utility.CoreSuperHelper;

public class PlanOptionsDetailsPage extends CoreSuperHelper{
	
	private static PlanOptionsDetailsPage thisIsTestObj;
	public  synchronized static PlanOptionsDetailsPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), PlanOptionsDetailsPage.class);
		return thisIsTestObj;
		}
	
	@FindBy(how=How.ID,using="findPlanTab")
	public WebElement findPlanTab;
	
	@CacheLookup
	@FindBy(how=How.XPATH,using="//*[@id=\"find\"]")
	public WebElement searchPlan;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"find-plan-header\"]/div/div[1]/input")
	public WebElement planTextBox;
	
	@FindBy(how=How.XPATH,using="//a[@id=\"findContractTab\"]")
	public WebElement btnFindOption;
	
	@FindBy(how=How.XPATH,using="//div[@id=\"find-contract-header\"]//input[@name=\"contractCode\"]")
	public WebElement txtOption;
	
	
	@FindBy(how=How.XPATH,using="//div[@id=\"find-contract-header\"]//input[@id=\"find\"]")
	public WebElement btnOptionSearch;
	
	@FindBy(how=How.XPATH,using="//div[@id=\"content-find-contract\"]//div[@class=\"search\"]//tr[@class=\"rowlink odd\"]//td[@class=\"  sorting_1\"]")
	public WebElement lblContractCode;
	
	@FindBy(how=How.XPATH,using="//div[@id='content-find-contract']/div[@class='search']//tr//td[contains(text(),'Production') or contains(text(),'Archived')]")
	public WebElement lblOptionStatus;
	
	@FindBy(how=How.XPATH,using="//div[@id=\"content-find-contract\"]//div[@class=\"search\"]//tr[@class=\"rowlink odd\"]//td[@class=\"  sorting_1\"]//following::td[1]")
	public WebElement lblEffectiveDate;
	
	@FindBy(how=How.XPATH,using="//div[@id='content-find-plan']//div[@class='search']//tr//td[contains(text(),'Production') or contains(text(),'Archived') or contains(text(),'Pending Audit')]")
	public WebElement lblPlanStatus;
	
	@FindBy(how=How.XPATH,using="//div[@id='content-find-plan']//div[@class='search']//tr[@class='rowlink odd']//td[1]")
	public WebElement lblPlanID;
	
	/*Option Details starts here*/
	@FindBy(how=How.XPATH,using="//a[@class=\"contractDetailsLink\" and contains(text(),'Option Details')]")
	public WebElement btnOptionDetails;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"contractDetailsTitleMain\"]/div[1]/strong")
	public WebElement lblOptionDetailsOptionName;
	
	@FindBy(how=How.XPATH,using="//*[@id='contractDetailsTitleMain']/div[2]/strong")
	public WebElement lblOptionDetailsServiceDate;
	
	@FindBy(how=How.XPATH,using="//*[@id='contractDetailsTitleMain']/div[3]/strong")
	public WebElement lblOptionDetailsAsOfDate;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"contractDetailsTitleSecondLine\"]/div[2]/strong")
	public WebElement lblOptionDetailsEffectiveDate;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"contractDetailsTitleSecondLine\"]/div[1]/strong")
	public WebElement lblOptionDetailsOptionStatus;
	/*Option Details ends here*/
	
	/*Service Date begins here*/
	/*Service Date ends here*/
	
	/*As Of Date begins here*/
	@FindBy(how=How.XPATH,using="//*[@id='find-contract-header']/div/div[3]/div/img")
	public WebElement lblDatePicker;
	
	@FindBy(how=How.XPATH,using="//*[@id='ui-datepicker-div']/table/tbody/tr[4]/td[5]")
	public WebElement lblYear;	
	
	@FindBy(how=How.XPATH,using="//*[@id='ui-datepicker-div']/table/tbody/tr/td[@class=' ui-datepicker-days-cell-over  ui-datepicker-current-day ui-datepicker-today']/a")
	public WebElement txtAsOfDateDay;	
	
	@FindBy(how=How.XPATH,using="//*[@id='ui-datepicker-div']/table/tbody/tr/td[@class='  ui-datepicker-current-day']/a")
	public WebElement txtAsOfDateDayCurrentDay;
	
	@FindBy(how=How.XPATH,using="//*[@id='ui-datepicker-div']/div[2]/dl/dd[1]")
	public WebElement txtAsOfDateTime;	
	
	@FindBy(how=How.XPATH,using="//*[@id='dp1509009055262']")
	public WebElement txtServiceDate;
		
	@FindBy(how=How.XPATH,using="//div[@class='modal-header clearfix']/button[@class='close']")
	public WebElement txtErrorAlertClose;
	
	public String findOptionAsOfDateYear()
	{	
		String strDay=seIsPlanBenefitOptionEnabled(txtAsOfDateDay,"Today")?seGetText(txtAsOfDateDay):seGetText(txtAsOfDateDayCurrentDay);
		strDay=(strDay.length()<2)?"0"+strDay:strDay;		
		String strMonth =String.valueOf((Integer.parseInt(
				getWebDriver().findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[4]/td[5]"))
						.getAttribute("data-month").toString().trim()))
				+ 1);		
		String strYear = getWebDriver().findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[4]/td[5]")).getAttribute("data-year").toString().trim();		
		String strTime = seGetText(txtAsOfDateTime);
		String strServiceDate = strMonth + "/" + strDay + "/" + strYear;
		String strAsOfDate = strMonth + "/" + strDay + "/" + strYear + " " + strTime + ":00";		
		return strAsOfDate;
	}
	
	/*As Of Date ends here*/
	
	/*Terminated Contract condition starts here*/	
	@FindBy(how=How.XPATH,using="//*[@id='content-find-contract']/div[@class='search']/h3[contains(text(),'No options meet the entered criteria')]")
	public WebElement lblOptionTerminated;
	
	/*Terminated Contract condition ends here*/
	
	/*Plan Available or not condition starts here*/	
	@FindBy(how=How.XPATH,using="//*[@id='content-find-plan']/div[@class='search']/h3[contains(text(),'No plans meet the entered criteria')]")
	public WebElement lblPlanUnavailable;
	
	/*Plan Available or not condition ends here*/
	public String findOptionsServiceDate()
	{
		String strDay=seIsPlanBenefitOptionEnabled(txtAsOfDateDay,"Today")?seGetText(txtAsOfDateDay):seGetText(txtAsOfDateDayCurrentDay);
	strDay=(strDay.length()<2)?"0"+strDay:strDay;
	String strMonth =String.valueOf((Integer.parseInt(
			getWebDriver().findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[4]/td[5]"))
					.getAttribute("data-month").toString().trim()))
			+ 1);	
	String strYear = getWebDriver().findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[4]/td[5]")).getAttribute("data-year").toString().trim();	
	String strServiceDate = strMonth + "/" + strDay + "/" + strYear;	
		return strServiceDate;
	}
	
	public void seContractExists(String strContractId, String strServiceDate) {
		/* Finding if a contract exists */
		try {
			String strIsContractUnAvailable = "No options";
			seClick(PlanOptionsDetailsPage.get().btnFindOption, "Find Option");
			seWaitForPageLoad(10);
			seSetText(PlanOptionsDetailsPage.get().txtOption, strContractId);	
			seClick(PlanOptionsDetailsPage.get().lblDatePicker, "Calendar");
			if (strServiceDate.equalsIgnoreCase("")) {
				strServiceDate = PlanOptionsDetailsPage.get().findOptionsServiceDate();
			} else {
				seSetText(FindOptionPage.get().serviceDate, strServiceDate);
			}
			String strAsOfDate = PlanOptionsDetailsPage.get().findOptionAsOfDateYear();
			seClick(PlanOptionsDetailsPage.get().btnOptionSearch, "Search Contract");
			waitForPageLoad();
			String strContractCode = seGetText(PlanOptionsDetailsPage.get().lblContractCode);
			String strContractStatus = seGetText(PlanOptionsDetailsPage.get().lblOptionStatus);
			String strEffectiveDate = seGetText((PlanOptionsDetailsPage.get().lblEffectiveDate));
			
			/* Verify if Plan is in Production */
			seVerifyFieldValue(PlanOptionsDetailsPage.get().lblOptionStatus, strContractStatus, "Status");

			if (strContractStatus.equalsIgnoreCase("Production") || strContractStatus.equalsIgnoreCase("Archived")) {
				log(PASS, "Plan [" + strContractId + "] in [" + strContractStatus + "] status");
				seClick(PlanOptionsDetailsPage.get().lblOptionStatus, "Contract Details");
				//waitForPageLoad(20);								
				/* Option Details Starts here */
				
						if(seIsPlanBenefitOptionEnabled(txtErrorAlertClose, "Alert"))
						{
							seClick(PlanOptionsDetailsPage.get().txtErrorAlertClose, "Alert");
						}					
					//seWaitForClickableWebElement(PlanOptionsDetailsPage.get().btnOptionDetails, 50);
					seClick(PlanOptionsDetailsPage.get().btnOptionDetails, "Option Details");
					seVerifyFieldValue(PlanOptionsDetailsPage.get().lblOptionDetailsOptionName, strContractCode,
							"Contract Code");					
					seVerifyFieldValue(PlanOptionsDetailsPage.get().lblOptionDetailsServiceDate, strServiceDate,
							"Service Date");					
					seVerifyFieldValue(PlanOptionsDetailsPage.get().lblOptionDetailsAsOfDate, strAsOfDate,
							"As Of Date");
					seVerifyFieldValue(PlanOptionsDetailsPage.get().lblOptionDetailsOptionStatus, strContractStatus,
							"Contract Status");
					seVerifyFieldValue(PlanOptionsDetailsPage.get().lblOptionDetailsEffectiveDate, strEffectiveDate,
							"Effective Date");

			} else if (seIsElementEnabled(PlanOptionsDetailsPage.get().lblOptionTerminated, "Terminated")) {
				
				log(PASS, "Plan [" + strContractId + "] unavailable in BQA");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void sePlanExistsInBQA(String strPlanId, String PlanServiceDate) {

		try {
			seClick(PlanOptionsDetailsPage.get().findPlanTab, "click Find plan Tab");
			if(strPlanId.equalsIgnoreCase(""))
			{
				log(INFO, "Plan ID not provided");
			}
			else
			{
				seSetText(PlanOptionsDetailsPage.get().planTextBox, strPlanId, "Enter Plan ID");	
			}
						
			if (!PlanServiceDate.equalsIgnoreCase("")) {
				seSetText(FindPlanPage.get().serviceDate, PlanServiceDate);
			}
			seClick(PlanOptionsDetailsPage.get().searchPlan, " Search Button");
			waitForPageLoad();
			/* Finding if a Plan exists */
			String displayedPlanID=seGetText(PlanOptionsDetailsPage.get().lblPlanID);
			String strPlanStatus = seGetText(PlanOptionsDetailsPage.get().lblPlanStatus);
			if (displayedPlanID.equalsIgnoreCase(strPlanId)&&(strPlanStatus.equalsIgnoreCase("Pending Audit")||strPlanStatus.equalsIgnoreCase("Production") || strPlanStatus.equalsIgnoreCase("Archived"))) 
				{
					seVerifyFieldValue(PlanOptionsDetailsPage.get().lblPlanID, strPlanId, "Plan ID");
					seVerifyFieldValue(PlanOptionsDetailsPage.get().lblPlanStatus, strPlanStatus, "Plan Status");
					log(PASS, "Plan [" + strPlanId + "] in [" + strPlanStatus + "] status");
				} else if(seIsPlanBenefitOptionEnabled(PlanOptionsDetailsPage.get().lblPlanUnavailable, "Plan ")){				
					log(FAIL, "Plan [" + strPlanId + "] unavailable in BQA");
				}			
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

public static boolean seIsPlanBenefitOptionEnabled(WebElement testObject, String strElementName) {
		
		boolean seIsElementEnabled = false;
		
		try {

			if (testObject.isDisplayed()) {				
				seIsElementEnabled = true;				
			} 
		} catch (Exception e) {
			log(INFO, "Plan ID isn't available");
			
		}
		
		return seIsElementEnabled;
	}

}
