package page.benefitQuery;



import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class FindPlanPage extends CoreSuperHelper{
	
	private static FindPlanPage thisIsTestObj;
	public  synchronized static FindPlanPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), FindPlanPage.class);
		return thisIsTestObj;
		}
	@FindBy(how=How.ID,using="findPlanTab")
	public WebElement findPlanTab;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"find-plan-header\"]/div/div[1]/input")
	public WebElement planTextBox;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"find-contract-header\"]/div/div[1]/input")
	public WebElement contractTextBox;
	
	@CacheLookup
	@FindBy(how=How.XPATH,using="//*[@id=\"find\"]")
	public WebElement searchPlan;
	
	@FindBy(how=How.NAME,using="effDateTo")
	public WebElement serviceDate;
	
	@FindBy(how=How.NAME,using="createDateTo")
	public WebElement asOfDate;
	
	
	@CacheLookup
	@FindBy(how=How.XPATH,using="//div[@id='content-find-plan']/div/div[@class='dataTables_wrapper']/table/tbody/tr")
	public WebElement searchTable;

	@FindBy(how=How.XPATH,using="//a[contains(@title,'Logout')]/i")
	public WebElement logOut;

	
	public void comparebool(Boolean var1, Boolean var2) {
		   
		if(var1 == var2)
		{
			log(PASS, "Benefit values and Out of pocket maximum values are displayed correctly","Values of PC and BQA are as expected,RESULT=PASS");
			
			
		}
		else
		{
			log(FAIL, "there is a mismatch in benefit values and Out of pocket maximum","Values of PC and BQA are NOT as expected,RESULT=FAIL");
			
			
		}
}}
