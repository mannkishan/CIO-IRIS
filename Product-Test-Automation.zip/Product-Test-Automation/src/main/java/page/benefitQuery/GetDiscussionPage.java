package page.benefitQuery;


import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.HashMap;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class GetDiscussionPage extends CoreSuperHelper{
	
	private static GetDiscussionPage thisIsTestObj;
	public  synchronized static GetDiscussionPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), GetDiscussionPage.class);
		return thisIsTestObj;
		}
	@FindBy(how=How.NAME,using="USER")
	public WebElement userNameField;
	@CacheLookup
	@FindBy(how=How.NAME,using="PASSWORD")
	public WebElement passwordField;
	
	@FindBy(how=How.XPATH,using="//input[@type='submit']")//input[@type='SUBMIT']
	@CacheLookup
	public WebElement submitButton;

	public void loginApplication(String userProfile){
		String[] userInfo = getLoginInfo(userProfile);
		setUserName(userInfo[0],"UserName");
		setPassword(userInfo[1]);
		clickSubmit();
	}
	
	public void seEnter()
	{
		try{
			String strContractID = getCellValue("ContractID");
			String strDate = getCellValue("Date");
			String strDiscussionID = getCellValue("Id");
			
			//Enter contract ID
			WebElement objContractID = getWebDriver().findElement(By.xpath("//*[@id='ContractID']"));
			//seClick(objContractID, "To Enter Value in Contract ID Field");
			objContractID.click();
			objContractID.sendKeys(strContractID);
			log( PASS , "Entered Contract ID : "+strContractID);
			//Enter Effective date
			WebElement objEffctiveDate = getWebDriver().findElement(By.xpath("//*[@id='EffectiveDate']"));
			seClick(objEffctiveDate, "To Enter Value in EffectiveDate Field");
			//objEffctiveDate.click();
			objEffctiveDate.sendKeys(strDate);
			log( PASS , "Entered Effective Date : "+strDate);
			//Enter discussion ID
			WebElement objDiscussionId = getWebDriver().findElement(By.xpath("//*[@id='DiscussionId']"));
			seClick(objDiscussionId, "To Enter Value in DiscussionID Field");
			//objDiscussionId.click();
			objDiscussionId.sendKeys(strDiscussionID);
			log( PASS , "Entered Discussion ID : "+strDiscussionID);
			//Enter environment
			waitForPageLoad();
			WebElement objEnv = getWebDriver().findElement(By.xpath("//*[@id='Env'][@value='UAT-New']"));
			((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objEnv);
			log( PASS , "Click on Environment : UAT New");
			waitForPageLoad();
			
			//login button
			
			System.out.println("going to Click on login ");waitForPageLoad();
			WebElement objLogin = getWebDriver().findElement(By.xpath("//input[@type='SUBMIT']"));waitForPageLoad();
			
			//((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objLogin);
			//seClick(objLogin, "");
			try{
			objLogin.click();waitForPageLoad();
			//System.out.println("clicked on login ");waitForPageLoad();
			} catch (Exception e){objLogin.click();}
			/*Alert alert = driver.switchTo().alert();
	        String strAlertText = alert.getText();
	        System.out.println(strAlertText);
	        alert.dismiss();*/
			log( PASS , "Click on Login Button");
			/*System.out.println("alert");
			Alert alert = driver.switchTo().alert();
			System.out.println("dismiss");
			waitForPageLoad();
	        alert.dismiss();

			for (String handle : driver.getWindowHandles()) {
 
			driver.switchTo().window(handle);
			driver.close();}
			
			Robot object1=new Robot();
			object1.keyPress(KeyEvent.VK_ENTER);*/
			
			
	        waitForPageLoad();
	        
			
		}catch (Exception e){
		System.out.println("Exception while executing seEnter");	
		}
	}
	
	
	
	
public void seUIActions()
{
	try{
		
		//Navigate to benefit Acupuncture and click on Benefit and Click on cost shares and UM rule for Precert on BQA screen
		waitForPageLoad(45);
		
		
		driver.findElement(By.xpath("//span[@class='benefitShortText'][contains(text(),'Acupuncture')]")).click();
		waitForPageLoad(20);
		log( PASS , "Click on Benefit : Acupuncture");
		waitForPageLoad();
		WebElement objElementAcupunctureone = driver.findElement(By.xpath("//table[@acronymid='Acupuncture:Participating:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='In Network Deductible - Individual']"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objElementAcupunctureone);
		log( PASS , "Click on cost shares : In Network Deductible - Individual");
		WebElement objElementAcupunctureTwo= driver.findElement(By.xpath("//*[@id='benefitModal']/div[1]/button/i"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objElementAcupunctureTwo);
		log( PASS , "Validated - Navigation to benefit Acupuncture and click on Benefit and Click on cost shares");
		
		
		//UM rule Acupuncture for Precert on BQA screen
		waitForPageLoad();
		WebElement objUMruleAcupunctureone = driver.findElement(By.xpath("//div[@hierarchy='Acupuncture']/a/img[@class='ribbon preCert']"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objUMruleAcupunctureone);
		log( PASS , "Click on UMRule : Acupuncture");
		WebElement objUMruleIDAcupuncture = driver.findElement(By.xpath("//td[@class='umRuleId ']"));
		String strUMRuleIDAcupuncture = objUMruleIDAcupuncture.getText();
		System.out.println(strUMRuleIDAcupuncture);
		waitForPageLoad();
		setCellValue("UMRuleIDAcupuncture", strUMRuleIDAcupuncture);
		
		WebElement objUMruleAcupunctureClick = driver.findElement(By.xpath("//td[@class='umRuleId ']/following::td[1]"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objUMruleAcupunctureClick);waitForPageLoad();
		log( PASS , "Click on UMRule Acupuncture for percert : AIMSLEEP");
		WebElement objUMruleClose = driver.findElement(By.xpath("//button[@class='close closeModal']"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objUMruleClose);waitForPageLoad();
		log( PASS , "Validated - Navigation to benefit Acupuncture and click on UM rule for Precert on BQA screen");
		
		//Navigate to benefit Ambulance  and click on Benefit and Click on cost shares
		waitForPageLoad(45);
		driver.findElement(By.xpath("//span[@class='benefitShortText'][contains(text(),'Ambulance')]")).click();
		waitForPageLoad(20);
		log( PASS , "Click on Benefit : Ambulance");
		waitForPageLoad();
		WebElement objElementAmbulanceone = driver.findElement(By.xpath("//table[@acronymid='Ambulance:Participating:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='In Network Deductible - Individual']"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objElementAmbulanceone);
		log( PASS , "Click on cost shares : In Network Deductible - Individual");
		WebElement objElementAmbulanceTwo= driver.findElement(By.xpath("//*[@id='benefitModal']/div[1]/button/i"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objElementAmbulanceTwo);
		
		log( PASS , "Validated - Navigation to benefit Ambulance  and click on Benefit and Click on cost shares");
	 
	    //UM rule Ambulance for Precert on BQA screen
		waitForPageLoad();
		WebElement objUMruleAmbulanceone = driver.findElement(By.xpath("//div[@hierarchy='Ambulance']/a/img[@class='ribbon preCert']"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objUMruleAmbulanceone);
		log( PASS , "Click on UMRule for Ambulance");
		WebElement objUMruleIDAmbulance = driver.findElement(By.xpath("//td[@class='umRuleId ']/a[text()='INPAT001']"));
		String strUMRuleIDAmbulance = objUMruleIDAmbulance.getText();
		System.out.println(strUMRuleIDAmbulance);
		waitForPageLoad();
		setCellValue("UMRuleIDAmbulance", strUMRuleIDAmbulance);waitForPageLoad();
		
		WebElement objUMruleAmbulanceClick = driver.findElement(By.xpath("//td[@class='umRuleId ']/a[text()='INPAT001']/following::td[1]"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objUMruleAmbulanceClick);waitForPageLoad();
		log( PASS , "Click on UMRule Acupuncture for percert : INPAT001");
		
		WebElement objUMruleCloseOne = driver.findElement(By.xpath("//button[@class='close closeModal']"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objUMruleCloseOne);waitForPageLoad();
		log( PASS , "Validated - Navigation to benefit Ambulance and click on UM rule for Precert on BQA screen");
		
		//Verify Get Discussion display Benefit details /cost shares and UMRules when we select Child Benefit first and 
		//then select Parent benefit in CCB BQA screen
        //Child Benefit 
		//click on Emergency Room Ancillary
		WebElement objEmergencyRoomAncillary = driver.findElement(By.xpath("//span[@class='benefitShortText'][text()='Emergency Room Ancillary']"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objEmergencyRoomAncillary);waitForPageLoad();
		log( PASS , "Click on Child benefit 'Emergency Room Ancillary'");
		
		//click on Emergency Room Ancillary benefit//close the popup
		WebElement objEmergencyRoomAncillaryBenefit = driver.findElement(By.xpath("//table[@acronymid='EmergencyRoomCareEmergencyRoomEmergencyRoomAncillary:Participating:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='In Network Deductible - Individual']"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objEmergencyRoomAncillaryBenefit);waitForPageLoad();
		log( PASS , "Click on Child benefit 'Emergency Room Ancillary' benefit");
		
		WebElement objEmergencyRoomAncillaryClose = driver.findElement(By.xpath("//*[@id='benefitModal']/div[1]/button/i"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objEmergencyRoomAncillaryClose);waitForPageLoad();
		
		
		//click on Emergency Room Ancillary um rule//close the popup
		WebElement objUMruleEmerAnclryone = driver.findElement(By.xpath("//div[@hierarchy='EmerRoomCare,EmerRoom,EmerRoomAncillary']/a/img[@class='ribbon preCert']"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objUMruleEmerAnclryone);
		log( PASS , "Click on Child benefit 'Emergency Room Ancillary' UM rule");
		WebElement objUMruleIDEmerAnclry = driver.findElement(By.xpath("//td[@class='umRuleId ']/a[text()='ANABNMR']"));
		String strUMRuleIDEmerAnclry = objUMruleIDEmerAnclry.getText();
		System.out.println(strUMRuleIDEmerAnclry);
		waitForPageLoad();
		setCellValue("UMRuleIDEmerAnclry", strUMRuleIDEmerAnclry);waitForPageLoad();
		
		WebElement objUMruleEmerAnclryClick = driver.findElement(By.xpath("//td[@class='umRuleId ']/a[text()='ANABNMR']/following::td[1]"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objUMruleEmerAnclryClick);waitForPageLoad();
		log( PASS , "Click on Child benefit 'Emergency Room Ancillary'UM rule Percert : ANABNMR");
		WebElement objUMruleCloseEmerAnclry = driver.findElement(By.xpath("//button[@class='close closeModal']"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objUMruleCloseEmerAnclry);waitForPageLoad();
		
		
		//click on Emergency Room
		WebElement objEmergencyRoom = driver.findElement(By.xpath("//span[@class='benefitShortText'][text()='Emergency Room']"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objEmergencyRoom);waitForPageLoad();
		log( PASS , "Click on Child benefit 'Emergency Room'");
		//click on Emergency Room benefit //close popup
		WebElement objEmergencyRoomBenefit = driver.findElement(By.xpath("//table[@acronymid='EmergencyRoomCareEmergencyRoom:Participating:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='In Network Emergency Room Copay']"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objEmergencyRoomBenefit);waitForPageLoad();
		log( PASS , "Click on Child benefit 'Emergency Room' benefit");
		WebElement objEmergencyRoomClose = driver.findElement(By.xpath("//*[@id='benefitModal']/div[1]/button/i"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objEmergencyRoomClose);waitForPageLoad();

		
		
		//click on Emergency Room um rule //close popup
		
		WebElement objUMruleEmerone = driver.findElement(By.xpath("//div[@hierarchy='EmerRoomCare,EmerRoom']/a/img[@class='ribbon preCert']"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objUMruleEmerone);
		log( PASS , "Click on Child benefit 'Emergency Room' Um rule");
		WebElement objUMruleIDEmer = driver.findElement(By.xpath("//td[@class='umRuleId ']/a[text()='AIMENCARD']"));
		String strUMRuleIDEmer = objUMruleIDEmer.getText();
		System.out.println(strUMRuleIDEmer);
		waitForPageLoad();
		setCellValue("UMRuleIDEmergencyRoom", strUMRuleIDEmer);waitForPageLoad();
		
		WebElement objUMruleEmerClick = driver.findElement(By.xpath("//td[@class='umRuleId ']/a[text()='AIMENCARD']/following::td[1]"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objUMruleEmerClick);waitForPageLoad();
		log( PASS , "Click on Child benefit 'Emergency Room' UM rule percert : AIMENCARD");
		WebElement objUMruleCloseEmer = driver.findElement(By.xpath("//button[@class='close closeModal']"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objUMruleCloseEmer);waitForPageLoad();
		
	    }catch (Exception e){
		System.out.println("Exception while executing seUI Actions");	
		}
}



public String getResponseWithDiscussionID(String strDiscussionID)
{ 
	String xmlInput="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:def=\"http://definition.webservices.app.health.ipl.fja.com\">"
	        +"<soapenv:Header/>\n"
			+"<soapenv:Body>\n"
			+"<def:getDiscussion>\n"
			+"<discussionID>"+strDiscussionID+"</discussionID>\n"
			+"</def:getDiscussion>\n"
			+"</soapenv:Body>\n"
			+"</soapenv:Envelope>";		

	  return xmlInput;
}

public void seValidatePlanIDandStatus(String strPlnID, String strStatus){
	try{
		waitForPageLoad(10);
		WebElement objPlanOptionsButton = getWebDriver().findElement(By.xpath("//ul[@id='plan-menu']/li/a[text()='Plan Options']"));
		//seClick(objPlanOptionsButton, "Plan Options");
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objPlanOptionsButton);
		log( PASS , "Click on Medical >Plan Options Button");
		WebElement objExpand = getWebDriver().findElement(By.xpath("//a[@data-parent='#plan-header']/i"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objExpand);
		log( PASS , "Click to Expand");
		
		WebElement objPlanID = getWebDriver().findElement(By.xpath("//ul[@class='plan-header-pane']/li[text()='Plan ID:']/strong"));waitForPageLoad(10);
		String strPlanIDText = objPlanID.getText().trim();
		log( PASS , "Get PlanID Associated with the Contract: "+strPlanIDText);
		System.out.println(strPlanIDText);
		
		WebElement objPlanStatus = getWebDriver().findElement(By.xpath("//ul[@class='plan-header-pane3']/li[text()='Status:']/strong"));waitForPageLoad(10);
		String strPlanIDStatus = objPlanStatus.getText().trim();
		log( PASS , "Get PlanID Status  Associated with the Contract: "+strPlanIDStatus);
		System.out.println(strPlanIDStatus);
		
		seCompareStrings(strPlnID, strPlanIDText, "=", "Verified that system returns the Contracts with the associated Plan version");
		waitForPageLoad();
		
		seCompareStrings(strStatus, strPlanIDStatus, "=", "Verify that system returns the Contracts with the associated Plan version in status of Production");
		waitForPageLoad();
		log( PASS , "Compared and verified that system returns the Contracts with the associated Plan version in status of Production ");
		WebElement objCollapse = getWebDriver().findElement(By.xpath("//a[@data-parent='#plan-header']/i"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objCollapse);
		log( PASS , "Click to Collapse");waitForPageLoad();
		
		
		//ul[@id='plan-menu']/li/a[text()='Benefits']
		WebElement objBenefitsButton = getWebDriver().findElement(By.xpath("//ul[@id='plan-menu']/li/a[text()='Benefits']"));
		//seClick(objPlanOptionsButton, "Plan Options");
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",objBenefitsButton);
		log( PASS , "Click on Medical >Benefits Button");
		
		
		
		
		
		
		
		
	}catch (Exception e){
		System.out.println("Exception while executing seValidatePlanIDandStatus");	
		}
	
}




	
	
	
	
	public void setUserName(String userId,String UserID){
		seSetUserId(userNameField, userId,"UserName");
	}
	
	public void setPassword(String pwd){
		seSetPassword(passwordField, pwd,"Password");
	}
	
	public void clickSubmit(){
		seClick(submitButton, "Submit");
	}
}