package page.benefitQuery;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Paths;
import java.util.List;
import java.io.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.util.Iterator;
import org.xml.sax.*;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class GetDiscussionXMLPage extends CoreSuperHelper{
	
	private static GetDiscussionXMLPage thisIsTestObj;
	public  synchronized static GetDiscussionXMLPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), GetDiscussionXMLPage.class);
		return thisIsTestObj;
		}	
	
	
	
	/*Acupuncture starts here*/
	@FindBy(how = How.XPATH, using = "//div/a[@data-id='/benefits/Acupuncture/benefitLevel/Acupuncture']/span[contains(text(),'Acupuncture')]")
	public WebElement lblAcupuncture_Benefits;
	
	@FindBy(how = How.XPATH, using = "//table[@acronymid='Acupuncture:Participating:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='In Network Deductible - Individual']")
	public WebElement lblAcupuncture_Benefits_INNDeductibleIndiv;
	
	/*Acupuncture ends here*/
	
	/*Ambulance starts here*/
	@FindBy(how = How.XPATH, using = "//div/a[@data-id='/benefits/Ambulance/benefitLevel/Ambulance']/span[contains(text(),'Ambulance')]")
	public WebElement lblAmbulance_Benefits;		
	
	@FindBy(how = How.XPATH, using = "//table[@acronymid='Ambulance:Participating:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='In Network Deductible - Individual']")
	public WebElement lblAmbulance_Benefits_INNDeductibleIndiv;
	
	/*Ambulance ends here*/
	
	/*DME--->Lease/Rental starts here*/
	@FindBy(how = How.XPATH, using = "//div/a[@data-id='/benefits/LeaseRental/benefitLevel/DurableMedEquip,LeaseRental']/span[contains(text(),'Lease / Rental')]")
	public WebElement lblDME_LeaseRental_Benefits;
	
	@FindBy(how = How.XPATH, using = "//table[@acronymid='DurableMedicalEquipmentLease/Rental:Participating:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='In Network Deductible - Individual']")
	public WebElement lblDME_LeaseRental_Benefits_INNDeductibleIndiv;
	
	@FindBy(how = How.XPATH, using = "//div[@hierarchy='DurableMedEquip,LeaseRental']/a/img")
	public WebElement lblDME_LeaseRental_UMRules;
	
	@FindBy(how = How.XPATH, using = "//div[@class='modal-body umRulesSummaryModalBody']//table/tbody/tr/td[contains(text(),'SLEEP STUDY CODES MANAGED BY AIM')]")
	public WebElement lblDME_LeaseRental_UMRules_AIMSLEEP;
	
	
	/*DME--->Lease/Rental ends here*/
		
	/*UM Rules starts here*/
	@FindBy(how = How.XPATH, using = "//a[@href='#tabIdUMRules0' and contains(text(),'UM Rules')]")
	public WebElement lblUMRules;
	
	@FindBy(how = How.XPATH, using = "//div[@id='um-rules']//div/table/tbody/tr/td[contains(text(),'SCRCALIST - RULES FOR CODES THAT REQUIRE PRECERT')]")
	public WebElement lblUMRules_PreCert;
	
	
	/*UM Rules ends here*/
	
	/* Deductible:Deductible starts here */

	@FindBy(how = How.XPATH, using = "//*[@acronymid='Deductible:Deductible']/div//a[@class='accordion-toggle' and contains(text(),'Deductible:Deductible')]")
	public WebElement lblDeductible;

	@FindBy(how = How.XPATH, using = "//*[@acronymid='Deductible:Deductible']/div//div/table/tbody/tr[@data-id='INNDedIndiv']/td[1]")
	public WebElement lblINNIndDeductible;

	/* Deductible:Deductible ends here */	

	/*Ambulance Trip Max starts here*/
	
	@FindBy(how = How.XPATH, using = "//*[@acronymid='AmbulanceTripMax:AmbulanceTripMaxOON']/div//a[@class='accordion-toggle' and contains(text(),'Ambulance Trip Max:Ambulance Trip Maximum Out of Network')]")
	public WebElement lblAmbulanceTripMax;
	
	@FindBy(how = How.XPATH, using = "//*[@acronymid='AmbulanceTripMax:AmbulanceTripMaxOON']/div//div/table/tbody/tr[@data-id='OONAmbulanceTripMaxDlrLmt']/td[1]")
	public WebElement lblAmbulanceTripMax_OONAmbulanceTripMaxDollarLimit;
	
	/*Ambulance Trip Max ends here*/
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'benefitFooterButtons')]//a[contains(text(),'Benefit Script')]")
	public WebElement lblBenefitScripts;
	
	@FindBy(how = How.XPATH, using = "//div[@class='modal-header']//button[@class='close closeModal']//i[@class='icon-black icon-remove-sign']")
	public WebElement lblCloseBenefits_BenefitScripts;		

	public String getResponseWithDiscussionID(String strDiscussionID)
	{ 
		String xmlInput="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:def=\"http://definition.webservices.app.health.ipl.fja.com\">"
		        +"<soapenv:Header/>\n"
				+"<soapenv:Body>\n"
				+"<def:getDiscussion>\n"
				+"<discussionID>"+strDiscussionID+"</discussionID>\n"
				+"</def:getDiscussion>\n"
				+"</soapenv:Body>\n"
				+"</soapenv:Envelope>";		

		  return xmlInput;
	} 	
	public void getDiscussionViewBenefitXMLDetails(String strXMLFile)
	{
		try {
			File inputFile = new File(strXMLFile);
	        SAXReader reader = new SAXReader();
	        Document document = reader.read(inputFile);	       
	        String strBenefitLevelCheck=getCellValue("PlanBenefit1");
	        List<Node> nodesPlanBenefit = document.selectNodes("//planBenefit[@benefitLevel='"+strBenefitLevelCheck+"']/situationGroups/situationGroup/situations/situation/calculations/calculation/calcSteps/calcStep");
	        for (Node node : nodesPlanBenefit) {
	            String strAccumName=node.valueOf("@accumName");	            
	            if(!strAccumName.equalsIgnoreCase(""))
	            {
	            	log(PASS,"Plan Benefit ["+strBenefitLevelCheck+"] has Accumulator ["+strAccumName+"]");
	            }
	            else
	            {
	            	log(FAIL,"Plan Benefit ["+strBenefitLevelCheck+"] has no Accumulator");
	            }
	                 		
	        }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void getDiscussionViewBenefitXMLDetailsQuoted(String strXMLFile)
	{
		try
		{
			File inputFile = new File(strXMLFile);
	        SAXReader reader = new SAXReader();
	        Document document = reader.read(inputFile);
		
	        for(int i=1;i<4;i++)
	        {
	        String strBenefitLevelCheck=getCellValue("PlanBenefit"+i);
	        String strCalcAccumName=getCellValue("PlanBenefit"+i+"Value1");
	        List<Node> nodesPlanBenefit = document.selectNodes("//planBenefit[@benefitLevel='"+strBenefitLevelCheck+"']/situationGroups/situationGroup/situations/situation/calculations/calculation/calcSteps/calcStep");	         
	         for (Node node : nodesPlanBenefit) {		            
		            String strBenefitLevel=node.valueOf("@benefitLevel");
		            String strAccumName=node.valueOf("@accumName");
		            String quotedValue=node.valueOf("@quoted");
		            
		            	if(strCalcAccumName.equalsIgnoreCase(strAccumName))
		            	{
		            		if(!quotedValue.equalsIgnoreCase(""))
				            {	            				
		            					log(PASS, "Quoted Value for Benefit Level ["+strBenefitLevelCheck+"] having Accumulator ["+strAccumName+"] is "+node.valueOf("@quoted"));
				            }            		
		            			
		            		else
		            		{		            			
		            			log(FAIL, "Quoted Value for Benefit Level ["+strBenefitLevelCheck+"] having Accumulator ["+strAccumName+"] is Unavailable");
		            		}  
		            	}	
	         	}
	        }
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public void getDiscussionViewUMRulesXMLDetails(String strXMLFile)
	{
		try
		{
			File inputFile = new File(strXMLFile);
	        SAXReader reader = new SAXReader();
	        Document document = reader.read(inputFile);
	       
	        for(int i=1;i<5;i++)
	        {
	        String strBenefitLevelCheck=getCellValue("UMRulePlanBenefit"+i);
	        String strUMRuleCheck=getCellValue("UMRulePlanBenefit"+i+"Value1");
	        int intUMFlag=0;
	        List<Node> nodesUMRules = document.selectNodes("//planBenefit[@benefitLevel='"+strBenefitLevelCheck+"']/umrule");
	        for (Node node : nodesUMRules) {
	        	String strUMRule=node.valueOf("@id");
	        	String quotedValue=node.valueOf("@quoted");
	        	if(strUMRule.equalsIgnoreCase(strUMRuleCheck))
	        	{
	        		if(!quotedValue.equalsIgnoreCase(""))
		            {	        			
    					log(PASS, "Quoted Value for Benefit Level ["+strBenefitLevelCheck+"] having UM Rule ["+strUMRule+"] is "+node.valueOf("@quoted"));
    					intUMFlag++;
		            }
	        		
	        	}	        
	        }
	        if(intUMFlag==0)
    		{    			
				log(FAIL, "Quoted Value for Benefit Level ["+strBenefitLevelCheck+"] having UM Rule ["+strUMRuleCheck+"] is unavailable");
    		}
        	
	        }
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public void getDiscussionViewBenefitScriptDetails(String strXMLFile)
	{
		try {
			
			File inputFile = new File(strXMLFile);
	        SAXReader reader = new SAXReader();
	        Document document = reader.read(inputFile);	        
	        String strBenefitLevelCheck=getCellValue("BenefitTextDisplay");
	        List<Node> nodesBenefitDetails = document.selectNodes("//planBenefit[@benefitLevel='"+strBenefitLevelCheck+"']/benefitTexts/BenefitText");
	        for (Node node : nodesBenefitDetails) {
	        	String strBenefitDetails=node.selectSingleNode("text").getText();
	        	if(!strBenefitDetails.equalsIgnoreCase(""))
	        	{
	        		log(PASS, "Benefit Script Details available for Benefit Level ["+strBenefitLevelCheck+"]");
	        	}
	        	else
	        	{
	        		log(FAIL, "Benefit Script Details Unavailable for Benefit Level ["+strBenefitLevelCheck+"]");
	        	}
	        }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void getDiscussionViewPlanOptionsAccumulatorQuoted(String strXMLFile)
	{
		try {
			File inputFile = new File(strXMLFile);
	        SAXReader reader = new SAXReader();
	        Document document = reader.read(inputFile);	       
	        for(int i=1;i<2;i++)
	        {
	        	String strPlanOptionName=getCellValue("PlanOptionName"+i);
	        	String strAccNameCheck=getCellValue("PlanOptionName"+i+"Acc1");
	        		List<Node> nodesPlanOptionsAccumulator = document.selectNodes("//planOptions/planOption[@planOptionName='"+strPlanOptionName+"']/accumulators/accumulator");
	        		for (Node node : nodesPlanOptionsAccumulator) {
	        	String strAccumName=node.valueOf("@accumulatorName");
	            String quotedValue=node.valueOf("@quoted");
	            if(strAccNameCheck.equalsIgnoreCase(strAccumName))
            	{
            		if(!quotedValue.equalsIgnoreCase(""))
		            {            				
            					log(PASS, "Quoted Value in Plan Option Type["+strPlanOptionName+"] for Accumulator ["+strAccumName+"] is "+node.valueOf("@quoted"));
		            }            		
            			
            		else
            		{
            			log(FAIL, "Quoted Value in Plan Option Type["+strPlanOptionName+"] for Accumulator ["+strAccumName+"] is Unavailable");
            		}  
            	}	
	            
	        }
	        }
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void getDiscussionViewBenefitOptionsAccumulatorQuoted(String strXMLFile)
	{
		try {
			File inputFile = new File(strXMLFile);
	        SAXReader reader = new SAXReader();
	        Document document = reader.read(inputFile);	      
	        String strBenefitOptionName=getCellValue("BenefitOption1");
	        String strAccNameCheck=getCellValue("BenefitOption1Acc1");
	        List<Node> nodesPlanOptionsAccumulator = document.selectNodes("//benefitOptions/benefitOption[@planOptionName='"+strBenefitOptionName+"']/accumulators/accumulator");
	        for (Node node : nodesPlanOptionsAccumulator) {
	        String strAccumName=node.valueOf("@accumulatorName");
            String quotedValue=node.valueOf("@quoted");
            if(strAccNameCheck.equalsIgnoreCase(strAccumName))
        	{
        		if(!quotedValue.equalsIgnoreCase(""))
	            {
        					log(PASS, "Quoted Value for Benefit Option ["+strAccumName+"] is "+node.valueOf("@quoted"));
	            } 
        		else
        		{
        			log(FAIL, "Quoted Value for Benefit Option ["+strAccumName+"] is Unavailable");
        		}  
        	}	
            
        }
		} catch (Exception e) {
				e.printStackTrace();
		}
	}
	
}
