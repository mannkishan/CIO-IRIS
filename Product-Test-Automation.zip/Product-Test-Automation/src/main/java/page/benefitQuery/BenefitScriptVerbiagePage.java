package page.benefitQuery;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class BenefitScriptVerbiagePage extends CoreSuperHelper{
	
	private static BenefitScriptVerbiagePage thisIsTestObj;
	public  synchronized static BenefitScriptVerbiagePage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), BenefitScriptVerbiagePage.class);
		return thisIsTestObj;
		}
	
	@FindBy(how = How.XPATH, using = "//div/a[@data-id='/benefits/OccupTherapy/benefitLevel/RehabTherapies,Professional,OccupTherapy']/span[contains(text(),'Occupational Therapy')]")
	public WebElement lblRehabTherapy_Prof_OccTherapy;
	
	@FindBy(how = How.XPATH, using = "//*[@id='02']/a")
	public WebElement lblRehabTherapy_Prof_OccTherapy_BlueAccNet_HomeByHealthProvider;
	
	@FindBy(how = How.XPATH, using = "//table[@acronymid='RehabilitationTherapiesProfessionalOccupationalTherapy:BlueAccessNetwork:HomebyaHomeHealthProvider:calc:1']/tbody/tr/td[text()='Blue Preferred Blue Access and Out of Network Home Health Care Visit Limit']")
	public WebElement lblRehabTherapy_Prof_OccTherapy_BlueAccNet_HomeByHealthProviderLimit;
	
	@FindBy(how = How.XPATH, using = "//a[@href='#tab-content-1' and text()='Blue Preferred Network']")
	public WebElement lblRehabTherapy_Prof_OccTherapy_BluePrefNet;	
	
	@FindBy(how = How.XPATH, using = "//*[@id='12']/a")
	public WebElement lblRehabTherapy_Prof_OccTherapy_BluePrefNet_HomeByHealthProvider;
	
	@FindBy(how = How.XPATH, using = "//table[@acronymid='RehabilitationTherapiesProfessionalOccupationalTherapy:BluePreferredNetwork:HomebyaHomeHealthProvider:calc:1']/tbody/tr/td[text()='Blue Preferred Blue Access and Out of Network Home Health Care Visit Limit']")
	public WebElement lblRehabTherapy_Prof_OccTherapy_BluePrefNet_HomeByHealthProviderLimit;
	
	@FindBy(how = How.XPATH, using = "//a[@href='#tab-content-2' and text()='Non-Participating']")
	public WebElement lblRehabTherapy_Prof_OccTherapy_NonPart;
	
	@FindBy(how = How.XPATH, using = "//*[@id='22']/a")
	public WebElement lblRehabTherapy_Prof_OccTherapy_NonPart_HomeByHealthProvider;
	
	@FindBy(how = How.XPATH, using = "//table[@acronymid='RehabilitationTherapiesProfessionalOccupationalTherapy:Non-Participating:HomebyaHomeHealthProvider:calc:1']/tbody/tr/td[text()='Blue Preferred Blue Access and Out of Network Home Health Care Visit Limit']")
	public WebElement lblRehabTherapy_Prof_OccTherapy_NonPart_HomeByHealthProviderLimit;
	
	@FindBy(how = How.XPATH, using = "//*[@id='benefitModal']/div[3]/div/div/a[2]")
	public WebElement lblRehabTherapy_Prof_OccTherapyBenefitScript;
	
			@FindBy(how = How.XPATH, using = "/html/body/div[10]/div/div[2]/div/p[7]")
	public WebElement lblRehabTherapy_Prof_OccTherapyBenefitScriptCalculation;
	
	@FindBy(how = How.XPATH, using = "//div/a[@data-id='/benefits/SkilledNursingSvcs/benefitLevel/HomeHealthCare,SkilledNursingSvcs']/span[contains(text(),'Skilled Nursing Services')]")
	public WebElement lblSkilledNursingServices;
	
	@FindBy(how = How.XPATH, using = "//table[@acronymid='HomeHealthCareSkilledNursingServices:BlueAccessNetwork:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='Blue Preferred Blue Access and Out of Network Home Health Care Visit Limit']")
	public WebElement lblSkilledNursingServicesBAccNetUnlessOtherwiseSpecifiedLimit;
	
	@FindBy(how = How.XPATH, using = "//a[@href='#tab-content-1' and text()='Blue Preferred Network']")
	public WebElement lblSkilledNursingServicesBPrefNet;
	
	@FindBy(how = How.XPATH, using = "//table[@acronymid='HomeHealthCareSkilledNursingServices:BluePreferredNetwork:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='Blue Preferred Blue Access and Out of Network Home Health Care Visit Limit']")
	public WebElement lblSkilledNursingServicesBPrefNetUnlessOtherwiseSpecifiedLimit;
		
	@FindBy(how = How.XPATH, using = "//a[@href='#tab-content-2' and text()='Non-Participating']")
	public WebElement lblSkilledNursingServicesNonPart;
	
	@FindBy(how = How.XPATH, using = "//table[@acronymid='HomeHealthCareSkilledNursingServices:Non-Participating:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='Blue Preferred Blue Access and Out of Network Home Health Care Visit Limit']")
	public WebElement lblSkilledNursingServicesNonPartUnlessOtherwiseSpecifiedLimit;
	
	@FindBy(how = How.XPATH, using = "//*[@id='benefitModal']/div[3]/div/div/a[2]")
	public WebElement lblSkilledNursingServicesBenefitScript;
	
	@FindBy(how = How.XPATH, using = "/html/body/div[10]/div/div[2]/div/p[3]")
	public WebElement lblSkilledNursingServicesBenefitScriptCalculation;
	
	@FindBy(how = How.XPATH, using = "/html/body/div[10]/div/div[2]/div/text()[1]")
	public WebElement lblSkilledNursingServicesBenefitScriptAddInfo;		
	
		
	@FindBy(how = How.XPATH, using = "/html/body/div[10]/div/div[2]/div//descendant::div")
	public WebElement lblSkilledNursingServicesBenefitScript_BenefitTree;
		
	@FindBy(how = How.XPATH, using = "//div[@id='content-find-plan']//div[@class='search']//tr//td[contains(text(),'Production') or contains(text(),'Archived')]")
	public WebElement lblPlanInProduction;
	
	@FindBy(how = How.XPATH, using = "/html/body/div[10]/div/div[1]/button/i")
	public WebElement lblCloseBenefitScript;
	
	@FindBy(how = How.XPATH, using = "//*[@id='benefitModal']/div[1]/button/i")
	public WebElement lblCloseBenefitClose;
		
	@FindBy(how = How.XPATH, using = "//*[@id='clearSearch']")
	public WebElement lblClearBenefitSearch;
	
	public void seCheckExaminerActionAvailabilityInBQA() {
		try {
			/*starts here*/
			seSetText(QuotedPlanOptionsBenfitOptions.get().txtSearchBenefits, "Skilled");
			QuotedPlanOptionsBenfitOptions.get().txtSearchBenefits.sendKeys(Keys.ENTER);
			waitForPageLoad(20);
			QuotedPlanOptionsBenfitOptions.get().lblBenefitsTab.sendKeys(Keys.PAGE_UP);
			seClick(BenefitScriptVerbiagePage.get().lblSkilledNursingServices, "Skilled Nursing Services");		
			seWaitForClickableWebElement(BenefitScriptVerbiagePage.get().lblSkilledNursingServicesBAccNetUnlessOtherwiseSpecifiedLimit, 20);
			seClick(BenefitScriptVerbiagePage.get().lblSkilledNursingServicesBAccNetUnlessOtherwiseSpecifiedLimit, "Blue Preferred Blue Access and Out of Network Home Health Care Visit Limit");
			seWaitForClickableWebElement(BenefitScriptVerbiagePage.get().lblSkilledNursingServicesBPrefNet, 20);
			seClick(BenefitScriptVerbiagePage.get().lblSkilledNursingServicesBPrefNet, "Blue Preferred Network");
			seWaitForClickableWebElement(BenefitScriptVerbiagePage.get().lblSkilledNursingServicesBPrefNetUnlessOtherwiseSpecifiedLimit, 20);
			seClick(BenefitScriptVerbiagePage.get().lblSkilledNursingServicesBPrefNetUnlessOtherwiseSpecifiedLimit, "Blue Preferred Blue Access and Out of Network Home Health Care Visit Limit");
			seWaitForClickableWebElement(BenefitScriptVerbiagePage.get().lblSkilledNursingServicesNonPart, 20);
			seClick(BenefitScriptVerbiagePage.get().lblSkilledNursingServicesNonPart, "Non Participating");
			seWaitForClickableWebElement(BenefitScriptVerbiagePage.get().lblSkilledNursingServicesNonPartUnlessOtherwiseSpecifiedLimit, 20);
			seClick(BenefitScriptVerbiagePage.get().lblSkilledNursingServicesNonPartUnlessOtherwiseSpecifiedLimit, "Blue Preferred Blue Access and Out of Network Home Health Care Visit Limit");
			seWaitForClickableWebElement(BenefitScriptVerbiagePage.get().lblSkilledNursingServicesBenefitScript, 20);
			seClick(BenefitScriptVerbiagePage.get().lblSkilledNursingServicesBenefitScript, "Benefit Script");			
			String strValueBenefitCalculation="";
			strValueBenefitCalculation=seGetText(lblSkilledNursingServicesBenefitScriptCalculation);
			if(!strValueBenefitCalculation.equalsIgnoreCase(""))
			{
				log(PASS, "Benefit Calculation is Displayed ",strValueBenefitCalculation);
			}
			else
			{
				log(FAIL, "Benefit Calculation Unavailable");
			}
			
			String strValueBenefitTree="";
			
			for(int i=1;i<12;i++)
			{
					strValueBenefitTree=strValueBenefitTree+seGetText(getWebDriver().findElement(By.xpath("/html/body/div[10]/div/div[2]/div//descendant::div["+ i + "]"))).trim();
			}
			
			String[] strValueBenefitTreeCalc=strValueBenefitTree.split(",|\\.");
			
			for(int j=0;j<strValueBenefitTreeCalc.length;j++)
			{				
				log(PASS, "Benefit Tree Covered", strValueBenefitTreeCalc[j]);
			}
			
			String otherValues="";
			String strlblSkilledNursingServicesDetails="/html/body/div[10]/div/div[2]";
			otherValues=seGetText(getWebDriver().findElement(By.xpath(strlblSkilledNursingServicesDetails)));
			String strlblSkilledNursingServicesSituationGroupType="Blue Preferred Network";
			String strlblSkilledNursingServicesSituationType="Unless Otherwise Specified";
			String strlblSkilledNursingServicesKeyword="coinsurance of the allowed amount.";
			int intlblSkilledNursingServicesSituationGroupTypePosition=0;
			int intlblSkilledNursingServicesSituationTypePosition=0;
			int intlblSkilledNursingServicesKeyWordPosition=0;
			intlblSkilledNursingServicesSituationGroupTypePosition=otherValues.indexOf(strlblSkilledNursingServicesSituationGroupType);			
			if(intlblSkilledNursingServicesSituationGroupTypePosition>=0)
			{
				intlblSkilledNursingServicesSituationTypePosition=otherValues.indexOf(strlblSkilledNursingServicesSituationType, intlblSkilledNursingServicesSituationGroupTypePosition);
				if(intlblSkilledNursingServicesSituationTypePosition>=0)
				{
					intlblSkilledNursingServicesKeyWordPosition=otherValues.indexOf(strlblSkilledNursingServicesKeyword, intlblSkilledNursingServicesSituationTypePosition);
					String checkIt="It is subject to";
					String keyText=	otherValues.substring(intlblSkilledNursingServicesSituationTypePosition, intlblSkilledNursingServicesKeyWordPosition+strlblSkilledNursingServicesKeyword.length());
					int fourthPosition=keyText.lastIndexOf(checkIt);					
					log(PASS, "Additional Info",keyText.substring(fourthPosition, keyText.length()));
				
				}
				else
				{
					log(FAIL, strlblSkilledNursingServicesSituationType+" unavailable in Benefit Script");
				}
			}
			else
			{
				log(FAIL, strlblSkilledNursingServicesSituationGroupType+" unavailable in Benefit Script");
			}
			seClick(lblCloseBenefitScript, "Close");
			seWaitForClickableWebElement(lblCloseBenefitClose, 20);
			seClick(lblCloseBenefitClose, "Benefit Close");
			
			
			/*ends here*/
			
			/*Occupational Therapy begins here*/
			seSetText(QuotedPlanOptionsBenfitOptions.get().txtSearchBenefits, "Occupational");
			QuotedPlanOptionsBenfitOptions.get().txtSearchBenefits.sendKeys(Keys.ENTER);
			waitForPageLoad(20);
			seWaitForClickableWebElement(lblRehabTherapy_Prof_OccTherapy,20);
			seClick(lblRehabTherapy_Prof_OccTherapy, "Occupational Therapy");
			seWaitForClickableWebElement(lblRehabTherapy_Prof_OccTherapy_BlueAccNet_HomeByHealthProvider,20);
			seClick(lblRehabTherapy_Prof_OccTherapy_BlueAccNet_HomeByHealthProvider, "Home Health Provider");			
			seWaitForClickableWebElement(lblRehabTherapy_Prof_OccTherapy_BlueAccNet_HomeByHealthProviderLimit,20);
			seClick(lblRehabTherapy_Prof_OccTherapy_BlueAccNet_HomeByHealthProviderLimit, "Home By Health Provider Limit");
			
			seWaitForClickableWebElement(lblRehabTherapy_Prof_OccTherapy_BluePrefNet,20);
			seClick(lblRehabTherapy_Prof_OccTherapy_BluePrefNet, "Blue Preferred Network");
			seWaitForClickableWebElement(lblRehabTherapy_Prof_OccTherapy_BluePrefNet_HomeByHealthProvider,20);
			seClick(lblRehabTherapy_Prof_OccTherapy_BluePrefNet_HomeByHealthProvider, "Home Health Provider");			
			seWaitForClickableWebElement(lblRehabTherapy_Prof_OccTherapy_BluePrefNet_HomeByHealthProviderLimit,20);
			seClick(lblRehabTherapy_Prof_OccTherapy_BluePrefNet_HomeByHealthProviderLimit, "Limit");
			
			seWaitForClickableWebElement(lblRehabTherapy_Prof_OccTherapy_NonPart,20);
			seClick(lblRehabTherapy_Prof_OccTherapy_NonPart,"Non Part");
			seWaitForClickableWebElement(lblRehabTherapy_Prof_OccTherapy_NonPart_HomeByHealthProvider,20);
			seClick(lblRehabTherapy_Prof_OccTherapy_NonPart_HomeByHealthProvider, "Home By Health Provider");
			seWaitForClickableWebElement(lblRehabTherapy_Prof_OccTherapy_NonPart_HomeByHealthProviderLimit,20);
			seClick(lblRehabTherapy_Prof_OccTherapy_NonPart_HomeByHealthProviderLimit, "Home By Health Provider Limit");
			seWaitForClickableWebElement(lblRehabTherapy_Prof_OccTherapyBenefitScript,20);
			seClick(lblRehabTherapy_Prof_OccTherapyBenefitScript, "Benefit Script");
			
			String strValueBenefitCalculation1="";
			strValueBenefitCalculation1=seGetText(lblRehabTherapy_Prof_OccTherapyBenefitScriptCalculation);
			if(!strValueBenefitCalculation1.equalsIgnoreCase(""))
			{
				log(PASS, "Benefit Calculation is Displayed ",strValueBenefitCalculation1);
			}
			else
			{
				log(FAIL, "Benefit Calculation Unavailable");
			}
			
			String strValueBenefitTree1="";			
			for(int i=1;i<12;i++)
			{
					strValueBenefitTree1=strValueBenefitTree1+seGetText(getWebDriver().findElement(By.xpath("/html/body/div[10]/div/div[2]/div//descendant::div["+ i + "]"))).trim();
			}
			String[] strValueBenefitTreeCalc1=strValueBenefitTree1.split(",|\\.");
			
			for(int j=0;j<strValueBenefitTreeCalc1.length;j++)
			{
				
				log(PASS, "Benefit Tree Covered", strValueBenefitTreeCalc1[j]);
			}
			String otherValues1="";
			String strSituationGroupType="Blue Preferred Network";
			String strSituationType="Home by a Home Health Provider";
			String strKeyword="coinsurance of the allowed amount.";
			int intSituationGroupTypePosition=0;
			int intSituationTypePosition=0;
			int intKeyWordPosition=0;
			String strlblRehabTherapy_Prof_OccTherapy_Details="/html/body/div[10]/div/div[2]";
			
			otherValues1=seGetText(getWebDriver().findElement(By.xpath(strlblRehabTherapy_Prof_OccTherapy_Details)));
			intSituationGroupTypePosition=otherValues1.indexOf(strSituationGroupType);			
			if(intSituationGroupTypePosition>=0)
			{
				intSituationTypePosition=otherValues1.indexOf(strSituationType, intSituationGroupTypePosition);
				if(intSituationTypePosition>=0)
				{
					intKeyWordPosition=otherValues1.indexOf(strKeyword, intSituationTypePosition);
					String checkIt="It is subject to";
					String keyText=	otherValues1.substring(intSituationTypePosition, intKeyWordPosition+strKeyword.length());
					int fourthPosition=keyText.lastIndexOf(checkIt);					
					log(PASS, "Additional Info",keyText.substring(fourthPosition, keyText.length()));
				
				}
				else
				{
					log(FAIL, strSituationType+" unavailable in Benefit Script");
				}
			}
			else
			{
				log(FAIL, strSituationGroupType+" unavailable in Benefit Script");
			}
			
			/*Occupational Therapy ends here*/
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	public void seAdditionalBenefitScriptInfo()
	{
		
	}
	
}
