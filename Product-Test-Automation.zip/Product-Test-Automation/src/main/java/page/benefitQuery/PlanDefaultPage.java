package page.benefitQuery;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class PlanDefaultPage extends CoreSuperHelper {

	private static PlanDefaultPage thisIsTestObj;
	public  synchronized static PlanDefaultPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), PlanDefaultPage.class);
		return thisIsTestObj;}
	
	
	@FindBy(how=How.XPATH,using="(//a[@class='ui-tabs-anchor'])[1]")
	public WebElement planOptionTab;
	
	@FindBy(how=How.XPATH,using="(//a[@class='ui-tabs-anchor'])[2]")
	public WebElement benefitOptionTab;
	
	@FindBy(how=How.XPATH,using="(//a[@class='ui-tabs-anchor'])[3]")
	public WebElement mandatesTab;
	
	@FindBy(how=How.XPATH,using="(//a[@class='ui-tabs-anchor'])[4]")
	public WebElement umRulesTab;
	
	@FindBy(how=How.XPATH,using="(//a[@class='ui-tabs-anchor'])[5]")
	public WebElement medicalPolicyTab;
	
	@FindBy(how=How.XPATH,using="(//a[@class='ui-tabs-anchor'])[6]")
	public WebElement BenefitsTab;
	
	@FindBy(how=How.XPATH,using="//ul[contains(@class,'mainHead nav nav-tabs')]/li[@id='tab-header-0']/a")
	public WebElement firstBenefitGroup;
	
	@FindBy(how=How.XPATH,using="//ul[contains(@class,'mainHead nav nav-tabs')]/li[@id='tab-header-1']/a")
	public WebElement secondBenefitGroup;
	
	@FindBy(how=How.XPATH,using="//div[@class='accordion benefit-accumulator-oop']")
	public WebElement oopMax;
	
	@FindBy(how=How.XPATH,using="//div[@id='benefitsHeader']/div[2]/div[contains(@class,'span')][1]")
	public WebElement participating;
	
	@FindBy(how=How.XPATH,using="//div[@id='benefitsHeader']/div[2]/div[contains(@class,'span')][2]")
	public WebElement nonParticipating;
	
	@FindBy(how=How.XPATH,using="//div[@class='serviceDateContainer']/input")
	public WebElement serviceDateContainer;
	
	@FindBy(how=How.XPATH,using="(//div/div[contains(@acronymid,'OOP')]/div/a[@class='accordion-toggle'])[1]")
	public WebElement oopMaxHeaderOpen;
	
	@FindBy(how=How.XPATH,using="(//div/div[contains(@acronymid,'OOP')]/div/a[@class='accordion-toggle collapsed'])[1]")
	public WebElement oopMaxHeaderCollapse;
}
