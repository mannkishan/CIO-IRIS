package page.benefitQuery;

import java.awt.List;
import java.util.LinkedList;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.xmlbeans.impl.xb.xsdschema.FieldDocument.Field.Xpath;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class ExaminerActionVerbiage extends CoreSuperHelper{

	private static ExaminerActionVerbiage thisIsTestObj;
	public  synchronized static ExaminerActionVerbiage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), ExaminerActionVerbiage.class);
		return thisIsTestObj;
		}
	
	
	
	
	
	
	public LinkedList<String> seGetPcExaminerAction(String strPcBenefitGroup,String strSituation){
		WebElement wbSituation=getWebDriver().findElement(By.xpath("//span[text()='"+strPcBenefitGroup+"' and @data-type='paymentLevelStatusCode']/../../span[2]/span[text()='"+strSituation+"']"));
        String dataAttribute=getWebDriver().findElement(By.xpath("//span[text()='"+strPcBenefitGroup+"' and @data-type='paymentLevelStatusCode']/../../span[2]/span[text()='"+strSituation+"']/..")).getAttribute("data-fullidentifier");
		seClick(wbSituation, "situation type");
		waitForPageLoad();
		LinkedList<String> PcExaminerAction=new LinkedList<>();

		try{for(int i=1;i<=3;i++){
			
		String strExamAction=getWebDriver().findElement(By.xpath("//div[contains(@fullpath,'"+dataAttribute+"')]/div/div[@class='examinerActionContainer']["+i+"]/span[2]")).getText();
		PcExaminerAction.add(strExamAction);
		
		
		}}catch(Exception e){}
     return PcExaminerAction;
	}
	
	
	public LinkedList<String> seGetBqaExaminerAction(String strBenefit,String strBqaBenefitGroup,String strSituation) throws InterruptedException, XPathExpressionException{
	WebElement benefit=getWebDriver().findElement(By.xpath("//span[text()='"+strBenefit+"'][1]"));
	((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",benefit);
	waitForPageLoad();					
	seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//a[contains(text(),'"+strBqaBenefitGroup+"')]")), 12);
    WebElement benefitOrPayment=getWebDriver().findElement(By.xpath("//a[contains(text(),'"+strBqaBenefitGroup+"')]"));
    ((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", benefitOrPayment);
	WebElement wb1=getWebDriver().findElement(By.xpath("//ul[@class='subHead nav-tabs']/li/a[text()='"+strSituation+"']"));
	seClick(wb1, "situation");
	waitForPageLoad();
	seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//div/a[text()='Benefit Script']")), 13);	
	
 seClick(driver.findElement(By.xpath("//div/a[text()='Benefit Script']")), "Benefit Script");
 waitForPageLoad();
 seWaitForClickableWebElement(getWebDriver().findElement(By.xpath("//p[@class='benefitScript-paymentLevelStatusCode' and text()='"+strBqaBenefitGroup+" "+"']/following::p[text()='"+strSituation+": "+"'][1]/following::p[1]")), 12);
 String strBenefitVerbiage=driver.findElement(By.xpath("//p[@class='benefitScript-paymentLevelStatusCode' and text()='"+strBqaBenefitGroup+" "+"']/following::p[text()='"+strSituation+": "+"'][1]/following::p[1]")).getText();
LinkedList<String> bqaExaminerAction=new LinkedList<>()	;
System.out.println(strBenefitVerbiage);
	String[] strExaminerAction=strBenefitVerbiage.split("Notes: ");
	String strNotes[]=strExaminerAction[1].split("\\.");
	try{for(int j=0;j<=5;j++){
		bqaExaminerAction.add(strNotes[j]);

	}}catch(Exception e){} 
	return bqaExaminerAction;
}
}
