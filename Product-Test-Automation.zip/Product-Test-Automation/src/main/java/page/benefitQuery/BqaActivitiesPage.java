package page.benefitQuery;

import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class BqaActivitiesPage extends CoreSuperHelper
{

	
	private static BqaActivitiesPage thisIsTestObj;
	public  synchronized static BqaActivitiesPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), BqaActivitiesPage.class);
		return thisIsTestObj;
		}
	
	public void seGetOopMaximumDetails(String strSituation){
		 try{
	        	for(int i=1;i<=12;i++){
	        		String strType=getWebDriver().findElement(By.xpath("(//table[contains(@acronymid,':"+strSituation.replaceAll("\\s+", "")+":')]/following::div[contains(@acronymid,'OOP')]/div[2]/div/table/tbody/tr["+i+"]/td[1])[1]")).getText();
	        		String strName=getWebDriver().findElement(By.xpath("(//table[contains(@acronymid,':"+strSituation.replaceAll("\\s+", "")+":')]/following::div[contains(@acronymid,'OOP')]/div[2]/div/table/tbody/tr["+i+"]/td[2])[1]")).getText();
	        		String strValues=getWebDriver().findElement(By.xpath("(//table[contains(@acronymid,':"+strSituation.replaceAll("\\s+", "")+":')]/following::div[contains(@acronymid,'OOP')]/div[2]/div/table/tbody/tr["+i+"]/td[3])[1]")).getText();
	        		String strPeriod=getWebDriver().findElement(By.xpath("(//table[contains(@acronymid,':"+strSituation.replaceAll("\\s+", "")+":')]/following::div[contains(@acronymid,'OOP')]/div[2]/div/table/tbody/tr["+i+"]/td[4])[1]")).getText();
	        		log(PASS, ""+strType+"  "+strName+"",""+strValues+"  "+strPeriod+"");
	        	}
	        }catch(Exception e){}
	}
	public void seGetPcValues(Set<String> pcCalcChoice,Set<String> pcCalcStep,String strPcBenefitGroup, String strSituation){		
		try{	for(int i=1;i<9;i++)
		{
		WebElement CalcValue=getWebDriver().findElement(By.xpath("//span[text()='"+strPcBenefitGroup+"' and @data-type='paymentLevelStatusCode']/../../span[2]/span[text()='"+strSituation+"']/../../../div/div[2]/div/div[2]/div/table/tbody/tr["+i+"]/td[@class='value_Value']/span"));
		String strPcCalcValue=seGetText(CalcValue);
		if(strPcCalcValue.equals("N/A")==false){
		WebElement CalcStep=getWebDriver().findElement(By.xpath("//span[text()='"+strPcBenefitGroup+"' and @data-type='paymentLevelStatusCode']/../../span[2]/span[text()='"+strSituation+"']/../../../div/div[2]/div/div[2]/div/table/tbody/tr["+i+"]/td[@class='value_Step']/span"));
		pcCalcStep.add(seGetText(CalcStep));
        WebElement CalcChoice=getWebDriver().findElement(By.xpath("//span[text()='"+strPcBenefitGroup+"' and @data-type='paymentLevelStatusCode']/../../span[2]/span[text()='"+strSituation+"']/../../../div/div[2]/div/div[2]/div/table/tbody/tr["+i+"]/td[@class='value_Type']/span"));
		pcCalcChoice.add(seGetText(CalcChoice));
		}
		}}catch(Exception e){}		}
	
	public void seGetBqaValues(String strSituation,Set<String> bqaCalcStep, Set<String> bqaCalcChoice){
		try{	for(int i=1;i<9;i++)
	{
	WebElement wbBqaStep=getWebDriver().findElement(By.xpath("//table[contains(@acronymid,':"+strSituation.replaceAll("\\s+", "")+":')]/tbody/tr["+i+"]/td[1]"));					
	bqaCalcStep.add(wbBqaStep.getText());
	WebElement wbBqaChoice=getWebDriver().findElement(By.xpath("//table[contains(@acronymid,':"+strSituation.replaceAll("\\s+", "")+":')]/tbody/tr["+i+"]/td[2]"));
	bqaCalcChoice.add(wbBqaChoice.getText());					
	}}catch(Exception e){}}
	
	public void seIsBqaTabsAreInOrder(){
		seWaitForClickableWebElement(PlanDefaultPage.get().planOptionTab, 11);
		String strPlanOption=seGetText(PlanDefaultPage.get().planOptionTab);
		String strbenefitOption=seGetText(PlanDefaultPage.get().benefitOptionTab);
		String strMandates=seGetText(PlanDefaultPage.get().mandatesTab);
		String strUmRules=seGetText(PlanDefaultPage.get().umRulesTab);
		String strMedicalPolicy=seGetText(PlanDefaultPage.get().medicalPolicyTab);
		String strBenefits = "";
try{
		strBenefits=seGetText(PlanDefaultPage.get().BenefitsTab);	}catch(Exception e){}	

        if((strPlanOption.equalsIgnoreCase("Plan Options") && strbenefitOption.equalsIgnoreCase("Benefit Options") && strMandates.equalsIgnoreCase("Mandates") && strUmRules.equalsIgnoreCase("UM Rules") && strMedicalPolicy.equalsIgnoreCase("Medical Policy") && strBenefits.equalsIgnoreCase("Benefits"))||(strPlanOption.equalsIgnoreCase("Plan Options") && strbenefitOption.equalsIgnoreCase("Benefit Options") && strMandates.equalsIgnoreCase("Medical Policy") && strUmRules.equalsIgnoreCase("UM Rules") && strMedicalPolicy.equalsIgnoreCase("Benefits"))||(strPlanOption.equalsIgnoreCase("Plan Options") && strbenefitOption.equalsIgnoreCase("Benefit Options") && strMandates.equalsIgnoreCase("Mandates") && strUmRules.equalsIgnoreCase("Medical Policy") && strMedicalPolicy.equalsIgnoreCase("Benefits")))
        {
	    log(PASS, "Tabs are in order", "RESULT=PASS");
        }
        else{log(FAIL, "Tabs are NOT in order", "RESULT=FAIL");}
	}
	
	
	public void seIsSituationGroupsAreInOrder(String strBenefit,String strBqaBenefitGroup,String strSituation){
		String strParticipating=PlanDefaultPage.get().participating.getText();
		String strNonParticipating=PlanDefaultPage.get().nonParticipating.getText();
		System.out.println(strParticipating+" this is "+strNonParticipating);
		WebElement benefit=getWebDriver().findElement(By.xpath("//span[text()='"+strBenefit+"'][1]"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();",benefit);
		waitForPageLoad();	
        seWaitForClickableWebElement(PlanDefaultPage.get().firstBenefitGroup, 20);
        String strFirstBenefitGroup=PlanDefaultPage.get().firstBenefitGroup.getText();
        String strSecondBenefitGroup=PlanDefaultPage.get().secondBenefitGroup.getText();
        if((strParticipating.equals("Participating")||strParticipating.equals("Participating - HMO") )&& strNonParticipating.equalsIgnoreCase("Non-Participating"))
		{
			log(PASS, "Participating and non participating in default page are in order", ""+strParticipating+""+strNonParticipating);
		}
		else{log(FAIL, "Participating and non participating in default page are NOT in order", ""+strParticipating+""+strNonParticipating);}
	  
		if((strFirstBenefitGroup.equalsIgnoreCase("Tier 1")||(strFirstBenefitGroup.equals("Participating")||strFirstBenefitGroup.equals("Participating - HMO")))&&(strSecondBenefitGroup.equalsIgnoreCase("Non-Participating")||strSecondBenefitGroup.equalsIgnoreCase("OON"))){
		   
		   log(PASS, "Participating or Tier 1 and non participating or OON in default page are in order", ""+strFirstBenefitGroup+" "+strSecondBenefitGroup+"");
		}
		else{log(FAIL, "Participating or Tier 1 and non participating or OON in default page are NOT in order", ""+strFirstBenefitGroup+" "+strSecondBenefitGroup+"");}

		if(strFirstBenefitGroup.equals(strBqaBenefitGroup)){
			seClick(PlanDefaultPage.get().firstBenefitGroup, strBqaBenefitGroup);
			waitForPageLoad();
		}
		else{
			seClick(PlanDefaultPage.get().secondBenefitGroup, strBqaBenefitGroup);
            waitForPageLoad();
		}
		WebElement wb1=getWebDriver().findElement(By.xpath("//ul[@class='subHead nav-tabs']/li/a[text()='"+strSituation+"']"));
		seWaitForClickableWebElement(wb1, 12);
		seClick(wb1, "situation");
		waitForPageLoad();
		
	}
}
