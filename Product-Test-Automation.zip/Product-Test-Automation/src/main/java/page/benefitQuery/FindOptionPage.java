package page.benefitQuery;



import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class FindOptionPage extends CoreSuperHelper{
	
	private static FindOptionPage thisIsTestObj;
	public  synchronized static FindOptionPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), FindOptionPage.class);
		return thisIsTestObj;
		}
	@FindBy(how=How.XPATH,using="//*[@id=\"find-contract-header\"]/div/div[1]/input")
	public WebElement optionTextBox;
	
	@CacheLookup
	@FindBy(how=How.XPATH,using="//*[@id=\"find\"]")
	public WebElement searchButton;
	
	@FindBy(how=How.NAME,using="effThru")
	public WebElement serviceDate;
	
	@FindBy(how=How.NAME,using="createdThru")
	public WebElement asOfDate;
	

	@CacheLookup
	@FindBy(how=How.XPATH,using="//*[@id=\"DataTables_Table_0\"]/tbody/tr")
	public WebElement searchTable;

	public void comparebool(Boolean var1, Boolean var2){
		if(var1 == var2)
		{
			log(PASS, "Accumulators and Accumulator steps are verfied successfully","Accumulator and Steps are displayed and verified,RESULT=PASS");
			
			
		}
		else
		{
			log(FAIL, "Accumulators and Accumulator steps are NOT verfied","Accumulator and Steps are NOT displayed or NOT verified,RESULT=FAIL");
			
			
		}
			
		}
	
}
