package page.benefitQuery;

import java.util.List;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class QuotedPlanOptionsBenfitOptions extends CoreSuperHelper {

	private static QuotedPlanOptionsBenfitOptions thisIsTestObj;

	public synchronized static QuotedPlanOptionsBenfitOptions get() {
		thisIsTestObj = PageFactory.initElements(getWebDriver(), QuotedPlanOptionsBenfitOptions.class);
		return thisIsTestObj;

	}

	/* Plan Options Tab in BQA */
	@FindBy(how = How.XPATH, using = "//a[@href='#plan-options0' and contains(text(),'Plan Options')]")
	public WebElement lblPlanOptionsTab;

	/* Benefit Options Tab in BQA */
	@FindBy(how = How.XPATH, using = "//a[@href='#benefit-options0' and contains(text(),'Benefit Options')]")
	public WebElement lblBenefitOptionsTab;

	/* Benefit Tab in BQA */
	@FindBy(how = How.XPATH, using = "//a[@href='#benefits0' and contains(text(),'Benefits')]")
	public WebElement lblBenefitsTab;

	/* Hospital/ Facility Care--->Bariatric Surgery begins here */

	@FindBy(how = How.XPATH, using = "//input[@class='textSearchTree input']")
	public WebElement txtSearchBenefits;

	@FindBy(how = How.XPATH, using = "//div/a[@data-id='/benefits/Bariatric/benefitLevel/InptInstitutionalCare,Bariatric']/span[contains(text(),'Bariatric')]")
	public WebElement lblHospitalFacilityCare_Bariatric;

	@FindBy(how = How.XPATH, using = "//table[@acronymid='Hospital/FacilityCareBariatric:Tier1:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='In Network Institutional Pre-Auth Penalty']")
	public WebElement benefitDetailsBariatricINNPreAuthPenaltyName;

	@FindBy(how = How.XPATH, using = "//table[@acronymid='Hospital/FacilityCareBariatric:Tier1:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='Bariatric Surgery']")
	public WebElement benefitDetailsBariatricBariatricSurgery;

	@FindBy(how = How.XPATH, using = "//table[@acronymid='Hospital/FacilityCareBariatric:Tier1:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='In Network Inpatient Care Coinsurance']")
	public WebElement benefitDetailsBariatricCoinsurance;

	@FindBy(how = How.XPATH, using = "//*[@id='tab-header-0']/a")
	public WebElement lblBenefitDetailsBariatricPageDown;

	@FindBy(how = How.XPATH, using = "//table[@acronymid='Hospital/FacilityCareBariatric:Tier1:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='In Network Individual Deductible']")
	public WebElement benefitDetailsINNNetDeductible;

	/* Hospital/ Facility Care--->Bariatric Surgery ends here */

	/* Penalties:Penalty begins here */

	@FindBy(how = How.XPATH, using = "//*[@acronymid='Penalties:WithPenalty']/div//a[@class='accordion-toggle' and contains(text(),'Penalties:With Penalty')]")
	public WebElement lblPenalties;

	@FindBy(how = How.XPATH, using = "//*[@acronymid='Penalties:WithPenalty']/div//div/table/tbody/tr[@data-id='PenPreAuthINNT1Inst']/td[1]")
	public WebElement lblPenaltiesINNPreAuthPenalty;

	/* Penalties:Penalty ends here */

	/* Coinsurance:Coinsurance begins here */

	@FindBy(how = How.XPATH, using = "//*[@acronymid='Coinsurance:Coinsurance']/div//a[@class='accordion-toggle' and contains(text(),'Coinsurance:Coinsurance')]")
	public WebElement lblCoinsurance;

	@FindBy(how = How.XPATH, using = "//*[@acronymid='Coinsurance:Coinsurance']/div//div/table/tbody/tr[@data-id='CoinINNT1Med']/td[1]")
	public WebElement lblCoinsuranceINNCoins;

	/* Coinsurance:Coinsurance ends here */

	/* Deductible:Deductible starts here */

	@FindBy(how = How.XPATH, using = "//*[@acronymid='Deductible:Deductible']/div//a[@class='accordion-toggle' and contains(text(),'Deductible:Deductible')]")
	public WebElement lblDeductible;

	@FindBy(how = How.XPATH, using = "//*[@acronymid='Deductible:Deductible']/div//div/table/tbody/tr[@data-id='DedINNT1IndMed']/td[1]")
	public WebElement lblINNIndDeductible;

	/* Deductible:Deductible ends here */

	/* Bariatric Surgery:Covered In Network & Out of Network starts here */

	@FindBy(how = How.XPATH, using = "//*[@id='plan-header']/div/div[1]/a/i")
	public WebElement lblPageUpBenefits;

	@FindBy(how = How.XPATH, using = "//*[@acronymid='MedicareCOB:MedicareCOB']/div//a[@class='accordion-toggle' and contains(text(),'Medicare COB:Medicare COB')]")
	public WebElement lblPageDownPlanAndBenefitOptions;

	@FindBy(how = How.XPATH, using = "//*[@acronymid='BariSurg:CoveredINNOON']/div//a[@class='accordion-toggle' and contains(text(),'Bariatric Surgery:Covered In Network & Out of Network')]")
	public WebElement lblBariatricSurgeryCoveredINOONBenefitOptions;

	@FindBy(how = How.XPATH, using = "//div/div/table/tbody/tr/td[text()='Bariatric Surgery']")
	public WebElement lblBariatricSurgery_BariatricSurgeryCoveredINOONBenefitOptions;

	/* Bariatric Surgery:Covered In Network & Out of Network ends here */

	public List<String> seCheckPlanOptionsAvailabilityInBQA() {
		try {

			if (seIsElementEnabled(QuotedPlanOptionsBenfitOptions.get().lblPlanOptionsTab,
					"Plan Options Tab Available")) {
				seClick(QuotedPlanOptionsBenfitOptions.get().lblPlanOptionsTab, "Plan Options");
			} else {
				seWaitForPageLoad(20);
			}
			for (int i = 0; i < 7; i++) {
				QuotedPlanOptionsBenfitOptions.get().lblPageDownPlanAndBenefitOptions.sendKeys(Keys.ARROW_DOWN);
			}
			seClick(QuotedPlanOptionsBenfitOptions.get().lblDeductible, "Deductible");
			List<String> valueFetchedPlanOptionDetails = new ArrayList<String>();
			valueFetchedPlanOptionDetails = QuotedPlanOptionsBenfitOptions.get().seFetchPlanOptionsValues();
			seClick(QuotedPlanOptionsBenfitOptions.get().lblINNIndDeductible, "In Network Individual Deductible");
			return valueFetchedPlanOptionDetails;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	public List<String> seCheckBenefitOptionsAvailabilityInBQA() {
		try {

			if (seIsElementEnabled(QuotedPlanOptionsBenfitOptions.get().lblBenefitOptionsTab, "Benefit Options")) {
				seClick(QuotedPlanOptionsBenfitOptions.get().lblBenefitOptionsTab, "Benefit Options");
			} else {
				seWaitForPageLoad(30);
			}
			QuotedPlanOptionsBenfitOptions.get().lblBenefitOptionsTab.sendKeys(Keys.PAGE_UP);
			QuotedPlanOptionsBenfitOptions.get().lblBenefitOptionsTab.sendKeys(Keys.PAGE_DOWN);
			QuotedPlanOptionsBenfitOptions.get().lblBenefitOptionsTab.sendKeys(Keys.PAGE_DOWN);
			seWaitForPageLoad(15);
			seClick(QuotedPlanOptionsBenfitOptions.get().lblBariatricSurgeryCoveredINOONBenefitOptions,
					"Bariatric Surgery");
			List<String> valueFetchedBenefitOptionDetails = new ArrayList<String>();
			valueFetchedBenefitOptionDetails = QuotedPlanOptionsBenfitOptions.get().seFetchBenefitOptionsValues();
			seClick(QuotedPlanOptionsBenfitOptions.get().lblBariatricSurgery_BariatricSurgeryCoveredINOONBenefitOptions,
					"Bariatric Surgery");
			return valueFetchedBenefitOptionDetails;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public LinkedHashMap<Integer, List<String>> seCheckBenefitDetailsAvailabilityInBQA() {
		try {
			seClick(QuotedPlanOptionsBenfitOptions.get().lblBenefitsTab, "Benefits Tab");
			waitForPageLoad(15);
			seSetText(QuotedPlanOptionsBenfitOptions.get().txtSearchBenefits, "Bariatric");
			QuotedPlanOptionsBenfitOptions.get().txtSearchBenefits.sendKeys(Keys.ENTER);
			waitForPageLoad(20);
			QuotedPlanOptionsBenfitOptions.get().lblBenefitsTab.sendKeys(Keys.PAGE_UP);
			seClick(QuotedPlanOptionsBenfitOptions.get().lblHospitalFacilityCare_Bariatric, "Bariatric");
			waitForPageLoad(20);
			LinkedHashMap<Integer, List<String>> valueVerify = new LinkedHashMap<Integer, List<String>>();
			valueVerify = QuotedPlanOptionsBenfitOptions.get().seCheckValueAvailableInBenefitDetailsBQA();
			return valueVerify;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public LinkedHashMap<Integer, List<String>> seCheckValueAvailableInBenefitDetailsBQA() {
		try {

			LinkedHashMap<Integer, List<String>> valueVerify = new LinkedHashMap<Integer, List<String>>();
			List<String> valueStored = new ArrayList<String>();
			String valueFetched = "";
			waitForPageLoad(10);
			for (int i = 2; i <= 5; i++) {
				valueFetched = seGetText(getWebDriver().findElement(By
						.xpath("//table[@acronymid='Hospital/FacilityCareBariatric:Tier1:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='Bariatric Surgery']//parent::tr//td["
								+ i + "]"))).trim();
				valueStored.add(valueFetched);
			}
			valueVerify.put(0, valueStored);
			QuotedPlanOptionsBenfitOptions.get().lblBenefitDetailsBariatricPageDown.sendKeys(Keys.PAGE_DOWN);
			waitForPageLoad(10);
			List<String> valueStored1 = new ArrayList<String>();
			for (int i = 2; i <= 5; i++) {
				valueFetched = seGetText(getWebDriver().findElement(By
						.xpath("//table[@acronymid='Hospital/FacilityCareBariatric:Tier1:UnlessOtherwiseSpecified:calc:1']/tbody/tr/td[text()='In Network Individual Deductible']//parent::tr//td["
								+ i + "]"))).trim();
				valueStored1.add(valueFetched);
			}
			valueVerify.put(1, valueStored1);
			return valueVerify;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public List<String> seFetchPlanOptionsValues() {
		try {
			List<String> valueStored = new ArrayList<String>();

			for (int i = 1; i <= 4; i++) {
				String valueFetched = seGetText(getWebDriver().findElement(By
						.xpath("//*[@acronymid='Deductible:Deductible']/div//div/table/tbody/tr[@data-id='DedINNT1IndMed']/td["
								+ i + "]"))).trim();
				valueStored.add(valueFetched);
			}

			return valueStored;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public List<String> seFetchBenefitOptionsValues() {
		try {
			List<String> valueStored = new ArrayList<String>();

			for (int i = 1; i <= 4; i++) {
				String valueFetched = seGetText(getWebDriver().findElement(By
						.xpath("//*[@acronymid='BariSurg:CoveredINNOON']/div//div/table/tbody/tr[@data-id='UnitBariSurg']/td["
								+ i + "]"))).trim();
				valueStored.add(valueFetched);
			}

			return valueStored;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public void seCheckQuotedValueAvailability(LinkedHashMap<Integer, List<String>> valueVerifyBD,
			LinkedHashMap<Integer, List<String>> valueVerifyPB) {
		List<String> valueStored = new ArrayList<String>();
		List<String> valueStored1 = new ArrayList<String>();
		valueStored = valueVerifyBD.get(0);
		valueStored1 = valueVerifyPB.get(1);
		if (valueStored.equals(valueStored1)) {
			seClick(QuotedPlanOptionsBenfitOptions.get().benefitDetailsBariatricBariatricSurgery, "Bariatric Surgery");
			log(PASS, "Benefit Option Accumulator [" + valueStored.get(1) + "] available in BQA");
		}
		valueStored = valueVerifyBD.get(1);
		valueStored1 = valueVerifyPB.get(0);
		if (valueStored.equals(valueStored1)) {
			seClick(QuotedPlanOptionsBenfitOptions.get().benefitDetailsINNNetDeductible, "In Network Deductible");
			log(PASS, "Plan Option Accumulator [" + valueStored.get(1) + "] available in BQA");
		}

	}

}
