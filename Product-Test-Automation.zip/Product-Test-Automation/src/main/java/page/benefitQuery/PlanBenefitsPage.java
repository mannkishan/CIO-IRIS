package page.benefitQuery;



import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class PlanBenefitsPage extends CoreSuperHelper{
	
	private static PlanBenefitsPage thisIsTestObj;
	public  synchronized static PlanBenefitsPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), PlanBenefitsPage.class);
		return thisIsTestObj;
		}
	@FindBy(how=How.XPATH,using="//a[text()='Benefits']")
	public WebElement benefits;
	
	
	@FindBy(how=How.ID,using="//*[@id=\"Navigation\"]/div[3]/input[1]")
	public WebElement searchText;
	
	@FindBy(how=How.ID,using="search")
	public WebElement searchButton;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Urgent Care Center')]")
	public WebElement UrgentCareFac;

	@FindBy(how=How.XPATH,using="//*[@id=\"benefitModal\"]/div[1]/button/i")
	public WebElement closeBenefitInfo;

	public static  void selectBenefit(String strBenefitText)
	{
		WebElement benefit=driver.findElement(By.xpath("//span[contains(text(),'"+strBenefitText+"')]"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", benefit);

	}
	
	public static  void clickBenefit(String strBenefitText)
	{
		seClick(driver.findElement(By.xpath("//a[contains(text(),'"+strBenefitText+"') and not (contains(text(),'-"+strBenefitText+"')) ]"))," benefit name");
	}
	
	
	public static  void clickPaymentLevel(String strPaymentText)
	
	{
			
		    WebElement benefitOrPayment=driver.findElement(By.xpath("//a[contains(text(),'"+strPaymentText+"')]"));
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", benefitOrPayment);
		
		
		
	}
	
	
	public static void clickBenefitDetails(String strButton1,String strButton2)
	{
		driver.findElement(By.xpath("//div/h4[contains(@acronymid,'"+strButton1+"')]/following::tr[td[text()='"+strButton2+"']][1]/td[4]")).click();
		
	}
	
	public static String getBenefitsTextValue(String strName1,String strName2)
	{
		return driver.findElement(By.xpath("//div/h4[contains(@acronymid,'"+strName1+"')]/following::tr[td[text()='"+strName2+"']][1]/td[4]")).getText();
		
	}
	public static String getBenefitsTextOop(String strVal1,String strVal2)
	{
		return driver.findElement(By.xpath("//div/h4[contains(@acronymid,'"+strVal1+"')]/following::tr[td[text()='"+strVal2+"']][1]/td[6]")).getText();
		
	}
	
	
	public static  void pcClick(String strButton1,String strButton2)
	{
		
		driver.findElement(By.xpath("//div[contains(@class,'"+strButton1+"') and contains(@class,'"+strButton2+"')]")).click();
		
	}
	public static String getPcBenefitsValue(String strPcText1,String strPcText2,String strPcText3)
	{
		return driver.findElement(By.xpath("(//div[contains(@class,'"+strPcText1+"') and contains(@class,'"+strPcText2+"')]//tr[contains(@class,'"+strPcText3+"')]/td[5]/span/span//span[text()])[1]")).getText();
		
	}
	public static String getPcBenefitsOop(String strPcName1,String strPcName2,String strPcName3)
	{
		return driver.findElement(By.xpath("//div[contains(@class,'"+strPcName1+"') and contains(@class,'"+strPcName2+"')]//tr[contains(@class,'"+strPcName3+"')]/td[7]/span")).getText();
		
	}
	
}
