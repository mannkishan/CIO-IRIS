package page.groupConfigurator;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import utility.CoreSuperHelper;
import utility.WebTable;

public class ContractSearchPage extends CoreSuperHelper{
	
	private static ContractSearchPage thisIsTestObj;
	public  synchronized static ContractSearchPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), ContractSearchPage.class);
		return thisIsTestObj;
		}
	@FindBy(how=How.XPATH,using="//a[@title='Create a new Contract']/span")
	@CacheLookup
	public WebElement createNewContract;
	
	@FindBy(how=How.ID,using="contractCode")
	@CacheLookup
	public WebElement contractCode;
	
	@FindBy(how=How.XPATH,using="//span[@class='btn_findGroup']/a/span[2]")
	@CacheLookup
	public WebElement search;
	
	@FindBy(how=How.LINK_TEXT,using="Contract Search")
	@CacheLookup
	public WebElement contractSearch;
	
	@FindBy(how=How.XPATH,using=".//*[@id='groupResults:0:resSelected']")
	public
	WebElement chk_row_1;
	
	@FindBy(how=How.XPATH,using=".//*[@id='groupResults:1:resSelected']")
	public
	WebElement chk_row_2;
	
	@FindBy(how=How.XPATH,using=".//*[@id='content']/div[3]/div[2]/span[2]/a[@title='Find Contracts for the supplied criteria.']")
	public
	WebElement button_Contract_Search;
	
	@FindBy(how=How.XPATH,using="//div[@id='groupResults']/table[@class=\"af_table_content\"]")
	public
	WebElement searchResults;
	
	@FindBy(how=How.XPATH,using=".//*[@id='groupResults']/table[2]/tbody/tr[2]")
	public
	WebElement row;
	
	@FindBy(how=How.XPATH,using=".//*[@id='groupResults']/table[2]/tbody/tr[2]/td[2]/a")
	public
	WebElement row_ContractResults_Table;
	
	
	
	
	/**
	 * @author AF12450
	 * This function is used to search the contract in the SPIDER GC application
	 * @param contractCode: Contract code that need to be found in GC 
	 */
	
	public void searchContract(String strContractCode)
	{
		seClick(contractSearch, "Click Contract Search link");
		seSetText(contractCode, strContractCode, "Set text for Contract Code");
		seClick(search, "Click Search button");
		List<WebElement> searchResult = getWebDriver().findElements(By.linkText(strContractCode));
		log(searchResult.size()>0?PASS:FAIL, "Search Contract","Search contract with contract code: "+strContractCode,true);
		if(searchResult.size()>0)
		{
			WebElement searchResults = getWebDriver().findElement(By.linkText(strContractCode));
			((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click();",searchResults);
		}
		
	}
	
	public boolean searchContract(String strContractCode,String status)
	{
		waitForPageLoad(300);
		seClick(contractSearch, "Click Contract Search link");
		seSetText(contractCode, strContractCode, "Set text for Contract Code");
		seClick(search, "Click Search button");
		seWaitForClickableWebElement(ContractSearchPage.get().searchResults, 120);
		WebTable searchResults = new WebTable(ContractSearchPage.get().searchResults, "Contract Search Results");
		if(searchResults.getRowsCount()>0)
		{
			List<WebElement> statusContract = getWebDriver().findElements(By.xpath("//*[@id=\"groupResults\"]/table[2]/tbody/tr[2]/td[3]/a"));
			if(statusContract.size()>0)
			{
				String textName = statusContract.get(0).getText();
				if(textName.equalsIgnoreCase(status))
				{
					return true;
				}
			}
			
		}
		
		return false;
		
	}
	
	
	public void seSearchContract(String strContractId){
		seClick(contractSearch, "Click Contract Search link");
		seSetText(contractCode, strContractId, "Set text for Contract Code");
		Select planCriteria=new Select(driver.findElement(By.xpath("//div/span[contains(text(),'Contract Criteria')]/..//select[1]")));
		planCriteria.selectByVisibleText("Status");
		waitForPageLoad();
		seClick(driver.findElement(By.xpath("//div/span[contains(text(),'Contract Criteria')]/..//select[1]/following::span[@class='ui-icon ui-icon-plus'][1]")), "+");
		Select statusCriteria=new Select(driver.findElement(By.xpath("//td[text()='Status']/following::select[1]")));
        statusCriteria.selectByVisibleText("Invalidated");
        seWaitForClickableWebElement(driver.findElement(By.xpath("//td[text()='Status']/preceding::input[@type='radio'][1]")), 5);
        seClick(driver.findElement(By.xpath("//td[text()='Status']/preceding::input[@type='radio'][1]")), "Exclude");
        seWaitForClickableWebElement(search, 15);
        seClick(search, "Click Search button");
		seWaitForClickableWebElement(getWebDriver().findElement(By.linkText(strContractId)), 30);
		List<WebElement> searchResult = getWebDriver().findElements(By.linkText(strContractId));
		log(searchResult.size()>0?PASS:FAIL, "Search Contract","Search contract with contract code: "+strContractId,true);		
	}
	
	public void seSearchContract(String strContractId,String ProxyId) throws InterruptedException{
		seClick(contractSearch, "Click Contract Search link");
		seSetText(contractCode, strContractId, "Set text for Contract Code");
		Select contractCriteria=new Select(driver.findElement(By.xpath("//div/span[contains(text(),'Plan Criteria')]/..//select[1]")));
		contractCriteria.selectByVisibleText("Proxy ID");
		waitForPageLoad();
	    new Actions(getWebDriver()).click(driver.findElement(By.xpath("//div/span[contains(text(),'Plan Criteria')]/..//span/a[1]"))).build().perform();
		waitForPageLoad();
	    seSetText(driver.findElement(By.xpath("//div/span[contains(text(),'Plan Criteria')]/..//span/a[1]/following::div/span/div/table//tr/td/span/input[contains(@class,'inputText')]")), ProxyId);
	    waitForPageLoad();
		Select planCriteria=new Select(driver.findElement(By.xpath("//div/span[contains(text(),'Contract Criteria')]/..//select[1]")));
		planCriteria.selectByVisibleText("Status");
		waitForPageLoad();
		seClick(driver.findElement(By.xpath("//div/span[contains(text(),'Contract Criteria')]/..//select[1]/following::span[@class='ui-icon ui-icon-plus'][1]")), "+");
		Select statusCriteria=new Select(driver.findElement(By.xpath("//td[text()='Status']/following::select[1]")));
        statusCriteria.selectByVisibleText("Invalidated");
        seWaitForClickableWebElement(driver.findElement(By.xpath("//td[text()='Status']/preceding::input[@type='radio'][1]")), 5);
        seClick(driver.findElement(By.xpath("//td[text()='Status']/preceding::input[@type='radio'][1]")), "Exclude");
        waitForPageLoad();
		seClick(search, "Click Search button");
		seWaitForClickableWebElement(getWebDriver().findElement(By.linkText(strContractId)), 30);
		List<WebElement> searchResult = getWebDriver().findElements(By.linkText(strContractId));
		log(searchResult.size()>0?PASS:FAIL, "Search Contract","Search contract with contract code: "+strContractId,true);
	}
	
	public  void sewaitForContractStatus(String strContractCode, String Status)
	{
		ExpectedCondition<Boolean> expectation = new  ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return searchContract(strContractCode,Status);
			}
		};

		WebDriverWait wait = new WebDriverWait(getWebDriver(), 600);
		wait.pollingEvery(5, TimeUnit.SECONDS);
		wait.until(expectation);

	}
	
	
	

}
