package page.groupConfigurator;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import utility.CoreSuperHelper;

public class ContractTransitionPage extends CoreSuperHelper{
	
	private static ContractTransitionPage thisIsTestObj;
	public  synchronized static ContractTransitionPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), ContractTransitionPage.class);
		return thisIsTestObj;
		}
	@FindBy(how=How.ID,using="ctrl_reason")
	@CacheLookup
	public WebElement reasonCode;
	
	@FindBy(how=How.ID,using="ctrl_comment")
	@CacheLookup
	public WebElement comment;
	
	@FindBy(how=How.XPATH,using="//span[@class='btn_okBtn']/a/span[2]")
	@CacheLookup
	public WebElement requestAudit;
	
	@FindBy(how=How.ID,using="ctrl_reason")
	@CacheLookup
	public WebElement approveAuditCode;
	
	@FindBy(how=How.XPATH,using=".//*[@id='mp_button']/a")
	@CacheLookup
	public WebElement buttonOk;
	
	public void selectReasonCode(String strReasonCode)
	{
		Select dropDown = new Select(reasonCode);
		dropDown.selectByValue(strReasonCode);
		int status = dropDown.getFirstSelectedOption().toString().equalsIgnoreCase(strReasonCode)?PASS:FAIL;
		log(status, "Select Reason Code", "Select"+strReasonCode+" from the Reason Code");
	}
	
	public void selectApproveAuditCode(String strReasonCode)
	{
		Select dropDown = new Select(approveAuditCode);
		dropDown.selectByValue(strReasonCode);
		int status = dropDown.getFirstSelectedOption().toString().equalsIgnoreCase(strReasonCode)?PASS:FAIL;
		log(status, "Select Approve Audit Code", "Select"+strReasonCode+" from the Approve audit Code");
	}
	
	
	public void clickOK(String buttonName) throws Exception
	{
		Actions act = new Actions(getWebDriver());
		act.moveToElement(ContractTransitionPage.get().requestAudit).build().perform();
		seClick(ContractTransitionPage.get().requestAudit, buttonName);
		Thread.sleep(2000);
		List<WebElement> approveTest = getWebDriver().findElements(By.xpath("//span[@class='btn_okBtn']/a/span[2]"));
		if(approveTest.size()>0)
		{
			approveTest.get(0).click();
		}
	}
	
	
	
	
	
	

}
