package page.groupConfigurator;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.SuperHelper;

public class HomePage extends SuperHelper{
	/**	
	 * <p>Singleton instance of this RFT Script (WGMMBRLU_SUBSCRIBER_DEPENDENT_ADD_COV) to support Interface (page Object) components.</p>
	 * <p>This is not required for DriverScript components.</p>
	 */
	private static HomePage thisIsTestObj;
	/**
	 * <p>Getter method for the singleton WGMMBRLU_SUBSCRIBER_DEPENDENT_ADD_COV instance.</p>
	 * @return the singleton instance of WGMMBRLU_SUBSCRIBER_DEPENDENT_ADD_COV
	 */
	public  synchronized static HomePage get() {
	thisIsTestObj =  PageFactory.initElements(getWebDriver(), HomePage.class);
	return thisIsTestObj;
	}
	
	
	@FindBy(how=How.LINK_TEXT,using="Group Bulk Update")
	public
	WebElement groupBulkUpdate;
		
	@FindBy(how=How.LINK_TEXT,using="Contract Search")
	public
	WebElement link_ContractSerach;
	
	@FindBy(how=How.XPATH,using=".//*[@id='main']")
	public
	WebElement mainDoc;
	
	@FindBy(how=How.XPATH,using="//div[4]/div[1]/span[2]/span/span/select")
	public
	WebElement contractCriteria;
	
	@FindBy(how=How.XPATH,using=".//*[@id='addOfferCrit']/span[1]")
	public
	WebElement addContractCriteria;
	
	@FindBy(how=How.XPATH,using="//div/table[2]/tbody/tr[2]/td[3]/span/select")
	public
	WebElement contractStatus;
	
	@FindBy(how=How.XPATH,using=".//*[@id='content']/div[4]/span")
	public
	WebElement resultErrorMessage;
	
	@FindBy(how=How.XPATH,using="//div[3]/div[1]/span[2]/span/span/select")
	public
	WebElement planCriteria;
	
	@FindBy(how=How.XPATH,using=".//*[@id='addPlanCrit']/span[1]")
	public
	WebElement addplanCriteria;
	
	@FindBy(how=How.XPATH,using="//div[@id='planCritTable']/table/tbody/tr[2]/td[3]/span/input[@class='af_inputText_content']")
	public
	WebElement planStatus;
	
	public boolean verifyContractResult(By testObject, Object className,int findCol,String findValue,String stepName)
	{

			try
			{
				WebElement table = driver.findElement(testObject);
				if(table != null)
				{
					List<WebElement> rows = table.findElements(By.tagName("tr"));
					System.out.println(rows.size());
					for(int i=2; i<= rows.size(); i++)
					{
					WebElement column = driver.findElement(By.xpath(".//*[@id='groupResults']/table[2]/tbody/tr["+i+"]/td["+findCol+"]"));
					String columnValue = column.getText();
					System.out.println(columnValue);
					if(columnValue.equals(findValue))
					{						
							return true;
					}
					}																		
				}
				else
				{
					setResult("STATUS", RESULT_STATUS);		
				}
			}
			catch(Exception e)
			{
				
			}
		return false;
		
	}
}
