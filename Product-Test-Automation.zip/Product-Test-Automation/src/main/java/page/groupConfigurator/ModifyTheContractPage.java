package page.groupConfigurator;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class ModifyTheContractPage extends CoreSuperHelper{
	
	private static ModifyTheContractPage thisIsTestObj;
	public  synchronized static ModifyTheContractPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), ModifyTheContractPage.class);
		return thisIsTestObj;
		}
	@FindBy(how=How.XPATH,using="//a[@title='Link Plan']/span")
	@CacheLookup
	public WebElement linkPlan;
	
	@FindBy(how=How.XPATH,using="//div[@id='addPlanMedicalDialog']/table/tbody/tr/td[2]/input")
	@CacheLookup
	public WebElement planID;
	
	@FindBy(how=How.XPATH,using="//div[@id='addPlanMedicalDialog']/div/span/a/span[2]")
	@CacheLookup
	public WebElement planLink;
	
	@FindBy(how=How.XPATH,using="//span[@class='btn_saveBtn_btm']/a/span[2]")
	@CacheLookup
	public WebElement save;
	
	@FindBy(how=How.ID,using="errorMessages")
	@CacheLookup
	public WebElement errorMessage;
	
	public boolean validateLinkPlan()
	{
		List<WebElement> errorMessage = getWebDriver().findElements(By.id("errorMessages"));
		int status = errorMessage.size()==0?PASS:FAIL;
		log(status, "Add Plan to contract", "Validate adding plan to contract", true);
		return status==1?true:false;
	}
	
	
	public boolean addPlanToContract(String strPlanID)
	{
		WebElement contract = ContractInformationPage.get().contract;
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click()", contract);
		/*seWaitForClickableWebElement(ContractInformationPage.get().contract, 60);
		seClick(ContractInformationPage.get().contract, "Contract Tab");*/
		seWaitForClickableWebElement(ContractInformationPage.get().addPlan, 60);
		seClick(ContractInformationPage.get().addPlan, "Add Plan");
		seWaitForClickableWebElement(ModifyTheContractPage.get().linkPlan, 60);
		seClick(ModifyTheContractPage.get().linkPlan, "Link Plan");
		seWaitForClickableWebElement(ModifyTheContractPage.get().planID, 60);
		seSetText(ModifyTheContractPage.get().planID, strPlanID, "Set text for plan id");
		seClick(ModifyTheContractPage.get().planLink, "Plan Link");
		boolean planAddStatus = ModifyTheContractPage.get().validateLinkPlan();
		seWaitForClickableWebElement(ModifyTheContractPage.get().save, 60);
		seClick(ModifyTheContractPage.get().save, "Save");
		return planAddStatus;
	}
	
	

}
