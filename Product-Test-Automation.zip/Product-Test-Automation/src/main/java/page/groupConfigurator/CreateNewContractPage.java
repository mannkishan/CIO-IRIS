package page.groupConfigurator;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class CreateNewContractPage extends CoreSuperHelper{
	
	private static CreateNewContractPage thisIsTestObj;
	public  synchronized static CreateNewContractPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), CreateNewContractPage.class);
		return thisIsTestObj;
		}
	@FindBy(how=How.ID,using="mpnEffDate")
	@CacheLookup
	public WebElement effectiveDate;
	
	@FindBy(how=How.ID,using="productLifecycleState")
	@CacheLookup
	public WebElement productLifeCycle;
	
	@FindBy(how=How.ID,using="approvalStatus")
	@CacheLookup
	public WebElement approvalStatus;
	
	@FindBy(how=How.ID,using="state")
	@CacheLookup
	public WebElement state;
	
	
	@FindBy(how=How.ID,using="mktSeg")
	@CacheLookup
	public WebElement marketSegment;
	
	@FindBy(how=How.XPATH,using="//div[@class='lobSelectSection']/div/span/select")
	@CacheLookup
	public WebElement lineOfBusiness;
	
	@FindBy(how=How.XPATH,using="//a[@title='Move items to the right']/span")
	@CacheLookup
	public WebElement moveToRight;
	
	
	
	@FindBy(how=How.ID,using="busEnt")
	@CacheLookup
	public WebElement businessEntity;
	
	@FindBy(how=How.ID,using="busUnit")
	@CacheLookup
	public WebElement businessUnit;
	

	@FindBy(how=How.XPATH,using="//span[@class='btn_retrieveCode']/a/span")
	@CacheLookup
	public WebElement nextAvailableCode;
	
	@FindBy(how=How.XPATH,using="//span[@class='btn_createMpnBtn']/a/span")
	@CacheLookup
	public WebElement create;
	
	
	
	
	
	
	
	
	
	
	
	

}
