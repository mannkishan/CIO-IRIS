package page.groupConfigurator;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.anthem.selenium.constants.BrowserConstants;
import com.anthem.selenium.utility.EnvHelper;

import page.planConfigurator.FindPlanPage;
import page.planConfigurator.HomePage;
import page.planConfigurator.LoginPage;
import page.planConfigurator.PlanHeaderPage;
import utility.CoreSuperHelper;
import utility.WebTable;

public class AutoRepublishPage extends CoreSuperHelper{
	

	static String strPcURL = EnvHelper.getValue("pc.url");
	static String strGcURL=EnvHelper.getValue("gc.url");
	static String strUserProfile = EnvHelper.getValue("user.profile");
	static String strUserProfileApprover = EnvHelper.getValue("user.profile.approver");
	
	private static AutoRepublishPage thisIsTestObj;
	public  synchronized static AutoRepublishPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), AutoRepublishPage.class);
		return thisIsTestObj;
		}

	@FindBy(how=How.XPATH,using="//button[@class='btn btn-sm history']")
	public
	WebElement history;
	
    @FindBy(how=How.XPATH,using="//div/div/span[text()='Medical']/../../div[@class='offerDetPlanBoxContents']/div//div/div")
	public
	WebElement medicalPlan;
    
    @FindBy(how=How.XPATH,using="/html/body/div[9]/div/div/div/div[1]/button[text()='�']")
	public
	WebElement closehistory;
    
	
	public String getRepublishedDate(String PlanId){
		 String datePc=driver.findElement(By.xpath("(//table[contains(@class,'table planTransitions dataTable')]/tbody/tr/td[text()='"+PlanId.trim()+"'])[1]/following::td[1]")).getText();
         String PcDate=datePc.split("\\s")[0];
         return PcDate;
	}
	
	public String seAutoRepublish_Plan_SentToTest(String contractId,String planName,int waitTime) throws InterruptedException, java.util.concurrent.TimeoutException{
		String[] strplan=planName.split("_");
        String proxyId=strplan[strplan.length-1];	
		seClick(HomePage.get().find, "Find");
		seClick(HomePage.get().findPlan, "Find Plan");
		waitForPageLoad();
		seSetText(FindPlanPage.get().planProxyId, proxyId);
	    seWaitForClickableWebElement(page.planConfigurator.FindPlanPage.get().planSearch, 14);
		seClick(page.planConfigurator.FindPlanPage.get().planSearch, "Search template");
		waitForPageLoad(40);
		seWaitForClickableWebElement(FindPlanPage.get().selectSearchedPlan, 14);
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);
		waitForPageLoad();
		PlanHeaderPage.get().seEditPlan();
		waitForPageLoad(45);
		PlanHeaderPage.get().seRequestAudit();
		try{seWaitForClickableWebElement(PlanHeaderPage.get().userLogout,waitTime);				
		    }
		catch(TimeoutException e){
            seClick(PlanHeaderPage.get().close, "Close button");
            waitForPageLoad();
            }
	    seClick(PlanHeaderPage.get().userNameHeader, " on Logged User Name");
		waitForPageLoad();
		seClick(PlanHeaderPage.get().userLogout, "Logout");
		waitForPageLoad(); 
		seCloseBrowser();
		seOpenBrowser(BrowserConstants.Chrome, strPcURL);							
            LoginPage.get().loginApplication(strUserProfileApprover);
	     	waitForPageLoad();
		    PlanHeaderPage.get().seMovePlanToSentToTest(proxyId);	
			return proxyId;

	}
	public String seAutoRepublish_RequestAudit(String contractId,String planName,int waitTime) throws InterruptedException{
		String[] strplan=planName.split("_");
        String proxyId=strplan[strplan.length-1];	
		seClick(HomePage.get().find, "Find");
		seClick(HomePage.get().findPlan, "Find Plan");
		waitForPageLoad();
		seSetText(FindPlanPage.get().planProxyId, proxyId);
	    seWaitForClickableWebElement(page.planConfigurator.FindPlanPage.get().planSearch, 14);
		seClick(page.planConfigurator.FindPlanPage.get().planSearch, "Search template");
		waitForPageLoad(40);
		seWaitForClickableWebElement(FindPlanPage.get().selectSearchedPlan, 14);
		((JavascriptExecutor) getWebDriver()).executeScript("arguments[0].click();", FindPlanPage.get().selectSearchedPlan);
		waitForPageLoad();
		PlanHeaderPage.get().seEditPlan();
		waitForPageLoad(45);
		PlanHeaderPage.get().seRequestAudit();
		try{seWaitForClickableWebElement(PlanHeaderPage.get().userLogout,waitTime);				
		    }
		catch(TimeoutException e){
            seClick(PlanHeaderPage.get().close, "Close button");
            waitForPageLoad();
            }
		return proxyId;
	}
}
