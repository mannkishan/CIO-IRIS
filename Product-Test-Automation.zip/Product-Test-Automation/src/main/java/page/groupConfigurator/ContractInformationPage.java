package page.groupConfigurator;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import utility.CoreSuperHelper;

public class ContractInformationPage extends CoreSuperHelper{
	
	private static ContractInformationPage thisIsTestObj;
	public  synchronized static ContractInformationPage get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), ContractInformationPage.class);
		return thisIsTestObj;
		}
	@FindBy(how=How.XPATH,using="//*[@id=\"content\"]/div[2]/span[2]")
	@CacheLookup
	public WebElement contractCode;
	
	@FindBy(how=How.XPATH,using="//a[@title='Show Administration']")
	@CacheLookup
	public WebElement adminTab;
	
	
	@FindBy(how=How.XPATH,using="//a[@title='Show Plan Administration']")
	@CacheLookup
	public WebElement planAdmin;
	
	@FindBy(how=How.ID,using="ctrl_lifetimeLimitRestriction")
	@CacheLookup
	public WebElement adminLifetimeLimitRestriction;
	
	@FindBy(how=How.ID,using="ctrl_preExisting")
	@CacheLookup
	public WebElement adminPreExisting;
	
	@FindBy(how=How.ID,using="ctrl_liabilityPriorityRule")
	@CacheLookup
	public WebElement adminLiabilityPriorityRule;
	
	
	@FindBy(how=How.ID,using="ctrl_qhpIndicator")
	@CacheLookup
	public WebElement adminQHPIndicator;
	

	@FindBy(how=How.ID,using="ctrl_qhpVariation")
	@CacheLookup
	public WebElement adminQHP;
	
	@FindBy(how=How.ID,using="ctrl_productMarketingName")
	@CacheLookup
	public WebElement adminProductMarketName;
	
	@FindBy(how=How.ID,using="ctrl_productMarketingCode")
	@CacheLookup
	public WebElement adminProductMarketCode;
	
	@FindBy(how=How.ID,using="ctrl_companyCode")
	@CacheLookup
	public WebElement adminCompanyCode;
	
	@FindBy(how=How.ID,using="ctrl_coverageLimitedTo")
	@CacheLookup
	public WebElement adminCoverageLimitedTo;
	
	@FindBy(how=How.ID,using="ctrl_maxEnrollmentAge")
	@CacheLookup
	public WebElement adminMaximumEnrollmentAge;
	
	@FindBy(how=How.ID,using="ctrl_salesEffectiveDate")
	@CacheLookup
	public WebElement adminSalesEffective;
	
	@FindBy(how=How.XPATH,using="//div[@id='offer_model_det']/span[1]/span[2]")
	@CacheLookup
	public WebElement PLCState;
	
	@FindBy(how=How.XPATH,using="//span[@class='btn_saveBtn']/a/span[2]")
	@CacheLookup
	public WebElement adminSave;
	
	@FindBy(how=How.XPATH,using="//table[@id='critRelValueRangeTable']/tbody/tr[1]/td[1]/span/select")
	@CacheLookup
	public WebElement adminPricerCoverage;
	
	@FindBy(how=How.XPATH,using="//table[@id='critRelValueRangeTable']/tbody/tr[1]/td[2]/span/select")
	@CacheLookup
	public WebElement adminPricerCode;
	
	@FindBy(how=How.XPATH,using="//table[@id='critRelValueRangeTable']/tbody/tr[1]/td[3]/span/select")
	@CacheLookup
	public WebElement adminPricerNetwork;
	
	@FindBy(how=How.XPATH,using="//a[@title='Show Contract']")
	@CacheLookup
	public WebElement contract;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"offerTable\"]/table[2]/tbody/tr[2]/td[2]/span/a")
	@CacheLookup
	public WebElement addPlan;
	
	@FindBy(how=How.XPATH,using="//span[@class='btn_reqAuditBtn']/a/span[2]")
	@CacheLookup
	public WebElement requestAudit;
	
	@FindBy(how=How.ID,using="ctrl_cdhVendor")
	@CacheLookup
	public WebElement CDHVendro;
	
	@FindBy(how=How.ID,using="ctrl_hraPaymentOption")
	@CacheLookup
	public WebElement HRAPaymentOption;
	
	@FindBy(how=How.XPATH,using="//div[@class='infoArea']/span[@class='rightAligned']")
	@CacheLookup
	public WebElement contractStatus;
	
	
	@FindBy(how=How.XPATH,using="//a[@title='Show Plan Administration']")
	@CacheLookup
	public WebElement contractPlanAdmin;
	
	@FindBy(how=How.XPATH,using="//span[@class='btn_apvAuditBtn']/a/span[2]")
	@CacheLookup
	public WebElement approveAudit;
	
	@FindBy(how=How.XPATH,using="//span[@class='btn_mvToTestBtn']/a/span[2]")
	@CacheLookup
	public WebElement moveToTest;
	
	@FindBy(how=How.XPATH,using="//span[@class='btn_apvTestBtn']/a/span[2]")
	@CacheLookup
	public WebElement approveTest;
	
	@FindBy(how=How.XPATH,using="//span[@class='btn_finalizeBtn']/a/span[2]")
	@CacheLookup
	public WebElement finalize;
	
	@FindBy(how=How.XPATH,using="//span[@class='btn_editMpnBtn']/a/span[@class='btnTxt']")
	@CacheLookup
	public WebElement editContract;
	
	@FindBy(how=How.ID,using="ctrl_employerHealthAcctContribution")
	@CacheLookup
	public WebElement empHealthAccountContribution;
	
	@FindBy(how=How.XPATH,using="//div[@id='offer_model_det']/span[2]/span[2]")
	@CacheLookup
	public WebElement approvalStatus;
	
	@FindBy(how=How.LINK_TEXT,using="Contact Info")
	public
	WebElement contactinfotab;
	
	@FindBy(how=How.XPATH,using="html/body/form/div/div[2]/div[4]/div[1]/div[2]/div/table[2]/tbody")
	public
	WebElement proxyIDtable;
	
	@FindBy(how=How.XPATH,using=".//*[@id='content']")
	public
	WebElement cont_inf;
	
	@FindBy(how=How.PARTIAL_LINK_TEXT,using="Plan Admin")
	public
	WebElement planAdminTabLink;
	
	@FindBy(how=How.PARTIAL_LINK_TEXT,using="Waiting Periods")
	public
	WebElement waitingPerTabLink;
	
	public void validateContractStatus(String strExpectedStatus)
	{
		seWaitForWebElement(60, ExpectedConditions.elementToBeClickable(contractStatus));
		String strActualStatus = seGetText(contractStatus);
		
		log(strActualStatus.contains(strExpectedStatus)?PASS:FAIL, "Validate Contract status", "Verify contract status is "+strExpectedStatus+" Actual status: "+strActualStatus, true);
	}
	
	/**
	 * @author AF14735
	 * This method will validated the edited changes in the contract.
	 * @return
	 */
	public void validateEditContract(String CDHVendor, String HRAPayment, String EmpHealthAccountContribution){
		seClick(ContractInformationPage.get().adminTab, "Admin");
        Actions action=new Actions(getWebDriver());
        action.moveToElement(ContractInformationPage.get().CDHVendro).perform();
		String strCDHVendor=seGetText((ContractInformationPage.get().CDHVendro)).toString().trim();
		log(strCDHVendor.equalsIgnoreCase(CDHVendor)?PASS:FAIL, "Validate CDHVendor", "Verify CDHVendor value is "+CDHVendor+" Actual Value: "+strCDHVendor, true);
		String strHRAPaymentOption=seGetText((ContractInformationPage.get().HRAPaymentOption)).toString().trim();
		log(strHRAPaymentOption.equalsIgnoreCase(HRAPayment)?PASS:FAIL, "Validate HRAPayment", "Verify HRAPayment value is "+HRAPayment+" Actual Value: "+strHRAPaymentOption, true);
		String strEmpHealthAccountContribution=seGetText((ContractInformationPage.get().empHealthAccountContribution)).toString().trim();
		log(strEmpHealthAccountContribution.equalsIgnoreCase(EmpHealthAccountContribution)?PASS:FAIL, "Validate EmpHealthAccountContribution", "Verify EmpHealthAccountContribution value is "+EmpHealthAccountContribution+" Actual Value: "+strEmpHealthAccountContribution, true);
	}
	
	
	
	
	
	
	
	
	
	/**
	 * @author AF12450
	 * This method will return the contract code and can be used after the create button is clicked in Create Contract page
	 * @return
	 */
	public String getContractCode()
	{
		seWaitForWebElement(120, ExpectedConditions.elementToBeClickable(contractCode));
		String code =seGetElementValue(contractCode).split(":")[1].trim();
		return code;
	}

}
