package page.groupConfigurator;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import utility.CoreSuperHelper;

public class ContractPlanAdmin extends CoreSuperHelper{
	
	private static ContractPlanAdmin thisIsTestObj;
	public  synchronized static ContractPlanAdmin get() {
		 thisIsTestObj = PageFactory.initElements(getWebDriver(), ContractPlanAdmin.class);
		return thisIsTestObj;
		}
	@FindBy(how=How.ID,using="ctrl_memberProductCode")
	@CacheLookup
	public WebElement memberProductCode;
	
	@FindBy(how=How.ID,using="ctrl_benefitPlanCode")
	@CacheLookup
	public WebElement benefitPlanCode;
	
	@FindBy(how=How.ID,using="ctrl_networkId")
	@CacheLookup
	public WebElement networkID;
	
	@FindBy(how=How.ID,using="ctrl_thirdPartyLiability")
	@CacheLookup
	public WebElement thirdPartyLiability;
	
	@FindBy(how=How.ID,using="ctrl_premiumEHB")
	@CacheLookup
	public WebElement premiumEHB;
	
	@FindBy(how=How.ID,using="ctrl_premiumStateMandate")
	@CacheLookup
	public WebElement premiumStateMandatedBenefits;
	
	@FindBy(how=How.ID,using="ctrl_premiumNonStateMandate")
	@CacheLookup
	public WebElement premiumNonStateMandatedBenefits;
	
	
	@FindBy(how=How.XPATH,using="//span[@class='btn_saveBtn']/a/span[2]")
	@CacheLookup
	public WebElement save;
	
	
	public void updatePlanDetails()
	{
		seClick(ContractInformationPage.get().contractPlanAdmin, "Click Plan Admin Tab");
		seWaitForClickableWebElement(ContractPlanAdmin.get().memberProductCode, 20);
		//seSelectText(ContractPlanAdmin.get().memberProductCode, "BMFP", "Select BMFP for Memeber Product Code");
		seSelectText(ContractPlanAdmin.get().memberProductCode, "BMFP", "Select BMFP for Memeber Product Code", 60);
		seSetText(true,ContractPlanAdmin.get().benefitPlanCode, "0000", "Set text for the Benefit Plan code");
		if(!seGetElementValue(benefitPlanCode).equalsIgnoreCase("0000"))
		{
		seSetText(true,ContractPlanAdmin.get().benefitPlanCode, "0000", "Set text for the Benefit Plan code");
		}
		seWaitForClickableWebElement(benefitPlanCode, 60);
		seSelectText(ContractPlanAdmin.get().networkID, "BCCADV00", "Select BCCADV00 for Network ID");
		seSelectText(ContractPlanAdmin.get().thirdPartyLiability, "Yes", "Select value from Third Party Liability");
		seSelectText(ContractPlanAdmin.get().premiumEHB, "Yes", "Select value from Premium EHB");
		seSelectText(ContractPlanAdmin.get().premiumStateMandatedBenefits, "Yes", "Select value from Premium State Mandated Benefits");
		seSelectText(ContractPlanAdmin.get().premiumNonStateMandatedBenefits, "Yes", "Select value from Premium Non State Mandated Benefits");
		seWaitForClickableWebElement(ContractPlanAdmin.get().save, 30);
		WebElement Save = ContractPlanAdmin.get().save;
		((JavascriptExecutor)getWebDriver()).executeScript("arguments[0].click()", Save);
	}

}
