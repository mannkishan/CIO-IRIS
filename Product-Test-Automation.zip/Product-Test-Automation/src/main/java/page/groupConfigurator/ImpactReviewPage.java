package page.groupConfigurator;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.SuperHelper;

public class ImpactReviewPage extends SuperHelper{
	
	/**	
	 * <p>Singleton instance of this Page class (WGMMBRLU_SUBSCRIBER_DEPENDENT_ADD_COV) to support Interface (page Object) components.</p>
	 */
	private static ImpactReviewPage thisIsTestObj;
	/**
	 * <p>Getter method for the singleton Impact Review instance.</p>
	 * @return the singleton instance of Impact Review 
	 */
	public  synchronized static ImpactReviewPage get() {
	thisIsTestObj =  PageFactory.initElements(driver, ImpactReviewPage.class);
	return thisIsTestObj;
	}
	
	@FindBy(how=How.LINK_TEXT,using="Impact Review")
	public
	WebElement impactReview;
	
	
	@FindBy(how=How.XPATH,using=".//*[@id='tab_']/span[1]/span/a[2]")
	public
	WebElement historyTab;

}
