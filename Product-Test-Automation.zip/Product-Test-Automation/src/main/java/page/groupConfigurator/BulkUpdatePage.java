package page.groupConfigurator;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.anthem.selenium.SuperHelper;

public class BulkUpdatePage extends SuperHelper{
	
	/**	
	 * <p>Singleton instance of this RFT Script (WGMMBRLU_SUBSCRIBER_DEPENDENT_ADD_COV) to support Interface (page Object) components.</p>
	 * <p>This is not required for DriverScript components.</p>
	 */
	private static BulkUpdatePage thisIsTestObj;
	/**
	 * <p>Getter method for the singleton WGMMBRLU_SUBSCRIBER_DEPENDENT_ADD_COV instance.</p>
	 * @return the singleton instance of WGMMBRLU_SUBSCRIBER_DEPENDENT_ADD_COV
	 */
	public  synchronized static BulkUpdatePage get() {
	thisIsTestObj =  PageFactory.initElements(driver, BulkUpdatePage.class);
	return thisIsTestObj;
	}

	@FindBy(how=How.ID,using="effThru")
	public
	WebElement effectiveThrough;
		
	@FindBy(how=How.XPATH,using="//div[6]/div[1]/span[2]/span/span/select")
	public
	WebElement adminCriteriaDropDown;
	
	@FindBy(how=How.XPATH,using="//*[@id='addAdminCrit']/span[1]")
	public
	WebElement addAdminCriteria;
	
	@FindBy(how=How.XPATH,using="//table[2]/tbody/tr[2]/td[3]/span/select[contains(@id,'adminCritTable')]")
	public
	WebElement adminCriteriaValue;

	@FindBy(how=How.XPATH,using="//span/a[@title='Find Contracts for the supplied criteria.']")
	public
	WebElement contractSearch;
	
	@FindBy(how=How.XPATH,using=".//*[@id='groupResults']/table/tbody/tr/td/table[@class='af_table_content']")
	public
	WebElement searchResults;

	@FindBy(how=How.CLASS_NAME,using="af_table_content")
	public
	WebElement impactRevewDetails;

	@FindBy(how=How.XPATH,using="//div[2]/div[3]/div[2]/a")
	public
	WebElement exportResults;
	
	@FindBy(how=How.XPATH,using="//div[4]/div[1]/span[2]/span/span/select")
	public
	WebElement planCriteria;
	
	@FindBy(how=How.XPATH,using="//select[contains(@id,'planCritTable')][contains(@class,'af_selectOneChoice_content')]")
	public
	WebElement planCriteria2;
	
	@FindBy(how=How.XPATH,using="//a[@id='addPlanCrit']/span[1]")
	public
	WebElement addPlanCriteria;
	
	@FindBy(how=How.XPATH,using="//div[7]/div[1]/span[2]/span/span/select")
	public
	WebElement planAdminCriteriaDropDown;

	@FindBy(how=How.XPATH,using="//a[@id='addPlanAdminCrit']/span[1]")
	public
	WebElement addPlanAdminCriteria;
	
	@FindBy(how=How.XPATH,using=".//select[@id='planAdminCritTable:0:j_id340']")
	public
	WebElement planAdminCritTabCol3;
	
	@FindBy(how=How.XPATH,using=".//select[@id='planAdminCritTable:0:j_id344']")
	public
	WebElement planAdminCritTabCol4;
	
	@FindBy(how=How.XPATH,using=".//select[@id='j_id349']")
	public
	WebElement waitingPeriodDropdown;
	
	@FindBy(how=How.XPATH,using="//a[@id='addWaitingPeriodCrit']/span[1]")
	public
	WebElement addWaitingPeriod;
	
	@FindBy(how=How.XPATH,using=".//select[@id='wpCritTable:0:j_id363']")
	public
	WebElement waitingPeriodTabCol3;
	
	@FindBy(how=How.XPATH,using=".//select[@id='wpCritTable:0:j_id367']")
	public
	WebElement waitingPeriodTabCol4;

	@FindBy(how=How.XPATH,using=".//*[@id='content']/div[3]/div[3]/span/a")
	public
	WebElement button_Search;
	
	@FindBy(how=How.XPATH,using="//input[contains(@id,'planCritTable')][@class='af_inputText_content']")
	public
	WebElement proxyIdValue;
	
	@FindBy(how=How.LINK_TEXT,using="Update Selected Contracts")
	public
	WebElement UpdateSelectedContracts;
	
	@FindBy(how=How.LINK_TEXT,using="Next 25")
	public
	WebElement Next25_Link;
	
	@FindBy(how=How.XPATH,using=".//*[@id='content']/div[4]")
	public
	WebElement searchResult;
	
	@FindBy(how=How.XPATH,using=".//*[@id='content']/div[4]/div[1]/span[1]/a[1]")
	public
	WebElement link_SelectAll;
	
	@FindBy(how=How.XPATH,using="//select[contains(@id,'planCritTable:0')][contains(@class,'af_selectOneChoice_content')]")
	public
	WebElement dropDown_LOB;
	
	@FindBy(how=How.XPATH,using="//select[contains(@id,'planCritTable:1')][contains(@class,'af_selectOneChoice_content')]")
	public
	WebElement dropDown_State;
	
	@FindBy(how=How.XPATH,using="//div[5]/div[1]/span[2]/span/span/select")
	public
	WebElement contractCriteria;
	
	@FindBy(how=How.XPATH,using="//a[@id='addOfferCrit']/span[1]")
	public
	WebElement addContractCriteria;
	
	@FindBy(how=How.XPATH,using="//select[contains(@id,'offerCritTable:1')][contains(@class,'af_selectOneChoice')]")
	public
	WebElement dropDown_MarketSegment;
	
	@FindBy(how=How.XPATH,using="//div[9]/div[1]/span[2]/span/span/select")
	public
	WebElement dropDown_ContactInfoCriteria;
	
	@FindBy(how=How.XPATH,using="//a[@id='addContactCrit']/span[1]")
	public
	WebElement addContactInfoCriteria;

	@FindBy(how=How.XPATH,using="//*[@id='ciCritTable:0:orgValue']")
	public
	WebElement dropDown_Name_OrgValue;
	
	@FindBy(how=How.XPATH,using="//table[@class='af_table_content']/tbody/tr[2]/td[2]/span/select[@id='ciCritTable:0:role']")
	public
	WebElement dropDown_Role_OrgValue;	

	@FindBy(how=How.ID,using="ciCritTable:0:j_id383")
	public
	WebElement dropDown_Role_ContactInfo;
	
	@FindBy(how=How.ID,using="ciCritTable:0:perValue")
	public
	WebElement dropDown_Name_Person;
	
	@FindBy(how=How.ID,using="ciCritTable:0:j_id383")
	public
	WebElement dropDown_Role_Person;
	
	@FindBy(how=How.XPATH,using=".//*[@id='errorMessages']/div")
	public
	WebElement errorMsg;
	
	@FindBy(how=How.ID,using="offerCritTable:1:j_id301")
	public
	WebElement dropDown_PLCState;
	
	@FindBy(how=How.XPATH,using="//div[5]/div[2]/span/div/table[2]/tbody/tr[3]/td[3]/span/select")
	public
	WebElement approvalStatus;
	
	@FindBy(how=How.XPATH,using="//table[2]/tbody/tr[2]/td[3]/span/select")
	public
	WebElement newApprovalStatus;
	
	@FindBy(how=How.XPATH,using="//div[2]/div[2]/div/table[2]")
	public
	WebElement historyDetails;
	
	@FindBy(how=How.XPATH,using="//table[2]/tbody/tr[2]/td[3]/span/select")
	public
	WebElement newPLCStatus;
	
	@FindBy(how=How.XPATH,using="//div/div[2]/div[1]/span[2]/select")
	public
	WebElement reasonCode;

	@FindBy(how=How.XPATH,using="//span[@class='btn_submit']/a")
	public
	WebElement bulkUpdateSubmit;
	
	@FindBy(how=How.ID,using="currEffDate")
	public
	WebElement currentEffectiveDate;

	@FindBy(how=How.ID,using="effDate")
	public
	WebElement effectiveDate; 
	
	@FindBy(how=How.ID,using="planCritTable:0:j_id264")
	public
	WebElement replaceValue;

	@FindBy(how=How.ID,using="adminCritTable:0:j_id287")
	public
	WebElement adminCritReplacevalue;

	@FindBy(how=How.ID,using="planAdminCritTable:0:j_id300")
	public
	WebElement planAdminCritReplacevalue;
	
	@FindBy(how=How.ID,using="waitingPeriodCritTable:0:j_id313")
	public
	WebElement waitingPerReplacevalue;

	@FindBy(how=How.LINK_TEXT,using="History")
	public
	WebElement clickHistory;
	
	@FindBy(how=How.XPATH,using=".//*[@id='mp_transition']/span/span/span/div/div")
	public
	WebElement WarningMsg;

	@FindBy(how=How.LINK_TEXT,using="Yes")
	public
	WebElement yesLink;
	
	@FindBy(how=How.LINK_TEXT,using="No")
	public
	WebElement noLink;

	@FindBy(how=How.XPATH,using=".//*[@id='errorMessages']/div")
	public
	WebElement errorMessage;
	
	@FindBy(how=How.ID,using="planCritTable:0:j_id264")
	public
	WebElement replaceProxyValue;
	
	@FindBy(how=How.ID,using="ciCritTable:0:role")
	public
	WebElement orgrole;

	@FindBy(how=How.ID,using="ciCritTable:0:role")
	public
	WebElement per_role;

	@FindBy(how=How.ID,using="ciCritTable:0:communication")
	public
	WebElement communication;
	
	@FindBy(how=How.XPATH,using="//table[@class='af_table_content']/tbody/tr[2]/td[4]/span/input[@id='ciCritTable:0:extension']")
	public
	WebElement ext;
	
	@FindBy(how=How.LINK_TEXT,using="Impact Review")
	public
	WebElement impactReview;
	
	
	public void recordSelection(int recordCount)
	{		
			try
			{
				for(int i=0; i<recordCount; i++)
				{
					if(i<24){
						WebElement element =driver.findElement(By.xpath(".//*[@id='groupResults:"+i+":resSelected']"));
						element.click();
						Thread.sleep(1000);
						//Web.get().SPIDERPC_WaitForPageLoad();
					}
					else if(i==24){
						WebElement element =driver.findElement(By.xpath(".//*[@id='groupResults:"+i+":resSelected']"));
						element.click();
//						GC_LOGIN.get().waitForPageLoad();	
						seClick(BulkUpdatePage.get().Next25_Link, "Next25_Link");
//						GC_LOGIN.get().waitForPageLoad();
					}
					else if(i>24&&i<49)
					{
						WebElement element =driver.findElement(By.xpath(".//*[@id='groupResults:"+(i-25)+":resSelected']"));
						element.click();
						Thread.sleep(1000);
						//	Web.get().SPIDERPC_WaitForPageLoad();	
					}
					else if(i==49){
						WebElement element =driver.findElement(By.xpath(".//*[@id='groupResults:"+(i-25)+":resSelected']"));
						element.click();
//						GC_LOGIN.get().waitForPageLoad();	
						seClick(BulkUpdatePage.get().Next25_Link, "Next25_Link");
//						GC_LOGIN.get().waitForPageLoad();	
					}
					else if(i>49)
					{
						WebElement element =driver.findElement(By.xpath(".//*[@id='groupResults:"+(i-50)+":resSelected']"));
						element.click();
						Thread.sleep(1000);
						//Web.get().SPIDERPC_WaitForPageLoad();	
					}

				}
			

			}
			catch(Exception e)
			{
				e.getLocalizedMessage();
				
			}
		
	}


	public boolean recordFound()
	{
		boolean found =false;
			try{
				if(seGetElementValue(BulkUpdatePage.get().searchResult).toString().contains("No Plans meet the entered criteria"))
				{
                   found =false;					
				}
				else{
					found =true;					
				}

			}catch(Exception e)
			{
                   e.getLocalizedMessage();

			}		
		return found;
	}

	

	/**
	 * This method validates the table header in the WEB application.
	 * @param testObject: variable holding the locator value of the table object that needs to be validated
	 * @param className: Name of the class where testobject present
	 * @param header: Header values that needs to be validated in the object
	 * @param stepName: reporting purpose
	 */
	public void VerifyTableHeader(WebElement ele,Object classname, String header,String stepName)
	{
		ArrayList<String> failedHeader = new ArrayList<>();		
		boolean result = false;
		
			try
			{
				WebElement table = driver.findElement(By.xpath(""));
				if(table != null)
				{
					List<WebElement> columns = table.findElements(By.xpath("//tr[1]/th"));
					String[] expectedValue = header.split(",");
					for(int i = 0; i< expectedValue.length; i++)
					{
						String actual  = "";
					for(int index = 0; index<columns.size(); index++)
					{
						actual = columns.get(index).getText();
						if(actual.equals(expectedValue[i]))
						{
							result = true;
							break;
						}
					}
					
					if(!result)
					{
						failedHeader.add(expectedValue[i]);
					}
					else
					{
						result = false;
					}
					
					}
					
					if(! (failedHeader.size()>0))
					{
						
						String testStepResultText = "Expected values"+header+ " are present in the table";
						setResult(testStepResultText, RESULT_STATUS);
					}
					else
					{
						String failedValues = "";
						for(int i =0; i< failedHeader.size(); i++ )
						{
							failedValues= failedHeader.get(i)+","+failedValues;
						}
						
						String testStepResultText = "Expected values"+failedValues+ " are not present in the table";
						setResult(testStepResultText, RESULT_STATUS);
					}
				}
				else
				{
					
					String testStepResultText = "Not able to identify the table with given properties";
					setResult(testStepResultText, RESULT_STATUS);
				}
			}
			catch(Exception e)
			{
				e.getLocalizedMessage();
				
			}		
	}
	
	protected static String getDeclaredVariableName(WebElement testObject,
			Object testClass) {
		String varName = "";
		java.lang.reflect.Field[] fields = testClass.getClass()
				.getDeclaredFields();
		for (int i = 0; i < fields.length; i++) {
			try {
				if (fields[i] != null && fields[i].get(testClass) != null) {
					if (fields[i].get(testClass).toString()
							.equalsIgnoreCase(testObject.toString())) {
						varName = fields[i].getName();
						break;
					}
				}
			} catch (java.lang.IllegalAccessException e) {
				e.printStackTrace();
			}
		}
		return varName;
	}
}
